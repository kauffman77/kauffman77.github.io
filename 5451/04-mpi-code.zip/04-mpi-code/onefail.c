// onefail.c: Illustrate the behavior of an MPI run when one of the
// processors fails due to errors (segfault in this case).

#include <stdio.h>
#include <unistd.h>
#include <mpi.h>

int *ptr = NULL;

int main (int argc, char *argv[]){
  int rank;                     // the id of this processor
  int size;                     // the number of processors being used

  MPI_Init (&argc, &argv);               // starts MPI
  MPI_Comm_rank (MPI_COMM_WORLD, &rank); // get current process id
  MPI_Comm_size (MPI_COMM_WORLD, &size); // get number of processes

  while(1){                     // all processors loop infinitely
    printf( "Proc %d of %d says 'Hello world'\n", rank, size );
    sleep(1);

    if(rank == size-1){         // last processor generates
      *ptr = 42;                // a segfault
    }

  }

  MPI_Finalize();
  return 0;
}
