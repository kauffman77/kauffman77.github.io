#include <sys/time.h>

static struct timeval tv; 
static struct timezone tz; 
static double time_start, time_end; 

void start_walltime(){
  gettimeofday(&tv, &tz); 
  time_start = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0; 
}

double elapsed_walltime(){
  gettimeofday(&tv, &tz); 
  time_end = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0; 
  return time_end - time_start;
}

