/* Runs two fibonacci number calculations, one with the standard
   recursive implementation, and one with the Cilk-plus extension
   which spawned threads to partially parallelize the computation.
   Timing information for each is printed.

   SAMPLE RUN:
   lila [test-code]% bgcc -fcilkplus cilk-fib.c
   lila [test-code]% a.out 48
   Standard
   fib(48) = 512559680
   Time:    49.31
   Cilk
   fib(48) = 512559680
   Time:    20.18
*/

#include <stdio.h>
#include <stdlib.h>
#include <cilk/cilk.h>

// Bring in functions to start and stop walltime 
#include "walltime.c"           

int fib(int n) {
  if (n < 2) return n;
  int x = fib(n-1);
  int y = fib(n-2);
  return x + y;
}

int cilk_fib(int n) {
  if (n < 2) return n;
  int x = cilk_spawn cilk_fib(n-1);
  int y = fib(n-2);
  cilk_sync;
  return x + y;
}

int main(int argc, char **argv){
  int fn,n;
  double tm;
  n = atoi(argv[1]);

  printf("Standard\n");
  start_walltime();
  fn = fib(n);
  tm = elapsed_walltime();
  printf("fib(%d) = %d\n",n,fn);
  printf("Time: %8.2f\n",tm);

  printf("Cilk\n");
  start_walltime();
  fn = cilk_fib(n);
  tm = elapsed_walltime();
  printf("fib(%d) = %d\n",n,fn);
  printf("Time: %8.2f\n",tm);

  return 0;
}
