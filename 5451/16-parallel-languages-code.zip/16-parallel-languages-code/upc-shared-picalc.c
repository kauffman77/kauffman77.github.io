// Demo of Unified Parallel C constructs. This example should run
// identically on both a shared memory machine, a distributed memory
// cluster, or a mixture of the two.

#include <stdio.h>
#include <math.h>
#include <upc.h>

// Array shared accross all threads even if distributed accross
// multiple machines. Sets up implicit communication via message
// passing of values in the shared memory area.
shared int all_hits [THREADS];

int main(int argc, char **argv) {
  int npoints = atoi(argv[1]);

  // Initialization of local variable based on thread id
  unsigned int state = 123456789 * MY_THREAD;

  upc_forall(i=0; i < npoints; i++){
    double x = ((double) rand_r(&state)) / ((double) RAND_MAX);
    double y = ((double) rand_r(&state)) / ((double) RAND_MAX);
    if (x*x + y*y <= 1.0){
      all_hits[MYTHREAD]++;     // update to shared array
    }
  }

  if (MYTHREAD == 0) {
    int total_hits = 0;
    for (i=0; i < THREADS; i++){
      // Automatic communication of shared blocks via message passing
      // if needed 
      total_hits += all_hits[i]; 
    }
    double pi_est = ((double)total_hits) / npoints * 4.0;
    printf("npoints: %8d\n",npoints);
    printf("hits:    %8d\n",total_hits);
    printf("pi_est:  %f\n",pi_est);
  }
}
