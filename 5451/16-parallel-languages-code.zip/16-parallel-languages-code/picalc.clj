;; Serial version with atomic updates
(defn calc-pi-atoms [iterations]
  (let [hits (atom 0)]
    (dotimes [i iterations]
      (let [x (rand) y (rand)]
        (if (<= (+ (* x x) (* y y)) 1)
          (swap! hits inc))))
    (double (* (/ @hits iterations) 4))))

;; Parallel version with atomic updates
(defn calc-pi-atoms [iterations nthreads]
  (let [hits (atom 0)]
    (doall (pmap ;; parallel map, force evaluation
      (fn [x]
        (dotimes [i (/ iterations nthreads)]
          (let [x (rand) y (rand)]
            (if (<= (+ (* x x) (* y y)) 1)
              (swap! hits inc)))))
      (range nthreads))) ;; map onto number of threads
    (double (* (/ @hits iterations) 4))))
