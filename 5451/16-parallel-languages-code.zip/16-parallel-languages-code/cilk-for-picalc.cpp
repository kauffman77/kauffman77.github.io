// Demonstrate use of cilk_for loop to do paralle pi computations Also
// use the reducer variable type to perform efficient updates.
// 
// Compile:
// > g++ cilk-for-picalc.cpp -fcilkplus 
#include <stdio.h>
#include <stdlib.h> 
#include <cilk/cilk.h>
#include <cilk/reducer_opadd.h>

int main(int argc, char **argv) { 
  if(argc < 2){
    printf("usage: cilk_picalc <num_samples> [threads]\n");
    printf("  num_samples: int, how many sample points to try, higher gets closer to pi\n");
    printf("  threads: how many threads to use, to a limit more gets better performance\n");
    return -1;
  }

  int npoints = atoi(argv[1]);
  cilk::reducer_opadd<int> total_hits; // C++ reducer type to allow parallel reduction

  unsigned int seed = 123456789;

  cilk_for (int i = 0; i < npoints; i++) { 
    double x = ((double) rand_r(&seed)) / ((double) RAND_MAX);
    double y = ((double) rand_r(&seed)) / ((double) RAND_MAX);
    if (x*x + y*y <= 1.0){
      total_hits++;          // Incr operator overloaded to allow parallelism
    }
  } 

  int th = total_hits.get_value();

  double pi_est = ((double)th) / npoints * 4.0;
  printf("npoints: %8d\n",npoints);
  printf("hits:    %8d\n",th);
  printf("pi_est:  %f\n",pi_est);
}
