// Demonstrate array-notation extensions in Cilk Plus
// 
// Compile:
// > gcc -fcilkplus cilk-array-syntax.c 

#include <stdio.h>
#include <cilk/cilk.h>

// standard element-wise vector multiply
void axpy(int n, double alpha, const double *x, double *y) {
  for (int i = 0; i < n; i++) {
    y[i] += alpha * x[i];
  }
}

// Cilk Plus abbreviated syntax
void axpy_cilk(int n, double alpha, const double *x, double *y) {
  y[0:n] += alpha * x[0:n];
}

#define LEN 10

int main(){
  
  double x1[LEN] = {0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5};
  double y1[LEN] = {2,   2,   2,   2,   2,   2,   2,   2,   2,   2, };

  axpy(LEN, 1, x1, y1);
  for(int i=0; i<LEN; i++){
    printf("%d:%.2f ",i,y1[i]);
  }
  printf("\n");

  double x2[LEN] = {0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5};
  double y2[LEN] = {2,   2,   2,   2,   2,   2,   2,   2,   2,   2, };

  // Call cilk version, should produce the same results
  axpy_cilk(LEN, 1, x2, y2);
  for(int i=0; i<LEN; i++){
    printf("%d:%.2f ",i,y2[i]);
  }
  printf("\n");

  double x3[LEN] = {0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5};
  double y3[LEN] = {2,   2,   2,   2,   2,   2,   2,   2,   2,   2, };

  // Direct computation using array syntax
  y3[0:LEN] += 1.0 * x3[0:LEN];

  for(int i=0; i<LEN; i++){
    printf("%d:%.2f ",i,y3[i]);
  }
  printf("\n");
}  
