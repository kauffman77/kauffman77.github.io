#!/bin/bash
#
# This script can be sourced to load appropriate modules for MSI work as in
#   >> source msi-setup.sh

module load ompi
