
#include <stdio.h>
#include <stdlib.h> 
#include <pthread.h>

#define MAX_THREADS 32

// Global variables shared by all threads
int thread_hits[MAX_THREADS];          // array for counts of hits for each thread
int points_per_thread = -1;

void *compute_pi(void *arg){
  long thread_id = (long) arg;
  unsigned int rstate = 123456789 * (thread_id+1); // give each thread its own starting point
  for (int i = 0; i < points_per_thread; i++) { 
    double x = ((double) rand_r(&rstate)) / ((double) RAND_MAX);
    double y = ((double) rand_r(&rstate)) / ((double) RAND_MAX);
    if (x*x + y*y <= 1.0){
      thread_hits[thread_id]++;                   // update this thread's hit count
    }
  } 
  return NULL;
}

int main(int argc, char **argv) { 
  if(argc < 2){
    printf("usage: %s <num_samples> [num_threads]\n",argv[0]);
    printf("  num_samples: int, how many sample points to try, higher gets closer to pi\n");
    printf("  num_threads: int, number of threads to use for the computation, default 4\n");
    return -1;
  }

  int npoints = atoi(argv[1]);                   // number of samples
  int num_threads = argc>2 ? atoi(argv[2]) : 4;  // number of threads

  points_per_thread = npoints / num_threads;     // init global variables

  pthread_t threads[num_threads];                // track each thread

  for(long p=0; p<num_threads; p++){             // launch each thread
    pthread_create(&threads[p],NULL,compute_pi, (void *) (p));
  }

  for(int p=0; p<num_threads; p++){              // wait for each thread to finish
    pthread_join(threads[p], (void **) NULL);
  }

  int total_hits=0;                              // sum up hits over all 
  for(int i=0; i<num_threads; i++){              // threads that added 
    total_hits += thread_hits[i];                // to to the array of hits
  }

  double pi_est = ((double)total_hits) / npoints * 4.0;
  printf("npoints: %8d\n",npoints);
  printf("hits:    %8d\n",total_hits);
  printf("pi_est:  %f\n",pi_est);
}
