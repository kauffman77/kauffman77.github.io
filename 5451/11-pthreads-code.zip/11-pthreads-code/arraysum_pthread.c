// pthread_sum_array: demonstrates a common pattern of dividing a
// shared data structure like an array among threads to work on the
// data in parallel.  Shows how to use a parameter to the thread
// function, an arraysum_t in this case, to pass a unique integer ID
// like 0,1,2,... to each thread which is then used to determine which
// part of the data the thrad will use for its portion of the
// computation.

#include <stdio.h>
#include <stdlib.h> 
#include <pthread.h>
#include <sys/time.h>


typedef struct {                // struct to encapsulate array summing params
  int thread_id;                // this threads logical id
  int nthreads;                 // total threads working on sum
  int *array;                   // pointer to array start
  int len;                      // length of array
  long mysum;                   // local sum for this array
} arraysum_t;

// worker function for threads that are participating in the summing
// of the array
void *arraysum_work(void *arg){             // thread worker function
  arraysum_t *as = (arraysum_t*) arg;       // caste arg to data
  int my_id = as->thread_id;                // extract logical thread id for this thread
  int count = (as->len / as->nthreads);     // how many elements each thread should sum up
  int start = my_id*count;                  // where this thread start in the array, based on its ID
  int stop  = (my_id+1)*count;              // where this thread should stop
  if(my_id == as->nthreads-1){              // last thread goes to end of array in case 
    stop = as->len;                         // the array length is not evenly divisible by num_threads
  }

  printf("Thread %d summing elements %d to %d\n",
         my_id,start,stop);

  long my_sum = 0;                          // local sum for this thread's portion of the array
  for(int i=start; i<stop; i++){
    my_sum += as->array[i];
  }

  printf("Thread %d sum is %ld\n", my_id, my_sum);

  as->mysum = my_sum;                      // set the struct field to personal sum for accumulation
  return NULL;
}

// Sums the given array of integers 'array' with length
// 'len'. Launches specified number of threads to parallelize the
// process. Returns the array sum as its return value.
long arraysum_pthreads(int *array, int len, int nthreads){
  pthread_t threads[nthreads];              // structs for tracking each thread and
  arraysum_t as[nthreads];                  // structs to inform threads of problem data

  for(int i=0; i<nthreads; i++){            // launch each thread
    as[i].thread_id = i;                    // threads each receive parameter data
    as[i].nthreads  = nthreads;
    as[i].array = array;
    as[i].len = len;
    pthread_create(&threads[i],NULL, arraysum_work, &as[i]);
  }

  long total_sum = 0;
  for(int i=0; i<nthreads; i++){            
    pthread_join(threads[i], NULL);         // wait for each thread to finish
    total_sum += as[i].mysum;               // add its thread total to the overall
  }                                         
  return total_sum;
}

// main function to test the arraysum_pthreads function
int main(int argc, char **argv) { 
  if(argc < 3){
    printf("usage: %s <array_len> <num_threads>\n",argv[0]);
    printf("  array_len:   int, length of the array to sum\n");
    printf("  num_threads: int, number of threads to use for the computation\n");
    return -1;
  }

  int array_len = atoi(argv[1]);              // set globals from command line
  int num_threads = atoi(argv[2]);


  int *array = malloc(sizeof(int)*array_len); // initialize array with 0,1,2,3,...
  for(int i=0; i<array_len; i++){
    array[i] = i;
  }

  struct timeval beg, end;

  gettimeofday(&beg, NULL);

  long actual_total_sum =
    arraysum_pthreads(array, array_len, num_threads);

  gettimeofday(&end, NULL);
  double wall_time = 
    ((double) (end.tv_usec - beg.tv_usec) / 1000000) +
    ((double) (end.tv_sec  - beg.tv_sec));

  long larray_len = (long) array_len;
  long expect_total_sum = (larray_len * (larray_len-1))/2;

  free(array);

  printf("actual total_sum: %ld\n",actual_total_sum);
  printf("expect total_sum: %ld\n",expect_total_sum);
  printf("nthreads: %d  walltime: %.6f\n",num_threads,wall_time);
  return 0;
}
