// pthreads_minimal.c: Minimal example of starting a
// pthread, passing a parameter to the thread function, then
// waiting for it to finish. Two threads are launched.
#include <pthread.h>
#include <stdio.h>

void *fx(void *param){
  int p=(int) param;
  p = p*2;
  return (void *) p;
}

int main(){
  pthread_t thread_1, thread_2;
  pthread_create(&thread_1, NULL, fx, (void *) 42);
  pthread_create(&thread_2, NULL, fx, (void *) 65);
  int res1, res2;
  pthread_join(thread_1, (void **) &res1); 
  pthread_join(thread_2, (void **) &res2); 
  printf("results are: %d %d\n",res1,res2);
  return 0;
}
