// Small stack frames may cause the functions fx and fy to falsely
// share cahce lines

#include <pthread.h>
#include <stdio.h>

void *fx(void *param) { 
  int i, x=(int) param;
  for(i=0; i<1000; i++){
    x = (x+1)*(x+3)/x;
    printf("x %d\n",x);
  }
  return (void *) x;
} 

void *fy(void *param){
  int i, y=(int) param;
  for(i=0; i<1000; i++){
    y = y/2;
    y = y+2*y;
    printf("y %d\n",y);
  }
  return (void *) y;
}

int main(int argc, char *argv[]) { 
  pthread_t     thread_1;
  pthread_t     thread_2;
  pthread_create(&thread_1, NULL, fx, 42);
  pthread_create(&thread_2, NULL, fy, 31);
  int *xres, *yres;
  pthread_join(thread_1, &xres);
  pthread_join(thread_2, &yres);
  printf("x is %d\ny is %d\n",
         (int) xres,(int) yres);
}
