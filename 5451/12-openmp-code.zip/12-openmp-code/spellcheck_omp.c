// Do speell checking using OpenMP: select random dictionary words and
// search for them linearly in the dictionary file. This creates
// non-uniform workload which may perform better under guided loop
// scheduling. However, for a large enough number of random words, the
// workload becomes reasonably balanced due to averaging.  Use the
// dictionary file english-words.txt as the dictionary provided on the
// command line.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

typedef struct {
  int fd;
  char *all;
  size_t all_size;
  char **words;
  int word_count;
  int *word_marks;
} dict_t;


dict_t *dict_open(char *filename){
  dict_t *dict = malloc(sizeof(dict_t));
  dict->fd = open(filename, O_RDONLY);
  if(dict->fd == -1){
    printf("Couldn't open dict file '%s'",filename);
    perror("");
    return NULL;
  }
  struct stat stat_buf;
  fstat(dict->fd, &stat_buf);
  dict->all_size = stat_buf.st_size;
  dict->all = mmap(NULL, dict->all_size, 
                   PROT_READ|PROT_WRITE,
                   MAP_PRIVATE, dict->fd, 0);
  // Using MAP_PRIVATE means write changes will not alter the file

  dict->word_count = 0;
  for(size_t i=0; i<dict->all_size; i++){
    if(dict->all[i] == '\n'){
      dict->word_count++;
    }
  }
  dict->words = malloc(sizeof(char*) * dict->word_count);
  size_t pos = 0;
  for(int i=0; i < dict->word_count; i++){
    dict->words[i] = dict->all + pos;
    while(dict->all[pos] != '\n'){
      pos++;
    }
    dict->all[pos] = '\0';      // null terminate
    pos++;
  }
  dict->word_marks = calloc(dict->word_count, sizeof(int));
  return dict;
}  

void dict_close(dict_t *dict){
  free(dict->words);
  free(dict->word_marks);
  munmap(dict->all, dict->all_size);
  close(dict->fd);
  free(dict);
}

  
int linear_search(dict_t *dict, char *query){
  for(int i=0; i<dict->word_count; i++){
    if(strcmp(dict->words[i],query) == 0){
      return i;
    }
  }
  return -1;
}

int main(int argc, char *argv[]) { 

  if(argc < 3){
    printf("usage: omp_spellcheck <dictfile> <wordfile> \n");
    printf("  dictfile: file containing the dictionary\n");
    printf("  wordfile: file of words to check spelling\n");
    return 0;
  }


  dict_t *dictionary = dict_open(argv[1]);
  dict_t *document = dict_open(argv[2]);
  if(dictionary==NULL || document==NULL){
    return 1;
  }

  // Parallel region where only the "master" thread prints
  long total_threads;
  #pragma omp parallel 
  {
    #pragma omp master
    {
      total_threads = omp_get_num_threads();
      printf("num_threads = %ld\n\n",total_threads);
    }
  }


  long thread_work[total_threads];    // Track work done by each thread
  int misspelled = 0;                 // accumulate total misspellings

  #pragma omp parallel                // do spell checking in parallel
  {
    int my_misspelled = 0;            // private versions of cumulative data
    long my_work = 0;
    #pragma omp for schedule(runtime) // parallel loop, schedule from OMP_SCHEDULE
    for (int i=0; i < document->word_count; i++) {
      int result = linear_search(dictionary, document->words[i]);
      my_work += result;
      if(result == -1){
        my_misspelled++;
      }
    }
    int tid = omp_get_thread_num();
    thread_work[tid] = my_work;
    #pragma omp atomic
    misspelled += my_misspelled;
  }

  printf("misspelled: %d\n", misspelled);

  long tot = 0;
  for(int i=0; i<total_threads; i++){
    printf("Thread %d work: %ld\n",i,thread_work[i]);
    tot += thread_work[i];
  }
  printf("Total work: %ld\n", tot);

  dict_close(dictionary);
  dict_close(document);

  return 0;
}
