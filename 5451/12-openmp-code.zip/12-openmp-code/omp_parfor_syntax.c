// omp_parfor_syntax.c: Show the basic syntax of the parallel for
// loop. Two compatible syntaxes are shown.

#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) { 
  const int REPS = 16;
  #pragma omp parallel
  {  
    #pragma omp for  
    for (int i = 0; i < REPS; i++) {
      int id = omp_get_thread_num();
      printf("Thread %d did iter %d\n", 
             id, i);
    }
  }
  printf("\n");

  // ABOVE AND BELOW IDENTICAL

  #pragma omp parallel for  
  for (int i = 0; i < REPS; i++) {
    int id = omp_get_thread_num();
    printf("Thread %d did iter %d\n", 
           id, i);
  }
  printf("\n");

}
