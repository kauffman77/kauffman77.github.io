// Demonstrate guided loop scheduling. Helps to pipe to sort to see
// chunks decrease in size OpenMP's parallel for loops.

#include <stdio.h>
#include <omp.h>
#include <stdlib.h>

int main(int argc, char **argv) { 
  const int REPS = 128;

  // TODO count the iters per thread in a shared variable

  // Parallel region where only the "master" thread prints
  int total_threads;
  #pragma omp parallel 
  {
    #pragma omp master
    {
      total_threads = omp_get_num_threads();
      printf("#threads = %d\n\n",total_threads);
    }
  }

  int *totals = malloc(total_threads * sizeof(int));
  for(int i=0; i<total_threads; i++){
    totals[i] = 0;
  }

  printf("GUIDED\n");
  #pragma omp parallel for schedule(guided)
  for (int i = 0; i < REPS; i++) {
    int id = omp_get_thread_num();
    printf("iter %03d by %d\n", 
           i, id);
    totals[id]++;
  }
  printf("\n");

  for(int i=0; i<total_threads; i++){
    printf("Thread %d did %d iters\n",i,totals[i]);
  }
  
  free(totals);
}
