// matvec_serial.c: Matrix/vector multiply demo
#include <stdio.h>
#include <stdlib.h> 

int main(int argc, char **argv) { 
  if(argc < 4){
    printf("usage: matrix_vector_multiply <rows> <cols> <print?>\n");
    printf("  rows cols: ints, size of the matrix to use\n");
    printf("  print?: int, 1 for printing, 0 for no output\n");
    return -1;
  }

  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);
  int print = atoi(argv[3]);

  int i,j;

  // Raw matrix as a 1D array, initialize
  double *data = malloc(rows * cols * sizeof(double));
  for(i=0; i<rows*cols; i++){
    data[i] = i;
  }

  // set up row pointers
  double **matrix = malloc(rows * sizeof(double*));
  for(i=0; i<rows; i++){
    matrix[i] = data + i*cols;
  }

  // Allocate and initialize vector and result
  double *vector = malloc(cols * sizeof(double));
  for(i=0; i<cols; i++){
    vector[i] = i;
  }
  double *result = malloc(rows * sizeof(double));
  for(i=0; i<rows; i++){
    result[i] = 0.0;
  }


  // Perform multiplication
  for(i=0; i<rows; i++){
    for(j=0; j<cols; j++){
      result[i] += matrix[i][j] * vector[j];
    }
  }

  // Print results
  if(print){
    printf("Results:\n");
    for(i=0; i<rows; i++){
      printf("%2d: %8.2f\n",i,result[i]);
    }
  }

  free(data);
  free(matrix);
  free(vector);
  free(result);
}
