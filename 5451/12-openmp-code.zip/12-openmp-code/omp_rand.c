// Attempt to get rand() to misbehave that have so far failed

#include <stdio.h>
#include <omp.h>
#include <stdlib.h> 

int main(int argc, char **argv) { 
  if(argc < 3){
    printf("usage: omp_rand <seed> <iters> [threads]\n");
    printf("  seed: seed for rand calls\n");
    printf("  iters: how many random numbers to print\n");
    printf("  threads: how many threads to use, to a limit more gets better performance\n");
    return -1;
  }

  if(argc > 3){
    omp_set_num_threads(atoi(argv[2]));
  }

  unsigned int seed = atoi(argv[1]);
  int iters = atoi(argv[2]);

  srand(seed);

  #pragma omp parallel
  { 
    int i;
    int thread_id = omp_get_thread_num();
    for (i = 0; i < iters; i++) { 
      int r = rand();
      printf("%d\n",r);
    } 
  } 

  return 0;
}
