// Demonstrate problems that can arise with use of shared variables in
// parallel for loops

#include <stdio.h>
#include <omp.h>
#include <stdlib.h> 

int main(int argc, char **argv) { 
  printf("LOOP LOCAL i\n");

  int iters = 5000000;

  int sum;

  sum = 0;
  #pragma omp parallel for  
  for (int i = 0; i < iters; i++) {
    // printf("Thread %d doing iter %d\n", 
    //        id, i);
    #pragma omp atomic
    sum += i;
  }
  printf("Sum is %d\n\n",sum);


  printf("SHARED i\n");
  sum = 0;
  int i;
  #pragma omp parallel for  
  for (i = 0; i < iters; i++) {
    // printf("Thread %d doing iter %d\n", 
    //        id, i);
    #pragma omp atomic
    sum += i;
  }
  printf("Sum is %d\n\n",sum);

  printf("WITH private(i)\n"); 
  sum = 0;
  #pragma omp parallel for private(i)
  for (i = 0; i < iters; i++) {
    // printf("Thread %d doing iter %d\n", 
    //        id, i);
    #pragma omp atomic
    sum += i;
  }
  printf("Sum is %d\n\n",sum);


  return 0;
}

