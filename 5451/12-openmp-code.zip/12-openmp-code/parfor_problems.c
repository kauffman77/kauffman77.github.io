// parfor_private_loopvar.c: Demonstrate how the loop variable is
// ALWAYS "private" even if scoping in the C program would indicate
// otherwise. Each of the blocks below will produce correct results
// for the sum despite a few having apparently shared loop variables.

#include <stdio.h>
#include <omp.h>
#include <stdlib.h> 

int main(int argc, char **argv) { 
  int iters = 5000000;
  int sum;

  printf("LOOP LOCAL i\n");
  sum = 0;
  #pragma omp parallel for  
  for (int i = 0; i < iters; i++) { // loop variable is private to each thread
    // printf("Thread %d doing iter %d\n", 
    //        id, i);
    #pragma omp atomic
    sum += i;
  }
  printf("Sum is %d\n\n",sum);


  printf("SHARED i\n");
  sum = 0;
  int i;
  #pragma omp parallel for  
  for (i = 0; i < iters; i++) { // despite looking shared, i is still private to each thread
    // printf("Thread %d doing iter %d\n", 
    //        id, i);
    #pragma omp atomic
    sum += i;
  }
  printf("Sum is %d\n\n",sum);

  printf("WITH private(i)\n"); 
  sum = 0;
  #pragma omp parallel for private(i)
  for (i = 0; i < iters; i++) { // private(i) declaration is implied for loop var i
    // printf("Thread %d doing iter %d\n", 
    //        id, i);
    #pragma omp atomic
    sum += i;
  }
  printf("Sum is %d\n\n",sum);


  return 0;
}

