// Compute the Collatz sequence and count steps for random numbers.
// Meant to create unbalanced work between iterations in a loop but
// random selection leads to the average work per thread being about
// equal for large numbers of iterations.

#include <stdio.h>
#include <stdlib.h>
#include <omp.h>


// Count how many steps are in the collatz sequence
long collatz_steps(long n){
  long steps = 0;
  while(n > 1){
    steps++;
    if(n % 2 == 0){
      n = n / 2;
    }
    else{
      n = n*3 + 1;
    }
  }
  return steps;
}

int main(long argc, char **argv) { 

  if(argc < 2){
    printf("usage: omp_collatz <nsamples> \n");
    printf("  nsamples: int, how many sample points to generate\n");
    return 0;
  }

  long nsamples = atoi(argv[1]);
  int state = 123456789;
  const long CAP = RAND_MAX;
  long *starts = malloc(nsamples * sizeof(long));
  long *steps =  malloc(nsamples * sizeof(long));
  for(long i=0; i<nsamples; i++){
    starts[i] = rand_r(&state) % CAP;
    steps[i] = -1;
  }

  // Parallel region where only the "master" thread prints
  long total_threads;
  #pragma omp parallel 
  {
    #pragma omp master
    {
      total_threads = omp_get_num_threads();
      printf("#threads = %d\n\n",total_threads);
    }
  }
  // Track work done by each tread
  long *totals = malloc(total_threads * sizeof(long));
  for(long i=0; i<total_threads; i++){
    totals[i] = 0;
  }

  // Compute the steps and track total steps for each thread
  #pragma omp parallel for schedule(runtime)
  for (long i = 0; i < nsamples; i++) {
    steps[i] = collatz_steps(starts[i]);
    int id = omp_get_thread_num();
    totals[id] += steps[i];
  }

  for(long i=0; i<total_threads; i++){
    printf("Thread %d did %d steps\n",i,totals[i]);
  }

  
  free(totals);
  free(starts);
  free(steps);
  return 0;
}
