// Demonstrate use of the private(var) clause to parallel sections to
// create a private copy of a shared variable.

#include <stdio.h>
#include <omp.h>

int main()  {
  int tid;                      // shared by all threads

  // tid is shared by default, may print redundant ids
  printf("Shared\n");
  tid = -1;
  #pragma omp parallel 
  {
    tid = omp_get_thread_num();
    printf("Hello World from thread = %d\n", tid);
  }
  printf("tid: %d\n",tid);      // tid is non-deterministic

  printf("\n");

  // each thread gets its own copy of tid in the below
  printf("Private\n");
  tid = -1;
  #pragma omp parallel private(tid)
  {
    tid = omp_get_thread_num();
    printf("Hello World from thread = %d\n", tid);
  }
  printf("tid: %d\n",tid);      // tid should be -1

}
