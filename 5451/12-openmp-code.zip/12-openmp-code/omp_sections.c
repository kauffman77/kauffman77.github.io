// Brief demonstration of OpenMP parallel sections directive for
// independent execution of disparate codes.
//
// Run with varying numbers of threads via
//
// >> OMP_NUM_THREADS=3 ./omp_sections

#include <omp.h>
#include <stdio.h>

#define N 1000

int main () {
  int i;
  float a[N], b[N], c[N], d[N];

  /* Some initializations */
  for (i=0; i < N; i++) {
    a[i] = i * 1.5;
    b[i] = i + 22.35;
  }

  #pragma omp parallel shared(a,b,c,d) private(i)
  {
    #pragma omp sections nowait
    {
      // Add
      #pragma omp section
      {
        printf("Thread %d computing c[]\n",
               omp_get_thread_num());
        for (i=0; i < N; i++)
          c[i] = a[i] + b[i];
      }
      // Mult
      #pragma omp section
      {
        printf("Thread %d computing d[]\n",
               omp_get_thread_num());
        for (i=0; i < N; i++)
          d[i] = a[i] * b[i];
      }
      // Chill
      #pragma omp section
      printf("Thread %d chillin' out\n",
             omp_get_thread_num());

      // Additional threads do nothing
    }

    printf("Thread %d ready for more\n",omp_get_thread_num());
  }

  for(i=0; i<10; i++){
    printf("c[%d] = %f\td[%d] = %f\n",i,c[i],i,d[i]);
  }
  return 0;
}
