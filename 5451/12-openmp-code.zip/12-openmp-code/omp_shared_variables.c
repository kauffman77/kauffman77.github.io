// omp_shared_variables.c: Demonstrate that the id_shared variable is
// shared by multiple threads and that the first block MAY not produce
// the desired output of each thread reporting its id uniquely.  This
// is somewhat system and compiler dependent.

#include <stdio.h>
#include <omp.h>
#include <stdlib.h>

int main(int argc, char** argv) {
  printf("\n");
  if (argc > 1) {
    omp_set_num_threads( atoi(argv[1]) );
  }

  int id_shared=-1;
  int numThreads=0;

  #pragma omp parallel shared(id_shared)
  {
    id_shared = omp_get_thread_num();
    numThreads = omp_get_num_threads();
    printf("A: Hello from thread %d of %d\n", id_shared, numThreads);
  }

  printf("\n");

  #pragma omp parallel 
  {
    int id_private = omp_get_thread_num();
    numThreads = omp_get_num_threads();
    printf("B: Hello from thread %d of %d\n", id_private, numThreads);
  }

  printf("\n");
  return 0;
}

