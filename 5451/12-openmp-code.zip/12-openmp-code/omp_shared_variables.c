// omp_shared_variables.c: Demonstrate that the id_shared variable is
// shared by multiple threads and that the first two blocks MAY not
// produce the desired output of each thread reporting its id
// uniquely.  This is somewhat system and compiler dependent.
//
// The following pipeline helps to run many examples to find instances
// when the shared variables cause problems.
//
// for i in $(seq 100); do ./a.out; done | grep [AB]: | sort | uniq -c

#include <stdio.h>
#include <omp.h>
#include <stdlib.h>

int main(int argc, char** argv) {
  printf("\n");
  if (argc > 1) {
    omp_set_num_threads( atoi(argv[1]) );
  }

  int id_shared = -1;
  int num_threads = -1;

  #pragma omp parallel master             // must check num threads in parallel
  num_threads = omp_get_num_threads();    // region otherwise will be 1

  #pragma omp parallel 
  {
    id_shared = omp_get_thread_num();     // id_shared is shared among all threads
    printf("A: Hey from thread %d / %d\n",
           id_shared, num_threads);
  }
  printf("\n");

  #pragma omp parallel shared(id_shared)  // pragman makes sharing explicit
  {
    id_shared = omp_get_thread_num();
    printf("B: Hey from thread %d / %d\n",
           id_shared, num_threads);
  }
  printf("\n");

  #pragma omp parallel private(id_shared) // pragma adjust to have a private copy
  {                                       // of an otherwise shared variable
    id_shared = omp_get_thread_num();
    printf("C: Hey from thread %d / %d\n",
           id_shared, num_threads);
  }
  printf("\n");

  #pragma omp parallel                    // variables declared in local scope
  {                                       // are automatically private to threads
    int id_private = omp_get_thread_num();
    printf("D: Hey from thread %d / %d\n",
           id_private, num_threads);
  }

  printf("\n");

  return 0;
}

