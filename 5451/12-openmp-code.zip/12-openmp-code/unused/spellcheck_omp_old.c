// Do speell checking using OpenMP: select random dictionary words and
// search for them linearly in the dictionary file. This creates
// non-uniform workload which may perform better under guided loop
// scheduling. However, for a large enough number of random words, the
// workload becomes reasonably balanced due to averaging.  Use the
// dictionary file english-words.txt as the dictionary provided on the
// command line.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>


void count_lines(char *file_name, int *set_count, int *set_maxlen){
  FILE *file = fopen(file_name,"r");
  char input;
  int line_num=0;
  int len=0,maxlen=0;
  for(input = fgetc(file); input != EOF; input = fgetc(file)){
    len++;
    if(input == '\n'){
      line_num++; 
      maxlen = len>maxlen ? len : maxlen;
      len=0;
    }
  }
  fclose(file);
  *set_count = line_num;
  *set_maxlen = maxlen;
  return;
}


int linear_search(char **dict, int dictsize, char *query){
  for(int i=0; i<dictsize; i++){
    if(strcmp(dict[i],query) == 0){
      return i;
    }
  }
  return -1;
}

int main(long argc, char **argv) { 

  if(argc < 3){
    printf("usage: omp_spellcheck <dictfile> <nsamples> \n");
    printf("  dictfile: file containing the dictionary\n");
    printf("  nsamples: number of random words to check for\n");
    return 0;
  }

  char *dictfile = argv[1];
  int nsamples = atoi(argv[2]);
  int dictsize, maxlen;
  count_lines(dictfile, &dictsize, &maxlen);
  char **dict = malloc(dictsize * sizeof(char*));
  FILE *in = fopen(dictfile,"r");
  for(int i=0; i<dictsize; i++){
    dict[i] = NULL;
    size_t ignore;
    getline(&(dict[i]), &ignore, in);
    int last = strlen(dict[i]);
    dict[i][last-1] = '\0';     // trim off newline
  }
  
  fclose(in);

  int state = 123456789;
  int *query_idxs =  malloc(nsamples * sizeof(int));
  for(int i=0; i<nsamples; i++){
    query_idxs[i] = rand_r(&state) % dictsize;
  }

  // Parallel region where only the "master" thread prints
  long total_threads;
  #pragma omp parallel 
  {
    #pragma omp master
    {
      total_threads = omp_get_num_threads();
      printf("#threads = %d\n\n",total_threads);
    }
  }
  // Track work done by each tread
  long *totals = malloc(total_threads * sizeof(long));
  for(long i=0; i<total_threads; i++){
    totals[i] = 0;
  }

  // Compute the steps and track total steps for each thread
  #pragma omp parallel for schedule(runtime)
  for (int i = 0; i < nsamples; i++) {
    int query_idx = query_idxs[i];
    int result = linear_search(dict, dictsize, dict[query_idx]);
    if(result != query_idx){
      printf("ERROR: Found %s at %d instead of %d\n",dict[query_idx],result,query_idx);
    }
    else{
      int id = omp_get_thread_num();
      totals[id] += result;
      // printf("Found %s at %d\n",dict[query_idx],result,query_idx);
    }
  }

  for(int i=0; i<total_threads; i++){
    printf("Thread %d did %d steps\n",i,totals[i]);
  }

  for(int i=0; i<dictsize; i++){
    free(dict[i]);
  }
  free(dict);
  free(query_idxs);
  free(totals);
}
