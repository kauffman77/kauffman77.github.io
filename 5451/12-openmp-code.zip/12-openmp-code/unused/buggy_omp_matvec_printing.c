// Original version of timing outer vs inner vs nested parallel
// matrix-vector mult.  In this version the inner variant lacks a
// reduction which leads to incorrect results and also cache
// thrashing.
// 
// Time 3 different versions of matrix vector multiplication
// parallelization: outer loop, inner loop, and both
// 
// Include printing to allow the number of threads to be determined.
//
// The altering environment variables such as
//   > export OMP_NESTED=TRUE
// can affect the number of threads reported.


#include <stdio.h>
#include <omp.h>
#include <stdlib.h> 
#include <sys/time.h>

// To measure timing
struct timeval tv; 
struct timezone tz; 
double time_start, time_end; 

void start_timer(){
  gettimeofday(&tv, &tz); 
  time_start = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0; 
}

double get_wall_time(){
  gettimeofday(&tv, &tz); 
  time_end = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0;
  double elapsed = time_end - time_start;
  return elapsed;
}

int main(int argc, char **argv) { 
  if(argc < 3){
    printf("usage: matrix_vector_multiply <rows> <cols> <print?> [threads]\n");
    printf("  rows cols: ints, size of the matrix to use\n");
    printf("  threads: how many threads to use, to a limit more gets better performance\n");
    return -1;
  }

  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);

  if(argc > 3){
    omp_set_num_threads(atoi(argv[3]));
  }

  int i,j;

  // Raw matrix as a 1D array, initialize
  double *data = malloc(rows * cols * sizeof(double));
  for(i=0; i<rows*cols; i++){
    data[i] = i;
  }

  // set up row pointers
  double **matrix = malloc(rows * sizeof(double*));
  for(i=0; i<rows; i++){
    matrix[i] = data + i*cols;
  }

  // Allocate and initialize vector and result
  double *vector = malloc(cols * sizeof(double));
  for(i=0; i<cols; i++){
    vector[i] = i;
  }
  double *result = malloc(rows * sizeof(double));
  for(i=0; i<rows; i++){
    result[i] = 0.0;
  }

  // Outer for loop multiplication
  start_timer();
  #pragma omp parallel for
  for(int i=0; i<rows; i++){
    for(int j=0; j<cols; j++){
      if(i==0 && j==0){
        printf("#threads = %d (outer)\n",omp_get_num_threads());
      }        
      result[i] += matrix[i][j] * vector[j];
    }
  }
  double time_outer_for = get_wall_time();

  // Inner for loop multiplication
  start_timer();
  for(int i=0; i<rows; i++){
    #pragma omp parallel for
    for(int j=0; j<cols; j++){
      if(i==0 && j==0){
        printf("#threads = %d (inner)\n",omp_get_num_threads());
      }        
      result[i] += matrix[i][j] * vector[j];
    }
  }
  double time_inner_for = get_wall_time();


  // Outer and Inner for loop multiplication
  start_timer();
  #pragma omp parallel for
  for(int i=0; i<rows; i++){
    if(i==0){
      printf("#threads = %d (both outer)\n",omp_get_num_threads());
    }
    #pragma omp parallel for
    for(int j=0; j<cols; j++){
      if(i==0 && j==0){
        printf("#threads = %d (both inner) \n",omp_get_num_threads());
      }        
      result[i] += matrix[i][j] * vector[j];
    }
  }
  double time_both_for = get_wall_time();

  printf("Outer : %8.4f\n",time_outer_for);
  printf("Inner : %8.4f\n",time_inner_for);
  printf("Both  : %8.4f\n",time_both_for);

  free(data);
  free(matrix);
  free(vector);
  free(result);
}
