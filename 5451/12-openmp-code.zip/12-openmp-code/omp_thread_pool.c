// omp_thread_pool.c: demonstrates starting threads via a parallel
// block and that thos threads stick around after that block finishes
// in a thread pool like fashio
// 
// Derived from https://nanxiao.me/en/beware-of-openmps-thread-pool/

#include <unistd.h>
#include <stdio.h>
#include <omp.h>

#define MAXITERS 32

int main(void){
  printf("PID: %d\n",getpid());
  printf("run \"watch -n 0.1 'ps H %d' in another terminal\n",
         getpid());
  printf("Press enter to begin parallel block\n");
  fgetc(stdin);

  #pragma omp parallel for
  for(int i = 0; i < MAXITERS; i++) {
    sleep(1);
  }

  printf("Parallel block ended, check tasks\n");

  while (1) {
    sleep(1);
  }

  return 0;
}
