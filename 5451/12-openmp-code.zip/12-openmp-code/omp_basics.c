// Basic demonstration of parallel statements/blocks in openmp with
// pragmas
// 
// COMPILE WITHOUT PARALLELISM
// gcc omp_basics.c
// 
// COMPILE WITH PARALLELISM
// gcc omp_basics.c -fopenmp

#include <stdio.h>
#include <omp.h>

int main(int argc, char** argv) {

    printf("Hello\n\n");

    #pragma omp parallel 
    printf("How are ");

    printf("You?\n\n");

    #pragma omp parallel 
    {
      printf("Sorry if I seem\n");
      printf("to be repeating\n");
      printf("myself.\n");
    }

    return 0;
}

