// omp_basics: Basic demonstration of parallel statements/blocks in
// openmp with pragmas
// 
// # COMPILE/RUN WITHOUT PARALLELISM
// >> gcc omp_basics.c
// >> ./a.out
// 
// COMPILE WITH PARALLELISM
// >> gcc omp_basics.c -fopenmp
// >> ./a.out

#include <stdio.h>
#include <omp.h>

int main(int argc, char** argv) {

    printf("It's time for...\n\n");

    #pragma omp parallel 
    printf("O-");

    printf("pen MP\n\n");

    #pragma omp parallel 
    {
      printf("Sometimes I stutter\n");
      printf("when I get excited\n");
      printf("about parallelism.\n");
    }

    // #pragma omp parallel for
    // for(int i=0; i<4; i++){
    //   printf("Hi\n");
    // }

    return 0;
}

