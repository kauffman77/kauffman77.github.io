// Time 3 different versions of matrix vector multiplication
// parallelization: outer loop, inner loop, and both

#include <stdio.h>
#include <omp.h>
#include <stdlib.h> 
#include <sys/time.h>

// To measure timing
struct timeval tv; 
struct timezone tz; 
double time_start, time_end; 

void start_timer(){
  gettimeofday(&tv, &tz); 
  time_start = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0; 
}

double get_wall_time(){
  gettimeofday(&tv, &tz); 
  time_end = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0;
  double elapsed = time_end - time_start;
  return elapsed;
}

void zero_array(double *x, int n){
  for(int i=0; i<n; i++){
    x[i] = 0.0;
  }
}
// #define PRINTING 1
int PRINTING = 0;
void print_array(double *x, int n, char *prefix){
  if(PRINTING){
    for(int i=0; i<n; i++){
      printf("%s %d %f\n",prefix,i,x[i]);
    }
    printf("\n");
  }
}


int main(int argc, char **argv) { 
  if(argc < 3){
    printf("usage: matrix_vector_multiply <rows> <cols> [threads] [print?]\n");
    printf("  rows cols: ints, size of the matrix to use\n");
    printf("  threads: how many threads to use, to a limit more gets better performance\n");
    return -1;
  }

  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);

  if(argc > 3){
    omp_set_num_threads(atoi(argv[3]));
  }

  if(argc == 5){
    PRINTING = atoi(argv[4]);
  }

  // Raw matrix as a 1D array, initialize
  double *data = malloc(rows * cols * sizeof(double));
  if(data == NULL){
    printf("Insufficient memory\n");
    return -1;
  }
  for(int i=0; i<rows*cols; i++){
    data[i] = i;
  }

  // set up row pointers
  double **matrix = malloc(rows * sizeof(double*));
  for(int i=0; i<rows; i++){
    matrix[i] = data + i*cols;
  }

  // Allocate and initialize vector and result
  double *vector = malloc(cols * sizeof(double));
  for(int i=0; i<cols; i++){
    vector[i] = i;
  }
  double *result = malloc(rows * sizeof(double));

  ////////////////////////////////////////////////////////////////////////////////
  // Outer for loop multiplication
  zero_array(result,rows);
  start_timer();
  #pragma omp parallel for
  for(int i=0; i<rows; i++){
    for(int j=0; j<cols; j++){
      result[i] += matrix[i][j] * vector[j];
    }
  }
  printf("Outer  : %8.4f\n", get_wall_time());
  print_array(result,rows,"O");
  ////////////////////////////////////////////////////////////////////////////////


  ////////////////////////////////////////////////////////////////////////////////
  // Inner for loop multiplication: reduction on result[i] added in
  // more recent versions of OpenMP
  zero_array(result,rows);
  start_timer();
  for(int i=0; i<rows; i++){
    #pragma omp parallel for reduction(+:result[i])
    for(int j=0; j<cols; j++){
      result[i] += matrix[i][j] * vector[j];
    }
  }
  printf("Inner  : %8.4f\n", get_wall_time());
  print_array(result,rows,"I");
  ////////////////////////////////////////////////////////////////////////////////

  // ////////////////////////////////////////////////////////////////////////////////
  // // Old Inner for loop multiplication with "manual" summation
  // zero_array(result,rows);
  // start_timer();
  // for(int i=0; i<rows; i++){
  //   double sum = 0.0;
  //   #pragma omp parallel for reduction(+:sum)
  //   for(int j=0; j<cols; j++){
  //     sum += matrix[i][j] * vector[j];
  //   }
  //   result[i] = sum;
  // }
  // printf("Inner1 : %8.4f\n", get_wall_time());
  // print_array(result,rows,"I");
  // ////////////////////////////////////////////////////////////////////////////////

  ////////////////////////////////////////////////////////////////////////////////
  // Outer and Inner for loop multiplication
  zero_array(result,rows);
  start_timer();
  #pragma omp parallel for
  for(int i=0; i<rows; i++){
    #pragma omp parallel for reduction(+:result[i])
    for(int j=0; j<cols; j++){
      result[i] += matrix[i][j] * vector[j];
    }
  }
  printf("Both   : %8.4f\n", get_wall_time());
  print_array(result,rows,"B");
  ////////////////////////////////////////////////////////////////////////////////

  // Report times

  free(data);
  free(matrix);
  free(vector);
  free(result);
}
