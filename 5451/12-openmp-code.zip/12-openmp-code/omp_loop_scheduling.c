// Demonstrate the main types of loop scheduling that can happen with
// OpenMP's parallel for loops.

#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) { 
  const int REPS = 16;

  // Parallel region where only the "master" thread prints
  #pragma omp parallel 
  {
    #pragma omp master
    printf("#threads = %d\n\n",omp_get_num_threads());
  }

  printf("STATIC\n");
  #pragma omp parallel for schedule(static)
  for (int i = 0; i < REPS; i++) {
    int id = omp_get_thread_num();
    printf("%d did iter %d\n", 
           id, i);
  }
  printf("\n");

  printf("STATIC 2\n");
  #pragma omp parallel for schedule(static,2)
  for (int i = 0; i < REPS; i++) {
    int id = omp_get_thread_num();
    printf("%d did iter %d\n", 
           id, i);
  }
  printf("\n");

  printf("DYNAMIC 2\n");
  #pragma omp parallel for schedule(dynamic,2)
  for (int i = 0; i < REPS; i++) {
    int id = omp_get_thread_num();
    printf("%d did iter %d\n", 
           id, i);
  }
  printf("\n");

  printf("GUIDED\n");
  #pragma omp parallel for schedule(guided)
  for (int i = 0; i < REPS; i++) {
    int id = omp_get_thread_num();
    printf("%d did iter %d\n", 
           id, i);
  }
  printf("\n");

  // Control with environment variables like
  // > export OMP_SCHEDULE="static,3"
  // > export OMP_SCHEDULE="dynamic,6"
  printf("RUNTIME\n");
  #pragma omp parallel for schedule(runtime)
  for (int i = 0; i < REPS; i++) {
    int id = omp_get_thread_num();
    printf("%d did iter %d\n", 
           id, i);
  }
  printf("\n");

}
