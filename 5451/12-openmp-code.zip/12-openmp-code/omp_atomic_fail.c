#include <stdio.h>
#include <omp.h>
#include <stdlib.h> 

int main(int argc, char** argv) {

    #pragma omp parallel 
    {
      int thread_id = omp_get_thread_num();
      #pragma omp atomic
      printf("Thread %d Reporting\n",thread_id);
      // printf() does not have atomic hardware support so triggers a
      // compiler error
    }

    return 0;
}

