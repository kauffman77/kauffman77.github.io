#!/bin/bash

mpif90 main.f90
mpirun -np 2 ./a.out
