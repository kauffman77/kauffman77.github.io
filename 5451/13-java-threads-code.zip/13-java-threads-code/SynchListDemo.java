// Sketch of how to implement the synchronizedList() method of Collections
class Collections{
  class SyncList<T> implements List<T>{
    List<T> myList;
    public SyncList(List l){
      this.myList = l;
    }
    public boolean add(T x){
      synchronized(this.myList){
        return myList.add(x);
      }
    }
    public T remove(int i){
      synchronized(this.myList){
        return myList.remove(i);
      }

    }
  }

  public static List<T> synchronizedList(List<T> list){
    return new SyncList(list);
  }
}
