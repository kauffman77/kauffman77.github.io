// Serial Java version of a 2D atom collisions calculations. Several
// parallel versions are the subject of in-class work.
import java.util.ArrayList;

public class Collisions{
  static class Atom {
    double x, y, rad;
    public Atom(double x, double y, double rad){
      this.x=x; this.y=y; this.rad=rad;
    }
  }

  static Atom [] atoms = {
            //   x       y     rad
    new Atom( 10.6,    2.8,    1.7),
    new Atom(  5.9,   18.6,    1.8),
    new Atom( 14.2,   19.3,    0.0),
    new Atom( 10.4,   12.8,    0.2),
    new Atom(  7.0,   18.8,    1.4),
    new Atom( 16.1,   10.0,    0.0),
    new Atom( 14.0,    7.3,    0.8),
    new Atom( 14.3,    9.1,    0.4),
    new Atom( 15.2,   18.7,    1.0),
    new Atom( 17.7,   17.9,    0.0),
    new Atom( 15.5,    3.8,    1.5),
    new Atom( 18.7,   13.5,    0.0),
    new Atom(  9.6,    6.3,    1.0),
    new Atom( 10.8,   10.5,    1.9),
    new Atom( 16.9,    7.0,    0.2),
    new Atom(  0.0,   18.2,    1.9),
    new Atom(  3.6,    6.6,    1.7),
    new Atom( 16.0,    6.2,    0.5),
    new Atom( 16.1,    3.1,    0.1),
    new Atom(  2.0,   18.9,    0.9),
  };


  // Parallelize the main computation
  public static void main(String args[]){

    int natoms = atoms.length;

    ArrayList<Integer> collisions = new ArrayList<Integer>();
    double xd,yd,dist,rads;
    for(int i=0; i<natoms-1; i++){
      for(int j=i+1; j<natoms; j++){
        xd = atoms[i].x - atoms[j].x;
        yd = atoms[i].y - atoms[j].y;
        dist = Math.sqrt(xd*xd + yd*yd);
        rads = atoms[i].rad + atoms[j].rad;
        if(dist < rads){
          collisions.add(i);
          collisions.add(j);
        }
      }
    }
  
    int ncollisions = collisions.size()/2;
    System.out.printf("%d collisions occurred\n",
                      ncollisions);
    for(int i=0; i<collisions.size()/2; i++){
      System.out.printf("%2d and %2d\n",
                        collisions.get(i*2+0),
                        collisions.get(i*2+1));
    }
    return;
  }
}
