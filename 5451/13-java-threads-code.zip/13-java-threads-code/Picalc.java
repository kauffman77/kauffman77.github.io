// Picalc.java: serial implementation of pi calculation via Monte
// Carlo Simulation.

import java.util.Random;

public class Picalc {
  public static void main(String args[]) { 
    if(args.length < 1){
      System.out.printf("usage: java Picalc <num_samples> \n");
      System.out.printf("  num_samples: int, how many sample points to try, higher gets closer to pi\n");
      return;
    }

    int total_hits = 0;

    Random rand = new Random(123456789);

    int npoints = Integer.parseInt(args[0]);

    for (int i = 0; i < npoints; i++) { 
      double x = rand.nextDouble();
      double y = rand.nextDouble();
      if (x*x + y*y <= 1.0){
        total_hits++;
      }
    } 

    double pi_est = ((double)total_hits) / npoints * 4.0;
    System.out.printf("npoints: %8d\n",npoints);
    System.out.printf("hits:    %8d\n",total_hits);
    System.out.printf("pi_est:  %f\n",pi_est);
    return;
  }
}
