// Thread-parallel version of Collisions using reduction-style
import java.util.ArrayList;

public class CollisionsReduction{

  static class Atom{
    double x, y, rad;
    public Atom(double x, double y, double rad){
      this.x=x; this.y=y; this.rad=rad;
    }

  }
  static Atom [] atoms = {
            //   x       y     rad
    new Atom( 10.6,    2.8,    1.7),
    new Atom(  5.9,   18.6,    1.8),
    new Atom( 14.2,   19.3,    0.0),
    new Atom( 10.4,   12.8,    0.2),
    new Atom(  7.0,   18.8,    1.4),
    new Atom( 16.1,   10.0,    0.0),
    new Atom( 14.0,    7.3,    0.8),
    new Atom( 14.3,    9.1,    0.4),
    new Atom( 15.2,   18.7,    1.0),
    new Atom( 17.7,   17.9,    0.0),
    new Atom( 15.5,    3.8,    1.5),
    new Atom( 18.7,   13.5,    0.0),
    new Atom(  9.6,    6.3,    1.0),
    new Atom( 10.8,   10.5,    1.9),
    new Atom( 16.9,    7.0,    0.2),
    new Atom(  0.0,   18.2,    1.9),
    new Atom(  3.6,    6.6,    1.7),
    new Atom( 16.0,    6.2,    0.5),
    new Atom( 16.1,    3.1,    0.1),
    new Atom(  2.0,   18.9,    0.9),
  };

  // set by the main method
  static int totalThreads; 

  static class Collider extends Thread{
    int threadNum;                 // Which thread
    ArrayList<Integer> collisions; // Local results

    // Construct a worker thread
    public Collider(int threadNum){
      this.threadNum = threadNum;
      this.collisions = new ArrayList<Integer>();
    }

    // Report the local results
    public ArrayList<Integer> getCollisions(){
      return this.collisions;
    }

    // Do work
    public void run(){
      int natoms = atoms.length;
      double xd,yd,dist,rads;
      
      // Divide outer loop iterattions by starting/stepping
      // differently for each thread
      for(int i=threadNum; i<natoms-1; i+=totalThreads){
        for(int j=i+1; j<natoms; j++){
          xd = atoms[i].x - atoms[j].x;
          yd = atoms[i].y - atoms[j].y;
          dist = Math.sqrt(xd*xd + yd*yd);
          rads = atoms[i].rad + atoms[j].rad;
          if(dist < rads){
            collisions.add(i);
            collisions.add(j);
          }
        }
      }
    }
  }

  public static void main(String args[]){
    // Accept number of threads from the command lin
    totalThreads = Integer.parseInt(args[0]);

    // Used to accumulate results from all children
    ArrayList<Integer> allCollisions = new ArrayList<Integer>();

    // Create and start worker threads running
    Collider threads[] = new Collider[totalThreads];
    for(int i=0; i<totalThreads; i++){
      threads[i] = new Collider(i);
      threads[i].start();
    }
    
    // Join on threads. While waiting to join can potentially be
    // interrupted so handle interruptions ungracefully.
    for(int i=0; i<totalThreads; i++){
      try{
        threads[i].join();                                 // Wait for child thread
        allCollisions.addAll( threads[i].getCollisions()); // Merge results
      }
      catch(InterruptedException e){
        System.out.println("Interrupted waiting for thread "+i);
      }
    }

    // Report results
    int ncollisions = allCollisions.size()/2;
    System.out.printf("%d collisions occurred\n",
                      ncollisions);
    for(int i=0; i<allCollisions.size()/2; i++){
      System.out.printf("%2d and %2d\n",
                        allCollisions.get(i*2+0),
                        allCollisions.get(i*2+1));
    }

    return;
  }
}
