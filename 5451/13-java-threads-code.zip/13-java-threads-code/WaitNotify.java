// Demonstrate busy waiting (polling) versus blocking waits in java
// threads. Usage:
// 
// > time java WaitNotify busy
// > time java WaitNotify blocking
//
// Should see same wall time but drastically different cpu time usage
// akin to the following:
// 
// >> javac WaitNotify.java
// 
// >> time java WaitNotify busy
// Starting busy wait
// Enabling joy
// Joy has been achieved!
//   real       0m2.060s
//   user       0m2.050s
//   sys        0m0.018s
// 
// >> time java WaitNotify blocking
// Starting blocking wait
// Enabling joy
// Joy and efficiency have been achieved!
//   real       0m2.061s
//   user       0m0.041s
//   sys        0m0.031s

// Class to serve coordinate on; field joy starts false and a thread
// waits either busily or blocking on changing to true
class C {

  // volatile: force threads to see changes made by other threads
  public volatile boolean joy = false;

  // // Try replacing the above with following with busy waiting...
  // // non-volatile: thread local memory which may not sync with changes made externally
  // public boolean joy = false;

  // Busy polling
  public void busyGuardedJoy() {
    while(!this.joy);           // Empty while loop - busy wait
    System.out.println("Joy has been achieved!");
  }

  // Blocking wait 
  public synchronized void blockingGuardedJoy() {
    while(!this.joy) {
      try {
        this.wait();
      } catch (InterruptedException e) {}
    }
    System.out.println("Joy and efficiency have been achieved!");
  }

  // Flip state of waiting
  public synchronized void notifyJoy() {
    System.out.println("Enabling joy");
    this.joy = true;
    this.notifyAll();
  }
}

public class WaitNotify{
  static C c = new C();  
  public static void main(String args[]) throws InterruptedException{

    if(args.length == 0){
      System.out.println("java WaitNotify <busy | blocking>");
      return;
    }

    // Create either a blocking or busy thread to demonstrate
    Thread t = null;
    if(args[0].equals("blocking")){
      t = new Thread(){
          public void run(){
            System.out.println("Starting blocking wait");
            c.blockingGuardedJoy();
          }
        };
    }
    else if(args[0].equals("busy")){
      t = new Thread(){
          public void run(){
            System.out.println("Starting busy wait");
            c.busyGuardedJoy();
          }
        };
    }
    else{
      System.out.printf("Don't undestand option '%s'\n",args[0]);
      return;
    }

    // Start the thread, have main() sleep, and on waking enable joy
    t.start();
    Thread.sleep(2000);
    c.notifyJoy();
    t.join();
  }
}
