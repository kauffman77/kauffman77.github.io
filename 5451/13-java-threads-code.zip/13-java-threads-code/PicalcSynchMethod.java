// Thread-paralle version of Picalc which uses a synchronized method
// to control updates to the global totalHits. This version will
// obviously be much slower.

import java.util.Random;

public class PicalcSynchMethod {

  static int totalHits;         // shared "global" variable among all threads

  static synchronized void incrTotal(){ // sychronized keyword locks on entry
    totalHits++;                        // so a single thread executes
  }

  static class CalcThread extends Thread{
    int threadNum;
    int nPoints;

    public CalcThread(int threadNum, int nPoints){
      this.threadNum = threadNum;
      this.nPoints = nPoints;
    }

    public void run(){
      Random rand = new Random(123456789 * this.threadNum);
      for (int i = 0; i < this.nPoints; i++) { 
        double x = rand.nextDouble();
        double y = rand.nextDouble();
        if (x*x + y*y <= 1.0){
          // totalHits++;
          incrTotal();          // invoke synchronized method to update
        }
      } 
    }
  }

  public static void main(String args[]) { 
    if(args.length < 2){
      System.out.printf("usage: java Picalc <num_samples> <nthreads>\n");
      System.out.printf("  num_samples: int, how many sample points to try, higher gets closer to pi\n");
      System.out.printf("  nthreads   : int, how many threads to use\n");
      return;
    }

    int nPoints  = Integer.parseInt(args[0]);
    int nThreads = Integer.parseInt(args[1]);
    CalcThread threads[] = new CalcThread[nThreads];
    for(int i=0; i<nThreads; i++){
      threads[i] = new CalcThread(i, nPoints/nThreads);
      threads[i].start();
    }
    
    totalHits = 0;
    for(int i=0; i<nThreads; i++){
      try{
        threads[i].join();
      }
      catch(InterruptedException e){
        System.out.println("Interrupted waiting for thread "+i);
      }
    }

    double piEst = ((double) totalHits) / nPoints * 4.0;
    System.out.printf("npoints: %8d\n",nPoints);
    System.out.printf("hits:    %8d\n",totalHits);
    System.out.printf("pi_est:  %f\n",piEst);
    return;
  }
}
