// PicalcReduction.java: Thread parallel version of Picalc which uses
// a reduction style-computation to accumulate results between
// threads.

import java.util.Random;

public class PicalcReduction {

  static class CalcThread extends Thread{
    // static subclass : Allows creation of the class without need for
    // an instance of the lexcially enclosing class to exist; e.g. can
    // create an instance of CalcThread within main() without
    // instantiating PicalcReduction.

    int threadNum;              // id for the thread
    int nPoints;                // number of points to calculate
    int hits;                   // number of hits in this thread

    public CalcThread(int threadNum, int nPoints){ // constructor 
      this.threadNum = threadNum;
      this.nPoints = nPoints;
    }

    public void run(){          // primary method invoked when thread is run
      Random rand = new Random(123456789 * this.threadNum);
      int myhits = 0;
      for (int i = 0; i < this.nPoints; i++) { 
        double x = rand.nextDouble();
        double y = rand.nextDouble();
        if (x*x + y*y <= 1.0){
          myhits++;
        }
      } 
      this.hits = myhits;
    }
    
    public int getHits(){       // allows access to calculated hits
      return this.hits;
    }
  }

  public static void main(String args[]) { 
    if(args.length < 2){
      System.out.printf("usage: java Picalc <num_samples> <nthreads>\n");
      System.out.printf("  num_samples: int, how many sample points to try, higher gets closer to pi\n");
      System.out.printf("  nthreads   : int, how many threads to use\n");
      return;
    }

    int nPoints  = Integer.parseInt(args[0]);
    int nThreads = Integer.parseInt(args[1]);

    long start = System.currentTimeMillis();

    // Create an array of threads
    CalcThread threads[] = new CalcThread[nThreads];
    for(int i=0; i<nThreads; i++){
      threads[i] = new CalcThread(i, nPoints/nThreads);
      threads[i].start();       // start thread running
    }
    
    int totalHits = 0;
    for(int i=0; i<nThreads; i++){
      try{                      // join() may throw an exception
        threads[i].join();      // join and perform reduction
        totalHits += threads[i].getHits();
      }
      catch(InterruptedException e){
        System.out.println("Interrupted waiting for thread "+i);
      }
    }
    long stop = System.currentTimeMillis();

    double piEst = ((double)totalHits) / nPoints * 4.0;
    System.out.printf("npoints: %8d\n",nPoints);
    System.out.printf("hits:    %8d\n",totalHits);
    System.out.printf("pi_est:  %f\n",piEst);

    double elapsedSeconds = (((double) stop) - ((double) start)) / 1000;
    System.out.printf("%.4f secs of compute\n",elapsedSeconds);
    return;
  }
}
