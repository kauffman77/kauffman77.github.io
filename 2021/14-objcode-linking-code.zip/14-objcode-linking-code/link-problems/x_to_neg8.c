// FILE: x_to_neg8.c
#include "x_to_neg8.h"

long x;      // actual global var definition

void x_to_neg8(){
  x = -8;    // set global var
}
