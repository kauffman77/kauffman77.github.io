// FILE: x_main.c
#include <stdio.h>
#include "x_to_neg8.h"
// defines that there will be an x and an x_to_neg8() function

//long x = 0;
long y = 0;

void x_to_neg8();
int main(){
  x_to_neg8();  // set x 
  printf("x: %ld\n",x);
  printf("y: %ld\n",y);
  int *xp = (int *) &x;
  printf("*xp: %d\n", *xp);
  return 0;
}
