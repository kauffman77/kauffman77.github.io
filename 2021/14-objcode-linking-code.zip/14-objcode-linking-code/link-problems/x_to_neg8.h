// FILE: x_to_neg8.h

#ifndef X_TO_NEG8_H
#define X_TO_NEG8_H

// globals defined in x_to_neg8.c, all weak symbols
extern long x;      
void x_to_neg8();

#endif
