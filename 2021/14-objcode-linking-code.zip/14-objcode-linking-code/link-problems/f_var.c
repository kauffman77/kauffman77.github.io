int func = 2;

int flunc(int x){
  return 2 * x;
}
