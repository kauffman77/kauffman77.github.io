// FILE: vf_strong_var.c
int foo = 0;
