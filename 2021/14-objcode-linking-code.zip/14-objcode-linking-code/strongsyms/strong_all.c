int foo;

void incfoo(){
  foo++;
}
int foo(int x){
  return 2*x;
}
#include <stdio.h>

void incfoo();
//extern int foo;
int foo(int x);

int main(){
  incfoo();
  printf("%d\n",foo);
  printf("%d\n",foo(2));
  return 0;
}
