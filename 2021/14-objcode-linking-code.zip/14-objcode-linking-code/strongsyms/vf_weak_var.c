// FILE: vf_weak_var.c
int foo;
