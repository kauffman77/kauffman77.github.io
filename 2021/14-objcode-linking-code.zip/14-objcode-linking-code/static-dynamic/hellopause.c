#include <stdio.h>
int main(int argc, char *argv[]){
  printf("Hello world! I'm a program\n");
  getchar();
  return 0;
}
