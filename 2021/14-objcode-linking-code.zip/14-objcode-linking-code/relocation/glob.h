extern int glob_arr[128];
void glob_func1(int scale);
void glob_func2(int scale, int y[]);
