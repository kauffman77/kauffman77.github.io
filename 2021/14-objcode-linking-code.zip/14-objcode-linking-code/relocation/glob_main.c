#include <stdio.h>
#include "glob.h"

#define PTR_MINUS_PTR(p,q) (((size_t) p) - ((size_t) q))

int main(){
  printf("Addresses below will change from run to run\n");
  printf("Addresses differences will remain consistent\n");
  printf("\n");

  printf("ADDRESSES\n");
  printf("%8p: glob_arr variable\n",&glob_arr);
  printf("%8p: main func\n",&main);
  printf("%8p: glob_func1\n",&glob_func1);
  printf("%8p: glob_func2\n",&glob_func2);
  
  printf("\nADDRESS DIFFERENCES\n");
  printf("%8lx: glob_arr - main\n",PTR_MINUS_PTR(&glob_arr,&main));
  printf("%8lx: glob_arr - glob_func1\n",PTR_MINUS_PTR(&glob_arr,&glob_func1));
  printf("%8lx: glob_func1 - main\n",PTR_MINUS_PTR(&glob_func1,&main));
  printf("%8lx: glob_func2 - glob_func1\n",PTR_MINUS_PTR(&glob_func2,&glob_func1));
  // printf("%lx: glob_func1 - glob variable\n",PTR_MINUS_PTR(&glob_func1,&glob));
  // printf("%lx: glob_func1 - glob variable\n",PTR_MINUS_PTR(&glob_func1,&glob));
  // printf("%lx: main - glob variable\n",PTR_MINUS_PTR(&main,&glob));
  // printf("%lx: main - glob variable\n",PTR_MINUS_PTR(&main,&glob));
  // printf("%lu: main func\n",&main);
  // printf("%lu: glob_func1 func\n",&glob_func1);
  // printf("%lu: glob_func2 func\n",&glob_func2);
}  
  
