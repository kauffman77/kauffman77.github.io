// file: glob.c

#include <stdio.h>
#include "glob.h"

int glob_arr[128];

void glob_func1(int scale){
  for(int i=0; i<128; i++){
    glob_arr[i] *= scale;
  }
}

void glob_func2(int scale, int y[]){
  glob_func1(scale);
  for(int i=0; i<128; i++){
    glob_arr[i] += y[i];
    printf("%d\n",glob_arr[i]);
  }
}
