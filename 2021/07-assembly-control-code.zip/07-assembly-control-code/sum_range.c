int sum_range(int start, int stop){
  int sum = 0;
  for(int i=start; i<=stop; i++){
    sum += i;
  }
  return sum;
}
