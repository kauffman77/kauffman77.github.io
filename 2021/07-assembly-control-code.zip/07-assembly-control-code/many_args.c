// many_args.c: includes a function that takes 8 arguments to
// demonstrate that arguments beyond the first 6 go on ths stack in
// x86-64. During execution of myfunc(), the first few assembly
// instructions are
//
// movq   8(%rsp),%r11
// movq  16(%rsp),%rax
//
// which use the stack pointer to pull the additional arguments off
// the stack into registers for subsequent arithmetic. %rsp itself
// continues to point at the return address as in the following diagram.
// 
// |-----+-----+-------|
// | Sym | REG | Value |
// |-----+-----+-------|
// | a   | rdi |    10 |
// | b   | rsi |    20 |
// | c   | rdx |    30 |
// | d   | rcx |    40 |
// | e   | r8  |    50 |
// | f   | r9  |    60 |
// | -   | rsp | #2048 |----------+
// |-----+-----+-------|          |
//                                |
// | Symbol | MEM   | Value   |   |
// |--------+-------+---------|   |
// | ...    | ...   | ...     |   |
// | h      | #2064 | 80      |   |
// | g      | #2056 | 70      |   |
// | -      | #2048 | RetAddr |<--+
// |        |       |         |

#include <stdio.h>

long myfunc(long a, long b, long c, long d,
            long e, long f, long g, long h)
{
    long xx = a * b * c * d * e * f * g * h;
    long yy = a + b + c + d + e + f + g + h;
    return xx*yy;
}

int main(){
  long result = myfunc(10, 20, 30, 40, 50, 60, 70, 80);
  printf("result: %ld\n",result);
  return 0;
}
