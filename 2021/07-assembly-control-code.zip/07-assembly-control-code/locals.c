int set_buf(char *b, int *s);

int main(){
  int size = -1;
  char buf[16];
  int x = set_buf(buf, &size);
  return 0;
}

