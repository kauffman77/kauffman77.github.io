> cat -n globals_bad.s               # show a bad way to use globals
     1	.data
     2	an_int:                      # global an_int
     3	        .int 17
     4	a_short:                     # global a_short
     5	        .short 12
     6	
     7	.text
     8	.globl  main
     9	main:
    10	        movl an_int,  %eax   # load global in eax
    11		movq $0, %rdx
    12	        movw a_short, %dx    # load global into dx
    13	        addl %edx, %eax
    14	        ret

> gcc globals_bad.s                  # compilation failes
/usr/bin/ld: /tmp/cc0MMJiv.o: relocation R_X86_64_32S against '.data' can not be used when making a PIE object; recompile with -fPIE
/usr/bin/ld: final link failed: nonrepresentable section on output
collect2: error: ld returned 1 exit status

> cat -n globals_good.s              # a good way to load globals
     1	.data
     2	an_int:
     3	        .int 17
     4	a_short:
     5	        .short 12
     6	
     7	.text
     8	.globl  main
     9	main:
    10	        movl an_int(%rip),  %eax   # use relative address from instruction pointer
    11		movq $0, %rdx
    12	        movw a_short(%rip), %dx    # again, relative position
    13	        addl %edx, %eax
    14	        ret

> gcc globals_good.s                       # compile succeeds
> ./a.out                                  # run program
> echo $?                                  # show return value of program: 17+12=29
29
