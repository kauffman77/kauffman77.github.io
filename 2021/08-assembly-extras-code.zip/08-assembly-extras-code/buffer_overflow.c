// buffer_overflow.c: Demo of a buffer overflow attack.
// 
// This code can get the function never() to run even though there are
// now calls to it in the code. This is done as follows.
// 
// 1. Compile to disable stack protection mechanisms via
//    > gcc -fno-stack-protector buffer_overflow.c 
// 
// 2. Run the code and inspect the addresses of functions and the
//    contents of the buf[] array which are mostly out of bounds.
//    Usually buf[2] looks like an address that is close to the
//    address of main() and is likely the stack location of the
//    return address for always().
//
// 3. Copy the address of never() from the output of the program and
//    paste it in as the input that will overwrite buf[2], often as
//    input that looks like this:
//    Enter 4 hex values: 0x01 0x2 0x5617e8b65159 0x4
//
// 4. One should see the routine never() run as evidenced by the output
//      This should never happen
//    which in a real setting might contain passwords, financial data,
//    or be a function that gives superviser control to an attacker.

#include <stdio.h>
void always();
void never();

int main(){
  printf("Running always()\n");
  always();
  printf("Done with always()\n");
  return 0;
}

void always(){
  long buf[1] = {0xABCD};

  printf("This always happens\n");
  printf("Address of never:  %0p\n",never);
  printf("Address of main:   %0p\n",main);
  printf("buf[0]:            %0p\n",buf[0]);
  printf("buf[1]:            %0p\n",buf[1]);
  printf("buf[2]:            %0p\n",buf[2]);
  printf("buf[3]:            %0p\n",buf[3]);

  printf("Enter 4 hex values: ");
  fscanf(stdin,"%lx %lx %lx %lx",
         &buf[0], &buf[1], &buf[2], &buf[3]);

  printf("buf[0]:            %0p\n",buf[0]);
  printf("buf[1]:            %0p\n",buf[1]);
  printf("buf[2]:            %0p\n",buf[2]);
  printf("buf[3]:            %0p\n",buf[3]);

  return;
}


void never(){
  printf("This should never happen\n");
  return;
}
