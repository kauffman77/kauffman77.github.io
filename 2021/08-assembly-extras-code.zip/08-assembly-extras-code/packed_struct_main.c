// packed_struct_main.c: illustrates how a small struct can be packed
// into a single register when it is passed as an argument. Used with
// accompanying assembly file. Compile and run with
// 
// > gcc packed_struct.s packed_struct_main.c 

#include <stdio.h>

typedef struct {                // struct that can be passed as arg
  short first;                  // bits 0-15 in a register, bytes 0-1 in memory
  short second;                 // bits 16-31 in a register, bytes 2-3 in memory
} twoints_t;                    

short sub_struct(twoints_t ti); // returns (ti.first - ti.second)

int main(){
  twoints_t ti = {.first=10, .second=-2}; // initialize struct
  int sum = sub_struct(ti);               // call function with struct arg
  printf("difference of %d and %d is %d\n",
         ti.first, ti.second, sum);
  return 0;
}
