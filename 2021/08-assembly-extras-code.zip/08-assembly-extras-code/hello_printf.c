#include <stdio.h>
int main(){
  printf("Hello Message\n");
  return 0;
}
