 /* 
 * phase5e.c - Similar to phase5a, this phase takes an input from the user
 * which is used to traverse a loop of pointers. To make sure they are not guessing,
 * the user must also input the difference of all the numbers (starting from 150).
 */
void phase_5(char *input)
{
#if defined(PROBLEM)
    static int array[] = {
      10,
      2,
      14,
      7,
      8,
      12,
      15,
      11,
      0,
      4,
      1,
      13,
      3,
      9,
      6,
      5
    };

    int count, sum;
    int start;
    int p, result;
    int numScanned;

    numScanned = sscanf(input, "%d %d", &p, &result);
    
    if (numScanned < 2)
      explode_bomb();

    p = p & 0x0f;
    start = p; /* debug */

    count = 0;
    sum = 150;
    while(p != 15) {
	count++;
	p = array[p];
	sum -= p;
    }

    if ((count != COUNT_VALUE_SET) || (sum != result))
	explode_bomb();
#elif defined(SOLUTION)
    char *ans = NULL;
    switch (COUNT_VALUE_GET) {
    case 1: ans="6 135"; break;
    case 2: ans="14 129"; break;
    case 3: ans="2 115"; break;
    case 4: ans="1 113"; break;
    case 5: ans="10 112"; break;
    case 6: ans="0 102"; break;
    case 7: ans="8 102"; break;
    case 8: ans="4 94"; break;
    case 9: ans="9 90"; break;
    case 10: ans="13 81"; break;
    case 11: ans="11 68"; break;
    case 12: ans="7 57"; break;
    case 13: ans="3 50"; break;
    case 14: ans="12 47"; break;
    case 15: ans="5 35"; break;
    default:
	printf("ERROR: bad count value in phase5a\n");
	exit(8);
    }
    printf("%s %s\n",ans,SECRET_PHRASE);
#else
    invalid_phase("5e");
#endif
}


