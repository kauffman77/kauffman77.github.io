#define SIZE 5

long hashcode(char* key) {
  union {
    char str[8];
    long num;
  } strnum;
  strnum.num = 0;

  for(int i=0; i<8; i++) {
    if(key[i] == '\0')
      break;
    strnum.str[i] = key[i];
  }

  return strnum.num;
}

void insert(int n, char** keys, char** vals, hashmap_t* hm) {
  for (int i = 0; i < n; i++) {
    long code = hashcode(keys[i]);
    int index = code % hm->table_size;
    int vI = i & 1 ? n - (i + 1) / 2 : i / 2;

    hashnode_t* ptr = hm->table[index];
    if (ptr) {
      hashnode_t* prev;
      while (ptr) {
        if (strcmp(ptr->key, keys[i]) == 0) {
          strcpy(ptr->val, vals[vI]);
          return;
        }
        prev = ptr;
        ptr = ptr->next;
      }

      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);

      node->next = NULL;
      prev->next = node;
      hm->item_count++;
    } else {
      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);
      node->next = NULL;
      hm->table[index] = node;
      hm->item_count++;
    }
  }
}

char* get(char* key, hashmap_t* hm) {
  long code = hashcode(key);
  int index = code % hm->table_size;

  hashnode_t* ptr = hm->table[index];
  while (ptr) {
    if (strcmp(ptr->key, key) == 0)
      return ptr->val;
    ptr = ptr->next;
  }

  return NULL;
}

void prep6(hashmap_t* hm) {
  hm->item_count = 0;
  hm->table_size = SIZE;
  hm->table = malloc(sizeof(hashnode_t*) * SIZE);
  memset(hm->table, 0,  sizeof(hashnode_t*) * SIZE);

  char* keys[] = {"Chrom", "Robin", "Edelgard", "Lucina", "Rey", "Kylo", "Vader"};
  char* vals[] = {"Luke", "Finn", "Han", "Leia", "Azura", "Byleth", "Corrin"};
  insert(7, keys, vals, hm);
}

void phase_6(char* input) {
#if defined(PROBLEM)
  char key0[128];
  char key1[128];
  char key2[128];
  char* keys[] = {key0, key1, key2};

  if (sscanf(input, "%s %s %s", key0, key1, key2) != 3) {
    explode_bomb();
  }
  for (int i=0; i<2; i++) {
    if (strcmp(keys[i],keys[i+1])>=0) {
      explode_bomb();
    }
  }
  hashmap_t hm;
  prep6(&hm);
  char* prev = get(keys[0], &hm);
  for (int i = 1; i < 3; i++) {
    char* curr = get(keys[i], &hm);
    if (!prev || !curr || strcmp(prev, curr) <= 0)
      explode_bomb();
    prev = curr;
  }


#elif defined(SOLUTION)
  printf("Chrom Edelgard Kylo\n");
  /*hashmap_t hm;
  char* keys[] = {"Chrom", "robin", "edelgard", "Lucina", "azura", "Byleth", "corrin"};
  char* vals[] = {"Luke", "Rey", "Han", "Leia", "Finn", "Kylo", "Vader"};
  insert(7, keys, vals, hm);
  for (int i=0; i<hm->table_size; i++) {
    if (strcmp(hm->table[i]->val, vals[2])==0){
      printf("%s\n",hm->table[i]->key);
    }
    }*/

#else
  invalid_phase("6d");
#endif
}
