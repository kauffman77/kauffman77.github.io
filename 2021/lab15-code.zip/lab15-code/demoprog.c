#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int important_func(int arg1, long arg2){
  printf("%p : important_func()\n",&important_func);
  printf("%p : arg1\n",&arg1);
  printf("%p : arg2\n",&arg2);
  printf("program pid is %d\n",getpid());
  printf("press any key to continue\n");
  getchar();
}

int main(int argc, char *argv[]){
  int x = 1;
  long y = 2;
  important_func(x, y);
  return 0;
}
