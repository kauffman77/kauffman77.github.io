// void_pointer_fixed.c: Demonstrates more standard C where typed
// pointers are used
#include <stdio.h>
int main(){
  int a = 5;                    // int
  double x = 1.2345;            // double
  // void *ptr;                    // pointer to anything

  int *iptr = &a;               // integer only pointer
  int b = *iptr;                // no caste needed
  printf("%d\n",b);

  double *dptr = &x;            // double only pointer
  double y = *dptr;             // no caste needed
  printf("%f\n",y);

  int c = *dptr;                // compiler inserts a conversion: 
  printf("%d\n",c);             // double -> int -> prints 1

  return 0;
}
