// print_file.c: Standard method to print a file character by
// character. Requires a storage space for characters as they are read
// from the file. Contrast this approach with mmap_print_file.c
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <file>\n",argv[0]);
    return 0;
  }

  FILE *fin = fopen(argv[1], "r");             // open file to get file descriptor
  char inchar;
  while(1){                                    // loop over the file
    int result = fscanf(fin, "%c", &inchar);   // read a character
    if(result == EOF){                         // check for end of file
      break;
    }
    printf("%c", inchar);                      // print single character read
  }

  fclose(fin);                                 // close the file
  return 0;
}
