/*
 * phase2d.c - To defeat this stage the user must enter a sequence of
 * 6 nonnegative numbers where x[i] = x[i-1]*3 + i*10
 */
void phase_2(char *input)
{
#if defined(PROBLEM)
    int i;
    int numbers[6];

    read_six_numbers(input, numbers);

    if (numbers[0] < 0)
	explode_bomb();

    for(i = 1; i < 6; i++) {
	if (numbers[i] != (numbers[i - 1])*3 + (i*10))
	    explode_bomb();
    }
#elif defined(SOLUTION)
    printf("0 10 50 180 580 1790 %s\n",SECRET_PHRASE);
#else
    invalid_phase("2a");
#endif
}
