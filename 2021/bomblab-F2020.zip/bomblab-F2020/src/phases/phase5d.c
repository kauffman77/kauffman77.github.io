/*
 * phase5d, must input an index of a loop of pointers. 
 * Each element of the array represents the offset
 * for the next element in the loop--ending at 15.
 * Users must input the starting index so that it iterates
 * the right amount of times, and must also enter in 
 * the sum of the array indexes to know they are not cheating.  
 */
void phase_5(char *input)
{
#if defined(PROBLEM)
    static int array[] = {
      5,  //0
      5,  //1
      10, //2
      6,  //3
      -1, //4
      -3, //5
      2,  //6
      4,  //7
      7,  //8
      5,  //9
      -2, //10
      2,  //11
      -5, //12
      -9, //13
      -13,//14 
      0   //15
    };
    //0, 5, 2, 12, 7, 11, 13, 4, 3, 9, 14, 1, 6, 8, 15
    int count, sum;
    int start;
    int p, result;
    int numScanned;

    numScanned = sscanf(input, "%d %d", &p, &result);
    
    if (numScanned < 2)
      explode_bomb();

    p = p & 0x0f;

    count = 0;
    sum = 0;
    while(p != 15) {
	count++;
    sum += p;
	p = array[p]+p;
    }
    count++;

    if(count != COUNT_VALUE_SET || sum != result) {
        explode_bomb();
    }

#elif defined(SOLUTION)
    switch (COUNT_VALUE_GET) {
    case 1: printf("15 0"); break;
    case 2: printf("8 8"); break;
    case 3: printf("6 14"); break;
    case 4: printf("1 15"); break;
    case 5: printf("14 29"); break;
    case 6: printf("9 38"); break;
    case 7: printf("3 41"); break;
    case 8: printf("4 45"); break;
    case 9: printf("13 58"); break;
    case 10: printf("11 69"); break;
    case 11: printf("7 76"); break;
    case 12: printf("12 88"); break;
    case 13: printf("2 90"); break;
    case 14: printf("5 95"); break;
    case 15: printf("0 95"); break;
    default:
	printf("ERROR: bad count value in phase5a\n");
	exit(8);
    }
    printf("\n");

#else
    invalid_phase("5d");
#endif
}


