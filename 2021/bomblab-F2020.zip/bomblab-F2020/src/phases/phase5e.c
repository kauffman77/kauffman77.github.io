 /* 
 * phase5e.c - Similar to phase5a, this phase takes an input from the user
 * which is used to traverse a loop of pointers. To make sure they are not guessing,
 * the user must also input the difference of all the numbers (starting from 150).
 */
void phase_5(char *input)
{
#if defined(PROBLEM)
    static int array[] = {
      10,
      2,
      14,
      7,
      8,
      12,
      15,
      11,
      0,
      4,
      1,
      13,
      3,
      9,
      6,
      5
    };

    int count, sum;
    int start;
    int p, result;
    int numScanned;

    numScanned = sscanf(input, "%d %d", &p, &result);
    
    if (numScanned < 2)
      explode_bomb();

    p = p & 0x0f;
    start = p; /* debug */

    count = 0;
    sum = 150;
    while(p != 15) {
	count++;
	p = array[p];
	sum -= p;
    }

    if ((count != COUNT_VALUE_SET) || (sum != result))
	explode_bomb();
#elif defined(SOLUTION)
    switch (COUNT_VALUE_GET) {
    case 1: printf("6 135"); break;
    case 2: printf("14 129"); break;
    case 3: printf("2 115"); break;
    case 4: printf("1 113"); break;
    case 5: printf("10 112"); break;
    case 6: printf("0 102"); break;
    case 7: printf("8 102"); break;
    case 8: printf("4 94"); break;
    case 9: printf("9 90"); break;
    case 10: printf("13 81"); break;
    case 11: printf("11 68"); break;
    case 12: printf("7 57"); break;
    case 13: printf("3 50"); break;
    case 14: printf("12 47"); break;
    case 15: printf("5 35"); break;
    default:
	printf("ERROR: bad count value in phase5a\n");
	exit(8);
    }
    printf("\n");
#else
    invalid_phase("5e");
#endif
}


