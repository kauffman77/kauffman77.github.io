/*
 * phase6d.c - The user has to enter the correct key string to match a
 * specific string in the hashmap.
 *
 * Since repeatedly calling insert manually makes this problem relatively
 * easy (just finding the arguments to insert), insert takes a list of
 * keys and values, and then inserts the keys and values, but using a
 * slightly obfuscated equation for selecting the value for each key.
 *
 * When debugging this, the easiest way is likely to realize that a hashmap
 * is being used and find calls to strcpy, and record the arguments (display
 * $rsi as a string), this will allow the user to associate between the key
 * and the value, and then finding the strcmp in phase_6 to determine what
 * the correct value is, so they can work out the correct key.
 */

#define SIZE 5

long hashcode(char* key) {
  union {
    char str[8];
    long num;
  } strnum;
  strnum.num = 0;

  for(int i=0; i<8; i++) {
    if(key[i] == '\0') 
      break;
    strnum.str[i] = key[i];
  }

  return strnum.num;
}

void insert(int n, char** keys, char** vals, hashmap_t* hm) {
  for (int i = 0; i < n; i++) {
    long code = hashcode(keys[i]);
    int index = code % hm->table_size;
    int vI = i & 1 ? n - (i + 1) / 2 : i / 2;

    hashnode_t* ptr = hm->table[index];
    if (ptr) {
      hashnode_t* prev;
      while (ptr) {
        if (strcmp(ptr->key, keys[i]) == 0) {
          strcpy(ptr->val, vals[vI]);
          return;
        }
        prev = ptr;
        ptr = ptr->next;
      }

      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);
      node->next = NULL;
      prev->next = node;
      hm->item_count++;
    } else {
      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);
      node->next = NULL;
      hm->table[index] = node;
      hm->item_count++;
    }
  }
}

char* get(char* key, hashmap_t* hm) {
  long code = hashcode(key);
  int index = code % hm->table_size;

  hashnode_t* ptr = hm->table[index];
  while (ptr) {
    if (strcmp(ptr->key, key) == 0)
      return ptr->val;
    ptr = ptr->next;
  }

  return NULL;
}

void prep6(hashmap_t* hm) {
  hm->item_count = 0;
  hm->table_size = SIZE;
  hm->table = malloc(sizeof(hashnode_t*) * SIZE);
  memset(hm->table, 0,  sizeof(hashnode_t*) * SIZE);

  char* keys[] = {"Eccleston", "Tennant", "Smith", "Capaldi", "Whitaker", 
    "Hurt", "Baker", "Davison"};
  char* vals[] = {"Rose", "Amy", "Yasmin", "Sarah", "Adric", "Moment", 
    "Clara", "Donna"};
  insert(8, keys, vals, hm);
}

void phase_6(char* input) {
#if defined(PROBLEM)
  char key0[128];
  char key1[128];
  char key2[128];
  char key3[128];
  char* keys[] = {key0, key1, key2, key3};

  if(sscanf(input, "%s %s %s %s", key0, key1, key2, key3) != 4) {
    explode_bomb();
  }
  for (int i = 1; i < 4; i++) {
    if (strcmp(keys[i-1], keys[i]) >= 0)
      explode_bomb();
  }
  
  hashmap_t hm;
  prep6(&hm);

  char* prev = get(keys[0], &hm);
  for (int i = 1; i < 4; i++) {
    char* curr = get(keys[i], &hm);
    if (!prev || !curr || strcmp(prev, curr) <= 0)
      explode_bomb();
    prev = curr;
  }
#elif defined(SOLUTION)
  printf("Baker Eccleston Hurt Smith\n");
#else
  invalid_phase("6d");
#endif
}
