// float_bits.c: Show binary layout of a float value in IEEE-754
// format
#include <stdio.h>
#include <math.h>   // macros for infinity

void showbits(void *xp);

int main(){
  float fl = 0.0;               // floating point value
  int *fp = (int *) &fl;        // pointer to float memory
  *fp = 0xC378C000;             // assign specific bits to float
  // *fp = 0b11000011011110001100000000000000;
  //         |   |   |   |   |   |   |   |   
  printf("%.4f\n",fl);
  showbits(&fl);


  printf("Assigning 0xC378C000 to float\n");
  fl = 0xC378C000;;             // compiler converts int constatnt to
  printf("%.4f\n",fl);          // float which produces a large value
  showbits(&fl);

  // Create value 1.0 with bits
  // 0b0 01111111 000 0000 0000 0000 0000 0000;
  //   s:exponent:mantissa (implied leading 1)

  *fp = 0b00111111100000000000000000000000;
  printf("%.4f\n",fl);
  showbits(&fl);


  // Special values: exponent bits are all 1s 

  // Playing with infinity
  float pinf =  INFINITY;
  float ninf = -INFINITY;
  float odz  = 1.0 / 0.0;
  float nodz = -1.0 / 0.0;
  printf("infinities: %f %f %f %f\n",pinf,ninf,odz,nodz);
  showbits(&pinf);
  showbits(&ninf);
  showbits(&odz);
  
  // NaN: not a number
  float nan = NAN;
  float odo = 0.0 / 0.0;
  float imi = INFINITY - INFINITY;
  printf("nans: %f %f %f\n",nan,odo,imi);
  showbits(&nan);
  showbits(&odo);
  showbits(&imi);
  
  printf("DENORMALIZED FLOATS\n"); 

  // Denormalized: very small numbers, exponent bits are all 0s
  float sm = 3.0;               // 1.1_2 * 2^1
  int exp_bits = 128;           // bits in float exponent: 1000_0000 = 128
  for(int i=0; i<125; i++){     
    sm /= 2.0;                  // divide by 2 125 times
    exp_bits--;
  }
  printf("--CLOSE TO DENORMALIZED---\n");
  printf("exp bits: %d\n",exp_bits); // 3
  printf("%e\n",sm);            // 1.1 * 2^-124 =~= 7.052966e-38
  showbits(&sm);                // 0_00000011_10000000000000000000000
  sm /= 2.0;                    // s exponent mantissa
  exp_bits--;

  printf("exp bits: %d\n",exp_bits); // 2
  printf("%e\n",sm);            // 1.1 * 2^-125 =~= 3.526483e-38
  showbits(&sm);                // 0_00000010_10000000000000000000000
  sm /= 2.0;                    // s exponent mantissa
  exp_bits--;

  printf("exp bits: %d\n",exp_bits); // 1
  printf("%e\n",sm);            // 1.1 * 2^-126 =~= 1.763242e-38
  showbits(&sm);                // 0_00000010_10000000000000000000000
  sm /= 2.0;                    // s exponent mantissa
  exp_bits--;

  printf("---DENORMALIZED---\n");
  printf("exp bits: %d\n",exp_bits); // 0
  printf("%e\n",sm);            // 3 * 2^-126 =~= 1.763242e-38
  showbits(&sm);                // shows all 0s exponent, 3 in mantissa
  sm /= 2.0;                    // s exponent mantissa

  for(int i=0; i < 25; i++){
     sm /= 2.0;
     printf("%e\n",sm);            // 3 * 2^-127 =~= 1.763242e-38
     showbits(&sm);                // shows all 0s exponent, 3 in mantissa
  }
  return 0;
}

#define INT_BITS 32

/* Print the most signficant (right-most) to least signficant bit in
   the integer passed in */
void showbits(void *xp){
  int x = *((int *) xp);
  int mask = 0x1;
  for(int i=INT_BITS-1; i>=0; i--){
    int shifted_mask = mask << i;
    if(shifted_mask & x){
      printf("1");
    } else {
      printf("0");
    }
  }
  printf("\n");
}
