#include <stdio.h>

int main(){
  printf("%.4e\n",123.456);
  printf("%.4e\n",50.01);
  printf("%.4e\n",0.54321);
  return 0;
}
