// func_v_macro.c: demonstrate timing differences between using
// function calls and macros. The mget()/vset() functions and
// MGET()/VSET() macros behave the same but macros do not involve
// control jumps so lead to better efficiency without
// optimizations. Performing function inlining such as is done at gcc
// -O3 will lead to near identical performance as the bodies of the
// small functions will be inserted at their call sites just like the
// macros are.
//
// The code features 3 versions of the rowsums code


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>               // for clock() and other functions
#include <stdio.h>
#include <sys/time.h>
#include "matvec.h"

// function versions of matrix/vector getter/setter
int mget(matrix_t mat, int i, int j){
  return mat.data[i*mat.cols + j];
}
int vset(vector_t vec, int i, int x){
  return vec.data[i] = x;
}

// macro versions of matrix/vector getter/setters
#define MGET(mat,i,j) ((mat).data[((i)*((mat).cols)) + (j)])
#define VSET(vec,i,x) ((vec).data[(i)] = (x))

// Use the function versions of mget() and vset()
void row_sums_FUNC(matrix_t mat, vector_t sums){
  for(int i=0; i<mat.rows; i++){
    int sum = 0;
    for(int j=0; j<mat.cols; j++){
      sum += mget(mat,i,j);
    }
    vset(sums, i, sum);
  }
}

// Use the macro versions which will avoid function calls
void row_sums_MACRO(matrix_t mat, vector_t sums){
  for(int i=0; i<mat.rows; i++){
    int sum = 0;
    for(int j=0; j<mat.cols; j++){
      sum += MGET(mat,i,j);
    }
    VSET(sums, i, sum);
  }
}

// Manually inline the body of the macro/function
void row_sums_MANUAL(matrix_t mat, vector_t sums){
  int idx = 0;
  for(int i=0; i<mat.rows; i++){
    int sum = 0;
    for(int j=0; j<mat.cols; j++){
      sum += mat.data[idx];
      idx++;
    }
    sums.data[i] = sum;
  }
}

int main(int argc, char *argv[]){

  if(argc < 3){
    printf("usage: %s <rows> <cols> \n",argv[0]);
    return 1;
  }

  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);


  // Allocate the matrix and fill it in with 1,2,3,4...
  matrix_t mat;
  int ret = matrix_init(&mat, rows,cols);
  matrix_fill_sequential(mat);

  // Variables for timing
  clock_t begin, end;
  double cpu_time;


  vector_t sums_FUNC;
  vector_init(&sums_FUNC, mat.rows);
  begin = clock();
  row_sums_FUNC(mat,sums_FUNC);
  end = clock();
  cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;
  printf("row_sums_FUNC:   %.4e secs\n",cpu_time);    

  
  vector_t sums_MACRO;
  vector_init(&sums_MACRO, mat.rows);
  begin = clock();
  row_sums_MACRO(mat,sums_MACRO);
  end = clock();
  cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;
  printf("row_sums_MACRO:  %.4e secs\n",cpu_time);    

  vector_t sums_MANUAL;
  vector_init(&sums_MANUAL, mat.rows);
  begin = clock();
  row_sums_MANUAL(mat,sums_MANUAL);
  end = clock();
  cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;
  printf("row_sums_MANUAL: %.4e secs\n",cpu_time);    

  matrix_free_data(&mat);
  vector_free_data(&sums_FUNC);
  vector_free_data(&sums_MACRO);
  vector_free_data(&sums_MANUAL);

  return 0;
}
