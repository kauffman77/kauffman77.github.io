#!/usr/bin/env bash

# Gradescope docker instance setup script

apt-get -y install build-essential gcc valgrind gawk zip tmux screen w3m
