// Bryant/O'Hallaron section 3.2.2 example
// Compile to assembly with
// > gcc -Og -S mstore.c
long mult2(long a, long b);
void multstore(long x, long y, long *dest){
  long t = mult2(x, y);
  *dest = t;
}

void doit(int a, int b);
void now(){
  doit(7, 9);
  return;
}
