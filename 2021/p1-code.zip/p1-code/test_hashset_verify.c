#include <stdio.h>
#include "hashset.h"
int main(){
  if((sizeof(hashset_t) != 32) || (sizeof(hashnode_t) != 144)){
    printf("Anti-theft countermeasures engaged\n");
    return 1;
  }
  return 0;
}
