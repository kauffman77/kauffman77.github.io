#include <stdio.h>
int main(int argc, char *argv[]){
  int x = 19;
  int y = 31;
  x = y;
  y = x;
  printf("x: %d y: %d\n",x,y);
  return x;
}
