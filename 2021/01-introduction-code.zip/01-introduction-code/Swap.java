public class Swap{
  public static void main(String args[]){
    int x = 42;                   
    int y = 31;                   
    swap(x, y);
    System.out.printf("%d %d\n",x,y);
    return;
  }

  public static void swap(int a, int b){
    int tmp = a;
    a = b;
    b = tmp;
    return;
  }
}
