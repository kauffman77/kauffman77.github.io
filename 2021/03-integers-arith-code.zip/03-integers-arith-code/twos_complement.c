// twos_complement.c: Demonstrate two's complement in C
#include <stdio.h>
int main(){
  char num = 124;               // initial signed positive number
  char neg = (~num) + 1;        // invert and add one to convert to negative twos complement
  char pos = (~neg) + 1;        // invert and add one to convert back to positive
  printf("%d %d %d\n",          // print number, negated version, and positive
         num,neg,pos);
  return 0;
}
