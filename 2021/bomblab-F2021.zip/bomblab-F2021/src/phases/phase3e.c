/*
 * phase3e.c - Builds an array of values. Asks for index of any value of the
 array and checks to see if the data is the same as input.
*/
void phase_3(char *input)
{
  #if defined(PROBLEM)

  int mystery_arrayb[20];
  for(int i = 0; i < 20; i++){
    if(i % 2 == 0){
      mystery_arrayb[i] = (i * i) + i;
    }
    else{
      mystery_arrayb[i] = (i + i) * i;
    }
  }

  int index, val = 0;
  int numScanned = 0;

  numScanned = sscanf(input, "%d %d", &index, &val);

  if (numScanned < 2)
    explode_bomb();

  if(index < 3 || index >= 20)
    explode_bomb();


  if (mystery_arrayb[index] != val)
    explode_bomb();

  #elif defined(SOLUTION)
  printf("3 18\n");
  #else
  invalid_phase("3b");
  #endif
}
