/*
 * phase3f.c - A long switch statement that the compiler should implement
 * with a jump table. The user has to enter both an index into the table
 * and a value stored there.
 */
void phase_3(char *input)
{
#if defined(PROBLEM)

int mystery_arrayc[15];
for(int i = 0; i < 15; i++){
   if(i % 2 != 0){
       mystery_arrayc[i] = (i << 4) >> 2;
   }
   else{
       mystery_arrayc[i] = (i << 3) >> 1;
   }
}

 int index, val = 0;
 int numScanned = 0;

 numScanned = sscanf(input, "%d %d", &index, &val);

 if (numScanned < 2)
explode_bomb();

if(index < 4 || index >= 15)
explode_bomb();

 if (mystery_arrayc[index] != val)
explode_bomb();

#elif defined(SOLUTION)
    printf("5 20\n");
#else
    invalid_phase("3c");
#endif
}
