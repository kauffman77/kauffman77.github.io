/*
 * phase2e.c - To defeat this stage the user must enter a sequence of
 * 6 nonnegative numbers where x[i] = x[i-1]*x[i-2]
 */
void phase_2(char *input)
{
#if defined(PROBLEM)
    int i;
    int numbers[6];

    read_six_numbers(input, numbers);

    if (numbers[0] != 2)
	explode_bomb();

    if (numbers[1] != 3)
  explode_bomb();


    for(i = 2; i < 6; i++) {
	if (numbers[i] != numbers[i - 1] * numbers[i-2] )
	    explode_bomb();
    }
#elif defined(SOLUTION)
    printf("2 3 6 18 108 1944\n");
    // printf("2 3 6 18 108 1944 %s\n",SECRET_PHRASE);
#else
    invalid_phase("2b");
#endif
}
