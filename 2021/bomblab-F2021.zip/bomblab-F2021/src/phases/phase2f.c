/*
 * phase2f.c - To defeat this stage the user must enter a sequence of
 * 6 numbers (possibly negative) where x[i] = x[i-2] - x[i-1]
 */
void phase_2(char *input)
{
  #if defined(PROBLEM)
      int i;
      int numbers[6];

      read_six_numbers(input, numbers);

      if (numbers[0] != 100 || numbers[1] != 75)
  	explode_bomb();
      for (i = 2; i < 6; i++) {
  	if (numbers[i] != numbers[i-2] - numbers[i-1])
  	    explode_bomb();
  }
#elif defined(SOLUTION)
      printf("100 75 25 50 -25 75\n");
      // printf("100 75 25 50 -25 75 %s\n",SECRET_PHRASE);
#else
    invalid_phase("2c");
#endif
}

