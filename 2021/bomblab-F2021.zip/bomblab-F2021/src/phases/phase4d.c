/*
 * A palindrome checker, student must input a number 
 * greater than 1234 and is palindrome. As a method to 
 * brute force proof, we make the student enter a second
 * palindrome number that is different from the first and 
 * greater than 12345
 */

int func4(int a, int *b)
{
  if (a >= 0 && a < 10)
    return (a == (*b % 10));
  if (!func4(a / 10, b))
    return 0;

  *b /= 10;

  return (a % 10 == *b % 10);
}

void phase_4(char *input) {
#if defined(PROBLEM)
    int user_val, user_val2;

    int numScanned = sscanf(input, "%d %d", &user_val, &user_val2);
    if ((numScanned != 2) || user_val < 1234 || user_val2 < 12345 || user_val == user_val2) {
	  explode_bomb();
    }

    int user_val_copy = user_val;
    int user_val_copy2 = user_val2;
    int ret = func4(user_val, &user_val_copy);
    int ret2 = func4(user_val2, &user_val_copy2);

    if (!ret || !ret2) {
	  explode_bomb();
    }
#elif defined(SOLUTION)
    printf("%d %d\n", 1331, 15651);
    // printf("%d %d %s\n", 1331, 15651, SECRET_PHRASE);
#else
    invalid_phase("4d");
#endif
}
