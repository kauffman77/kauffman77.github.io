/*
 * phase5f.c - This stage requires the user to enter a string of six
 * characters, where each character in the string is used as an offset
 * into the character array.  The six characters indexed by the
 * offsets must spell out a particular word IN REVERSE (similar to
 * phase 5b except for reverse).
 */

void phase_5(char *all_input)
{
#if defined(PROBLEM)
    static char array[] = {
	'm',
	'a',
	'd',
	'u',
	'i',
	'e',
	'r',
	's',
	'n',
	'f',
	'o',
	't',
	'v',
	'b',
	'y',
	'l'
    };

    int i, length;
    char theWord[7];
    char input[MAX_LINE];
    sscanf(all_input, "%s",input);

    length = string_length(input);
    if (length != 6)
	explode_bomb();
    
    for (i = 5; i >= 0; i--)
	theWord[i] = array[ (input[5-i] & 0x0f) ];
    theWord[6] = '\0';

    /* devils, flyers, flames, bruins, sabres, oilers */
    if (strings_not_equal(theWord, "SHORT_WORD_SET") != 0)
	explode_bomb();
#elif defined(SOLUTION)
    char *ans = NULL;
    if (!strcmp("SHORT_WORD_GET", "devils"))
	ans="7o4l52";
    else if (!strcmp("SHORT_WORD_GET", "flyers"))
	ans="765no9";
    else if (!strcmp("SHORT_WORD_GET", "flames"))
	ans="7501o9";
    else if (!strcmp("SHORT_WORD_GET", "bruins"))
	ans="78436m";
    else if (!strcmp("SHORT_WORD_GET", "sabres"))
	ans="756m17";
    else if (!strcmp("SHORT_WORD_GET", "oilers"))
	ans="765o4j";

    if(ans != NULL){
      printf("%s %s %s\n", ans, "ignored", SECRET_PHRASE);
    }
    else {
	printf("ERROR: bad short_word in phase 5b\n");
	exit(8);
    }
#else
invalid_phase("5f");
#endif
}

