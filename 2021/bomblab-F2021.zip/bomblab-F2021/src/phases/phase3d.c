/*
 * phase3d.c - A long switch statement that the compiler should implement
 * with a jump table. The user has to enter both an index into the table
 * and a value stored there.
 */
void phase_3(char *input)
{
#if defined(PROBLEM)

int mystery_arraya[20];
for(int i = 0; i < 20; i++){
   if(i < 13){
       mystery_arraya[i] = i * i;
   }
   else if(i < 17){
       mystery_arraya[i] = i * 9;
   }
   else{
       mystery_arraya[i] = i * i;
   }
}

 int index, val = 0;
 int numScanned = 0;

 numScanned = sscanf(input, "%d %d", &index, &val);

 if (numScanned < 2)
explode_bomb();

  if(index < 12 || index > 17)
explode_bomb();


 if (mystery_arraya[index] != val)
explode_bomb();

#elif defined(SOLUTION)
    printf("13 117\n");
#else
    invalid_phase("3a");
#endif
}
