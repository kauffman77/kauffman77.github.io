/*
 * CS:APP Binary Bomb (Autolab version)
 *
 * Copyright (c) 2004, R. Bryant and D. O'Hallaron, All rights reserved.
 * May not be used, modified, or copied without permission.
 */ 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "phases.h"
#include "support.h"

/* Global bomb ID */
int bomb_id = 45;

/* 
 * phase1a.c - The user's input must match the specified string 
 */
void phase_1(char *input)
{
#if defined(PROBLEM)
    if (strings_not_equal(input, "I can see Russia from my house!") != 0)
	explode_bomb();
#elif defined(SOLUTION)
    printf("I can see Russia from my house!\n"); 
#else
    invalid_phase("1a");
#endif    
}

/* 
 * phase2a.c - To defeat this stage the user must enter a sequence of 
 * 6 nonnegative numbers where x[i] = x[i-1] + i
 */
void phase_2(char *input)
{
#if defined(PROBLEM)
    int i;
    int numbers[6];

    read_six_numbers(input, numbers);

    if (numbers[0] < 0)
	explode_bomb();

    for(i = 1; i < 6; i++) {
	if (numbers[i] != numbers[i - 1] + i)
	    explode_bomb();
    }
#elif defined(SOLUTION)
    printf("2 3 5 8 12 17\n");
    // printf("2 3 5 8 12 17 %s\n",SECRET_PHRASE);
#else
    invalid_phase("2a");
#endif
}
/* 
 * phase3a.c - A long switch statement that the compiler should implement
 * with a jump table. The user has to enter both an index into the table 
 * and a value stored there.
 */
void phase_3(char *input)
{
#if defined(PROBLEM)
    int index, val, x = 0;
    int numScanned = 0;

    numScanned = sscanf(input, "%d %d", &index, &val);

    if (numScanned < 2)
	explode_bomb();

    switch(index) {
    case 0:
	x = 636;
	break;
    case 1:
	x = 208;
	break;
    case 2:
	x = 303;
	break;
    case 3:
	x = 377;
	break;
    case 4:
	x = 783;
	break;
    case 5:
	x = 911;
	break;
    case 6:
	x = 809;
	break;
    case 7:
	x = 376;
	break;
    default:
	explode_bomb();
    }

    if (x != val)
	explode_bomb();
#elif defined(SOLUTION)
    printf("4 783\n");
#else
    invalid_phase("3a");
#endif
}
/*
 * A palindrome checker, student must input a number 
 * greater than 1234 and is palindrome. As a method to 
 * brute force proof, we make the student enter a second
 * palindrome number that is different from the first and 
 * greater than 12345
 */

int func4(int a, int *b)
{
  if (a >= 0 && a < 10)
    return (a == (*b % 10));
  if (!func4(a / 10, b))
    return 0;

  *b /= 10;

  return (a % 10 == *b % 10);
}

void phase_4(char *input) {
#if defined(PROBLEM)
    int user_val, user_val2;

    int numScanned = sscanf(input, "%d %d", &user_val, &user_val2);
    if ((numScanned != 2) || user_val < 1234 || user_val2 < 12345 || user_val == user_val2) {
	  explode_bomb();
    }

    int user_val_copy = user_val;
    int user_val_copy2 = user_val2;
    int ret = func4(user_val, &user_val_copy);
    int ret2 = func4(user_val2, &user_val_copy2);

    if (!ret || !ret2) {
	  explode_bomb();
    }
#elif defined(SOLUTION)
    printf("%d %d\n", 1331, 15651);
    // printf("%d %d %s\n", 1331, 15651, SECRET_PHRASE);
#else
    invalid_phase("4d");
#endif
}
/*
 * phase5b.c - This stage requires the user to enter a string of
 * six characters, where each character in the string is used as an offset
 * into the character array.  The six characters indexed by the
 * offsets must spell out a particular word.
 */
void phase_5(char *all_input)
{
#if defined(PROBLEM)
    static char array[] = {
	'm',
	'a',
	'd',
	'u',
	'i',
	'e',
	'r',
	's',
	'n',
	'f',
	'o',
	't',
	'v',
	'b',
	'y',
	'l'
    };

    int i, length;
    char theWord[7];
    char input[MAX_LINE];
    sscanf(all_input, "%s",input);

    length = string_length(input);
    if (length != 6)
	explode_bomb();
    
    for (i = 0; i < 6; i++)
	theWord[i] = array[ (input[i] & 0x0f) ];
    theWord[6] = '\0';

    /* devils, flyers, flames, bruins, sabres, oilers */
    if (strings_not_equal(theWord, "bruins") != 0)
	explode_bomb();
#elif defined(SOLUTION)
    char *ans = NULL;
    if (!strcmp("bruins", "devils"))
	ans = "25l4o7";
    else if (!strcmp("bruins", "flyers"))
	ans = "9on567";
    else if (!strcmp("bruins", "flames"))
	ans = "9o1057";
    else if (!strcmp("bruins", "bruins"))
	ans = "m63487";
    else if (!strcmp("bruins", "sabres"))
	ans = "71m657";
    else if (!strcmp("bruins", "oilers"))
	ans = "j4o567";
    
    if(ans != NULL){
      printf("%s %s %s\n", ans, "ignored", SECRET_PHRASE);
    }
    else {
	printf("ERROR: bad short_word in phase 5b\n");
	exit(8);
    }
#else
invalid_phase("5b");
#endif
}

#define SIZE 5

long hashcode(char* key) {
  union {
    char str[8];
    long num;
  } strnum;
  strnum.num = 0;

  for(int i=0; i<8; i++) {
    if(key[i] == '\0')
      break;
    strnum.str[i] = key[i];
  }

  return strnum.num;
}

void insert(int n, char** keys, char** vals, hashmap_t* hm) {
  for (int i = 0; i < n; i++) {
    long code = hashcode(keys[i]);
    int index = code % hm->table_size;
    int vI = i & 1 ? n - (i + 1) / 2 : i / 2;

    hashnode_t* ptr = hm->table[index];
    if (ptr) {
      hashnode_t* prev;
      while (ptr) {
        if (strcmp(ptr->key, keys[i]) == 0) {
          strcpy(ptr->val, vals[vI]);
          return;
        }
        prev = ptr;
        ptr = ptr->next;
      }

      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);

      node->next = NULL;
      prev->next = node;
      hm->item_count++;
    } else {
      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);
      node->next = NULL;
      hm->table[index] = node;
      hm->item_count++;
    }
  }
}

char* get(char* key, hashmap_t* hm) {
  long code = hashcode(key);
  int index = code % hm->table_size;

  hashnode_t* ptr = hm->table[index];
  while (ptr) {
    if (strcmp(ptr->key, key) == 0)
      return ptr->val;
    ptr = ptr->next;
  }

  return NULL;
}

void prep6(hashmap_t* hm) {
  hm->item_count = 0;
  hm->table_size = SIZE;
  hm->table = malloc(sizeof(hashnode_t*) * SIZE);
  memset(hm->table, 0,  sizeof(hashnode_t*) * SIZE);

  char* keys[] = {"Chrom", "Robin", "Edelgard", "Lucina", "Azura", "Byleth", "Corrin"};
  char* vals[] = {"Luke", "Rey", "Han", "Leia", "Finn", "Kylo", "Vader"};
  insert(7, keys, vals, hm);
}

void phase_6(char* input) {
#if defined(PROBLEM)
  char key0[128];
  char key1[128];
  char key2[128];
  char* keys[] = {key0, key1, key2};

  if (sscanf(input, "%s %s %s", key0, key1, key2) != 3) {
    explode_bomb();
  }
  for (int i=0; i<2; i++) {
    if (strcmp(keys[i],keys[i+1])>=0) {
      explode_bomb();
    }
  }
  hashmap_t hm;
  prep6(&hm);
  char* prev = get(keys[0], &hm);
  for (int i = 1; i < 3; i++) {
    char* curr = get(keys[i], &hm);
    if (!prev || !curr || strcmp(prev, curr) <= 0)
      explode_bomb();
    prev = curr;
  }


#elif defined(SOLUTION)
  printf("Chrom Corrin Lucina\n");
  /*hashmap_t hm;
  char* keys[] = {"Chrom", "robin", "edelgard", "Lucina", "azura", "Byleth", "corrin"};
  char* vals[] = {"Luke", "Rey", "Han", "Leia", "Finn", "Kylo", "Vader"};
  insert(7, keys, vals, hm);
  for (int i=0; i<hm->table_size; i++) {
    if (strcmp(hm->table[i]->val, vals[2])==0){
      printf("%s\n",hm->table[i]->key);
    }
    }*/

#else
  invalid_phase("6d");
#endif
}
/* 
 * phase7.c - The infamous secret stage! 
 * The user has to find leaf value given path in a binary tree.
 */

typedef struct treeNodeStruct
{
    int value;
    struct treeNodeStruct *left, *right;
} treeNode;

/* balanced binary tree containing randomly chosen values */
treeNode n48 = {1001, NULL, NULL};
treeNode n46 = {47, NULL, NULL};
treeNode n43 = {20, NULL, NULL};
treeNode n42 = {7, NULL, NULL};
treeNode n44 = {35, NULL, NULL};
treeNode n47 = {99, NULL, NULL};
treeNode n41 = {1, NULL, NULL};
treeNode n45 = {40, NULL, NULL};
treeNode n34 = {107, &n47, &n48};
treeNode n31 = {6, &n41, &n42};
treeNode n33 = {45, &n45, &n46};
treeNode n32 = {22, &n43, &n44};
treeNode n22 = {50, &n33, &n34};
treeNode n21 = {8, &n31, &n32};
treeNode n1 = {36, &n21, &n22};

/* 
 * Searches for a node in a binary tree and returns path value.
 * 0 bit denotes left branch, 1 bit denotes right branch
 * Example: the path to leaf value "35" is left, then right,
 * then right, and thus the path value is 110(base 2) = 6.
 */

int fun7(treeNode* node, int val)
{
    if (node == NULL) 
	return -1;
  
    if (val < node->value) 
	return fun7(node->left, val) << 1;
    else if (val == node->value) 
	return 0;
    else 
	return (fun7(node->right, val) << 1) + 1;
}
     
void secret_phase()
{

#if defined(PROBLEM)
    char *input = read_line();
    int target = atoi(input);
    int path;

    /* Make sure target is in the right range */
    if ((target < 1) || (target > 1001))
	explode_bomb();

    /* Determine the path to the given target */
    path = fun7(&n1, target);

    /* Compare the retrieved path to a random path */
    if (path != 3)
	explode_bomb();
  
    printf("Wow! You've defused the secret stage!\n");

    phase_defused();
#elif defined(SOLUTION)
    int path = 3;
    treeNode *node = &n1;
    
    node = (path    & 0x1) ? node->right : node->left;
    node = (path>>1 & 0x1) ? node->right : node->left;
    node = (path>>2 & 0x1) ? node->right : node->left;
    printf("%d\n", node->value);
#else
    invalid_phase("7");
#endif
}


