/*
 * CS:APP Binary Bomb (Autolab version)
 *
 * Copyright (c) 2004, R. Bryant and D. O'Hallaron, All rights reserved.
 * May not be used, modified, or copied without permission.
 */ 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "phases.h"
#include "support.h"

/* Global bomb ID */
int bomb_id = 50;

/* 
 * phase1b.c - The user's input must match the specified string 
 */
void phase_1(char *input)
{
#if defined(PROBLEM)
    if (strings_not_equal(input, "Verbosity leads to unclear, inarticulate things.") != 0)
	explode_bomb();
#elif defined(SOLUTION)
    printf("Verbosity leads to unclear, inarticulate things.\n");
#else
    invalid_phase("1b");
#endif
}

/*
 * phase2f.c - To defeat this stage the user must enter a sequence of
 * 6 numbers (possibly negative) where x[i] = x[i-2] - x[i-1]
 */
void phase_2(char *input)
{
  #if defined(PROBLEM)
      int i;
      int numbers[6];

      read_six_numbers(input, numbers);

      if (numbers[0] != 100 || numbers[1] != 75)
  	explode_bomb();
      for (i = 2; i < 6; i++) {
  	if (numbers[i] != numbers[i-2] - numbers[i-1])
  	    explode_bomb();
  }
#elif defined(SOLUTION)
      printf("100 75 25 50 -25 75\n");
      // printf("100 75 25 50 -25 75 %s\n",SECRET_PHRASE);
#else
    invalid_phase("2c");
#endif
}

/* 
 * phase3b.c - A long switch statement that the compiler should
 * implement with a jump table. The user must enter both an index 
 * into the table and the sum accumulated by falling through the rest 
 * of the table 
 */

void phase_3(char *input)
{
#if defined(PROBLEM)
    int index, sum, x = 0;
    int numScanned = 0;

    numScanned = sscanf(input, "%d %d", &index, &sum);

    if (numScanned < 2)
	explode_bomb();

    switch(index) {
    case 0:
	x = x + 737;
    case 1:
	x = x - 720;
    case 2:
	x = x + 963;
    case 3:
	x = x - 592;
    case 4:
	x = x + 592;
    case 5:
	x = x - 592;
    case 6:
	x = x + 592;
    case 7:
	x = x - 592;
	break;
    default:
	explode_bomb();
    }

    if ((index > 5) || (x != sum))
	explode_bomb();
#elif defined(SOLUTION)
    printf("3 -592\n");
#else
    invalid_phase("3b");
#endif
}
/* 
 * phase4a.c - A recursive binary search function to sort out.  The
 * search is over the indexes [0..14] of a binary search tree, where
 * root=7, root->left=3, root->right=11, and so on. The user must
 * predict the sum of the indexes that will be visited during the
 * search for a particular target index, and must input both the sum
 * and the target index.
 */
int func4(int val, int low, int high)
{
    int mid;

    mid = low + (high - low) / 2;

    if (mid > val)
	return func4(val, low, mid-1) + mid;
    else if (mid < val)
	return func4(val, mid+1, high) + mid;
    else
	return mid;
}


void phase_4(char *input) {
#if defined(PROBLEM)
    int user_val, user_sum, result, target_sum, numScanned;

    numScanned = sscanf(input, "%d %d", &user_val, &user_sum);
    if ((numScanned != 2) || user_val < 0 || user_val > 14) {
	explode_bomb();
    }

    target_sum = 10; 
    result = func4(user_val, 0, 14);

    if (result != target_sum || user_sum != target_sum) {
	explode_bomb();
    }
#elif defined(SOLUTION)
    int i;
    int target_sum = 10;
    
    for (i=0; i<15; i++) { 
	if (target_sum == func4(i, 0, 14))
	    break;
    }
    printf("%d %d\n", i, target_sum);
    // printf("%d %d %s\n", i, target_sum, SECRET_PHRASE);
#else
    invalid_phase("4a");
#endif
}

/* 
 * phase5a.c - Just to be hairy, this traverses a loop of pointers and 
 * counts its length.  The input determines where in the loop we begin. 
 * Just to make sure the user isn't guessing, we make them input the sum of
 * the pointers encountered along the path, too.
 */
void phase_5(char *input)
{
#if defined(PROBLEM)
    static int array[] = {
      10,
      2,
      14,
      7,
      8,
      12,
      15,
      11,
      0,
      4,
      1,
      13,
      3,
      9,
      6,
      5
    };

    int count, sum;
    int start;
    int p, result;
    int numScanned;

    numScanned = sscanf(input, "%d %d", &p, &result);
    
    if (numScanned < 2)
      explode_bomb();

    p = p & 0x0f;
    start = p; /* debug */

    count = 0;
    sum = 0;
    while(p != 15) {
	count++;
	p = array[p];
	sum += p;
    }

    if ((count != 15) || (sum != result))
	explode_bomb();
#elif defined(SOLUTION)
    switch (15) {
    case 1: printf("6 15"); break;
    case 2: printf("14 21"); break;
    case 3: printf("2 35"); break;
    case 4: printf("1 37"); break;
    case 5: printf("10 38"); break;
    case 6: printf("0 48"); break;
    case 7: printf("8 48"); break;
    case 8: printf("4 56"); break;
    case 9: printf("9 60"); break;
    case 10: printf("13 69"); break;
    case 11: printf("11 82"); break;
    case 12: printf("7 93"); break;
    case 13: printf("3 100"); break;
    case 14: printf("12 103"); break;
    case 15: printf("5 115"); break;
    default:
	printf("ERROR: bad count value in phase5a\n");
	exit(8);
    }
    printf(" %s\n",SECRET_PHRASE);
#else
    invalid_phase("5a");
#endif
}

#define SIZE 5

long hashcode(char* key) {
  union {
    char str[8];
    long num;
  } strnum;
  strnum.num = 0;

  for(int i=0; i<8; i++) {
    if(key[i] == '\0')
      break;
    strnum.str[i] = key[i];
  }

  return strnum.num;
}

void insert(int n, char** keys, char** vals, hashmap_t* hm) {
  for (int i = 0; i < n; i++) {
    long code = hashcode(keys[i]);
    int index = code % hm->table_size;
    int vI = i & 1 ? n - (i + 1) / 2 : i / 2;

    hashnode_t* ptr = hm->table[index];
    if (ptr) {
      hashnode_t* prev;
      while (ptr) {
        if (strcmp(ptr->key, keys[i]) == 0) {
          strcpy(ptr->val, vals[vI]);
          return;
        }
        prev = ptr;
        ptr = ptr->next;
      }

      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);

      node->next = NULL;
      prev->next = node;
      hm->item_count++;
    } else {
      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);
      node->next = NULL;
      hm->table[index] = node;
      hm->item_count++;
    }
  }
}

char* get(char* key, hashmap_t* hm) {
  long code = hashcode(key);
  int index = code % hm->table_size;

  hashnode_t* ptr = hm->table[index];
  while (ptr) {
    if (strcmp(ptr->key, key) == 0)
      return ptr->val;
    ptr = ptr->next;
  }

  return NULL;
}

void prep6(hashmap_t* hm) {
  hm->item_count = 0;
  hm->table_size = SIZE;
  hm->table = malloc(sizeof(hashnode_t*) * SIZE);
  memset(hm->table, 0,  sizeof(hashnode_t*) * SIZE);

  char* keys[] = {"Chrom", "Robin", "Edelgard", "Lucina", "Rey", "Kylo", "Vader"};
  char* vals[] = {"Luke", "Finn", "Han", "Leia", "Azura", "Byleth", "Corrin"};
  insert(7, keys, vals, hm);
}

void phase_6(char* input) {
#if defined(PROBLEM)
  char key0[128];
  char key1[128];
  char key2[128];
  char* keys[] = {key0, key1, key2};

  if (sscanf(input, "%s %s %s", key0, key1, key2) != 3) {
    explode_bomb();
  }
  for (int i=0; i<2; i++) {
    if (strcmp(keys[i],keys[i+1])>=0) {
      explode_bomb();
    }
  }
  hashmap_t hm;
  prep6(&hm);
  char* prev = get(keys[0], &hm);
  for (int i = 1; i < 3; i++) {
    char* curr = get(keys[i], &hm);
    if (!prev || !curr || strcmp(prev, curr) <= 0)
      explode_bomb();
    prev = curr;
  }


#elif defined(SOLUTION)
  printf("Chrom Edelgard Kylo\n");
  /*hashmap_t hm;
  char* keys[] = {"Chrom", "robin", "edelgard", "Lucina", "azura", "Byleth", "corrin"};
  char* vals[] = {"Luke", "Rey", "Han", "Leia", "Finn", "Kylo", "Vader"};
  insert(7, keys, vals, hm);
  for (int i=0; i<hm->table_size; i++) {
    if (strcmp(hm->table[i]->val, vals[2])==0){
      printf("%s\n",hm->table[i]->key);
    }
    }*/

#else
  invalid_phase("6d");
#endif
}
/* 
 * phase7.c - The infamous secret stage! 
 * The user has to find leaf value given path in a binary tree.
 */

typedef struct treeNodeStruct
{
    int value;
    struct treeNodeStruct *left, *right;
} treeNode;

/* balanced binary tree containing randomly chosen values */
treeNode n48 = {1001, NULL, NULL};
treeNode n46 = {47, NULL, NULL};
treeNode n43 = {20, NULL, NULL};
treeNode n42 = {7, NULL, NULL};
treeNode n44 = {35, NULL, NULL};
treeNode n47 = {99, NULL, NULL};
treeNode n41 = {1, NULL, NULL};
treeNode n45 = {40, NULL, NULL};
treeNode n34 = {107, &n47, &n48};
treeNode n31 = {6, &n41, &n42};
treeNode n33 = {45, &n45, &n46};
treeNode n32 = {22, &n43, &n44};
treeNode n22 = {50, &n33, &n34};
treeNode n21 = {8, &n31, &n32};
treeNode n1 = {36, &n21, &n22};

/* 
 * Searches for a node in a binary tree and returns path value.
 * 0 bit denotes left branch, 1 bit denotes right branch
 * Example: the path to leaf value "35" is left, then right,
 * then right, and thus the path value is 110(base 2) = 6.
 */

int fun7(treeNode* node, int val)
{
    if (node == NULL) 
	return -1;
  
    if (val < node->value) 
	return fun7(node->left, val) << 1;
    else if (val == node->value) 
	return 0;
    else 
	return (fun7(node->right, val) << 1) + 1;
}
     
void secret_phase()
{

#if defined(PROBLEM)
    char *input = read_line();
    int target = atoi(input);
    int path;

    /* Make sure target is in the right range */
    if ((target < 1) || (target > 1001))
	explode_bomb();

    /* Determine the path to the given target */
    path = fun7(&n1, target);

    /* Compare the retrieved path to a random path */
    if (path != 6)
	explode_bomb();
  
    printf("Wow! You've defused the secret stage!\n");

    phase_defused();
#elif defined(SOLUTION)
    int path = 6;
    treeNode *node = &n1;
    
    node = (path    & 0x1) ? node->right : node->left;
    node = (path>>1 & 0x1) ? node->right : node->left;
    node = (path>>2 & 0x1) ? node->right : node->left;
    printf("%d\n", node->value);
#else
    invalid_phase("7");
#endif
}


