/*
 * CS:APP Binary Bomb (Autolab version)
 *
 * Copyright (c) 2004, R. Bryant and D. O'Hallaron, All rights reserved.
 * May not be used, modified, or copied without permission.
 */ 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "phases.h"
#include "support.h"

/* Global bomb ID */
int bomb_id = 57;

/* 
 * phase1a.c - The user's input must match the specified string 
 */
void phase_1(char *input)
{
#if defined(PROBLEM)
    if (strings_not_equal(input, "He is evil and fits easily into most overhead storage bins.") != 0)
	explode_bomb();
#elif defined(SOLUTION)
    printf("He is evil and fits easily into most overhead storage bins.\n"); 
#else
    invalid_phase("1a");
#endif    
}

/*
 * phase2f.c - To defeat this stage the user must enter a sequence of
 * 6 numbers (possibly negative) where x[i] = x[i-2] - x[i-1]
 */
void phase_2(char *input)
{
  #if defined(PROBLEM)
      int i;
      int numbers[6];

      read_six_numbers(input, numbers);

      if (numbers[0] != 100 || numbers[1] != 75)
  	explode_bomb();
      for (i = 2; i < 6; i++) {
  	if (numbers[i] != numbers[i-2] - numbers[i-1])
  	    explode_bomb();
  }
#elif defined(SOLUTION)
      printf("100 75 25 50 -25 75\n");
      // printf("100 75 25 50 -25 75 %s\n",SECRET_PHRASE);
#else
    invalid_phase("2c");
#endif
}

/* 
 * phase3b.c - A long switch statement that the compiler should
 * implement with a jump table. The user must enter both an index 
 * into the table and the sum accumulated by falling through the rest 
 * of the table 
 */

void phase_3(char *input)
{
#if defined(PROBLEM)
    int index, sum, x = 0;
    int numScanned = 0;

    numScanned = sscanf(input, "%d %d", &index, &sum);

    if (numScanned < 2)
	explode_bomb();

    switch(index) {
    case 0:
	x = x + 675;
    case 1:
	x = x - 432;
    case 2:
	x = x + 257;
    case 3:
	x = x - 248;
    case 4:
	x = x + 248;
    case 5:
	x = x - 248;
    case 6:
	x = x + 248;
    case 7:
	x = x - 248;
	break;
    default:
	explode_bomb();
    }

    if ((index > 5) || (x != sum))
	explode_bomb();
#elif defined(SOLUTION)
    printf("3 -248\n");
#else
    invalid_phase("3b");
#endif
}
/* 
 * phase4c.c - A recursive function to sort out.  
 *
 *          0, if n=0
 * F(n,b) = b, if n=1, 
 *          b + F(n-1, b) + F(n-2, b), if n>1
 * 
 * For a randomly chosen n, student must enter matching F(n, b) and b.
 */

int func4(int n, int base) {
    if (n <= 0) {
	return 0;
    }
    if (n == 1) {
	return base;
    }
    return base + func4(n-1, base) + func4(n-2, base);
}

void phase_4(char *input) {
#if defined(PROBLEM)
    int n, base, val, result, numScanned;

    numScanned = sscanf(input, "%d %d", &val, &base);
    if ((numScanned != 2) || (base < 2) || (base > 4)) {
	explode_bomb();
    }

    n = 6;
    result = func4(n, base);

    if (result != val) {
	explode_bomb();
    }
#elif defined(SOLUTION)
    printf("%d %d\n", func4(6, 2), 2);
    // printf("%d %d %s\n", func4(6, 2), 2, SECRET_PHRASE);
#else
    invalid_phase("4c");
#endif
}

/*
 * phase5d, must input an index of a loop of pointers. 
 * Each element of the array represents the offset
 * for the next element in the loop--ending at 15.
 * Users must input the starting index so that it iterates
 * the right amount of times, and must also enter in 
 * the sum of the array indexes to know they are not cheating.  
 */
void phase_5(char *input)
{
#if defined(PROBLEM)
    static int array[] = {
      5,  //0
      5,  //1
      10, //2
      6,  //3
      -1, //4
      -3, //5
      2,  //6
      4,  //7
      7,  //8
      5,  //9
      -2, //10
      2,  //11
      -5, //12
      -9, //13
      -13,//14 
      0   //15
    };
    //0, 5, 2, 12, 7, 11, 13, 4, 3, 9, 14, 1, 6, 8, 15
    int count, sum;
    int start;
    int p, result;
    int numScanned;

    numScanned = sscanf(input, "%d %d", &p, &result);
    
    if (numScanned < 2)
      explode_bomb();

    p = p & 0x0f;

    count = 0;
    sum = 0;
    while(p != 15) {
	count++;
    sum += p;
	p = array[p]+p;
    }
    count++;

    if(count != 15 || sum != result) {
        explode_bomb();
    }

#elif defined(SOLUTION)
    char *ans = NULL;
    switch (15) {
    case 1: ans="15 0"; break;
    case 2: ans="8 8"; break;
    case 3: ans="6 14"; break;
    case 4: ans="1 15"; break;
    case 5: ans="14 29"; break;
    case 6: ans="9 38"; break;
    case 7: ans="3 41"; break;
    case 8: ans="4 45"; break;
    case 9: ans="13 58"; break;
    case 10: ans="11 69"; break;
    case 11: ans="7 76"; break;
    case 12: ans="12 88"; break;
    case 13: ans="2 90"; break;
    case 14: ans="5 95"; break;
    case 15: ans="0 95"; break;
    default:
	printf("ERROR: bad count value in phase5a\n");
	exit(8);
    }
    printf("%s %s\n",ans,SECRET_PHRASE);
#else
    invalid_phase("5d");
#endif
}


#define SIZE 5

long hashcode(char* key) {
  union {
    char str[8];
    long num;
  } strnum;
  strnum.num = 0;

  for(int i=0; i<8; i++) {
    if(key[i] == '\0')
      break;
    strnum.str[i] = key[i];
  }

  return strnum.num;
}

void insert(int n, char** keys, char** vals, hashmap_t* hm) {
  for (int i = 0; i < n; i++) {
    long code = hashcode(keys[i]);
    int index = code % hm->table_size;
    int vI = i & 1 ? n - (i + 1) / 2 : i / 2;

    hashnode_t* ptr = hm->table[index];
    if (ptr) {
      hashnode_t* prev;
      while (ptr) {
        if (strcmp(ptr->key, keys[i]) == 0) {
          strcpy(ptr->val, vals[vI]);
          return;
        }
        prev = ptr;
        ptr = ptr->next;
      }

      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);

      node->next = NULL;
      prev->next = node;
      hm->item_count++;
    } else {
      hashnode_t* node = malloc(sizeof(hashnode_t));
      strcpy(node->key, keys[i]);
      strcpy(node->val, vals[vI]);
      node->next = NULL;
      hm->table[index] = node;
      hm->item_count++;
    }
  }
}

char* get(char* key, hashmap_t* hm) {
  long code = hashcode(key);
  int index = code % hm->table_size;

  hashnode_t* ptr = hm->table[index];
  while (ptr) {
    if (strcmp(ptr->key, key) == 0)
      return ptr->val;
    ptr = ptr->next;
  }

  return NULL;
}

void prep6(hashmap_t* hm) {
  hm->item_count = 0;
  hm->table_size = SIZE;
  hm->table = malloc(sizeof(hashnode_t*) * SIZE);
  memset(hm->table, 0,  sizeof(hashnode_t*) * SIZE);

  char* keys[] = {"Chrom", "Robin", "Edelgard", "Lucina", "Rey", "Kylo", "Vader"};
  char* vals[] = {"Luke", "Finn", "Han", "Leia", "Azura", "Byleth", "Corrin"};
  insert(7, keys, vals, hm);
}

void phase_6(char* input) {
#if defined(PROBLEM)
  char key0[128];
  char key1[128];
  char key2[128];
  char* keys[] = {key0, key1, key2};

  if (sscanf(input, "%s %s %s", key0, key1, key2) != 3) {
    explode_bomb();
  }
  for (int i=0; i<2; i++) {
    if (strcmp(keys[i],keys[i+1])>=0) {
      explode_bomb();
    }
  }
  hashmap_t hm;
  prep6(&hm);
  char* prev = get(keys[0], &hm);
  for (int i = 1; i < 3; i++) {
    char* curr = get(keys[i], &hm);
    if (!prev || !curr || strcmp(prev, curr) <= 0)
      explode_bomb();
    prev = curr;
  }


#elif defined(SOLUTION)
  printf("Chrom Edelgard Kylo\n");
  /*hashmap_t hm;
  char* keys[] = {"Chrom", "robin", "edelgard", "Lucina", "azura", "Byleth", "corrin"};
  char* vals[] = {"Luke", "Rey", "Han", "Leia", "Finn", "Kylo", "Vader"};
  insert(7, keys, vals, hm);
  for (int i=0; i<hm->table_size; i++) {
    if (strcmp(hm->table[i]->val, vals[2])==0){
      printf("%s\n",hm->table[i]->key);
    }
    }*/

#else
  invalid_phase("6d");
#endif
}
/* 
 * phase7.c - The infamous secret stage! 
 * The user has to find leaf value given path in a binary tree.
 */

typedef struct treeNodeStruct
{
    int value;
    struct treeNodeStruct *left, *right;
} treeNode;

/* balanced binary tree containing randomly chosen values */
treeNode n48 = {1001, NULL, NULL};
treeNode n46 = {47, NULL, NULL};
treeNode n43 = {20, NULL, NULL};
treeNode n42 = {7, NULL, NULL};
treeNode n44 = {35, NULL, NULL};
treeNode n47 = {99, NULL, NULL};
treeNode n41 = {1, NULL, NULL};
treeNode n45 = {40, NULL, NULL};
treeNode n34 = {107, &n47, &n48};
treeNode n31 = {6, &n41, &n42};
treeNode n33 = {45, &n45, &n46};
treeNode n32 = {22, &n43, &n44};
treeNode n22 = {50, &n33, &n34};
treeNode n21 = {8, &n31, &n32};
treeNode n1 = {36, &n21, &n22};

/* 
 * Searches for a node in a binary tree and returns path value.
 * 0 bit denotes left branch, 1 bit denotes right branch
 * Example: the path to leaf value "35" is left, then right,
 * then right, and thus the path value is 110(base 2) = 6.
 */

int fun7(treeNode* node, int val)
{
    if (node == NULL) 
	return -1;
  
    if (val < node->value) 
	return fun7(node->left, val) << 1;
    else if (val == node->value) 
	return 0;
    else 
	return (fun7(node->right, val) << 1) + 1;
}
     
void secret_phase()
{

#if defined(PROBLEM)
    char *input = read_line();
    int target = atoi(input);
    int path;

    /* Make sure target is in the right range */
    if ((target < 1) || (target > 1001))
	explode_bomb();

    /* Determine the path to the given target */
    path = fun7(&n1, target);

    /* Compare the retrieved path to a random path */
    if (path != 7)
	explode_bomb();
  
    printf("Wow! You've defused the secret stage!\n");

    phase_defused();
#elif defined(SOLUTION)
    int path = 7;
    treeNode *node = &n1;
    
    node = (path    & 0x1) ? node->right : node->left;
    node = (path>>1 & 0x1) ? node->right : node->left;
    node = (path>>2 & 0x1) ? node->right : node->left;
    printf("%d\n", node->value);
#else
    invalid_phase("7");
#endif
}


