/*
 * CS:APP Binary Bomb (Autolab version)
 *
 * Copyright (c) 2004, R. Bryant and D. O'Hallaron, All rights reserved.
 * May not be used, modified, or copied without permission.
 */ 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "phases.h"
#include "support.h"

/* Global bomb ID */
int bomb_id = 8;

/* 
 * phase1c.c - The user's input must match the specified string 
 */
void phase_1(char *input)
{
#if defined(PROBLEM)
    if (strings_not_equal(input, "The future will be better tomorrow.") != 0)
	explode_bomb();
#elif defined(SOLUTION)
    printf("The future will be better tomorrow.\n");
#else
    invalid_phase("1c");
#endif
}
/*
 * phase2d.c - To defeat this stage the user must enter a sequence of
 * 6 nonnegative numbers where x[i] = x[i-1]*3 + i*10
 */
void phase_2(char *input)
{
#if defined(PROBLEM)
    int i;
    int numbers[6];

    read_six_numbers(input, numbers);

    if (numbers[0] < 0)
	explode_bomb();

    for(i = 1; i < 6; i++) {
	if (numbers[i] != (numbers[i - 1])*3 + (i*10))
	    explode_bomb();
    }
#elif defined(SOLUTION)
    printf("0 10 50 180 580 1790\n");
    // printf("0 10 50 180 580 1790 %s\n",SECRET_PHRASE);
#else
    invalid_phase("2a");
#endif
}
/*
 * phase3d.c - A long switch statement that the compiler should implement
 * with a jump table. The user has to enter both an index into the table
 * and a value stored there.
 */
void phase_3(char *input)
{
#if defined(PROBLEM)

int mystery_arraya[20];
for(int i = 0; i < 20; i++){
   if(i < 13){
       mystery_arraya[i] = i * i;
   }
   else if(i < 17){
       mystery_arraya[i] = i * 9;
   }
   else{
       mystery_arraya[i] = i * i;
   }
}

 int index, val = 0;
 int numScanned = 0;

 numScanned = sscanf(input, "%d %d", &index, &val);

 if (numScanned < 2)
explode_bomb();

  if(index < 12 || index > 17)
explode_bomb();


 if (mystery_arraya[index] != val)
explode_bomb();

#elif defined(SOLUTION)
    printf("13 117\n");
#else
    invalid_phase("3a");
#endif
}
/*
 * A palindrome checker, student must input a number 
 * greater than 1234 and is palindrome. As a method to 
 * brute force proof, we make the student enter a second
 * palindrome number that is different from the first and 
 * greater than 12345
 */

int func4(int a, int *b)
{
  if (a >= 0 && a < 10)
    return (a == (*b % 10));
  if (!func4(a / 10, b))
    return 0;

  *b /= 10;

  return (a % 10 == *b % 10);
}

void phase_4(char *input) {
#if defined(PROBLEM)
    int user_val, user_val2;

    int numScanned = sscanf(input, "%d %d", &user_val, &user_val2);
    if ((numScanned != 2) || user_val < 1234 || user_val2 < 12345 || user_val == user_val2) {
	  explode_bomb();
    }

    int user_val_copy = user_val;
    int user_val_copy2 = user_val2;
    int ret = func4(user_val, &user_val_copy);
    int ret2 = func4(user_val2, &user_val_copy2);

    if (!ret || !ret2) {
	  explode_bomb();
    }
#elif defined(SOLUTION)
    printf("%d %d\n", 1331, 15651);
    // printf("%d %d %s\n", 1331, 15651, SECRET_PHRASE);
#else
    invalid_phase("4d");
#endif
}
 /* 
 * phase5e.c - Similar to phase5a, this phase takes an input from the user
 * which is used to traverse a loop of pointers. To make sure they are not guessing,
 * the user must also input the difference of all the numbers (starting from 150).
 */
void phase_5(char *input)
{
#if defined(PROBLEM)
    static int array[] = {
      10,
      2,
      14,
      7,
      8,
      12,
      15,
      11,
      0,
      4,
      1,
      13,
      3,
      9,
      6,
      5
    };

    int count, sum;
    int start;
    int p, result;
    int numScanned;

    numScanned = sscanf(input, "%d %d", &p, &result);
    
    if (numScanned < 2)
      explode_bomb();

    p = p & 0x0f;
    start = p; /* debug */

    count = 0;
    sum = 150;
    while(p != 15) {
	count++;
	p = array[p];
	sum -= p;
    }

    if ((count != 15) || (sum != result))
	explode_bomb();
#elif defined(SOLUTION)
    char *ans = NULL;
    switch (15) {
    case 1: ans="6 135"; break;
    case 2: ans="14 129"; break;
    case 3: ans="2 115"; break;
    case 4: ans="1 113"; break;
    case 5: ans="10 112"; break;
    case 6: ans="0 102"; break;
    case 7: ans="8 102"; break;
    case 8: ans="4 94"; break;
    case 9: ans="9 90"; break;
    case 10: ans="13 81"; break;
    case 11: ans="11 68"; break;
    case 12: ans="7 57"; break;
    case 13: ans="3 50"; break;
    case 14: ans="12 47"; break;
    case 15: ans="5 35"; break;
    default:
	printf("ERROR: bad count value in phase5a\n");
	exit(8);
    }
    printf("%s %s %s\n",ans,"ignored",SECRET_PHRASE);
#else
    invalid_phase("5e");
#endif
}


/* 
 * phase6b.c - The user has to enter the permutation vector that
 * sorts a list in ascending order. The catch here is that the 
 * code inverts the permutation and checks for descending order.
 */
listNode node6 = {920, 6, NULL};
listNode node5 = {692, 5, &node6};
listNode node4 = {537, 4, &node5};
listNode node3 = {492, 3, &node4};
listNode node2 = {462, 2, &node3};
listNode node1 = {506, 1, &node2};

#if defined(SOLUTION)
/* Sort list in ascending order */
listNode *fun6(listNode *start)
{
    listNode *head = start;
    listNode *p, *q, *r;

    head = start;
    p = start->next;
    head->next = NULL;

    while (p != NULL) {
	r = head;
	q = head;

	while ((r != NULL) && (r->value > p->value)) {
	    q = r;
	    r = r->next;
	}

	if (q != r)
	    q->next = p;
	else
	    head = p;

	q = p->next;
	p->next = r;

	p = q;
    }

    return head;
}
#endif

void phase_6(char *input)
{
#if defined(PROBLEM)
    listNode *start = &node1;
    listNode *p;
    int indices[6];
    listNode *pointers[6];
    int i, j;

    read_six_numbers(input, indices);

    /* Check the range of the indices and whether or not any repeat */
    for (i = 0; i < 6; i++) {
	if ((indices[i] < 1) || (indices[i] > 6))
	    explode_bomb();
	
	for (j = i + 1; j < 6; j++) {
	    if (indices[i] == indices[j])
		explode_bomb();
	}
    }

    /* Reverse the permutation */
    for (i = 0; i < 6; i++) {
	indices[i] = 7 - indices[i];
    }

    /* Rearrange the list according to the user input */
    for (i = 0; i < 6; i++) {
	p = start;
	for (j = 1; j < indices[i]; j++)
	    p = p -> next;
	pointers[i] = p;
    }

    start = pointers[0];
    p = start;

    for (i = 1; i < 6; i++) {
	p->next = pointers[i];
	p = p->next;
    }
    p->next = NULL;

    /* Now see if the list is sorted in descending order*/
    p = start;
    for (i = 0; i < 5; i++) {
	if (p->value < p->next->value)
	    explode_bomb();
	
	p = p->next;
    }
#elif defined(SOLUTION)
    listNode *start = &node1;
    listNode *p;

    /* sort */
    start = fun6(start);

    /* emit the (inverted) node indices of the sorted list */
    p = start;
    while (p) {
	printf("%d ", 7 - p->index);
	p = p->next;
    }
    printf("\n");
#else
    invalid_phase("6b");
#endif
}



/* 
 * phase7.c - The infamous secret stage! 
 * The user has to find leaf value given path in a binary tree.
 */

typedef struct treeNodeStruct
{
    int value;
    struct treeNodeStruct *left, *right;
} treeNode;

/* balanced binary tree containing randomly chosen values */
treeNode n48 = {1001, NULL, NULL};
treeNode n46 = {47, NULL, NULL};
treeNode n43 = {20, NULL, NULL};
treeNode n42 = {7, NULL, NULL};
treeNode n44 = {35, NULL, NULL};
treeNode n47 = {99, NULL, NULL};
treeNode n41 = {1, NULL, NULL};
treeNode n45 = {40, NULL, NULL};
treeNode n34 = {107, &n47, &n48};
treeNode n31 = {6, &n41, &n42};
treeNode n33 = {45, &n45, &n46};
treeNode n32 = {22, &n43, &n44};
treeNode n22 = {50, &n33, &n34};
treeNode n21 = {8, &n31, &n32};
treeNode n1 = {36, &n21, &n22};

/* 
 * Searches for a node in a binary tree and returns path value.
 * 0 bit denotes left branch, 1 bit denotes right branch
 * Example: the path to leaf value "35" is left, then right,
 * then right, and thus the path value is 110(base 2) = 6.
 */

int fun7(treeNode* node, int val)
{
    if (node == NULL) 
	return -1;
  
    if (val < node->value) 
	return fun7(node->left, val) << 1;
    else if (val == node->value) 
	return 0;
    else 
	return (fun7(node->right, val) << 1) + 1;
}
     
void secret_phase()
{

#if defined(PROBLEM)
    char *input = read_line();
    int target = atoi(input);
    int path;

    /* Make sure target is in the right range */
    if ((target < 1) || (target > 1001))
	explode_bomb();

    /* Determine the path to the given target */
    path = fun7(&n1, target);

    /* Compare the retrieved path to a random path */
    if (path != 2)
	explode_bomb();
  
    printf("Wow! You've defused the secret stage!\n");

    phase_defused();
#elif defined(SOLUTION)
    int path = 2;
    treeNode *node = &n1;
    
    node = (path    & 0x1) ? node->right : node->left;
    node = (path>>1 & 0x1) ? node->right : node->left;
    node = (path>>2 & 0x1) ? node->right : node->left;
    printf("%d\n", node->value);
#else
    invalid_phase("7");
#endif
}


