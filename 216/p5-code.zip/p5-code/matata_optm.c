// optimized version of MATATA operation
#include "matata.h"

////////////////////////////////////////////////////////////////////////////////
// REQUIRED: Paste a copy of your sumdiag_benchmark from an ODD grace
// node below.
//
// -------REPLACE WITH YOUR RUN + TABLE --------
// 
// grace3>> ./mata_benchmark 
// ==== Matrix A^T*A Benchmark Version 2.0 ====
// Performing 12 runs with 2 thread_counts (max 2)
//   ROWS   COLS   BASE  T   OPTM SPDUP POINT TOTAL 
//    128    128  0.007  1  0.007  0.99  0.00  0.00 
//                       2  0.004  1.79  1.68  1.68 
//    171    151  0.012  1  0.011  1.07  0.19  1.88 
//                       2  0.006  1.99  1.99  3.87 
//    196    180  0.020  1  0.018  1.09  0.24  4.10 
// ...
// ...
// ...
// RAW POINTS: 0.00
// TOTAL POINTS: 0 / 35
// 
// -------REPLACE WITH YOUR RUN + TABLE --------
// 
// NOTE: During grading, staff will independently evaluate your code
// performance on a grace node and take the best score from 3 runs of
// the benchmark.
////////////////////////////////////////////////////////////////////////////////


// You may add helper functions, struct definitions, thread entry
// points, and other items here. Likely you'll do all of that.

// Required function for MATATA operation
int matata_OPTM(matrix_t mat, matrix_t ans, int tc) {
  // YOUR CODE HERE
  return 0;
}

////////////////////////////////////////////////////////////////////////////////
// REQUIRED: DON'T FORGET TO PASTE YOUR TIMING RESULTS FOR
// sumdiag_benchmark FROM A GRACE NODE AT THE TOP OF THIS FILE
////////////////////////////////////////////////////////////////////////////////
