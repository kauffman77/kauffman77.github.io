// optimized versions of matrix diagonal summing
#include "sumdiag.h"

////////////////////////////////////////////////////////////////////////////////
// REQUIRED: Paste a copy of your sumdiag_benchmark from Zaratan
// below.
//
// -------REPLACE WITH YOUR RUN + TABLE --------
//
// user@login-1 [p5-code]% make benchmark
// timeout --foreground 60s ./sumdiag_benchmark
// ==== Matrix Diagonal Sum Benchmark Version 6 ====
// ------ Tuned for zaratan.umd.edu machines -------
// Running with 3 sizes and 4 thread_counts (max 8)
//   SIZE   BASE #T   OPTM  SPDUP POINTS  TOTAL
//   4096  1.739  1  0.000   0.00   0.00   0.00
//                2  0.000   0.00   0.00   0.00
//                5  0.000   0.00   0.00   0.00
//                8  0.000   0.00   0.00   0.00
//   8193  2.015  1  0.000   0.00   0.00   0.00
//                2  0.000   0.00   0.00   0.00
//                5  0.000   0.00   0.00   0.00
//                8  0.000   0.00   0.00   0.00
//  12705  2.180  1  0.000   0.00   0.00   0.00
//                2  0.000   0.00   0.00   0.00
//                5  0.000   0.00   0.00   0.00
//                8  0.000   0.00   0.00   0.00
// RAW POINTS: 0.00
// TOTAL POINTS: 0 / 35


// You can write several different versions of your optimized function
// in this file and call one of them in the last function.

int sumdiag_VER1(matrix_t mat, vector_t vec, int thread_count) {
  // OPTIMIZED CODE HERE
  return 0;
}

int sumdiag_VER2(matrix_t mat, vector_t vec, int thread_count) {
  // OPTIMIZED CODE HERE
  return 0;
}

int sumdiag_OPTM(matrix_t mat, vector_t vec, int thread_count) {
  // call your preferred version of the function
  return sumdiag_VER1(mat, vec, thread_count);
}

////////////////////////////////////////////////////////////////////////////////
// REQUIRED: DON'T FORGET TO PASTE YOUR TIMING RESULTS FOR
// sumdiag_benchmark FROM ZARATAN AT THE TOP OF THIS FILE
////////////////////////////////////////////////////////////////////////////////
