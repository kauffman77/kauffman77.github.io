// optimized versions of matrix diagonal summing
#include "sumdiag.h"

// You can write several different versions of your optimized function
// in this file and call one of them in the last function.

int sumdiag_VER1(matrix_t mat, vector_t vec, int thread_count) {
  // OPTIMIZED CODE HERE
  return 0;
}

int sumdiag_VER2(matrix_t mat, vector_t vec, int thread_count) {
  // OPTIMIZED CODE HERE
  return 0;
}

int sumdiag_OPTM(matrix_t mat, vector_t vec, int thread_count) {
  // call your preferred version of the function
  return sumdiag_VER1(mat, vec, thread_count);
}
