#include <stdio.h>

int convert(char *str);
// written in C, called from assembly

int add2strs(char *astr, char *bstr);
// written in assembly, called from C, calls a C function

//   C: main() calls...
// ASM: add2strs() calls...
//   C: convert()


// demonstrate and test the behavior of the add2strs() function
// written in either C or assembly. The provided assembly version is
// broken and must be repaired.
int main(int argc, char *argv[]){
  char *astr, *bstr;

  astr = "123";
  bstr = "-456";
  int sum1 = add2strs(astr,bstr);
  printf("%-6s + %-6s = %6d\n",astr,bstr,sum1);

  astr = "781923";
  bstr = "-234";
  int sum2 = add2strs(astr,bstr);
  printf("%-6s + %-6s = %6d\n",astr,bstr,sum2);

  int sum3 = sum1 + sum2;
  printf("%6d + %6d = %6d\n",sum1,sum2,sum3);

  return 0;
}

void clobber_regs();
// written in assembly; used to make legal changes to caller save
// registers to check that functions adhere to caller/callee save
// conventions

#define ERROR -1

int convert(char *str){
// Converts a string to an integer; note that this function fails
// silently with incorrect / unpredictable results returned if
// anything goes wrong in the conversion. That makes it a simple but
// risky function to use but is representative of other similar
// functions like atoi() and strtol().
  clobber_regs();
  if(str[0] == '\0'){           // check for a null
    return ERROR;
  }
  int negate = 0;
  int i = 0;
  if(str[0] == '-'){            // check for leading negation
    negate = 1;
    i++;
  }
  int num = 0;
  for(; str[i]!='\0'; i++){    // loop over characters in string
    char digit = str[i];
    if(digit < '0' || digit > '9'){
      break;                    // non-digits terminate the conversion
    }
    digit = digit - '0';
    num = num*10 + digit;       // "shift" the digits over and add the new one
  }
  if(negate){                   // negate if needed from earlier
    num = -num;
  }
  return num;
}

