// FILE: func_long.c
void negate(long *a){
  long b = *a;
  *a = (-b);
}
