#include <stdio.h>

int func(int x);                // weak def

int main(){
  printf("calling func\n");
  int ret = func(7);
  printf("returned %d\n", ret);
  return 0;
}
