#include <stdio.h>
#include "funcs.h"
int main(int argc, char *argv[]){
  // call various library functions
  func_0X();
  return 0;
}
