// FILE vf_strong_func.c
int foo(int x){
  return 2*x;
}
