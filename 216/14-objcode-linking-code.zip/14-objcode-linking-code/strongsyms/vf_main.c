// FILE: vf_main.c
#include <stdio.h>
int foo(int x);
int main(){
  printf("%d\n",foo);
  printf("%d\n",foo(2));
  return 0;
}
