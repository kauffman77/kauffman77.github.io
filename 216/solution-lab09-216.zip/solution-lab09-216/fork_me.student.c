// TEMPLATE
// fork_me.c: a deceptive pattern of forking

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>  // uncomment if using wait() / waitpid() system call

int global_total = 0;

int main(void) {
  printf("START| pid: %d parent_pid: %d \n",
         getpid(),getppid());
  fflush(stdout);               // flush stdout to prevent I/O duplication
  int depth = 0;
  for(int i=0; i<4; i++){
    global_total++;
    pid_t child = fork();
    if(child == 0){
      depth++;
    }
    // TODO: insert code that makes parent pause until child is
    // finished, extracts its exit code, and adds that exit code onto
    // the global_total in this parent
  }
  for(int i=0; i<depth; i++){
    printf("--");
  }
  printf("FINISH| pid: %d parent_pid: %d global_total: %d\n",
         getpid(), getppid(),global_total);
  return global_total;
}
