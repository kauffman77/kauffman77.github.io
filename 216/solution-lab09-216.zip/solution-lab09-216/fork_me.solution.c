// SOLUTION:
// fork_me.c: a deceptive pattern of forking

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>  // uncomment if using wait() / waitpid() system call

int main(void) {
  printf("|START| pid: %d parent_pid: %d\n",
         getpid(), getppid());
  fflush(stdout);               // flush stdout to preven I/O duplication
  for(int i=0; i<4; i++){
    pid_t child = fork();
    if(child != 0){
      wait(NULL);
    }
  }
  printf("FINISH| pid: %d parent_pid: %d\n",
         getpid(), getppid());
  return 0;
}
