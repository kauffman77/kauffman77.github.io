// SOLUTION:
// fork_me.c: a deceptive pattern of forking

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>  // uncomment if using wait() / waitpid() system call

int global_total = 0;

int main(void) {
  printf("START| pid: %d parent_pid: %d \n",
         getpid(),getppid());
  fflush(stdout);               // flush stdout to preven I/O duplication
  int depth = 0;
  for(int i=0; i<4; i++){
    global_total++;
    pid_t child = fork();
    if(child == 0){
      depth++;
    }
    // TODO: insert code that makes parent pause until child is
    // finished, extracts its exit code, and adds that exit code onto
    // the global_total in this parent
    else{
      int status;
      int ret = wait(&status);
      // waitpid(child,&status); // alternative
      if(ret == -1){            // optional error checking of the system call
        perror("wait() failed");
      }
      if(WIFEXITED(status)){
        int exit_code = WEXITSTATUS(status);
        global_total += exit_code;
        // printf("WAIT| child pid %d exit code %d\n",
        //        child,exit_code);
      }
    }
  }
  for(int i=0; i<depth; i++){
    printf("--");
  }
  printf("FINISH| pid: %d parent_pid: %d global_total: %d\n",
         getpid(), getppid(),global_total);
  return global_total;
}
