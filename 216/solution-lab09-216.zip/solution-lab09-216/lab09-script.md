# Monday 1: fork() + wait()
REMIND students to complete the Assembly Reflection for 1 EP
- Open up fork_me.c program to analyze it
- Note the primary feature: a loop with a fork() call in it
- Mention as well that the fflush(stdout) call guarantees that output
  in the original process (parent) will go to the screen before
  forking and won't be duplicated by child processes. Flushing output
  like this is needed sometimes when fork() gets involved
- Ask students for a prediction of how many "FINISH" messages will be
  printed. Give them 1-2mins to discuss among themselves; most of them
  should sense a trick of some kind but some will answer 4 or 5 FINISH
  messages 
- Compile and run fork_me as shown below; the output produced will be
  similar for runs on any Linux system including GRACE

```sh
>> make
gcc -Wall -Werror -g  -o fork_me fork_me.c

>> ./fork_me
START| parent_pid: 1010387 pid: 570337 
FINISH| pid: 570337 parent_pid: 1010387 global_total: 4
--FINISH| pid: 570341 parent_pid: 570337 global_total: 4
--FINISH| pid: 570343 parent_pid: 570337 global_total: 4
--FINISH| pid: 570339 parent_pid: 570337 global_total: 4
----FINISH| pid: 570342 parent_pid: 570339 global_total: 4
--FINISH| pid: 570338 parent_pid: 570337 global_total: 4
----FINISH| pid: 570340 parent_pid: 570338 global_total: 4
>> ----FINISH| pid: 570347 parent_pid: 1 global_total: 4
----FINISH| pid: 570345 parent_pid: 1 global_total: 4
------FINISH| pid: 570348 parent_pid: 1 global_total: 4
----FINISH| pid: 570349 parent_pid: 1 global_total: 4
----FINISH| pid: 570344 parent_pid: 1 global_total: 4
------FINISH| pid: 570346 parent_pid: 1 global_total: 4
------FINISH| pid: 570350 parent_pid: 1 global_total: 4
--------FINISH| pid: 570352 parent_pid: 570346 global_total: 4
------FINISH| pid: 570351 parent_pid: 570344 global_total: 4
```

- The total finish messages printed is 16
- Ask students to discuss why pointing out that each child created
  will pick up executing the same for loop. 
- Encourage students to draw a small table or "family tree" of the
  processes including what "i" value they are created at and who their
  parent is; such a picture might look something like

| Start | i=0            | i=1            | i=2            | i=3            | printf()    |
|-------|----------------|----------------|----------------|----------------|-------------|
| P100  | fork() -> P101 | fork() -> P102 | fork() -> P104 | fork() -> P108 | FINISH P100 |
|       | P101           | fork() -> P103 | fork() -> P105 | fork() -> P109 | FINISH P101 |
|       |                | P102           | fork() -> P106 | fork() -> P110 | FINISH P102 |
|       |                | P103           | fork() -> P107 | fork() -> P111 | FINISH P103 |
|       |                |                | P104           | fork() -> P112 | FINISH P104 |
|       |                |                | P105           | fork() -> P113 | FINISH P105 |
|       |                |                | P106           | fork() -> P114 | FINISH P106 |
|       |                |                | P107           | fork() -> P115 | FINISH P107 |
|       |                |                |                | P108           | FINISH P108 |
|       |                |                |                | P109           | FINISH P109 |
|       |                |                |                | P110           | FINISH P110 |
|       |                |                |                | P111           | FINISH P111 |
|       |                |                |                | P112           | FINISH P112 |
|       |                |                |                | P113           | FINISH P113 |
|       |                |                |                | P114           | FINISH P114 |
|       |                |                |                | P115           | FINISH P115 |

- Run fork_me() several times and note the differing output ordering,
  the fact that sometimes the prompt is clobbered and that some
  processes report a parent PID of 1; mention this is all due to there 
  being no coordination between parents/children
- Walk through the QUIZ questions and help provide answers
- Indicate to students that they can begin attempting to satisfy the
  constraints of the program but that will the focus of the next
  discussion
- Students should add wait() or waitpid() calls in the code to cause
  parents to wait for children after they are created (easy addition)
- Students will also need to capture the status of the finished child
  in their wait()/waitpid() calls, then use the WIFEXITED() /
  WEXITSTATUS() macros to extract information
- Indicate that these look like functions but if they are ALL CAPS are
  slightly different and referred to as Macros; we don't have time to
  cover on the technical distinction but those interested can do their
  own research
- Make sure students DO NOT wait() unless there is a child process to
  wait for; put the wait() in an else{} block for Parent-only code
- Discuss overall solution along with properties like gathering the
  exit codes from child programs and using them; they totaled here but
  can be used for other things such as checking for errors in the child

Note use of the 'test_order_pids' script to order IDS for testing as
described in QUESTIONS.txt
```sh
# raw output of program
>> ./fork_me
START| parent_pid: 1010387 pid: 568951 
FINISH| pid: 568951 parent_pid: 1010387 global_total: 4
--FINISH| pid: 568953 parent_pid: 568951 global_total: 4
----FINISH| pid: 568954 parent_pid: 568952 global_total: 4
----FINISH| pid: 568957 parent_pid: 568953 global_total: 4
----FINISH| pid: 568956 parent_pid: 568952 global_total: 4
----FINISH| pid: 568960 parent_pid: 568955 global_total: 4
----FINISH| pid: 568961 parent_pid: 568952 global_total: 4
--FINISH| pid: 568955 parent_pid: 568951 global_total: 4
--FINISH| pid: 568952 parent_pid: 568951 global_total: 4
------FINISH| pid: 568964 parent_pid: 1 global_total: 4
------FINISH| pid: 568965 parent_pid: 1 global_total: 4
----FINISH| pid: 568962 parent_pid: 1 global_total: 4
------FINISH| pid: 568959 parent_pid: 1 global_total: 4
--FINISH| pid: 568958 parent_pid: 568951 global_total: 4
------FINISH| pid: 568963 parent_pid: 1 global_total: 4
--------FINISH| pid: 568966 parent_pid: 1 global_total: 4

# pipe throug the test_order_pids filter to get consistent PIDs
>> ./fork_me | ./test_order_pids
START| parent_pid: 101 pid: 100
FINISH| pid: 100 parent_pid: 101 global_total: 4
--FINISH| pid: 102 parent_pid: 100 global_total: 4
--FINISH| pid: 103 parent_pid: 100 global_total: 4
----FINISH| pid: 104 parent_pid: 102 global_total: 4
--FINISH| pid: 105 parent_pid: 100 global_total: 4
----FINISH| pid: 106 parent_pid: 105 global_total: 4
------FINISH| pid: 107 parent_pid: 106 global_total: 4
----FINISH| pid: 108 parent_pid: INIT global_total: 4
----FINISH| pid: 109 parent_pid: INIT global_total: 4
------FINISH| pid: 110 parent_pid: INIT global_total: 4
------FINISH| pid: 111 parent_pid: INIT global_total: 4
----FINISH| pid: 112 parent_pid: INIT global_total: 4
--------FINISH| pid: 113 parent_pid: 111 global_total: 4
----FINISH| pid: 114 parent_pid: INIT global_total: 4
--FINISH| pid: 115 parent_pid: INIT global_total: 4
------FINISH| pid: 116 parent_pid: INIT global_total: 4
```

# Wed : File statistics with stat() 
- Walk through the `stat_demo.c` file and point out items of
  interest. Students will not have seen the functions used in it yet
  but it they are fairly simple.
- Discuss use of `access(filename, F_OK)` to check if a file exists;
  note that `stat(filename, &sb)` will return -1 to indicate that a
  file doesn't exit; these are alternatives to accomplish the task of
  checking if a file exists though `stat()` can reveal much more about
  files
- Note the use of "traditional" struct syntax for the variable

  `struct stat sb;` 
  
  This is common in C code that uses old-style structs and simply
  means that `sb` is a variable of type `stat` which is a struct type
- Describe the use of macros like `S_ISDIR(sb.st_mode)` to determine
  the type of a file - discuss the notion of "file type" here as
  different from PDF / Source File / Text File / JPEG / etc.: those
  are all "regular files" in the UNIX scheme whereas a directory
  (folder) is qualitatively different as is a network connection
  (socket)
- Emphasize the presence of `stat.st_size` which gives the number of
  bytes in a file: it is often the most useful and frequently used in
  projects
- Point out the use of the `ctime(...)` function to create a string
  rendition of times encoded in fields like `sb.st_atime` (not
  pertinent to projects but of interest)
- Note the "high resolution" timestamps on files at the end of the
  demo which include timestamps in nanoseconds in the `struct
  timespec` fields. These are used in the functions students will
  use in the next part.
- Point students at the `newer_file.c` template which they must fill
  in to pass the tests associated with the problem
- Help students copy over code from the `stat_demo.c` that is relevant
  and complete template
- Point out to students the use of command line arguments in several
  spots in the program to convey information into the program
  
  
