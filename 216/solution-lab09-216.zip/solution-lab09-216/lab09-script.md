# Monday
- Open up fork_me.c program to analyze it
- Note the primary feature: a loop with a fork() call in it
- Mention as well that the fflush(stdout) call guarantees that output
  in the original process (parent) will go to the screen before
  forking and won't be duplicated by child processes. Flushing output
  like this is needed sometimes when fork() gets involved
- Ask students for a prediction of how many "FINISH" messages will be
  printed. Give them 1-2mins to discuss among themselves; most of them
  should sense a trick of some kind but some will answer 4 or 5 FINISH
  messages 
- Compile and run fork_me as shown below; the output produced will be
  similar for runs on any Linux system including GRACE

```sh
>> make
gcc -Wall -Werror -g  -o fork_me fork_me.c

>> ./fork_me
START| parent_pid: 1010387 pid: 570337 
FINISH| pid: 570337 parent_pid: 1010387 global_total: 4
--FINISH| pid: 570341 parent_pid: 570337 global_total: 4
--FINISH| pid: 570343 parent_pid: 570337 global_total: 4
--FINISH| pid: 570339 parent_pid: 570337 global_total: 4
----FINISH| pid: 570342 parent_pid: 570339 global_total: 4
--FINISH| pid: 570338 parent_pid: 570337 global_total: 4
----FINISH| pid: 570340 parent_pid: 570338 global_total: 4
>> ----FINISH| pid: 570347 parent_pid: 1 global_total: 4
----FINISH| pid: 570345 parent_pid: 1 global_total: 4
------FINISH| pid: 570348 parent_pid: 1 global_total: 4
----FINISH| pid: 570349 parent_pid: 1 global_total: 4
----FINISH| pid: 570344 parent_pid: 1 global_total: 4
------FINISH| pid: 570346 parent_pid: 1 global_total: 4
------FINISH| pid: 570350 parent_pid: 1 global_total: 4
--------FINISH| pid: 570352 parent_pid: 570346 global_total: 4
------FINISH| pid: 570351 parent_pid: 570344 global_total: 4
```

- The total finish messages printed is 16
- Ask students to discuss why pointing out that each child created
  will pick up executing the same for loop. 
- Encourage students to draw a small table or "family tree" of the
  processes including what "i" value they are created at and who their
  parent is; such a picture might look something like

| Start | i=0            | i=1            | i=2            | i=3            | printf()    |
|-------|----------------|----------------|----------------|----------------|-------------|
| P100  | fork() -> P101 | fork() -> P102 | fork() -> P104 | fork() -> P108 | FINISH P100 |
|       | P101           | fork() -> P103 | fork() -> P105 | fork() -> P109 | FINISH P101 |
|       |                | P102           | fork() -> P106 | fork() -> P110 | FINISH P102 |
|       |                | P103           | fork() -> P107 | fork() -> P111 | FINISH P103 |
|       |                |                | P104           | fork() -> P112 | FINISH P104 |
|       |                |                | P105           | fork() -> P113 | FINISH P105 |
|       |                |                | P106           | fork() -> P114 | FINISH P106 |
|       |                |                | P107           | fork() -> P115 | FINISH P107 |
|       |                |                |                | P108           | FINISH P108 |
|       |                |                |                | P109           | FINISH P109 |
|       |                |                |                | P110           | FINISH P110 |
|       |                |                |                | P111           | FINISH P111 |
|       |                |                |                | P112           | FINISH P112 |
|       |                |                |                | P113           | FINISH P113 |
|       |                |                |                | P114           | FINISH P114 |
|       |                |                |                | P115           | FINISH P115 |

- Run fork_me() several times and note the differing output ordering,
  the fact that sometimes the prompt is clobbered and that some
  processes report a parent PID of 1; mention this is all due to there 
  being no coordination between parents/children
- Walk through the QUIZ questions and help provide answers
- Indicate to students that they can begin attempting to satisfy the
  constraints of the program but that will the focus of the next
  discussion
  
# Wednesday
- Students should add wait() or waitpid() calls in the code to cause
  parents to wait for children after they are created (easy addition)
- Lecture includes examples of wait() and waitpid() that can be
  utilized
- Students will also need to capture the status of the finished child
  in their wait()/waitpid() calls, then use the WIFEXITED() /
  WEXITSTATUS() macros to extract information
- Indicate that these look like functions but if they are ALL CAPS are
  slightly different and referred to as Macros; we don't have time to
  cover on the technical distinction but those interested can do their
  own research
- Ask students to insert some code akin to what was done in lecture
  prior to Exam 2 and then help construct the answer as a group
- Make sure students DO NOT wait() unless there is a child process to
  wait for; put the wait() in an else{} block for Parent-only code
- Discuss overall solution along with properties like gathering the
  exit codes from child programs and using them; they totaled here but
  can be used for other things such as checking for errors in the child

Note use of the 'test_order_pids' script to order IDS for testing as
described in QUESTIONS.txt
```sh
# raw output of program
>> ./fork_me
START| parent_pid: 1010387 pid: 568951 
FINISH| pid: 568951 parent_pid: 1010387 global_total: 4
--FINISH| pid: 568953 parent_pid: 568951 global_total: 4
----FINISH| pid: 568954 parent_pid: 568952 global_total: 4
----FINISH| pid: 568957 parent_pid: 568953 global_total: 4
----FINISH| pid: 568956 parent_pid: 568952 global_total: 4
----FINISH| pid: 568960 parent_pid: 568955 global_total: 4
----FINISH| pid: 568961 parent_pid: 568952 global_total: 4
--FINISH| pid: 568955 parent_pid: 568951 global_total: 4
--FINISH| pid: 568952 parent_pid: 568951 global_total: 4
------FINISH| pid: 568964 parent_pid: 1 global_total: 4
------FINISH| pid: 568965 parent_pid: 1 global_total: 4
----FINISH| pid: 568962 parent_pid: 1 global_total: 4
------FINISH| pid: 568959 parent_pid: 1 global_total: 4
--FINISH| pid: 568958 parent_pid: 568951 global_total: 4
------FINISH| pid: 568963 parent_pid: 1 global_total: 4
--------FINISH| pid: 568966 parent_pid: 1 global_total: 4

# pipe throug the test_order_pids filter to get consistent PIDs
>> ./fork_me | ./test_order_pids
START| parent_pid: 101 pid: 100
FINISH| pid: 100 parent_pid: 101 global_total: 4
--FINISH| pid: 102 parent_pid: 100 global_total: 4
--FINISH| pid: 103 parent_pid: 100 global_total: 4
----FINISH| pid: 104 parent_pid: 102 global_total: 4
--FINISH| pid: 105 parent_pid: 100 global_total: 4
----FINISH| pid: 106 parent_pid: 105 global_total: 4
------FINISH| pid: 107 parent_pid: 106 global_total: 4
----FINISH| pid: 108 parent_pid: INIT global_total: 4
----FINISH| pid: 109 parent_pid: INIT global_total: 4
------FINISH| pid: 110 parent_pid: INIT global_total: 4
------FINISH| pid: 111 parent_pid: INIT global_total: 4
----FINISH| pid: 112 parent_pid: INIT global_total: 4
--------FINISH| pid: 113 parent_pid: 111 global_total: 4
----FINISH| pid: 114 parent_pid: INIT global_total: 4
--FINISH| pid: 115 parent_pid: INIT global_total: 4
------FINISH| pid: 116 parent_pid: INIT global_total: 4
```
