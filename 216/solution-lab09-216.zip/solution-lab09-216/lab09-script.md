# Mon : Makefiles
- Discuss basic syntax of Makefiles surveyed in lab web page; students
  will have seen this in lecture but will likely need a refresher to
  stay oriented
- Discuss examples provided in subdirectories
  - makeproblem-demo-little/Makefile : simplest version for
    small project
  - makeproblem-demo-little/Makefile-shortcuts : introduces
    variables and pattern rules; DON'T spend a lot of time on this,
    just mention that like most programmatic systems, Makefiles have
    more features
  - makeproblem-demo-big/Makefile : larger version, verbose as
    it doesn't use any shortcuts
  - makeproblem-demo-big/Makefile-shortcuts : good use of variables
    and pattern rules to make the Makefile shorter
- Direct students to complete the provided template in
  prob1-makefile/Makefile
- Discuss the @ syntax which will omit printing commands being run by
  the Makefile which can make output look a bit nicer; EXAMPLE:
```makefile
targ1 :
   echo "hello world"

targ2 :
   @echo "hello world"
```
Shell run:
```shell
>> make targ1
echo "hello world"    # prints command to be run
hello world           # prints output of comand

>> make targ2
hello world           # @ omits printing command, only output shown
```  

NOTE: Keep an eye on automated tests; they are a bit tricky to write
for Makefiles but this problem has worked okay

# Wed : I/O Redirection via dup2()
- Show a few examples of how I/O redirection looks on the command line
  knowing that students have seen things like this but may not
  remember or know the terminology. Showing some commands like the
  following to demonstrate the utility of Output and Input redirection.
  ```sh
  >> seq 5
  1
  2
  3
  4
  5
  >> seq 5 > nums.txt
  >> sort -r < nums.txt
  5
  4
  3
  2
  1
  ``` 
- Indicate that this capability on the shell is general and is
  accomplished via some system calls in C programs
- Students will come to lab knowing a bit about File Descriptors.  The
  presence of STDOUT_FILENO and the general file descriptor table will
  havebeen discussed and likely discussion as well of the dup2()
  system call
- Walk through the use switch_stdout.c program noting the use dup2()
  and use the provided diagrams in the lab spec to discuss how the FD
  table for processes is manipulated using this call
- Show the program output and the contents of mystery.txt: printf()
  calls go to screen but then go into mystery.txt after the dup2() call
- Guide students in filling in the redirect_child.c template file;
  intent of the file is to
  - fork() a child process
  - have the child process eventually print some output via an exec()
    of `wc`
  - before calling exec() use dup2() to redirect output into a file
- TODO items indicate where code should be filled in

