#include <time.h>
#include <stdio.h>
#include <stdlib.h>

// usage: sleep_print secs message
//
// Sleep for the given number of seconds then print the given message
int main(int argc, char *argv[]){

  if(argc < 2){
    printf("usage: %s <sleepsecs> <msg>\n",
           argv[0]);
    return 1;
  }
  
  int secs = atoi(argv[1]);

  struct timespec tm = {
    .tv_nsec = 0,
    .tv_sec  = secs,
  };
  nanosleep(&tm,NULL);
  for(int i=2; i<argc; i++){
    printf("%s ",argv[i]);
  }
  printf("\n");

  return secs;
}
  
