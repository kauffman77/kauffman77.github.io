#!/bin/bash

# usage: 00_eval_performance.sh $(ls) > ../scores.txt
#        00_eval_performance.sh $(ls | head) > ../scores.txt
# 
# automates scoring of the performance benchmark; requries a post
# processing script to be used later

basedir=$(pwd)
header="sumdiag.h"
benchmark="sumdiag_benchmark"
repeats=3

for f in $*; do
    printf "====== %s =======\n" "$f"

    targdir=$(find $f -name $header)
    if [[ "$?" != "0" ]]; then
        echo "No $header found in $f"
        continue
    fi
    targdir=$(dirname $targdir)
    echo "Changing to $targdir"
    cd $targdir
    make clean
    make $benchmark
    if [[ "$?" != "0" ]]; then
        cd $basedir
        continue
    fi

    for i in $(seq $repeats); do
        timeout 120s $benchmark | grep TOTAL
        if [[ "$?" != "0" ]]; then
            echo "Timeout / Killed"
        fi
    done

    cd $basedir
done
