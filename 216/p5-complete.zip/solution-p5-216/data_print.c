// prints the string in data
#include <stdio.h>

int actual_score=0, total_points=0;
#include "data.c"

int main(){
  printf("%s",(char*) data);
  return 0;
}
