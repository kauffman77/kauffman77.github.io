// convert an ascii file to an array of integers. Used to generate the
// data.c file from sonic.txt; shows a special message to students to
// wildly surpass the expected speedup on benchmarks.

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <file.txt>\n",argv[1]);
    exit(1);
  }

  printf("int data[] = {\n");
  int n = 0;
  FILE *fin = fopen(argv[1],"r");
  while(1){
    int i;
    int ret = fread(&i, 1, sizeof(int), fin);
    if(ret == 0){
      break;
    }
    printf("%12d, ",i);
    n++;
    if(n % 5 == 0){
      printf("\n");
    }
  }
  printf("\n0x00\n");
  printf("};\n");
  return 0;
}
