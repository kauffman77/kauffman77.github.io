// optimized version of matrix column normalization
#include "colnorm.h"

// You can write several different versions of your optimized function
// in this file and call one of them in the last function.

////////////////////////////////////////////////////////////////////////////////
// single-threaded versions
////////////////////////////////////////////////////////////////////////////////

// Replica of baseline
int cn_base1(matrix_t mat, vector_t avg, vector_t std) {
  for(int i=0; i<avg.len; i++){                    // initialize avg/std to all 0s
    VSET(avg, i, 0.0);                             // may not be necessary for some 
    VSET(std, i, 0.0);                             // algorithmic approaches
  }

  for(int j=0; j<mat.cols; j++){
    double sum_j = 0.0;                              // PASS 1: Compute column average
    for(int i=0; i<mat.rows; i++){                 
      sum_j += MGET(mat,i,j);
    }
    double avg_j = sum_j / mat.rows;
    VSET(avg,j,avg_j);
    sum_j = 0.0;
    for(int i=0; i<mat.rows; i++){                 // PASS 2: Compute column standard deviation
      double diff = MGET(mat,i,j) - avg_j;
      sum_j += diff*diff;
    };
    double std_j = sqrt(sum_j / mat.rows);
    VSET(std,j,std_j);
    for(int i=0; i<mat.rows; i++){                 // PASS 3: Normalize matrix column
      double mij = MGET(mat,i,j);
      mij = (mij - avg_j) / std_j;
      MSET(mat,i,j,mij);
    }
  }
  return 0;
}

// Memory reorder only, use auxiliary sum vector in computation
int cn_mem1(matrix_t mat, vector_t avg, vector_t std){
  vector_t sum;                                    // auxiliary sums
  vector_init(&sum, mat.cols);
  for(int j=0; j<mat.cols; j++){                   // initialize sum to all 0s
    VSET(sum, j, 0.0);
  }

  for(int i=0; i<mat.rows; i++){                   // PASS 1: Compute column average
    for(int j=0; j<mat.cols; j++){
      VSET(sum, j, VGET(sum,j) + MGET(mat,i,j));
    }
  }
  for(int j=0; j<mat.cols; j++){
    VSET(avg, j, VGET(sum,j) / mat.rows);
    VSET(sum, j, 0.0);
  }
  for(int i=0; i<mat.rows; i++){                   // PASS 2: Compute column standard deviation
    for(int j=0; j<mat.cols; j++){
      double diff = MGET(mat,i,j) - VGET(avg,j);
      VSET(sum,j, VGET(sum,j) + diff*diff);
    }
  }
  for(int j=0; j<mat.cols; j++){
    VSET(std, j, sqrt(VGET(sum,j) / mat.rows));
  }
  for(int i=0; i<mat.rows; i++){                   // PASS 3: Normalize matrix column
    for(int j=0; j<mat.cols; j++){
      double mij = MGET(mat,i,j);
      mij = (mij - VGET(avg,j)) / VGET(std,j);
      MSET(mat,i,j,mij);
    }
  }
  vector_free_data(&sum);
  return 0;
}

// Memory reorder only, use existing vectors for sum in computation
int cn_mem2(matrix_t mat, vector_t avg, vector_t std){
  for(int j=0; j<mat.cols; j++){                   // initialize sum to all 0s
    VSET(avg, j, 0.0);
    VSET(std, j, 0.0);
  }

  for(int i=0; i<mat.rows; i++){                   // PASS 1: Compute column average
    for(int j=0; j<mat.cols; j++){
      VSET(avg, j, VGET(avg,j) + MGET(mat,i,j));
    }
  }
  for(int j=0; j<mat.cols; j++){
    VSET(avg, j, VGET(avg,j) / mat.rows);
  }
  for(int i=0; i<mat.rows; i++){                   // PASS 2: Compute column standard deviation
    for(int j=0; j<mat.cols; j++){
      double diff = MGET(mat,i,j) - VGET(avg,j);
      VSET(std,j, VGET(std,j) + diff*diff);
    }
  }
  for(int j=0; j<mat.cols; j++){
    VSET(std, j, sqrt(VGET(std,j) / mat.rows));
  }
  for(int i=0; i<mat.rows; i++){                   // PASS 3: Normalize matrix column
    for(int j=0; j<mat.cols; j++){
      double mij = MGET(mat,i,j);
      mij = (mij - VGET(avg,j)) / VGET(std,j);
      MSET(mat,i,j,mij);
    }
  }
  return 0;
}

////////////////////////////////////////////////////////////////////////////////
// multi-threaded versions
////////////////////////////////////////////////////////////////////////////////

// Struct to hold computing context for threads
typedef struct {
  int thread_id;
  int thread_count;
  matrix_t mat;
  vector_t avg;
  vector_t std;
  pthread_mutex_t *lock;
  pthread_barrier_t *barrier;
} colnorm_context_t;

// WORKER: block rows, each thread gets a group of contiguous rows to
// grind on. This is an easy division that gets pretty good
// performance and is typically what students would use. FULL CREDIT
// solution.
void *rowthread1(void *arg){
  colnorm_context_t ctx = *((colnorm_context_t *) arg);
  matrix_t mat = ctx.mat;
  vector_t avg = ctx.avg;
  vector_t std = ctx.std;

  int rows_per_thread = mat.rows / ctx.thread_count;
  int beg_row = rows_per_thread * ctx.thread_id;
  int end_row = rows_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_row = mat.rows;
  }

  int cols_per_thread = mat.cols / ctx.thread_count;
  int beg_col = cols_per_thread * ctx.thread_id;
  int end_col = cols_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_col = mat.cols;
  }

  vector_t sum;                                    // auxiliary sums
  vector_init(&sum, mat.cols);
  for(int j=0; j<mat.cols; j++){                   // initialize sum to all 0s
    VSET(sum, j, 0.0);
  }

  for(int i=beg_row; i<end_row; i++){              // PASS 1: Compute column average
    for(int j=0; j<mat.cols; j++){
      VSET(sum, j, VGET(sum,j) + MGET(mat,i,j));
    }
  }
  pthread_mutex_lock(ctx.lock);
  for(int j=0; j<mat.cols; j++){                         // using division here spares 
    VSET(avg, j, VGET(avg, j) + VGET(sum,j) / mat.rows); // the need for a second pass
  }
  pthread_mutex_unlock(ctx.lock);
  for(int j=0; j<mat.cols; j++){                   // initialize sum to all 0s
    VSET(sum, j, 0.0);
  }

  pthread_barrier_wait(ctx.barrier);

  for(int i=beg_row; i<end_row; i++){              // PASS 2: Compute column standard deviation
    for(int j=0; j<mat.cols; j++){
      double diff = MGET(mat,i,j) - VGET(avg,j);
      VSET(sum,j, VGET(sum,j) + diff*diff);
    }
  }

  pthread_mutex_lock(ctx.lock);
  for(int j=0; j<mat.cols; j++){
    VSET(std, j, VGET(std, j) + VGET(sum,j) / mat.rows);
  }
  pthread_mutex_unlock(ctx.lock);
  pthread_barrier_wait(ctx.barrier);

  for(int j=beg_col; j<end_col; j++){              // finalize std in parallel
    VSET(std, j, sqrt(VGET(std, j)));
  }
  pthread_barrier_wait(ctx.barrier);

  for(int i=beg_row; i<end_row; i++){              // PASS 3: Normalize matrix column
    for(int j=0; j<mat.cols; j++){
      double mij = MGET(mat,i,j);
      mij = (mij - VGET(avg,j)) / VGET(std,j);
      MSET(mat,i,j,mij);
    }
  }
  vector_free_data(&sum);
  return 0;
}

// WORKER: block rows, eliminate macro use and favor direct data
// access
void *rowthread2(void *arg){
  colnorm_context_t ctx = *((colnorm_context_t *) arg);
  matrix_t mat = ctx.mat;
  vector_t avg = ctx.avg;
  vector_t std = ctx.std;

  int rows_per_thread = mat.rows / ctx.thread_count;
  int beg_row = rows_per_thread * ctx.thread_id;
  int end_row = rows_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_row = mat.rows;
  }

  int cols_per_thread = mat.cols / ctx.thread_count;
  int beg_col = cols_per_thread * ctx.thread_id;
  int end_col = cols_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_col = mat.cols;
  }

  vector_t sum;                                    // auxiliary sums
  vector_init(&sum, mat.cols);
  memset(sum.data, 0, sum.len*sizeof(double));     // initialize sum to all 0s

  for(int i=beg_row; i<end_row; i++){              // PASS 1: Compute column average
    double *row = mat.data + i*mat.cols;
    for(int j=0; j<mat.cols; j++){
      sum.data[j] += row[j];
    }
  }
  pthread_mutex_lock(ctx.lock);
  for(int j=0; j<mat.cols; j++){                   // using division here spares 
    avg.data[j] += sum.data[j] / mat.rows;         // the need for a second pass
  }
  pthread_mutex_unlock(ctx.lock);

  memset(sum.data, 0, sum.len*sizeof(double));     // initialize sum to all 0s

  pthread_barrier_wait(ctx.barrier);

  for(int i=beg_row; i<end_row; i++){              // PASS 2: Compute column standard deviation
    double *row = mat.data + i*mat.cols;
    for(int j=0; j<mat.cols; j++){
      double diff = row[j] - avg.data[j];
      sum.data[j] += diff*diff;
    }
  }

  pthread_mutex_lock(ctx.lock);
  for(int j=0; j<mat.cols; j++){
    std.data[j] += sum.data[j] / mat.rows;
  }
  pthread_mutex_unlock(ctx.lock);
  pthread_barrier_wait(ctx.barrier);

  for(int j=beg_col; j<end_col; j++){              // finalize std in parallel
    std.data[j] = sqrt(std.data[j]);
  }
  pthread_barrier_wait(ctx.barrier);

  for(int i=beg_row; i<end_row; i++){              // PASS 3: Normalize matrix column
    double *row = mat.data + i*mat.cols;
    for(int j=0; j<mat.cols; j++){
      row[j] = (row[j] - avg.data[j]) / std.data[j];
    }
  }
  vector_free_data(&sum);
  return 0;
}

// WORKER: block rows, eliminate macro use and favor direct data
// access, unroll loops by 4x
void *rt_ur4(void *arg){
  colnorm_context_t ctx = *((colnorm_context_t *) arg);
  matrix_t mat = ctx.mat;
  vector_t avg = ctx.avg;
  vector_t std = ctx.std;

  int rows_per_thread = mat.rows / ctx.thread_count;
  int beg_row = rows_per_thread * ctx.thread_id;
  int end_row = rows_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_row = mat.rows;
  }

  int cols_per_thread = mat.cols / ctx.thread_count;
  int beg_col = cols_per_thread * ctx.thread_id;
  int end_col = cols_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_col = mat.cols;
  }

  vector_t sum;                                    // auxiliary sums
  vector_init(&sum, mat.cols);
  memset(sum.data, 0, sum.len*sizeof(double));     // initialize sum to all 0s

  for(int i=beg_row; i<end_row; i++){              // PASS 1: Compute column average
    double *row = mat.data + i*mat.cols;
    int j=0;
    for(; j<mat.cols-4; j+=4){
      sum.data[j+0] += row[j+0];
      sum.data[j+1] += row[j+1];
      sum.data[j+2] += row[j+2];
      sum.data[j+3] += row[j+3];
    }
    for(; j<mat.cols; j+=1){
      sum.data[j+0] += row[j+0];
    }
  }
  pthread_mutex_lock(ctx.lock);
  for(int j=0; j<mat.cols; j++){                   // using division here spares 
    avg.data[j] += sum.data[j] / mat.rows;         // the need for a second pass
  }
  pthread_mutex_unlock(ctx.lock);

  memset(sum.data, 0, sum.len*sizeof(double));     // initialize sum to all 0s

  pthread_barrier_wait(ctx.barrier);

  for(int i=beg_row; i<end_row; i++){              // PASS 2: Compute column standard deviation
    double *row = mat.data + i*mat.cols;
    // double diffs[4];
    double diff0, diff1, diff2, diff3;
    int j=0;
    for(; j<mat.cols-4; j+=4){                     // explore ordering here
      diff0 = row[j+0] - avg.data[j+0];
      sum.data[j+0] += diff0*diff0;
      diff1 = row[j+1] - avg.data[j+1];
      sum.data[j+1] += diff1*diff1;
      diff2 = row[j+2] - avg.data[j+2];
      sum.data[j+2] += diff2*diff2;
      diff3 = row[j+3] - avg.data[j+3];
      sum.data[j+3] += diff3*diff3;
    }
    for(; j<mat.cols; j+=1){
      diff0= row[j+0] - avg.data[j+0];
      sum.data[j+0] += diff0*diff0;
    }
  }

  pthread_mutex_lock(ctx.lock);
  int j=0;
  for(; j<mat.cols-4; j+=4){
    std.data[j+0] += sum.data[j+0] / mat.rows;
    std.data[j+1] += sum.data[j+1] / mat.rows;
    std.data[j+2] += sum.data[j+2] / mat.rows;
    std.data[j+3] += sum.data[j+3] / mat.rows;
  }
  for(; j<mat.cols; j+=1){
    std.data[j+0] += sum.data[j+0] / mat.rows;
  }
  pthread_mutex_unlock(ctx.lock);
  pthread_barrier_wait(ctx.barrier);

  j=beg_col;
  for(; j<end_col-4; j+=4){              // finalize std in parallel
    std.data[j+0] = sqrt(std.data[j+0]);
    std.data[j+1] = sqrt(std.data[j+1]);
    std.data[j+2] = sqrt(std.data[j+2]);
    std.data[j+3] = sqrt(std.data[j+3]);
  }
  for(; j<end_col; j+=1){              // finalize std in parallel
    std.data[j+0] = sqrt(std.data[j+0]);
  }
  pthread_barrier_wait(ctx.barrier);

  for(int i=beg_row; i<end_row; i++){              // PASS 3: Normalize matrix column
    double *row = mat.data + i*mat.cols;
    int j=0;
    for(; j<mat.cols-4; j+=4){
      row[j+0] = (row[j+0] - avg.data[j+0]) / std.data[j+0];
      row[j+1] = (row[j+1] - avg.data[j+1]) / std.data[j+1];
      row[j+2] = (row[j+2] - avg.data[j+2]) / std.data[j+2];
      row[j+3] = (row[j+3] - avg.data[j+3]) / std.data[j+3];
    }
    for(; j<mat.cols; j+=1){
      row[j+0] = (row[j+0] - avg.data[j+0]) / std.data[j+0];
    }
  }
  vector_free_data(&sum);
  return 0;
}

// this type uses GCC's builtin vector extension which allows
// generation of vector operations with use of the type. If compiled
// with options like -msse3, vectors will produce "packed" vector
// operations atthe assembly level like `addpd` `subpd` `divpd` which
// perform multiple floating point operations instead of a single
// operation. This can greatly speed up numeric operations.
typedef double v2d __attribute__ ((vector_size (16), aligned (16)));
// typedef double v2d __attribute__ ((vector_size (16)));

// WORKER: block rows, eliminate macro use and favor direct data
// access, unroll loops by 4x, use VECTOR instructions; casting to the
// v2d type cause the compiler to generated packed floating point
// operations which will improve speed
void *rt_vec(void *arg){
  colnorm_context_t ctx = *((colnorm_context_t *) arg);
  matrix_t mat = ctx.mat;
  vector_t avg = ctx.avg;
  vector_t std = ctx.std;
  double *mat_data = mat.data;
  double *avg_data = avg.data;
  double *std_data = std.data;

  int rows_per_thread = mat.rows / ctx.thread_count;
  int beg_row = rows_per_thread * ctx.thread_id;
  int end_row = rows_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_row = mat.rows;
  }

  int cols_per_thread = mat.cols / ctx.thread_count;
  int beg_col = cols_per_thread * ctx.thread_id;
  int end_col = cols_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_col = mat.cols;
  }

  vector_t sum;                                    // auxiliary sums
  vector_init(&sum, mat.cols);
  memset(sum.data, 0, sum.len*sizeof(double));     // initialize sum to all 0s
  double *sum_data = sum.data;

  int j=0;
  double drows = mat.rows;

  for(int i=beg_row; i<end_row; i++){              // PASS 1: Compute column average
    double *row = mat_data + i*mat.cols;
    j=0;
    if((((unsigned long) row) & 0xF) != 0){        // align row references
      sum_data[j+0] += row[j+0];
      j++;
    }
    for(; j<mat.cols-4; j+=4){
      printf("tid: %d j: %d row: %p sum_data: %p\n",ctx.thread_id,j,row+j,sum_data+j);
      *((v2d*) &sum_data[j+0]) += *((v2d*) &row[j+0]);
      printf("tid: %d j: %d row: %p sum_data: %p\n",ctx.thread_id,j+2,row+j+2,sum_data+j+2);
      *((v2d*) &sum_data[j+2]) += *((v2d*) &row[j+2]);
    }
    for(; j<mat.cols; j+=1){
      sum_data[j+0] += row[j+0];
    }
  }
  pthread_mutex_lock(ctx.lock);
  for(j=0; j<mat.cols-4; j+=4){
    *((v2d*) &avg_data[j+0]) += *((v2d*) &sum_data[j+0]) / drows;
    *((v2d*) &avg_data[j+2]) += *((v2d*) &sum_data[j+2]) / drows;
  }
  for(; j<mat.cols; j+=1){
    avg.data[j+0] += sum.data[j+0] / drows;
  }
  pthread_mutex_unlock(ctx.lock);

  memset(sum_data, 0, sum.len*sizeof(double));     // initialize sum to all 0s

  pthread_barrier_wait(ctx.barrier);

  for(int i=beg_row; i<end_row; i++){              // PASS 2: Compute column standard deviation
    double *row = mat_data + i*mat.cols;
    for(j=0; j<mat.cols-4; j+=4){                  // explore ordering here
      v2d d0 = *((v2d*) (row+j+0));
      d0 -= *((v2d *) (avg_data+j+0));
      d0 *= d0;
      *((v2d*) (sum_data+j+0)) += d0;

      v2d d2 = *((v2d*) (row+j+2));
      d2 -= *((v2d *) (avg_data+j+2));
      d2 *= d2;
      *((v2d*) (sum_data+j+2)) += d2;
    }
    for(; j<mat.cols; j+=1){
      double diff0 = row[j+0] - avg_data[j+0];
      sum_data[j+0] += diff0*diff0;
    }
  }

  pthread_mutex_lock(ctx.lock);
  for(j=0; j<mat.cols-4; j+=4){
    *((v2d*) &std_data[j+0]) += *((v2d*) &sum_data[j+0]) / drows;
    *((v2d*) &std_data[j+2]) += *((v2d*) &sum_data[j+2]) / drows;
  }
  for(; j<mat.cols; j+=1){
    std_data[j+0] += sum_data[j+0] / mat.rows;
  }
  pthread_mutex_unlock(ctx.lock);
  pthread_barrier_wait(ctx.barrier);

  j=beg_col;
  for(; j<end_col-4; j+=4){                        // finalize std in parallel
    std_data[j+0] = sqrt(std_data[j+0]);           // sqrt() doesn't have vector support
    std_data[j+1] = sqrt(std_data[j+1]);           // for doubles
    std_data[j+2] = sqrt(std_data[j+2]);
    std_data[j+3] = sqrt(std_data[j+3]);
    // *((v2d*) &std.data[j+0]) = sqrt( *((v2d*) &std.data[j+0]) );
    // *((v2d*) &std.data[j+2]) = sqrt( *((v2d*) &std.data[j+2]) );
  }
  for(; j<end_col; j+=1){              // finalize std in parallel
    std_data[j+0] = sqrt(std_data[j+0]);
  }
  pthread_barrier_wait(ctx.barrier);

  for(int i=beg_row; i<end_row; i++){              // PASS 3: Normalize matrix column
    double *row = mat_data + i*mat.cols;
    for(j=0; j<mat.cols-4; j+=4){
      *((v2d*) &row[j+0]) -= *((v2d*) &avg_data[j+0]);
      *((v2d*) &row[j+0]) /= *((v2d*) &std_data[j+0]);
      *((v2d*) &row[j+2]) -= *((v2d*) &avg_data[j+2]);
      *((v2d*) &row[j+2]) /= *((v2d*) &std_data[j+2]);
    }
    for(; j<mat.cols; j+=1){
      row[j+0] = (row[j+0] - avg.data[j+0]) / std_data[j+0];
    }
  }
  vector_free_data(&sum);
  return 0;
}

// WORKER: block columns, each thread works on distinct columns, no
// synchronization is needed (lock / barrier) but the cache
// performance is likely to be TERRIBLE
void *colthread1(void *arg){
  colnorm_context_t ctx = *((colnorm_context_t *) arg);
  matrix_t mat = ctx.mat;
  vector_t avg = ctx.avg;
  vector_t std = ctx.std;

  int cols_per_thread = mat.cols / ctx.thread_count;
  int beg_col = cols_per_thread * ctx.thread_id;
  int end_col = cols_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_col = mat.cols;
  }

  for(int j=beg_col; j<end_col; j++){
    double sum_j = 0.0;                              // PASS 1: Compute column average
    for(int i=0; i<mat.rows; i++){                 
      sum_j += MGET(mat,i,j);
    }
    double avg_j = sum_j / mat.rows;
    VSET(avg,j,avg_j);
    sum_j = 0.0;
    for(int i=0; i<mat.rows; i++){                 // PASS 2: Compute column standard deviation
      double diff = MGET(mat,i,j) - avg_j;
      sum_j += diff*diff;
    };
    double std_j = sqrt(sum_j / mat.rows);
    VSET(std,j,std_j);
    for(int i=0; i<mat.rows; i++){                 // PASS 3: Normalize matrix column
      double mij = MGET(mat,i,j);
      mij = (mij - avg_j) / std_j;
      MSET(mat,i,j,mij);
    }
  }
  return 0;
}



int cn_threads(matrix_t mat, vector_t avg, vector_t std,
               int thread_count, void *(*start_routine)(void *))
{
  for(int i=0; i<avg.len; i++){
    VSET(avg,i,0.0);
    VSET(std,i,0.0);
  }

  pthread_mutex_t lock;                      // lock to coordinate end results
  pthread_mutex_init(&lock, NULL);
  pthread_barrier_t barrier;                 // barrier to coordinate end results
  pthread_barrier_init(&barrier, NULL, thread_count);

  pthread_t threads[thread_count];           // track each thread
  colnorm_context_t ctxs[thread_count];      // context for each thread

  for(int i=0; i<thread_count; i++){
    ctxs[i].thread_id = i;                   // set up the context: thread_id and 
    ctxs[i].thread_count = thread_count;     // locals to this function housed in 
    ctxs[i].mat = mat;                       // a struct
    ctxs[i].avg = avg;
    ctxs[i].std = std;
    ctxs[i].lock = &lock;                    // pass pointers to the same lock/barrier
    ctxs[i].barrier = &barrier;              // for all threads
    
    pthread_create(&threads[i], NULL,        // start worker thread to compute part of answer
                   start_routine, &ctxs[i]); // start routine is passed as a param
  }

  for(int i=0; i<thread_count; i++){          // wait for each thread to finish
    pthread_join(threads[i], NULL);
  }
  
  pthread_mutex_destroy(&lock);              // get rid of the lock/barrier to
  pthread_barrier_destroy(&barrier);         // avoid a memory leak
  return 0;
}

int colnorm_OPTM(matrix_t mat, vector_t avg, vector_t std, int nt) {
  if(avg.len != mat.cols || std.len != mat.cols){
    printf("colnorm_optm: bad sizes\n");
    return 1;
  }
  char *alg = getenv("ALG");
  alg = (alg != NULL) ? alg : "ROWTHREAD1";
  // printf("ALG: %s\n",alg);
  if(0){}
  else if(strcmp(alg,"BASE1")==0)      { cn_base1  (mat, avg, std); }
  else if(strcmp(alg,"MEM1")==0)       { cn_mem1   (mat, avg, std); }
  else if(strcmp(alg,"MEM2")==0)       { cn_mem2   (mat, avg, std); }
  else if(strcmp(alg,"ROWTHREAD1")==0) { cn_threads(mat, avg, std, nt, rowthread1); }
  else if(strcmp(alg,"ROWTHREAD2")==0) { cn_threads(mat, avg, std, nt, rowthread2); }
  else if(strcmp(alg,"COLTHREAD1")==0) { cn_threads(mat, avg, std, nt, colthread1); }
  else if(strcmp(alg,"RT_UR4")==0)     { cn_threads(mat, avg, std, nt, rt_ur4); }
  else if(strcmp(alg,"RT_VEC")==0)     { cn_threads(mat, avg, std, nt, rt_vec); }
  else {
    printf("ERROR: no algorithm '%s'\n",alg);
    return 1;
  }

  return 0;
}

