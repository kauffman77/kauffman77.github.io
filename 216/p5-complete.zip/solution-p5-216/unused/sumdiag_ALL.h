typedef int (*sumdiag_t)(matrix_t *mat, vector_t *ovec);

// struct for search algorithm information
typedef struct {
  char *name;                   // description
  sumdiag_t func;               // function pointer
  double total_points;          // points for algorithm
} algs_t;

extern algs_t sumdiag_algs[];
