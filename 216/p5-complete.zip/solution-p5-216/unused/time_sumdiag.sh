#!/bin/bash

BENCHMARK=~kauffman/2021/solution-p4-2021/sumdiag_benchmark.c

if [[ -e sumdiag_benchmark.c ]]; then
    mkdir -p bkup
    cp --backup=numbered ./sumdiag_benchmark.c bkup
fi
cp $BENCHMARK .
make clean
make sumdiag_benchmark
./sumdiag_benchmark
./sumdiag_benchmark
./sumdiag_benchmark
