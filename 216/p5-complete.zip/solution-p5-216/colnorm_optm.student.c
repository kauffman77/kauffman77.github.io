// optimized versions of matrix diagonal summing
#include "sumdiag.h"

////////////////////////////////////////////////////////////////////////////////
// REQUIRED: Paste a copy of your sumdiag_benchmark from an ODD grace
// node below.
//
// -------REPLACE WITH YOUR RUN + TABLE --------
// 
// grace9:~/216/p5-code: ./sumdiag_benchmark
// ==== Matrix Diagonal Sum Benchmark Version 5 ====
// ------ Tuned for ODD grace.umd.edu machines -----
// Running with 5 sizes (max 8192) and 4 thread_counts (max 4)
//   SIZE   BASE #T   OPTM  SPDUP POINTS 
//   1024  0.000  1  0.000   0.00   0.00 
//                2  0.000   0.00   0.00 
//                3  0.000   0.00   0.00 
//                4  0.000   0.00   0.00 
//   1101  0.000  1  0.000   0.00   0.00 
//                2  0.000   0.00   0.00 
//   .....             ......
//                4  0.000   0.00   0.00 
//   8192  0.000  1  0.000   0.00   0.00 
//                2  0.000   0.00   0.00 
//                3  0.000   0.00   0.00 
//                4  0.000   0.00   0.00 
// RAW POINTS:  0.00
// TOTAL POINTS:  0 / 30
// 
// -------REPLACE WITH YOUR RUN + TABLE --------



// You can write several different versions of your optimized function
// in this file and call one of them in the last function.

int sumdiag_VER1(matrix_t mat, vector_t vec, int thread_count) {
  // OPTIMIZED CODE HERE
  return 0;
}

int sumdiag_VER2(matrix_t mat, vector_t vec, int thread_count) {
  // OPTIMIZED CODE HERE
  return 0;
}

int sumdiag_OPTM(matrix_t mat, vector_t vec, int thread_count) {
  // call your preferred version of the function
  return sumdiag_VER1(mat, vec, thread_count);
}

////////////////////////////////////////////////////////////////////////////////
// REQUIRED: DON'T FORGET TO PASTE YOUR TIMING RESULTS FOR
// sumdiag_benchmark FROM AN ODD GRACE NODE AT THE TOP OF THIS FILE
////////////////////////////////////////////////////////////////////////////////
