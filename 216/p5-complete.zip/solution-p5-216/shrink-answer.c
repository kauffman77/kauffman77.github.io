#include "el_malloc.c"
////////////////////////////// SOLUTION //////////////////////////////
el_blockhead_t *el_shrink_block(el_blockhead_t *head, size_t newsize){
// Shrinks the size of the given block potentially creating a new block.  Computes remaining space
// as the difference between the current size and parameter newsize. If this is smaller than
// EL_BLOCK_OVERHEAD, does nothing further and returns NULL. Otherwise, reduces the size of the
// given block by adjusting its header and footer and establishes a new block above it with
// remaining space beyond the block overhead. Returns a pointer to the newly introduced blocks. Does
// not modify any links in lists.

  // NOTE: could simplify considerably using el_split_block()
  size_t remaining = head->size - newsize;
  if(remaining < EL_BLOCK_OVERHEAD){
    return NULL;
  }
  head->size = newsize;                       // adjust size
  el_blockfoot_t *foot = el_get_footer(head); // allows middle foot to be found
  foot->size = newsize;                       // set 

  el_blockhead_t *above_head = el_block_above(head); // new header location
  above_head->size = remaining - EL_BLOCK_OVERHEAD;  // set its size
  el_blockfoot_t *above_foot = el_get_footer(above_head); // should be old foot 
  above_foot->size = remaining - EL_BLOCK_OVERHEAD;       // set size
  return above_head;
}

int el_shrink(void *ptr, size_t newsize){
// Shrink the area associated with the given ptr if possible.  Checks to ensure that the block
// associated with the given user ptr is EL_USED and exits if not.  Uses el_shrink_block() to
// adjust the block size and create a block for the remaining space.  If not possible to shrink,
// returns 0.  Otherwise moves the current block to the front of the Used List and places the newly
// created block to the front of the Available List after setting its state to EL_AVAILABLE. Returns
// 1 on successfully shrinking.

  el_blockhead_t *head = PTR_MINUS_BYTES(ptr,sizeof(el_blockhead_t));
  if(head->state != EL_USED){              // error check
    printf("Does not appear to be a used block\n");
    exit(1);
  }
  el_blockhead_t *above = el_shrink_block(head, newsize);
  if(above == NULL){
    return 0;                               // could not shrink
  }
  above->state = EL_AVAILABLE;              // now available for use
  el_remove_block(el_ctl->used, head);      // out of used list
  el_add_block_front(el_ctl->used,  head);  // to front of used list
  el_add_block_front(el_ctl->avail, above); // to front of available list
  return 1;                                 // could shrink
  // likely want to attempt merging above with block above to limit fragmentation
  // in a full implementation of shrinking
}
