#include <stdio.h>

typedef double v2d __attribute__ ((vector_size (16)));

int main(){
  int len = 8;

  double vecA[len];
  double vecB[len];
  for(int i=0; i<len; i++){
    vecA[i] = i+10.0;
    vecB[i] = 100.0;
  }

  for(int i=0; i<len; i+=2){
    v2d a,b;
    a = *((v2d*) (vecA+i));
    b = *((v2d*) (vecB+i));
    a += b;
    *((v2d*) (vecA+i)) = a;
  }

  for(int i=0; i<len; i++){
    printf("vecA[%d]: %f\n",i,vecA[i]);
  }

  return 0;
}
