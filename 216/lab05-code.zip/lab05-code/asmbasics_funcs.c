// asmbasics_funcs.c: C implementations of some simple
// functions. These are written in a style that reflect how they will
// appear in x86-64 assembly.

// return the difference between arguments
int difference(int x, int y){
  int ans = x;
  ans -= y;
  return ans;
}

// return the square of the arguement
int squared(int x){
  int ans = x;
  ans *= ans;
  return ans;
}

// return the sum of the squares of the two arguments
int squared_sum(int x, int y){
  int ans = x;
  ans *= ans;
  y *= y;
  ans += y;
  return ans;
}
  
// return the difference of the squares of the two arguments
int squared_diff(int x, int y){
  int ans = x;
  ans *= ans;
  y *= y;
  ans -= y;
  return ans;
}
  
// return the twice the product of the arguements
int twice_product(int x, int y){
  int ans = x;
  ans *= y;
  ans *= 2;
  return ans;
}

// compute the difference between a^2+b^2-c^2
int pythagorean_diff(int a, int b, int c){
  int ans = a;
  ans *= ans;
  b *= b;
  ans += b;
  c *= c;
  ans -= c;
  return ans;
}

// ending function that returns a constant
int meaning_of_life(){
  int ans = 42;
  return ans;
}
  
