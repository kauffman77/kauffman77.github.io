// asmbasics_main.c: demonstrate Euclid's formula for determining
// triples of a^2+b^2=c^2 with integer values. Calls several functions
// which are written in both C and Assembly though the assembly
// versions require completion.

#include <stdio.h>
#include <stdlib.h>

int difference(int x, int y);
int squared(int x);
int squared_sum(int x, int y);
int squared_diff(int x, int y);
int twice_product(int x, int y);
int pythagorean_diff(int a, int b, int c);
int meaning_of_life();

int main(int argc, char *argv[]){
  printf("Let's explore Euclid's formula!\n");
  if(argc < 3){
    printf("provide two integers <m> <n> on the command line\n");
    return 1;
  }
  int m = atoi(argv[1]);
  int n = atoi(argv[2]);
  printf("Values are m: %d  n: %d\n",m,n);

  int diff = difference(m,n);
  if(diff < 1){
    printf("m must be greater than n\n");
    return 1;
  }

  int m2 = squared(m);
  int n2 = squared(n);
  printf("m^2: %d  n^2: %d\n",m2,n2);

  int c = squared_sum(m, n);
  printf("c = %d^2 + %d^2 = %d\n",m,n,c);
  int a = squared_diff(m, n);
  printf("a = %d^2 - %d^2 = %d\n",m,n,a);
  int b = twice_product(m, n);
  printf("b = 2 * %d * %d = %d\n",m,n,b);
  printf("According to Euclid, %d^2 + %d^2 = %d^2 = 0\n",a,b,c);
  printf("Let's check\n");
  int pdiff = pythagorean_diff(a,b,c);
  printf("%d^2 + %d^2 - %d^2 = %d\n",a,b,c,pdiff);
  if(pdiff == 0){
    printf("Euclid was right! What a chad <3\n");
  }
  else{
    printf("Wait? Math is broken?... Always has been (bang)\n");
  }
  return 0;
}
