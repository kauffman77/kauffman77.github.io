### Create a working version of the add2strs() function in assembly in
### this file.  It is recommended to start basing your code on the B
### version.

.text
.global add2strs
add2strs:
        ## Add 2 strings together by converting them to integers and
        ## summing those integers
        ## rdi is astr / rsi is bstr, strings to convert and add
        ret
