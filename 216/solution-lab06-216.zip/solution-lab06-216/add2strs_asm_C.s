### SOLUTION: working version of add2strs_asm() function

.text
.global add2strs
add2strs:
        ## rdi is astr / rsi is bstr, strings to convert and add
	pushq	%rbp            # need to save 2 pieces of data across a 
	pushq	%rbx            # function call AND align the stack for calls
	subq	$8, %rsp        # 24 bytes in stack + 8 for return = 32 bytes, aligned
	movq	%rsi, %rbp      # rbp is bstr, pointer to second string, callee save so preserved across function call
	call	convert         # call to convert rdi/astr to a number in eax
	movl	%eax, %ebx      # copy anum to ebx  to preserve across 2nd function call
	movq	%rbp, %rdi      # load bstr to 1st arg register
	call	convert         # convert to bstr to bnum
	addl	%ebx, %eax      # eax is now sum = anum+bnum
	addq	$8, %rsp        # restore the stack by shrinking it and
	popq	%rbx            # restore the callee save register used
	popq	%rbp            # MUST pop in the opposite order of push
	ret
