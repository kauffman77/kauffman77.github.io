### This file contains a very broken version of the add2strs()
### function which should be analyzed and compared to the B version in
### a different file.

.text
.global add2strs
add2strs:
        ## Add 2 strings together by converting them to integers and
        ## summing those integers
        ## rdi is astr / rsi is bstr, strings to convert and add
	subq	$8, %rsp        # 8 bytes in stack + 8 for return = 16 bytes, aligned
	call	convert         # call to convert rdi/astr to a number in eax
	movl	%eax, %edx      # copy anum to edx, will get bnum in eax on next call
	movq	%rsi, %rdi      # load bstr to 1st arg register
	call	convert         # convert to bstr to bnum
	addl	%edx, %eax      # eax is now sum = anum+bnum
	addq	$8, %rsp        # restore the stack by shrinking it and return
	ret
