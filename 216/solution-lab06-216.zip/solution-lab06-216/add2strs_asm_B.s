### This file contains a "better" version of the add2strs() function
### which is still broken. It should be compared to the A version and
### used as a basis to creat the completed C version.

.text
.global add2strs
add2strs:
        ## Add 2 strings together by converting them to integers and
        ## summing those integers
        ## rdi is astr / rsi is bstr, strings to convert and add
	subq	$8, %rsp        # 8 bytes in stack + 8 for return = 16 bytes, aligned
	movq	%rsi, %rbp      # rbp is now bstr, pointer to second string, callee save so preserved across function calls
	call	convert         # call to convert rdi/astr to a number in eax
	movl	%eax, %ebx      # copy anum to ebx (callee save) to preserve across 2nd function call
	movq	%rbp, %rdi      # load bstr to 1st arg register
	call	convert         # convert to bstr to bnum
	addl	%ebx, %eax      # eax is now sum = anum+bnum
	addq	$8, %rsp        # restore the stack by shrinking it and return
	ret
