.text
.global clobber_regs

### This function clobbers all caller-save registers which will cause
### problems for any function which improperly relies upon caller-save
### registers to stay the same across function call boundaries.
clobber_regs:
        movabsq $0xBADBADBADBADBADD, %rax
        ## movabsq $0xBADBADBADBADBADD, %rbx
        movabsq $0xBADBADBADBADBADD, %rcx
        movabsq $0xBADBADBADBADBADD, %rdx
        movabsq $0xBADBADBADBADBADD, %rsi
        movabsq $0xBADBADBADBADBADD, %rdi
        ## movabsq $0xBADBADBADBADBADD, %rsp
        ## movabsq $0xBADBADBADBADBADD, %rbp
        movabsq $0xBADBADBADBADBADD, %r8
        movabsq $0xBADBADBADBADBADD, %r9
        movabsq $0xBADBADBADBADBADD, %r10
        movabsq $0xBADBADBADBADBADD, %r11
        ## movabsq $0xBADBADBADBADBADD, %r12
        ## movabsq $0xBADBADBADBADBADD, %r13
        ## movabsq $0xBADBADBADBADBADD, %r14
        ## movabsq $0xBADBADBADBADBADD, %r15
        ret
