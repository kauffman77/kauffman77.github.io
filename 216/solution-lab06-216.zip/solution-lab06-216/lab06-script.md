Lab06 SCRIPT

# Mon PROBLEM 1: GDB on Binaries
- Let students Problem 1 concerns using GDB and other tools analyze a
  program where there is no source code available
- Indicate to students that program is comprised of
  - `quote_main.c` : the `main()` function which calls some other
    functions and uses data not defined in that file; it reads an
    `input.txt` which requires the correct number to be in it
  - `quote_data.o` : an object file (compiled binary) that has the
    functions and data of interest
- Indicate that the code tests are easy to get right via a guess and
  check approach and all student will have the same number in
  `input.txt` to pass
- BUT the point is to understand tools and techniques to analyze the
  binary in cases where it is not tractable to brute force / guess and
  check the answers which will be the case in Project 3
- Walk students through the QUESTIONS.txt QUIZ questions and show them
  how to use some tools like `nm` and `objdump` to show information
  from the binary `quote_data.o`
- Compile the program via `make` and then run it in GDB to show how
  stepping into the `get_it()` function leads to "No Source Available"
- Show how to switch to assembly mode via `layout asm` and show the
  registers via `layout regs` and rerun to show the disassembled code
- Indicate to students that GDB will show instructions in a slightly
  different format than students should write their assembly but it
  should be understandable
- Take some steps and show students how to navigate using `stepi` and
  `nexti` to advance through the assembly instructions
- Hint that there is a linked list at play and it's a good idea to
  study the code to see how traversing a linked list looks in assembly 
- Give students time to explore on their own; indicate that the code
  is compiled from C by GCC and so may contain some unfamiliar
  instructions - they do not need to understand EVERY instruction,
  just enough to make progress
- Encourage students to try to reconstruct how the C code might look
  with loops, conditions, variables; be on the look out for Nodes in
  the list, NULL checks, etc.
- End the lab by asking for techniques students they found useful
- Don't be afraid to give away the correct response which is 6 in
  `input.txt`; just reiterate that the point is to learn how one might
  GET this answer if it weren't easy to brute force try all
  possibilities

# Wed: Problem 2 addstrs (caller / callee registers)
- Bring up a copy of the x86-64 General Purpose Register diagram which
  shows registers as Blue "Caller Save" and Tan "Callee Save"
- Mention to students that this distinction will be important in this
  lab
- Tour the C `main()` function and the `convert()` function in
  `add2strs_main.c`; show that the assembly code is called by `main()`
  and in turn calls `convert()`
- The above means that the `add2strs()` function is both a Callee and
  a Caller
- Download the lab code and run `make` to produce the 3 executables
  - A : `add2strs_main_a` based on assembly `add2strs_asm_A.s`, buggy 
  - B : `add2strs_main_b` based on assembly `add2strs_asm_B.s`, buggy
  - C : `add2strs_main_a` based on assembly `add2strs_asm_C.s`, empty
- Run the A version via `./add2strs_main_a` and again under Valgrind
  to observe the Segfaults that result and answer the first few quiz
  questions
- Use `gdb add2strs_main_a` to step into the `add2strs()` function in
  the A version and show that many registers change after the `call
  convert` instruction; all the changed registers are Caller Save
  registers so the code in `add2strs()` is faulty as it assumes these
  registers will not change but they can and do
- Again run the B version via `./ad2strs_main_b` and again under
  Valgrind noting this time that the problems occur in `main()`
- Examine the code in `add2strs_asm_b.s` and illustrate from the
  comments that the intent is to use Callee save registers to preserve
  pointers / values across the function call boundary for `convert()`
- Use `gdb add2strs_main_b` to step through the function and show that
  using the callee save registers works to preserve data across the
  functino call boundary of `convet()` BUT on returning from
  `add2strs()`, `main()` also expects that registers like `%rbp` will
  not have changed - use the `layout asm` to show the assembly
  instructions associated with the C code in `main()`
- The problem now is to save/restore the Callee save registers use
  during `add2strs()`
- Let students work on a correct version in `add2strs_asm_c.s`; remind
  them about the push/pop instructions and also that stack alignment
  is still needed (not aligning the stack may work fine on Grace but
  fail on other machines like Gradescope)
  
