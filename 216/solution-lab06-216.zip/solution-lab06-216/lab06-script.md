# Lab06 Script

# Mon
- Mention that it is wise to configure editors to do assembly syntax
  highlighting; video linked in "Associated Reading" section on how
  to configure VS Code: https://www.youtube.com/watch?v=AgmXUFOEgIw
- Quickly survey `coins_funcs.c` which has C versions of the two
  function which will be coded in assembly
- Discuss the "algorithm" used in both cases to compute the coins
  needed for a given total cents
- Point out especially the prototype differences in functions
  ```c
  int set_coins(int cents, coins_t *coins);
  // pointer to a coins_t

  int total_coins(coins_t coins);
  // actual coins_t struct
  ```
- Show how to compile and test via `make` and point out that 2
  executables are created
  ```sh
  >> make
  gcc -Wall -Werror -g  -o coins_main coins_main.c coins_funcs_asm.s
  gcc -Wall -Werror -g  -o coins_main_c_only coins_main.c coins_funcs.c
  ```
  One has only C code involved; the other has a mixture of C (main)
  and assembly (funcs)
- Walk through provided assembly code for `set_coins()` in
  `coins_funcs_asm.s` and compare to `coins_funcs.c`
- Indicate to students that the function takes arguments and they are
  present in specific registers in assembly, arg 1 is in %rdi
- Show the diagram of registers to give context to functions receiving
  register arugments
- Discuss briefly the syntax 
  ```asm
  movb    %al,0(%rsi)     # coins->quarters = cents / 25
  ```
  with Parentheses around the register and mention that this treats
  the register contents as a memory address to write to
- Draw attention to the table in `coins.h` of the byte-offsets for
  fields of the `coins_t` struct, needed to complete the code
- Give students time to work on BLOCK C which they must complete
- OPTIONAL if time: show use of GDB on coins_main program to observe
  what is happening internally in the assembly functions; try running
  
# Wed
- Review quickly the context: coding functions in x86-64 Assembly to
  behave like existing C functions; partially complete and just need
  to fill in remaining parts
- CAUTION students that it is easy to copy-paste-complete but the
  purpose it get acquainted with register, assembly syntax, GDB usage,
  etc. 
- Demo a GDB session on ac completed assembly version of the first
  function
  ```sh
  >> gdb coins_main            # start GDB on C/Assembly version
  GNU gdb (GDB) 16.2
  
  (gdb) break set_coins        # stop on reaching assembly function
  Breakpoint 1 at 0x1303: file coins_funcs_asm.s, line 15.
  
  (gdb) set args 83            # set the command line arg to 83 cents
  
  (gdb) run                    # run program
  Starting program: 
  Breakpoint 1, set_coins () at coins_funcs_asm.s:15
  15	        cmpl    $99,%edi        # Describe this block

  (gdb) layout regs            # show the register file

  (gdb) stepi                  # step single instruction     
  ```
- Move on to discuss `total_coins()` in assembly, contrast existing
  portion with the C version, walks through provided code.
- Contrast the arguments between 2 functions AGAIN to emphasize the
  difference between a POINTER to a struct (1st func) and a PACKED
  STRUCT arg (2nd func)
- Show coins.h which shows the bit layout of the register: which
  fields are in which registers - different from the byte offsets
- Point out the shifting of data in registers along with Masking with
  0xFF pattern to extract a single field
- Give time for students to work on BLOCK D which they must complete
