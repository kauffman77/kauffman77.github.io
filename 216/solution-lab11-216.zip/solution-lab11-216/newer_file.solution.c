#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sysmacros.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>

// returns difference in times between a-b; positive return means a is
// newer than b; negative indicates b is newer than a
long diff_timespec(struct timespec a, struct timespec b){
  long diff = a.tv_sec - b.tv_sec;
  if(diff != 0){
    return diff;
  }
  diff = a.tv_nsec - b.tv_nsec;
  return diff;
}

int main(int argc, char *argv[]) {
  if (argc < 3) {
    fprintf(stderr, "Usage: %s <file1> <file2>\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  char *file1 = argv[1];
  char *file2 = argv[2];

  // TODO: check that file1 and file2 both exist. If one of the
  // following situatinos arises, print an appropriate message and
  // exit with code 1.
  // 
  // Both FILE1 and FILE2 cannot be accessed
  // FILE1 cannot be accessed
  // FILE2 cannot be accessed
  //
  // Replace FILE1/FILE2 with the names of the files
  int file1_exists = access(file1, F_OK)==0;
  int file2_exists = access(file2, F_OK)==0;
  if(!file1_exists && !file2_exists){
    printf("Both %s and %s cannot be accessed\n",file1,file2);
    return 1;
  }
  else if(!file1_exists){
    printf("%s cannot be accessed\n",file1);
    return 1;
  }
  else if(!file2_exists){
    printf("%s cannot be accessed\n",file2);
    return 1;
  }

  // both files exist, compare times

  // TODO: Call stat() on each file and extract their `st_mtim` field
  // which is a `struct timespec` indicating the last modification
  // time for the file. Pass these two to the provided diff_timespec()
  // function and use the result to print a message according the
  // following situations.
  //
  // FILE1 and FILE2 are EQUAL in age
  // FILE1 is OLDER than FILE2
  // FILE1 is NEWER than FILE2
  struct stat sb;
  stat(file1, &sb);
  struct timespec file1_mtime = sb.st_mtim; // file1 modfication time
  stat(file2, &sb);
  struct timespec file2_mtime = sb.st_mtim; // file2 modification time
  long diff = diff_timespec(file1_mtime,file2_mtime);
  if(diff > 0){
    printf("%s is NEWER than %s\n",file1,file2);
  }
  else if(diff < 0){
    printf("%s is OLDER than %s\n",file1,file2);
  }
  else{
    printf("%s and %s are EQUAL in age\n",file1,file2);
  }

  return 0;
}
