# Mon : Makefiles
- Announce to students that this lab will involve performance timing
  and they will need to evaluate their code speed on
  grace-aws.umd.edu : a special grace node which will provide
  reasonably stable timing results

- Students can log in like normal grace nodes by changing the machine name:
  ```
  ssh DIRECTORYID@grace-aws.umd.edu
  ```

- No changes need to be made for any configuration files, just the SSH
  into a node for an interactive session; all files on "normal" grace
  are shared with the AWS timing node
  
- Walk students through analyzing matrix/vector code
  - vector_t which has a one-dimensional array as the data
  - matrix_t which also has a one-dimensional array for the data but
    uses Macros to access elements
  - Tour these types in matvec.h

- Indicate to students that they will use the same basic setup for the
  upcoming Project 5 which will also feature optimization 
  
- Walk students through the functions in matsums_funcs.c
  - row_sums() which produces a vector of all row sums
  - col_sums() which does the same but for columns
  - opt_col_sums(), incomplete and will be finished by students

- Ask students about the overall complexity of the row vs col sums,
  how many total addition operations are needed: the same for both,
  O(R*C), so they should theoretically have the same overall runtime
  
- Have students compile and run the matsums_main.c program and enter
  some test sizes to observe speed
  
- Coach students that times lower than 0.01 seconds CANNOT BE TRUSTED
  as the clock resolution on most systems isn't fine enough to be
  reliable; times at about 1s are easily trustable so try parameters
  that get the longest time to about 1 second

- On grace-aws.umd.edu a common run is
```
[grace-aws]% ./matsums_main 5000 16384                                                                                                          
      row_sums CPU usage:     0.0690 sec                                                                                                                                  
      col_sums CPU usage:     0.9717 sec                                                                                                                                  
```

- Ask students to consider why the results differ between the Row vs
  Column approaches so much; consider drawing a small diagram of how
  rows and columns lay out in the one-dimensional data[] array of
  matrices to show the stride induced by going "down" a column
  
- Indicate to students that they will need to find a way to compute
  the column sums while going across rows rather than down columns to
  get better cache performance; suggest to students "partial sums"
  where each row contributes to the overall column sum and when all
  rows are have been visited, the column sums are finished
