# Mon : Makefiles
- Discuss basic syntax surveyed in lab HTML specificaion
- Discuss examples provided in subdirectories
  - lab10-code/demo-makefile-little/Makefile : simplest version for
    small project
  - lab10-code/demo-makefile-little/Makefile-shortcuts : introduces
    variables and patter rules (optional)
  - lab10-code/demo-makefile-big/Makefile : larger version, verbose as
    it doesn't use any shortcuts
  - lab10-code/demo-makefile-little/Makefile-shortcuts : good use of
    variables and pattern rules to make the Makefile shorter
- Direct students to complete the provided template in
  prob1-makefile/Makefile
- Possibly discuss the @ syntax which will omit printing commands
  being run by the Makefile; example
```makefile
targ1 :
   echo "hello world"

targ2 :
   @echo "hello world"
```
Shell run:
```shell
>> make targ1
echo "hello world"    # prints command to be run
hello world           # prints output of comand

>> make targ2
hello world           # @ omits printing command, only output shown
```  
NOTE: Keep an eye on automated tests; they are a bit tricky to write
for Makefiles

# Wed : Structs and Memory Stride
- Students will have discussed cache memory and the benefit of
  accessing memory in a sequential fashion without strides during
  lecture
- Students will also have seen the clock function so should know the
  basics of timing code
- Walk briefly through the content on clock() in the lab11.html
  document to orient students on its use, use ~clock_demo.c~ as a
  concrete example: compile and run it to show times
- Warn students that when examining times, time values LESS THAN
  0.001s ARE NOT RELIABLE in most cases and ON GRACE TIMES LESS THAN
  1.000s are usually unreliable (GRACE has poor time resolution)
- Runs the ~clock_demo~ program with several parameters to show how it
  reports time
```shell
>> ./clock_demo
usage: ./clock_demo <arrlen> <repeats>
>> ./clock_demo 100 100
Summing array length 100 with 100 repeats, ascending
Summing array length 100 with 100 repeats, descending
method:  sum ascending CPU time: 3.4000e-05 sec   sum: 4950
method: sum descending CPU time: 3.1000e-05 sec   sum: 4950
>> ./clock_demo 100 10000
Summing array length 100 with 10000 repeats, ascending
Summing array length 100 with 10000 repeats, descending
method:  sum ascending CPU time: 2.7670e-03 sec   sum: 4950
method: sum descending CPU time: 2.7890e-03 sec   sum: 4950
>> ./clock_demo 10000 1000
Summing array length 10000 with 1000 repeats, ascending
Summing array length 10000 with 1000 repeats, descending
method:  sum ascending CPU time: 2.5740e-02 sec   sum: 49995000
method: sum descending CPU time: 2.5551e-02 sec   sum: 49995000
>> ./clock_demo 100000 1000
Summing array length 100000 with 1000 repeats, ascending
Summing array length 100000 with 1000 repeats, descending
method:  sum ascending CPU time: 1.7423e-01 sec   sum: 704982704
method: sum descending CPU time: 8.3510e-02 sec   sum: 704982704
```
- Indicate to students that they will be measuring time in the
  ~struct_stride.c~ program for several different blocks of code
- Give students some time to fill in clock() calls for the TODO
  sections to complete the CODE portion of the lab
- Demonstrate your own runs of this code to show timing which will
  answer the first QUIZ question
- Discuss with students the remaining QUIZ questions which offer
  explanations for the relative speeds
- Pay particular attention to the varying struct layout
  - int_field_t: places data in an a/b/a/b pattern
  - arr_field_t: places data in an aaa/bbb pattern
- Help students to understand that that the memory layout along with
  the order it is visited in affects performance 
