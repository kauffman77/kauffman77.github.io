// UNDOCUMENTED EXAMPLE
// buffered_outpu_input.c: Demonstrate that full buffering can make
// output/input trickier: the prompt will not display under full
// buffering 
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define BUFSIZE 64


int main(int argc, char *argv[]){
  char *msg;
  char outbuf[BUFSIZE] = {};
  msg = "0. Enabling full I/O buffering of stdout\n";
  write(STDOUT_FILENO, msg, strlen(msg));
  setvbuf(stdout, outbuf, _IOFBF, BUFSIZE); // set full "block" buffering for stdout
  // setvbuf(stdout, outbuf, _IOLBF, 1024); // set line buffering for stdout

  fprintf(stdout,"A. Here is a message\n");  // some of these messages won't actually be printed
  fprintf(stdout,"B. And some more text\n"); // yet as they are buffered in outbuf
  fprintf(stdout,"C. With a final message\n");

  msg = "3. write() bypasses C's standard I/O buffers\n";
  write(STDOUT_FILENO, msg, strlen(msg));
  msg = "4. Contents of the outbuf:\n";
  write(STDOUT_FILENO, msg, strlen(msg));
  write(STDOUT_FILENO, outbuf, BUFSIZE);
  msg = "\n5. Flushing standard output\n";
  write(STDOUT_FILENO, msg, strlen(msg));
  fflush(stdout);
  
  return 0;
}

// char *msg = "Enter number: ";
// int len = strlen(msg);
// for(int i=0; i<len; i++){
//   fputc(msg[i],stdout);
// }
