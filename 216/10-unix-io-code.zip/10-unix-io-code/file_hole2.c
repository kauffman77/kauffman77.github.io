// file_hole2.c: Continues manipulating a file via lseek() and
// ftruncate().
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

int main(void) {
  int flags = O_WRONLY;
  mode_t perms = S_IRUSR | S_IWUSR;
  int fd = open("holey.txt", flags,perms);
  lseek(fd,  20, SEEK_SET);          // offset now = 20
  char buf1[] = "ZYXW";
  write(fd, buf1, strlen(buf1));     // write data from 30-39
  ftruncate(fd, 55);                 // change the file size to 55 (shrink)
  close(fd);
  exit(0);
}

