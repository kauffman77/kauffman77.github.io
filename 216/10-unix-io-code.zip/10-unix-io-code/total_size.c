// total_size.c: Solution to in-class exercise. Uses combination of
// readdir() and lstat() total the size in bytes of all regular files
// in a directory.

#include <dirent.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>

int main(int argc, char *argv[]){
  size_t total_size = 0;        // total size in bytes of all regular files
  DIR *dir = opendir(".");      // open the current directory
  while(1){                     // read through all files in directory
    struct dirent *file = readdir(dir);
    if(file == NULL){           // if no more files, break
      break;
    }
    struct stat sb;
    lstat(file->d_name, &sb);   // get stats on file including link info
    if(S_ISREG(sb.st_mode)){    // only sum up regular files
      printf("%8lu %s\n",       // print file info
             sb.st_size, file->d_name);
      total_size += sb.st_size; // add to total size
    }
    else{                       // skip directories, symlinks, etc.
      printf("%-8s %s\n", "SKIP", file->d_name);
    }
  }
  closedir(dir);                // done with directory, print toal
  printf("==================\n");
  printf("%8lu total bytes from REGULAR files\n",
         total_size);
  return 0;
}
