// write_then_read.c: Basic demonstration of writing data to a file
// the reading it back using open(), close(), read(), write().
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define BUFSIZE 128

int main(int argc, char *argv[]){
  char *outfile = "existing.txt";         
  printf("0. Recreating empty existing.txt\n");
  system("echo '' > existing.txt");                     // ensures existing.txt present, empty initially

  printf("1. Opening file %s for writing\n",outfile);
  int out_fd = open(outfile,O_WRONLY);                  // open for writing, must exist 
  if(out_fd == -1){                                     // check result and fail if not opened
    perror("Couldn't open output file");
    exit(1);
  }

  printf("2. Writing to file %s\n",outfile);
  char outbuf[BUFSIZE] = "here is some text to write\0\0\0hello\0"; // what to write

  int bytes_written = write(out_fd, outbuf, BUFSIZE);   // do th write
  if(bytes_written == -1){                              // check for errors
    perror("Failed to write to file");
    exit(1);
  }
  printf("3. Wrote %d bytes to %s\n",bytes_written,outfile);

  if(close(out_fd) == -1){                              // check for errors on close
    perror("Couldn't close file");
    exit(1);
  }
  
  printf("4. Opening %s for reading\n",outfile);
  int in_fd = open(outfile,O_RDONLY);                   // open file for reading
  if(in_fd == -1){                                      // check result and fail if not opened
    perror("Couldn't open file");
    exit(1);
  }

  printf("5. Reading up to %d bytes from %s\n",BUFSIZE-1,outfile);
  char inbuf[BUFSIZE];                                  // someplace to read into
  int bytes_read = read(in_fd, inbuf, BUFSIZE-1);       // read from file, max BUFSIZE
  if(bytes_read == -1){                                 // check for errors
    perror("Failed to read from file");
    exit(1);
  }

  inbuf[bytes_read] = '\0';                               // null terminate string
  printf("6. Read %d chars, printf()'ing:\n",bytes_read); // print bytes read
  printf("%s\n", inbuf);                                  // printf what was read

  printf("7. printf()'ing %d characters individually\n",bytes_read);
  for(int i=0; i<BUFSIZE; i++){
    if(inbuf[i] == '\0'){
      printf("\\0");
    }
    else{
      printf("%c",inbuf[i]);
    }
  }
  printf("\n");

  printf("8. write()'ing %d characters to screen\n",bytes_read);
  write(STDOUT_FILENO, inbuf, BUFSIZE);

  int result = close(in_fd);
  if(result == -1){
    perror("Failed to close file");
    exit(1);
  }

  printf("\n\n");
  return 0;
}
