#include <stdio.h>
void func_12(){
  printf("Calling function func_12\n");
}
