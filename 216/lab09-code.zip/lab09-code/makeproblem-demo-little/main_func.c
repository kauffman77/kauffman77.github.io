#include <stdio.h>
#include "funcs.h"
int main(int argc, char *argv[]){
  // call various library functions
  func_01();
  printf("all done\n");
  return 0;
}
