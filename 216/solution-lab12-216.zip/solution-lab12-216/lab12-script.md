# Mon
- Review the file `example_matsums_funcs.c` which is the solution to
  HW11 on optimizing a column sum operation for a matrix
- Mention that the data structures in use like `matrix_t` and
  `vector_t` will be used again for this lab and the project
- Point out the use of macros like `VSET(vec,i)` and `MGET(mat,i,j)`
  to ensure students are acquainted with them
- Put the functions `col_sums_A()` and `col_sums_B()` on a screen and
  ask students to indicate which will be faster and justify this
- Emphasize to students that the difference between the routines is
  the order in which memory is visited with `col_sums_B()`
  benefiting much more from cache memory because it does not have a
  stride in its memory access pattern
- Indicate that the lab problem STARTS with something like
  `col_sums_B()` and will make it go even faster with multiple
  threads BUT using multiple threads with the un-optimized
  `col_sums_A()` version would likely get little benefit
- Introduce the idea of threads, similar to processes created via
  fork() BUT with memory shared between main/worker thread that is
  created. 
- Utilize "Basic Overview of Threads" material in lab web page which
  divides solving a problem with threaded programming into 4 parts
  1. Main thread Creating threads
  2. Worker threads that start in a function and operate on shared
     data
  3. Coordination of worker threads via a mutex
  4. Main thread blocks until all worker threads complete
- Take students on a survey of the template that is provided in
  `csums_threaded_funcs.c` 
- Discuss `col_sums_threaded()` which contains some TODO parts; talk
  through the general flow of the threaded implementation
  - Perform setup
  - Create Threads
  - Wait for Threads to complete
- Point out use of the `pthread_create()` function and show students
  the `pthread_join()` function; both of these answer some QUIZ
  questions

# Wed
- Remind students that the goal for this use of threads is to improve
  performance over the serial (single-threaded) version; threads can
  achieve higher performance because they can be run in parallel
- Show students the prototype for `col_sums_worker()` which needs
  "context", data to operate on which must be set up in the
  `col_sums_threaded()` before the thread starts
- Point out that each worker thread iterates over only PART of the
  matrix and then adds on to its portion; this is the potential source
  of speed
```c
  // serial version: all rows
  for(int i=0; i<mat.rows; i++){

  // threaded version: only some rows
  for(int i=beg_row; i<end_row; i++){

```
- Coach students through the use of the Mutex: `pthread_mutex_lock() /
  _unlock()` to lock and unlock to guarantee exclusive access to
  vec.data[]
- Indicate to students that this is a system call, an ask to the OS to
  block if the mutex is currently assigned to another thread
- Indicate that many times the code would work without the lock/unlock
  BUT occasionally it will produce incorrect results if two threads
  simultaneously try to add on to the same data (will demo this in
  lecture)
- Demonstrate to students the timing results for correctly implemented
  threaded code pointing out speedup. Will likely not be quite 2X for
  2 threads and significantly below 4X for 4 threads but this is
  expected.
```c
>> ./csums_thread_main 20000 10000 2
col_sums_single wall time: 2.8336e-01 sec
col_sum_threaded wall time: 1.7020e-01 sec
2 threads speedup: 1.66

>> ./csums_thread_main 20000 10000 4
col_sums_single wall time: 2.7103e-01 sec
col_sum_threaded wall time: 1.0022e-01 sec
4 threads speedup: 2.70
```
