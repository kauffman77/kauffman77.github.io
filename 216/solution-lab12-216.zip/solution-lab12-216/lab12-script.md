Lab12 Script
# Mon: mapped array via mmap()
- Indicate to students that they will be studying a system call named
  mmap() which is how programs create their stack, heap, and other
  regions of memory; students will use it here and in the final
  project to create their own heap / malloc() implementation
- mmap() is a direct ask for memory from the operating system NOT
  associated with malloc() or other allocation techniques and can be
  used in special situations where user programs want more control
  over the layout of memory allocated for them
- Study the first provided function in `mapped_array.c` called
  `mapped_init()` which initializes an array with space gotten
  directly from the OS via a call to `mmap()` 
- Outline how the operating system will allocate memory in chunks
  called pages which are typically 4096 bytes; smaller chunks are NOT
  possible to allocate so there are usually bytes "left over" at the
  ends of pages that are not out of bounds from the OS perspective but
  are not a logical part of the data structures
- Specific addresses can be requested from the OS to map pages but the
  OS may fail or return a different address so checking the returned
  address is necessary
- Help students to complete the TODO portions in the `mapped_resize()`
  function which a slight variation on the first function
- Pay careful attention to the pointer arithmetic to calculate where
  new pages should be mapped to allow expansion of an array: this
  should happen via either `(char *)` or `(void *)` pointers so that
  calculations are done in bytes, NOT `(int *)` which will scale by 4
  bytes and lead to incorrect results
- As students complete the code, walk through the quiz questions with
  them to ensure they understand that requests at specific addresses
  can succeed or fail due to space being available or not available
  due to conflicts at higher addresses in a region to be mapped
  
# Wed
- Review the file `example_matsums_funcs.c` which is the solution to
  Lab11 on optimizing a column sum operation for a matrix
- Mention that the data structures in use like `matrix_t` and
  `vector_t` will be used again for this lab and the project so use of
  macros like `VSET(vec,i)` and `MGET(mat,i,j)` are necessary
- Put the functions `col_sums_A()` and `col_sums_B()` on a screen and
  ask students to indicate which will be faster and justify this;
  Emphasize the difference between the routines is the order in which
  memory is visited with `col_sums_B()` benefiting much more from
  cache memory because it does not have a stride in its memory access
  pattern
- Indicate that the goal of this problem is to speed up column sums
  calculation further over the `col_sums_B()` version by utilizing
  multiple processors through **threads**
- Introduce the idea of threads, similar to processes created via
  fork() BUT with memory shared between main/worker thread that is
  created. 
- Utilize "Basic Overview of Threads" material in lab web page which
  divides solving a problem with threaded programming into 4 parts
  1. Main thread Creating threads
  2. Worker threads that start in a function and operate on shared
     data
  3. Coordination of worker threads via a mutex
  4. Main thread blocks until all worker threads complete
- Take students on a survey of the template that is provided in
  `csums_threaded_funcs.c` 
- Discuss `col_sums_threaded()` which contains some TODO parts; talk
  through the general flow of the threaded implementation relating
  them previous concepts like `fork()` and `wait()`
  - Perform setup
  - Create Threads via `pthread_create()`
  - Wait for Threads to complete `pthread_join()`
- Show students the prototype for `col_sums_worker()` which needs
  "context", data to operate on which must be set up in the
  `col_sums_threaded()` before the thread starts
- Point out that each worker thread iterates over only PART of the
  matrix and then adds on to its portion; this is the potential source
  of speed
```c
  // serial version: all rows
  for(int i=0; i<mat.rows; i++){

  // threaded version: only some rows
  for(int i=beg_row; i<end_row; i++){

```
- Coach students through the use of the Mutex: `pthread_mutex_lock() /
  _unlock()` to lock and unlock to guarantee exclusive access to
  vec.data[]
- Indicate to students that this is a system call, an ask to the OS to
  block if the mutex is currently assigned to another thread
- Indicate that many times the code would work without the lock/unlock
  BUT occasionally it will produce incorrect results if two threads
  simultaneously try to add on to the same data (will demo this in
  lecture)
- Demonstrate to students the timing results for correctly implemented
  threaded code pointing out speedup. Will likely not be quite 2X for
  2 threads and significantly below 4X for 4 threads but this is
  expected.
```c
>> ./csums_thread_main 20000 10000 2
col_sums_single wall time: 2.8336e-01 sec
col_sum_threaded wall time: 1.7020e-01 sec
2 threads speedup: 1.66

>> ./csums_thread_main 20000 10000 4
col_sums_single wall time: 2.7103e-01 sec
col_sum_threaded wall time: 1.0022e-01 sec
4 threads speedup: 2.70
```
