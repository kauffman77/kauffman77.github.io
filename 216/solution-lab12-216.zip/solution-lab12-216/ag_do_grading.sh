#!/bin/bash

export SHELL=/bin/bash
export COLUMNS=126
# export PATH=/autograder/source:$PATH
/autograder/source/ag_merge_json.awk < /dev/null > results.json    # Empty results initially

search_file="QUESTIONS.txt"     # file to help locate submission working directory

workdir=$(dirname "$(find /autograder/submission -name "$search_file" | head -1)")

if [ -z "$workdir" ]; then
    printf "Could not find '%s' in below submission\n" "$search_file"
    find /autograder/submission
    printf "Check that submission is not EMPTY\n"
    printf "Bailing out\n"
    exit 1
fi

echo Changing to working directory "$workdir"
cd "$workdir"

echo Copying testing files 
cp /autograder/source/test_* .   # testing scripts/data
cp /autograder/source/testy  .   # testing scripts/data
cp /autograder/source/ag_* .     # autograder files
cp /autograder/source/Makefile . # makefile
chmod u+x test_* ag_* testy
mkdir -p ag-results               # ensure ag-results directory is present

echo Cleaning old test files
make clean
make clean-tests

echo Running tests

# NOTE: ag_test2json.awk will pick up the name, score, and max_score
# from output BUT if the generating command fails, these may be
# missing. To prevent blank output, specify these as parameters to the
# script as well which will ensure that they are part of the output.

#export TIMEOUT=1s 
NAME="Lab Tests"
{
    SHOWFAIL=1 make test
} >& ag-results/p1.tmp
./ag_test2json.awk  -vname="$NAME" -vmax_score=1 ag-results/p1.tmp > ag-results/p1.json

echo Finished testing

echo Merging results of tests
./ag_merge_json.awk ag-results/*.json > results.json

echo Copying test results to Gradescope
cp ./results.json /autograder/results/results.json

echo Done
