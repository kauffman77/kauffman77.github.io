#!/usr/bin/env bash

# Gradescope docker instance setup script

apt-get -y install build-essential gcc valgrind gdb gawk zip tmux screen w3m libssl-dev file locales

# Set the default locale; needed for sorting order of `ls` and
# such. Normally this would be done in setup and is part of dpkg but
# the below does the trick in simple, non-interactive setups
# https://serverfault.com/questions/362903/how-do-you-set-a-locale-non-interactively-on-debian-ubuntu
locale-gen en_US.UTF-8
update-locale LANG=en_US.UTF-8 LC_MESSAGES=POSIX LC_ALL=en_US.UTF-8
# echo -e 'LANG="en_US.UTF-8"\nLANGUAGE="en_US:en"\n' > /etc/default/locale
