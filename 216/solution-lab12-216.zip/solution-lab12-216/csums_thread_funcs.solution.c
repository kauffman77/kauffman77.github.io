// csums_thread_funcs.c: Template to fill in for multi-threaded column
// sums. //////////////////// SOLUTION ////////////////////

#include "csums_thread.h"

// col_sums_B() from example_matsums_funcs.c: optimized version of
// column summing which uses a cache-friendly memory access pattern to
// sum the columns. Can only use a single thread for the computation.
int col_sums_single(matrix_t mat, vector_t csums){
  if(mat.cols != csums.len){
    printf("size mismatch: mat.cols %ld != csums.len %ld\n",
           mat.cols,csums.len);
    return 1;
  }

  for(int j=0; j<csums.len; j++){
    VSET(csums,j,0);
  }

  for(int i=0; i<mat.rows; i++){
    for(int j=0; j<mat.cols; j++){
      int sum = VGET(csums,j) + MGET(mat,i,j);
      VSET(csums,j,sum);
    }
  }
  return 0;
}

// context struct for thread workers to cooperate on column sums
typedef struct {
  int thread_id;                // logical id of thread, 0,1,2,...
  int thread_count;             // total threads working on summing
  matrix_t mat;                 // matrix to sum
  vector_t vec;                 // vector to place sums
  pthread_mutex_t *vec_lock;    // mutex to lock the vec before adding on results
} colsums_context_t;


// worker thread defined below
void *col_sums_worker(void *arg);

// entry point for column summing using threads; creates a
// thread_count() threads that run the function col_sums_worker()
int col_sums_threaded(matrix_t mat, vector_t csums, int thread_count){
  if(mat.cols != csums.len){
    printf("size mismatch: mat.cols %ld != csums.len %ld\n",
           mat.cols,csums.len);
    return 1;
  }

  // initialize the shared results vector
  for(int j=0; j<csums.len; j++){
    VSET(csums,j,0);
  }

  // init a mutex to be used for threads to add on their local results
  pthread_mutex_t vec_lock;
  pthread_mutex_init(&vec_lock, NULL);

  pthread_t threads[thread_count];           // track each thread
  colsums_context_t ctxs[thread_count];      // context for each trhead

  // loop to create threads
  for(int i=0; i<thread_count; i++){

    // TODO: fill field values for the context to pass to threads;
    // thread IDs are 0,1,2,... and are used to determine which part
    // of the matrix to operate on. The remaining data are copies of
    // local data that enable the thread to "see" the matrix and
    // vector as well as utilize the mutex for coordination.

    ctxs[i].thread_id = i;                   // set up the context: thread_id and 
    ctxs[i].thread_count = thread_count;     // locals to this function housed in 
    ctxs[i].mat = mat;                       // a struct
    ctxs[i].vec = csums;
    ctxs[i].vec_lock = &vec_lock;            // pass pointer to the same lock for all threads
    
    // Loop to create the threads
    pthread_create(&threads[i], NULL,        // start worker thread to compute part of answer
                   col_sums_worker,
                   &ctxs[i]);
  }
  
  // TODO: use a loop to join the threads
  for(int i=0; i<thread_count; i++){          // wait for each thread to finish
    pthread_join(threads[i], NULL);
  }

  pthread_mutex_destroy(&vec_lock);          // get rid of the lock to avoid a memory leak
  return 0;
}

// worker function which will compute partial sums of matrix columns
// and add them on
void *col_sums_worker(void *arg){
  // extract the parameters / "context" via a caste
  colsums_context_t ctx = *((colsums_context_t *) arg);

  // extract the matrix and vector for the parameter context struct
  matrix_t mat = ctx.mat;
  vector_t vec = ctx.vec;

  // calculate how much work this thread should do and where its
  // begin/end rows are located. Leftover rows are handled by the last
  // thread.
  int rows_per_thread = mat.rows / ctx.thread_count;
  int beg_row = rows_per_thread * ctx.thread_id;
  int end_row = rows_per_thread * (ctx.thread_id+1);
  if(ctx.thread_id == ctx.thread_count-1){
    end_row = mat.rows;
  }
  
  // allocate memory for the thread to locally compute its results
  // avoiding the need to lock a mutex every time it adds.
  int *local_vec = malloc(sizeof(int) * vec.len);
  //  memset(local_vec, 0, sizeof(int)*vec.len);
  for(int i=0; i<vec.len; i++){
    local_vec[i] = 0;
  }

  // iterate over the matrix adding column elements to the local sum
  for(int i=beg_row; i<end_row; i++){
    for(int j=0; j<mat.cols; j++){
      local_vec[j] += MGET(mat, i, j);

      // CORRECT BUT INEFFICIENT
      // pthread_mutex_lock(ctx.vec_lock);
      // VSET(vec, VGET(vec,j) + el_ij);
      // pthread_mutex_lock(ctx.vec_lock);
    }
  }

  // TODO: lock the mutex to get controlled access to the shared
  // results vector and add on the local sum; locking prevents
  // multiple threads from simultaenously modifying the results which
  // may corrupt them.
  pthread_mutex_lock(ctx.vec_lock);

  // TODO: Add on the local results to the shared vec in a loop
  for(int i=0; i<vec.len; i++){
    VSET(vec, i, VGET(vec,i) + local_vec[i]);
  }

  // TODO: Unlock the mutex
  pthread_mutex_unlock(ctx.vec_lock);

  // free the local vector before ending
  free(local_vec);
  return NULL;
}

