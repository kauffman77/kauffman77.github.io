### return_seven_asm_buggy.s: illustrates a problem that can arise if
### stack is not restored before ret instruction
### 
### COMPILE:
### > gcc -g return_seven_asm_buggy.s 
        
.text
.global return_seven
return_seven:
	pushq   $0x42                   # push but no pop before returning
        movl    $7, %eax
        ret                             # %rsp points to a 0x42 return address
        
.global main
main:                                   # main() function
        subq    $8, %rsp                # grow stack by 8 bytes, space uninitialized
	
	call    return_seven            # call function, 1st return location
	
	leaq    .FORMAT_1(%rip), %rdi   # load address of format string, 1st arg to printf()
        movl    %eax, %esi              # 2nd arg to printf
        movl    $0, %eax                # no vector regs used for variadic printf()
        call    printf@PLT              # call printf
	
	call    return_seven            # call function 2nd return location
	
	leaq    .FORMAT_2(%rip), %rdi   # load address of format string, 1st arg to printf()
        movl    %eax, %esi              # 2nd arg to printf
        movl    $0, %eax                # no vector regs used for variadic printf()
        call    printf@PLT              # call printf
	
        addq    $8, %rsp                # Shrink stack by 8 bytes to undo earlier pushq
        movl    $0, %eax                # set return value
        ret
.data                           
.FORMAT_1:
        .asciz "first:  %d\n"           # format strings used by printf
.FORMAT_2:
        .asciz "second: %d\n"
        
