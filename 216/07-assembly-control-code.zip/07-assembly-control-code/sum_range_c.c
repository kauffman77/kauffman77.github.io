// sumrange_c.c: C version of assembly example. Several calls to the
// sumrange() function require values to be saved across function
// calls. Assembly version shows use of callee save registers to
// accomplish this.
#include <stdio.h>
int sum_range(int start, int stop){
  int sum = 0;
  for(int i=start; i<=stop; i++){
    sum += i;
  }
  return sum;
}

int main(){
  int sum1 = sum_range(1,5);
  int sum2 = sum_range(10,15);
  int sum3 = sum_range(20,25);
  int tot = sum1+sum2+sum3;

  printf("total: %d\n",tot);
  return tot;
}
