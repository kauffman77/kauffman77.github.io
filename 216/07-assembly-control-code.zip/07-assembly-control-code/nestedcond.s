	.file	"nestedcond.c"
	.text
	.globl	nested_conds
	.type	nested_conds, @function
nested_conds:
.LFB0:
	.cfi_startproc
	testl	%edi, %edi
	jle	.L2
	cmpl	$499, %esi
	jbe	.L4
	movl	$111, %eax
	ret
.L2:
	testl	%esi, %esi
	jne	.L5
	movl	$333, %eax
	ret
.L4:
	movl	$222, %eax
	ret
.L5:
	movl	$444, %eax
	ret
	.cfi_endproc
.LFE0:
	.size	nested_conds, .-nested_conds
	.ident	"GCC: (GNU) 12.2.1 20230111"
	.section	.note.GNU-stack,"",@progbits
