### Compile and run with
### > gcc jmp_tests_asm.s

        .section .text
        .global main
main:
        movl    $0,%eax
        movl    $5,%edi
        movl    $3,%esi
        movq    $0,%rdx
        movl    $-4,%ecx

        testl   %edi,%edi
        jnz     .NONZERO
        addl    $20,%eax

.NONZERO:
        testl   %esi,%esi
        jz      .FALSEY
        addl    $30,%eax
        
.FALSEY:
        testq   %rdx,%rdx
        je      .ISNULL
        addl    $40,%eax

.ISNULL:
        testl   %ecx,%ecx
        jns     .NONNEGATIVE
        addl    $50,%eax
        
.NONNEGATIVE:
        ret
        
