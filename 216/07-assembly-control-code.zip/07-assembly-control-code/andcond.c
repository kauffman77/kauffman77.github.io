// andcond.c: logical and condition in C; encoded in assembly in
// andcond_asm.s. Note: gcc will use lots of tricks to generate more
// efficient code which minimizes jumps for efficiency so don't be
// surprised if `gcc -Og -S andcond.c` produces different assembly
// than the hand written version.
int andcond(int edi){
  int ecx;
  if(edi >= 2 && edi <= 10){
    ecx = 10;
  }
  else{
    ecx = 5;
  }
  return ecx;
}

