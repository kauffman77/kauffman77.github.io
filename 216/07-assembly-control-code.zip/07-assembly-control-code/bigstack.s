	.file	"bigstack.c"
	.text
	.section	.rodata
	.align 32
.LC0:
	.long	1
	.long	2
	.long	3
	.long	4
	.long	5
	.long	6
	.long	7
	.long	8
	.long	9
	.long	10
	.long	11
	.long	12
	.long	13
	.long	14
	.long	15
	.long	16
	.long	17
	.long	18
	.long	19
	.long	20
	.long	21
	.long	22
	.long	23
	.long	24
	.long	25
	.long	26
	.long	27
	.long	28
	.long	29
	.long	30
	.long	31
	.long	32
	.long	33
	.long	34
	.long	35
	.long	36
	.long	37
	.long	38
	.long	39
	.long	40
	.long	41
	.long	42
	.long	43
	.long	44
	.long	45
	.long	46
	.long	47
	.long	48
	.long	49
	.long	50
	.long	51
	.long	52
	.long	53
	.long	54
	.long	55
	.long	56
	.long	57
	.long	58
	.long	59
	.long	60
	.long	61
	.long	62
	.long	63
	.long	64
	.long	65
	.long	66
	.long	67
	.long	68
	.long	69
	.long	70
	.long	71
	.long	72
	.long	73
	.long	74
	.long	75
	.long	76
	.long	77
	.long	78
	.long	79
	.long	80
	.long	81
	.long	82
	.long	83
	.long	84
	.long	85
	.long	86
	.long	87
	.long	88
	.long	89
	.long	90
	.long	91
	.long	92
	.long	93
	.long	94
	.long	95
	.long	96
	.long	97
	.long	98
	.long	99
	.long	100
	.long	101
	.long	102
	.long	103
	.long	104
	.long	105
	.long	106
	.long	107
	.long	108
	.long	109
	.long	110
	.long	111
	.long	112
	.long	113
	.long	114
	.long	115
	.long	116
	.long	117
	.long	118
	.long	119
	.long	120
	.long	121
	.long	122
	.long	123
	.long	124
	.long	125
	.long	126
	.long	127
	.long	128
	.long	129
	.long	130
	.long	131
	.long	132
	.long	133
	.long	134
	.long	135
	.long	136
	.long	137
	.long	138
	.long	139
	.long	140
	.long	141
	.long	142
	.long	143
	.long	144
	.long	145
	.long	146
	.long	147
	.long	148
	.long	149
	.long	150
	.long	151
	.long	152
	.long	153
	.long	154
	.long	155
	.long	156
	.long	157
	.long	158
	.long	159
	.long	160
	.long	161
	.long	162
	.long	163
	.long	164
	.long	165
	.long	166
	.long	167
	.long	168
	.long	169
	.long	170
	.long	171
	.long	172
	.long	173
	.long	174
	.long	175
	.long	176
	.long	177
	.long	178
	.long	179
	.long	180
	.long	181
	.long	182
	.long	183
	.long	184
	.long	185
	.long	186
	.long	187
	.long	188
	.long	189
	.long	190
	.long	191
	.long	192
	.long	193
	.long	194
	.long	195
	.long	196
	.long	197
	.long	198
	.long	199
	.long	200
	.text
	.globl	main
	.type	main, @function
main:
.LFB11:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	subq	$832, %rsp
	.cfi_def_cfa_offset 848
	movq	%fs:40, %rax
	movq	%rax, 824(%rsp)
	xorl	%eax, %eax
	movl	$1, 8(%rsp)
	movl	$2, 12(%rsp)
	movq	LIL_MSG(%rip), %rdi
	call	printf@PLT
	movl	$0, %ebx
	jmp	.L2
.L3:
	movslq	%ebx, %rax
	movl	8(%rsp,%rax,4), %esi
	movq	LIL_FMT(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, %ebx
.L2:
	cmpl	$1, %ebx
	jle	.L3
	leaq	16(%rsp), %rdi
	leaq	.LC0(%rip), %rsi
	movl	$100, %ecx
	rep movsq
	movq	BIG_MSG(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	$0, %ebx
	jmp	.L4
.L5:
	movslq	%ebx, %rax
	movl	16(%rsp,%rax,4), %esi
	movq	BIG_FMT(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, %ebx
.L4:
	cmpl	$199, %ebx
	jle	.L5
	movq	824(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L8
	movl	$0, %eax
	addq	$832, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L8:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE11:
	.size	main, .-main
	.globl	BIG_FMT
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC1:
	.string	"%d\n"
	.section	.data.rel.local,"aw"
	.align 8
	.type	BIG_FMT, @object
	.size	BIG_FMT, 8
BIG_FMT:
	.quad	.LC1
	.globl	LIL_FMT
	.align 8
	.type	LIL_FMT, @object
	.size	LIL_FMT, 8
LIL_FMT:
	.quad	.LC1
	.globl	BIG_MSG
	.section	.rodata.str1.1
.LC2:
	.string	"Printing the big_arr\n"
	.section	.data.rel.local
	.align 8
	.type	BIG_MSG, @object
	.size	BIG_MSG, 8
BIG_MSG:
	.quad	.LC2
	n.globl	LIL_MSG
	.section	.rodata.str1.1
.LC3:
	.string	"Printing the lil_arr\n"
	.section	.data.rel.local
	.align 8
	.type	LIL_MSG, @object
	.size	LIL_MSG, 8
LIL_MSG:
	.quad	.LC3
	.ident	"GCC: (GNU) 10.2.0"
	.section	.note.GNU-stack,"",@progbits
