// nestedcond.c: function with nested conditionals. Hand-translated
// assembly version in nestedcond_asm.s

int nested_cond(int edi, unsigned int esi){
  int eax = 0;
  if(edi > 0){                  // edi greater than 0
    if(esi >= 500 ){
      eax = 111;
    }
    else{
      eax = 222;
    }
  }
  else if(edi < 0){             // edi less than zero
    if(esi <= 900){
      eax = 333;
    }
    else{
      eax = 444;
    }
  }
  else{                         // edi must be zero
    eax = 555;
  }
  return eax;
}
