### swap_pointers_asm.s: demonstrates pushing data on stack for local
### variables that need an address. main() calls the swap_ptr()
### function with addresses for two ints to swap.  This requires
### main memory addresses so main() manipulates the stack poitner
### %rsp: subtract to grow it, call function, add to shrink stack
### before finishing. Based on swap_pointers.c.
### 
### COMPILE:
### > gcc swap_pointers_asm.s
        
.text
.global swap_ptr
swap_ptr:                               # function to swap values at pointed to by pointer args
        movl    (%rdi), %eax            # load values into registers
        movl    (%rsi), %edx
        movl    %edx, (%rdi)            # write back to opposite memory
        movl    %eax, (%rsi)            # locations
        ret
        
.text
.global main
main:                                   # main() function
        subq    $8, %rsp                # grow stack by 8 bytes, space uninitialized
                                        # now aligned at 16-byte boundary, ready for call
#       pushq   $0                      # ALTERNATE: grow stack, initialize with 0: subq $8, %rsp; movq $0, (%rsp)

        movl    $19, (%rsp)             # move 19 to local variable x
        movl    $31, 4(%rsp)            # move 31 to local variable y
        movq    %rsp, %rdi              # load address of x into rdi, 1st arg to swap_ptr()
        leaq    4(%rsp), %rsi           # load address of y into rsi, 2nd arg to swap_ptr()
        call    swap_ptr                # call swap function
        
        leaq    .FORMAT(%rip), %rdi     # load address of format string, 1st arg to printf()
        movl    (%rsp), %esi            # move x from main memory into esi, 2nd arg to printf()
        movl    4(%rsp), %edx           # move y from main memory into edx, 3rd arg to printf()
        movl    $0, %eax                # no vector regs used for variadic printf()
        call    printf@PLT              # call printf
        
        addq    $8, %rsp                # Shrink stack by 8 bytes to undo earlier pushq
#       popq    %rsi                    # ALTERNATE: shrink stack by 8 bytes, copies val into reg;  movq (%rsp), %rsi;  addq $8, %rsp
        movl    $0, %eax                # set return value
        ret
.data                           
.FORMAT:
        .asciz "%d %d\n"                # format string used by printf
