### andcond_asm.s: Assembly translation of C code
### int andcond(int edi){
###   int ecx;
###   if(edi >= 2 && edi <= 10){
###     ecx = 10;
###   }
###   else{
###     ecx = 5;
###   }
###   return ecx;
### }
###
### Demonstrates how logical conditions are grouped strung together in
### assembly and shows how "short circuit" boolean expressions work
.text
.global andcond
andcond:        
        cmpl  $2,%edi    # compare: edi-2
        jl .ELSE         # 
        cmpl $10, %edi   # compare: edi-10
        jg .ELSE         # 

        ## if(edi >= 2 && edi <= 10){
        movl  $10,%ecx   # greater/equal 
        ## }
        jmp   .AFTER
.ELSE:
        ## else{
        movl  $5,%ecx    # less than 
        ## }
.AFTER:
        movl  %ecx,%eax
        ret
