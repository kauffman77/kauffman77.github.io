### nestedcond_asm.c: Example of hand-coded assembly version of
### nestedcond.c. Compiler is likely to make different decisions than
### this but what shows up below constitutes a direct translation of
### the original C.  Note (1) use of comparison inversions, jump if
### the required C conditional is FALSE, fall through to next
### instructions when TRUE; and (2) use of jl/jle for signed numbers
### versus jb/jbe for unsigned numbers.

.text
.global	nested_cond
nested_cond:                    # int nested_cond(int edi, unsigned int esi){
        movl    $0, %eax        #   int eax = 0;
        cmpl    $0, %edi        #   if(edi > 0){        // edi greater than 0
        jle     .EDI_LE_ZERO    # 
        cmpl    $500, %esi      #     if(esi >= 500 ){
        jb      .ESI_BELOW_500  # 
        movl    $111, %eax      #       eax = 111;
        jmp     .DONE           #     }
.ESI_BELOW_500:                 #     else{
        movl    $222,%eax       #       eax = 222;
        jmp     .DONE           #     }
.EDI_LE_ZERO:                   #   }
        cmpl    $0, %edi        #   else if(edi < 0){   // edi less than zero
        je      .EDI_IS_ZERO    # 
        cmpl    $900,%esi       #     if(esi <= 900){
        ja      .ESI_ABOVE_900  # 
        movl    $333, %eax      #       eax = 333;
        jmp     .DONE           #     }
.ESI_ABOVE_900:                 #     else{
        movl    $444,%eax       #       eax = 444;
        jmp     .DONE           #   }
.EDI_IS_ZERO:                   #   else{               // edi must be zero
        movl    $555,%eax       #     eax = 555;
.DONE:                          #   }
        ret                     #   return eax;


