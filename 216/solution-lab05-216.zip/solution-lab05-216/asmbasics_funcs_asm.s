### asmbasics_funcs_asm.s: assembly implementations of some simple
### functions to demonstrate essential assembly syntax. Use the
### asmbasics_funcs.c file as a reference where equivalent
### functionality is implemented in C.
###
### Each function uses some integer arguments and returns an
### integer. For the exercise, make use of the following 32-bit
### integer registers:
###   |------+--------------------------------------|
###   | REG  | PURPOSE                              |
###   |------+--------------------------------------|
###   | %eax | function return value (if non-void)  |
###   | %edi | first integer argument (if present)  |
###   | %esi | second integer argument (if present) |
###   | %edx | third integer argument (if present)  |
###   | %ecx | fourth integer argumnt (if present)  |
###   |------+--------------------------------------|
### Each register can be changed during the computation.
###
### The following instruction formats may be used.
###   |------------------+-----------------------------------------------------|
###   | INSTRUCTION      | EFFECT                                              |
###   |------------------+-----------------------------------------------------|
###   | movl %edi, %eax  | copy register %edi to register %eax                 |
###   | movl $5, %eax    | copy constant 5 to %eax                             |
###   | addl %esi, %eax  | add the value in %esi onto %eax                     |
###   | addl $2, %eax    | add 2 onto %eax                                     |
###   | subl %edi, %eax  | subtract %edi from %eax                             |
###   | subl $4, %eax    | subtract 4 from %eax                                |
###   | imull $3, %eax   | triple %eax                                         |
###   | imull %edi, %eax | store the product of %edi, %eax in %eax             |
###   | ret              | return from the function, %eax has the return value |
###   |------------------+-----------------------------------------------------|
###
### TODO sections are marked and should be completed

.text

### labels below become available to other code as functions
.global difference
.global squared_sum
.global squared
.global squared_diff
.global twice_product
.global pythagorean_diff
.global meaning_of_life

## return the difference between arguments
difference:
        movl %edi, %eax
        subl %esi, %eax
        ret 

## return the square of the arguement
squared:
        movl  %edi, %eax
        imull %eax, %eax
        ret

## return the sum of the squares of the two arguments
squared_sum:
        movl  %edi, %eax
        imull %eax, %eax
        imull %esi, %esi
        addl  %esi, %eax
        ret

## return the difference of the squares of the two arguments
squared_diff:
###### TODO #####
        movl  %edi, %eax
        imull %eax, %eax
        imull %esi, %esi
        subl  %esi, %eax
        ret

## return the twice the product of the arguements
twice_product:
###### TODO #####
        movl %edi, %eax
        imull %esi, %eax
        imull $2, %eax
        ret

## compute the difference between a^2+b^2-c^2
pythagorean_diff:
###### TODO #####
        movl  %edi, %eax
        imull %eax, %eax
        imull %esi, %esi
        addl  %esi, %esi
        imull %edi, %edi
        subl  %edi, %eax
        ret

## ending function that returns a constant
meaning_of_life:
        movl $42, %eax
        ret
