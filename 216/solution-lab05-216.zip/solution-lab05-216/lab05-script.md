Lab05 Script

# Monday: asmbasics program
- Students will have had an introductory discussion on x86-64 assembly
  in lecture
- Quickly survey the `asmbasics_main.c` and `asmbasics_funcs.c` files
- Point out the slightly strange style used in `asmbasics_funcs.c` and
  mention it is reminiscent of how x86-64 assembly will look
- Open the `asmbasics_funcs_asm.s` file and do a quick tour of the top
  comments which give some basic information about registers and their
  use and the instruction formats used in the code
- This is a good time to mention to students that they will need to
  configure their code editor to get syntax highlighting for assembly
  code; instructions to do so in VS Code are linked at the top of the
  lab page
- Open `asmbasics_funcs_asm.s` side by side with `asmbasics_funcs.c`
  and compare the three completed assembly functions to their analogs
  in the C code; point out features of interest
  - In this assembly syntax, the right operand is modified so 
    `addl %edi, %eax` changes `%eax` by adding on `%edi`
  - Point out the equivalence of some C variables to registers like
    `%eax` is always `ans` in the C code
  - Point out that arguments come into assembly functions in registers
    so knowing that `%edi, %esi, %edx, ...` contain arguments helps to
    understand the functions
- Help students solve the first assembly function that needs to be
  completed `squared_diff` using the C version as a model; ask for
  guesses on how to translate the first C line to an assembly line,
  the 2nd line, etc
- After completing the function, compile and experiment a bit
  comparing the output of `asmbasics_c_only` and `asmbasics_mixed` to
  see if the behavior of the first function looks correct
- Then give students time to try the other two functions
- NOTE: the `meaning_of_life` function is at the end as some callable
  assembly functions lack a `ret` instruction until students add it;
  since code will fall through in several spots, incomplete
  implementations will get 42 as the answer to several functions; this
  is a tricky point that we will address later in lecture once we've
  gotten into the nature of assembly more fully
  
# Wednesday: coins_funcs_asm.s 
- Quickly survey `coins_funcs.c` which has C versions of the two
  function which will be coded in assembly
- Discuss the "algorithm" used in both cases to compute the coins
  needed for a given total cents
- Point out especially the prototype differences in functions
  ```c
  int set_coins(int cents, coins_t *coins);
  // pointer to a coins_t

  int total_coins(coins_t coins);
  // actual coins_t struct
  ```
- Show how to compile and test via `make` and point out that 2
  executables are created
  ```sh
  >> make
  gcc -Wall -Werror -g  -o coins_main coins_main.c coins_funcs_asm.s
  gcc -Wall -Werror -g  -o coins_main_c_only coins_main.c coins_funcs.c
  ```
  One has only C code involved; the other has a mixture of C (main)
  and assembly (funcs)
- Walk through provided assembly code for `set_coins()` in
  `coins_funcs_asm.s` and compare to `coins_funcs.c`
- Indicate to students that the function takes arguments and they are
  present in specific registers in assembly, arg 1 is in %rdi
- Show the diagram of registers to give context to functions receiving
  register arugments
- Discuss briefly the syntax 
  ```asm
  movb    %al,0(%rsi)     # coins->quarters = cents / 25
  ```
  with Parentheses around the register and mention that this treats
  the register contents as a memory address to write to
- Draw attention to the table in `coins.h` of the byte-offsets for
  fields of the `coins_t` struct, needed to complete the code
- Give students time to work on BLOCK C which they must complete
- CAUTION students that it is easy to copy-paste-complete but the
  purpose it get acquainted with register, assembly syntax, GDB usage,
  etc.
- Demo a GDB session on a completed assembly version of the first
  function
  ```sh
  >> gdb coins_main            # start GDB on C/Assembly version
  GNU gdb (GDB) 16.2
  
  (gdb) break set_coins        # stop on reaching assembly function
  Breakpoint 1 at 0x1303: file coins_funcs_asm.s, line 15.
  
  (gdb) set args 83            # set the command line arg to 83 cents
  
  (gdb) run                    # run program
  Starting program: 
  Breakpoint 1, set_coins () at coins_funcs_asm.s:15
  15	        cmpl    $99,%edi        # Describe this block

  (gdb) layout regs            # show the register file

  (gdb) stepi                  # step single instruction     
  ```
- Indicate that the pattern for the next `total_coins()` function is
  different BECAUSE it involves an Actual struct packed into a
  register instead of a pointer to a struct

# Optional if Time
- Show use of GDB on coins_main program to observe
  what is happening internally in the assembly functions; try running
- Move on to discuss `total_coins()` in assembly, contrast existing
  portion with the C version, walks through provided code.
- Contrast the arguments between 2 functions AGAIN to emphasize the
  difference between a POINTER to a struct (1st func) and a PACKED
  STRUCT arg (2nd func)
- Show coins.h which shows the bit layout of the register: which
  fields are in which registers - different from the byte offsets
- Point out the shifting of data in registers along with Masking with
  0xFF pattern to extract a single field
