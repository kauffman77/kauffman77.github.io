Lab05 Script
# Monday: masking.c outline file
- We will discuss bit operation in lecture on Tuesday so you'll need
  to give students a quick overview of their nature
- Survey the Terminology and table of Bitwise operations in
  QUESTIONS.txt (terms like "bit index" and "low-order bit" will be
  new for students)

```
| Operation | Description          |
|-----------+----------------------|
| x & y     | Bit-wise And         |
| x | y     | Bit-wise Or          |
| x ^ y     | Bit-wise Xor         |
| ~x        | Bit-wise inversion   |
| x << y    | Bit-wise Left-shift  |
| x >> y    | Bit-wise Right-shift |
```
- Show some examples such as the following to make the ideas concrete

```
ASSUME 8 bits for all
x = 0100 1100
y = 1110 0101

x & y is
  0100 1100
& 1110 0101
===========
  0100 0100

x << 2 is
    7654 3210  
    0100 1100
  <<        2
  ============
 98 7654 3210
 01 0011 0000
 XX        ^^
  =============
    0011 0000
```
- Mention that combination of Shifting constants ("masks") left
  Bitwise-Or can "Set" bits to 1
- Discuss example of setting; first question in QUESTIONS.txt or
  provided portion in masking.c has some
- Mention also that combination of Shifting mask left, Bit-wise
  Inversion, with Bit-wise And can "Clear" a bit to 0
- Again show example from code or your own
- Mention that can affect multiple bits using masks like 0b1111
- This will have relevance to Project 2 as students will need to
  construct specific patterns of bits in variables to achieve a
  specified outcome
- The last part of `masking.c` is close to an upcoming debugger
  exercise in P2 where a certain pattern of bits must be formed by
  putting numbers in `input.txt` to dictate some shifts

# Wednesday: asmbasics program
- Students will have had an introductory discussion on x86-64 assembly
  in lecture
- Quickly survey the `asmbasics_main.c` and `asmbasics_funcs.c` files
- Point out the slightly strange style used in `asmbasics_funcs.c` and
  mention it is reminiscent of how x86-64 assembly will look
- Open the `asmbasics_funcs_asm.s` file and do a quick tour of the top
  comments which give some basic information about registers and their
  use and the instruction formats used in the code
- This is a good time to mention to students that they will need to
  configure their code editor to get syntax highlighting for assembly
  code; instructions to do so in VS Code are linked at the top of the
  lab page
- Open `asmbasics_funcs_asm.s` side by side with `asmbasics_funcs.c`
  and compare the three completed assembly functions to their analogs
  in the C code; point out features of interest
  - In this assembly syntax, the right operand is modified so 
    `addl %edi, %eax` changes `%eax` by adding on `%edi`
  - Point out the equivalence of some C variables to registers like
    `%eax` is always `ans` in the C code
  - Point out that arguments come into assembly functions in registers
    so knowing that `%edi, %esi, %edx, ...` contain arguments helps to
    understand the functions
- Help students solve the first assembly function that needs to be
  completed `squared_diff` using the C version as a model; ask for
  guesses on how to translate the first C line to an assembly line,
  the 2nd line, etc
- After completing the function, compile and experiment a bit
  comparing the output of `asmbasics_c_only` and `asmbasics_mixed` to
  see if the behavior of the first function looks correct
- Then give students time to try the other two functions
- NOTE: the `meaning_of_life` function is at the end as some callable
  assembly functions lack a `ret` instruction until students add it;
  since code will fall through in several spots, incomplete
  implementations will get 42 as the answer to several functions; this
  is a tricky point that we will address later in lecture once we've
  gotten into the nature of assembly more fully
  
    
