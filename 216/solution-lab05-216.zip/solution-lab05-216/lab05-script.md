Lab05 Script

# Monday
- Mention that no code is written for firs part: instead it simulates
  part of the puzzlebox program that is in Project 2
- The point is to use GDB to determine the correct input to place in a
  file that will cause a program advance; simulates puzzlebox phase03
- Demonstrate downloading the codepack, `make` to compile, then run
  `./phase03 input.txt`
  to show that the program does not advance and fails
- Demonstrate how to set up the debugger to run the program via
  `gdb -tui phase03`
- Discuss setting break points via several mechanisms
  - At the start of a function via `break main`
  - At a specific line in the current source file via `break 36`
  - In another source file via `break thefile.c:82`
- Discuss setting command line arguments via either
  `set args input.txt`
  or
  `run input.txt`
- Discuss the basic control commands
  - run  : re-run from beginning
  - next : next line of code
  - step : step ahead and into functions
  - continue : keep executing until next break point
- Answer questions about the specific phase such as the use of the
  shift operations and bit-wise or operation
- Describe use of 
  `print/t var`
  to print in binary format; that there are several other printing
  options top print like this
- Mention to students that they will all have the same answers for
  this lab but differing answers for puzzlebox on Project 2

# Wednesday
- Survey the table of bit operations at the midway through QUESTIONS.txt
```
| Operation | Description          |
|-----------+----------------------|
| x & y     | Bit-wise And         |
| x | y     | Bit-wise Or          |
| x ^ y     | Bit-wise Xor         |
| ~x        | Bit-wise inversion   |
| x << y    | Bit-wise Left-shift  |
| x >> y    | Bit-wise Right-shift |
```
- We will have discussed these in lecture but a few more examples
  often help such as the following

```
ASSUME 8 bits for all
x = 0100 1100
y = 1110 0101

x & y is
  0100 1100
& 1110 0101
===========
  0100 0100

x << 2 is
    7654 3210  
    0100 1100
  <<        2
  ============
 98 7654 3210
 01 0011 0000
 XX        ^^
  =============
    0011 0000
```
- Mention that combination of Shifting constants ("masks") left
  Bitwise-Or can "Set" bits to 1
- Discuss example of setting; first question in QUESTIONS.txt or
  provided portion in masking.c has some
- Mention also that combination of Shifting mask left, Bit-wise
  Inversion, with Bit-wise And can "Clear" a bit to 0
- Again show example from code or your own
- Mention that can affect multiple bits using masks like 0b1111
- This will have relevance to Project 2 as students will need to
  construct specific patterns of bits in variables to achieve a
  specified outcome
