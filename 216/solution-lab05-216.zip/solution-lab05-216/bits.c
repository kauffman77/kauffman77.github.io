#include <stdio.h>

int main(){
  char bits[] = "Fun";
  printf("%d\n",*((int *) bits));

  int ints[] = {4165,0};
  printf("%s\n",((char *) ints));
  return 0;
}
             
