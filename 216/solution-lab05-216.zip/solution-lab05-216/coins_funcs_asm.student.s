### coins_funcs_asm.s: Implements several functions in assembly that
### do simple arithmetic operations. The functions also operate on
### structs and pointers to structs requiring an understanding of
### how structs are handled in assmebly.

.text
.global set_coins
set_coins:
### args are
### %edi = int cents
### %rsi = coints_t *coins
        ## BLOCK A
        cmpl    $99,%edi        # Describe this block
        jg      .OOB
        cmpl    $0,%edi
        jl      .OOB
        
        ## BLOCK B
        movl    %edi,%eax       # eax now has cents
        cltd                    # prep for division
        movl    $25,%r8d
        idivl   %r8d
        movw    %ax,0(%rsi)     # coins->quarters = cents / 25
        movl    %edx,%eax       # cents = cents % 25
        
        cltd                    # prep for division
        movl    $10,%r8d
        idivl   %r8d
        movw    %ax,2(%rsi)     # coins->dimes = cents / 10
        movl    %edx,%eax       # cents = cents % 10
        
        ## BLOCK C: Complete for nickels and pennies
        ## COMPLETE THIS CODE

        ## Return 
        movl    $0,%eax         # return value
        ret
.OOB:
        movl    $1, %eax
        ret


.global total_coins
total_coins:
### args are
### %rdi packed coin_t struct with struct fields in the following bit ranges
###  {0-7: quarters, 8-15: dimes, 16-23: nickels,  24-31: pennies}

        movl    $0,%eax          # tot = 0
        
        ## BLOCK D: extract quarters and dimes from struct and add to total
        ## quarters
        movq    %rdi,%rdx        # copy whole struct including quarters
        ## sarq    $0,%rdx         # no shift needed
        andq    $0xFFFF,%rdx     # rdx = quarters, mask low byte
        imull   $25,%edx         # rdx *= 25
        addl    %edx,%eax        # tot += coins.quarters*25
        
        ## dimes
        movq    %rdi,%rdx        # copy whole struct including dimes
        sarq    $16,%rdx         # shift dimes to low order bits
        andq    $0xFFFF,%rdx     # rdx = dimes
        imull   $10,%edx         # rdx *= 10
        addl    %edx,%eax        # tot += coins.dimes*10
        
        ## BLOCK F: extract nickes and pennies from struct and add to total
	## COMPLETE THIS CODE

        ## Nickels
        
        ## Pennies

        ## return value already in eax
        ret

