7 5 3
0 2 Death_Crystals
4 1 Mega_Seeds
6 3 Flurbo_stash
