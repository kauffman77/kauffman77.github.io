	.file	"verify.c"
	.text
	.globl	verify
	.type	verify, @function
verify:
.LFB0:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	16+answers(%rip), %rsi
	call	strcmp@PLT
	popq	%rdx
	.cfi_def_cfa_offset 8
	testl	%eax, %eax
	setne	%al
	movzbl	%al, %eax
	ret
	.cfi_endproc
.LFE0:
	.size	verify, .-verify
	.globl	answers
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"a set of dental instruments\n"
.LC1:
	.string	"C++ without the ++ part\n"
.LC2:
	.string	"assembly language\n"
.LC3:
	.string	"trick question: it isn't convenient\n"
.LC4:
	.string	"a gun that shoots forwards and backwards\n"
.LC5:
	.string	"OCaml without type inference, garbage collection, or first-class functions\n"
.LC6:
	.string	"Dvorak keyboards\n"
	.section	.data.rel.local,"aw"
	.align 32
	.type	answers, @object
	.size	answers, 56
answers:
	.quad	.LC0
	.quad	.LC1
	.quad	.LC2
	.quad	.LC3
	.quad	.LC4
	.quad	.LC5
	.quad	.LC6
	.ident	"GCC: (GNU) 16.2.1 20260810"
	.section	.note.GNU-stack,"",@progbits
