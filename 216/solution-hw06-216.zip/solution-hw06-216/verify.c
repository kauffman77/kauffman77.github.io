#include <stdio.h>
#include <string.h>

char *answers[] = {
  "a set of dental instruments\n",
  "C++ without the ++ part\n",
  "assembly language\n",
  "trick question: it isn't convenient\n",
  "a gun that shoots forwards and backwards\n",
  "OCaml without type inference, garbage collection, or first-class functions\n",
  "Dvorak keyboards\n"
};
  
// int compare_strings(char *a, char *b);

int verify(char *buf){
  // int diff = compare_strings(buf,answers[2]);
  int diff = strcmp(buf,answers[2]);
  if(diff == 0){
    return 0;
  }
  else{
    return 1;
  }
  
  // for(int i=0; i<19; i++){
  //   if(buf[i] != ans[i]){
  //     return 1;
  //   }
  // }
  // return 0;
}

// int compare_strings(char *a, char *b){
//   for(int i=0; ; i++){
//     if(a[i]=='\0' && b[i]=='\0'){
//       break;
//     }
//     else if(a[i]=='\0'){
//       return -1;
//     }
//     else if(b[i]=='\0'){
//       return +1;
//     }
//     int diff = a[i] - b[i];
//     if(diff != 0){
//       return diff;
//     }
//   }
//   return 0;
// }

