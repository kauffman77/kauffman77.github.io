# Lab01 Script Wednesday
- 5min Lab staff introduce themselves, give a piece of advice to
  students about how to succeed at C programming
- 15min Direct students to Coding Environment Guide linked from
  ELMS/Canvas site
  - Walk students through VS Code install
  - SSH basics via cmd.exe or Terminal.app
  - VS Code install, SFTP extension install
  - Configuration of SFTP
- 5min Discuss getting lab01-code.zip onto Zaratan 
  - Use of wget or SFTP sync to get zip onto Zaratan
  - Unzip on Zaratan utility to unpack the zip
  - Sync files between Zaratan / laptops
  - cd / ls to navigate into the folder
- 10min on QUESTIONS.txt file
  - Open QUESTIONS.txt, indicate this contains "QUIZ" questions and
    instructions on what to code
  - Discuss first few SSH / SCP / terminal command questions; ask
    students for answers, give guidance if needed
  - Check answers using `make test-quiz` on Zaratan: make sure that
    files are sync'd to remote, warn students and demonstrate how to
    do this
- 10min CODE portion of QUESITONS.txt
  - Open `hello_c.c` file
  - Compile via `make` and run via `./hello_c`
  - Observe to students that each `make` runs some other commands;
    note they'll learn how to write simple Makefiles in a few weeks
    but can start looking at the provided `Makefile` now
  - Use `make test-code` to run tests on code
- 5min Test results and code corrections
  - Show students results file from test-code
  - Explain 'diff' output: left side EXPECT vs right side ACTUAL
  - Start editing hello_c, run `make test-code` again, show changes in
    test results 
  - Finish editing and do a `make test-code` to check answers
- IF TIME: Zip / Submit 
  - Final `make test` to ensure all tests passed
  - `make zip` to create lab01-complete.zip which archives the answers
  - `make submit` will prompt for Gradescope Email / Password and
    upload the complete zip
  - To retain copies of completed code, Sync code from Remote -> Local
  - Remind that submitting via a web browser is also possible; after
    downloading `lab01-complete.zip`, navigate to Gradescope, click
    the assignment, and upload the zip

