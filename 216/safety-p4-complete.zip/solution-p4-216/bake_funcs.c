// bake_funcs.c: required service functions for handling of Bakefiles
#include "bake.h"

////////////////////////////////////////////////////////////////////////////////
// PROBLEM 1
////////////////////////////////////////////////////////////////////////////////

// PROBLEM 1: Uses combination of stat() and read() to efficiently
// read in the entire contents of a file into a malloc()'d block of
// memory, null terminates it (\0). Returns a pointer to the file data
// or NULL if the file could not be opened.
char *slurp_file_efficient(char *fname){
  Dprintf("START slurp_file_efficient(%s)\n",fname);
  struct stat sb;
  int result = stat(fname, &sb); // unix system call to determine size of named file
  if(result==-1){                // bail if something went wrong
    perror("Couldn't open file");
    return NULL;
  }
    
  int fd = open(fname, O_RDONLY);
  if(fd == -1){
    perror("Couldn't open file");
    return NULL;
  }

  size_t nbytes = sizeof(char) * sb.st_size;
  char *text = malloc(nbytes+1); // extra byte for \0 termination
  int nread = read(fd, text, nbytes);
  if(nread != nbytes){
    printf("Didn't read the whole file...\n");
  }
  text[nbytes] = '\0';        // null terminate
  close(fd);
  return text;
}

// PROBLEM 1: Searches bake for a rule with a target that equals
// `targname`. If found, returns a pointer to that rule. Otherwise
// returns NULL if no rule with target `targname` exists.
//
// DESIGN NOTE: The curent design makes use of linear search for
// target location, O(rule_count) for each lookup. Maintainting a hash
// table of target->rule key/vals would allow O(1) lookup for rules
// with given target names.
rule_t *bake_target_rule(bake_t *bake, char *targname){
  for(int i=0; i<bake->rule_count; i++){
    rule_t *rule = &bake->rules[i];
    // Dprintf("comparing rule.target '%s' to '%s'\n",rule->target,targname);
    if(strcmp(targname, rule->target)==0){
      return rule;
    }
  }
  return NULL;
}

// PROBLEM 1: Modifies `bake` to add a new, empty rule to it and
// returns a pointer to that rule. If bake->rules[] is full
// (rule_capacity and rule_count are equal) doubles the size of
// rules[] via realloc() in order create room at its end for the new
// empty rule. Returns a pointer to the new empty rule.
//
// CLARIFICATION: This function intitalizes all the date in the
// returned rule to NULL or 0 including the nested arrays. HINT: make
// use of the memset() to quickly initialize the entire rule_t struct
// to 0's. This is possible due to the nested arrays being within the
// rule_t rather than pointers to other blocks of memory which means a
// single memset() call will suffice.
// 
// CAUTION: Calling this function MAY invalidate any pointers to
// existing rules as the array that houses the rules may move.
// This sequence is dangerous:
//   rule_t *rule  = bake_target_rule(bake, "sometarget");
//   rule_t *empty = bake_add_empty_rule(bake);
//   rule may now point to de-allocated memory
rule_t *bake_add_empty_rule(bake_t *bake){
  if(bake->rule_count == bake->rule_capacity){
    bake->rule_capacity *= 2;
    bake->rules = realloc(bake->rules, sizeof(rule_t)*bake->rule_capacity);
  }
  rule_t *new_rule = &bake->rules[bake->rule_count];
  memset(new_rule, 0, sizeof(rule_t));
  bake->rule_count++;
  return new_rule;
}
  
// PROBLEM 1: Iterate over all rules appending implicit rules for any
// dependency that is not an explicit target. New rules added in this
// way are marked with the RULE_IMPLICIT_BIT.
//
// CAUTION: Since bake->rules[] may expand, care must be taken when
// referencing rules in this function to avoid inadvertently derefing
// a pointer to free()'d memory.
int bake_add_implicit_rules(bake_t *bake){
  Dprintf("bake_add_implicit_rules()\n");
  int expl_count = bake->rule_count;
  int nadded = 0;
  for(int i=0; i<expl_count; i++){
    for(int j=0; bake->rules[i].deps[j] != NULL; j++){
      if(bake_target_rule(bake, bake->rules[i].deps[j]) == NULL){ 
        rule_t *new_rule = bake_add_empty_rule(bake); // create implicit rule
        new_rule->target = bake->rules[i].deps[j];
        SET_BIT(new_rule->rule_flags, RULE_IMPLICIT_BIT);
        nadded++;
      }
    }
  }
  return nadded;
}


// PROBLEM 1: If the SILENCE_BIT is set, does nothing and immediately
// returns. Otherwise, prints the given command token by token. If I/O
// redirects are indicated by the fields of the command, prints the
// after all tokens with "< infile" for input followed by "> outfile"
// if present. This function is used to print out commands in
// bake_execute_cmd().
void bake_print_cmd(cmd_t *cmd){
  if( CHECK_BIT(cmd->cmd_flags, CMD_SILENCE_BIT) ){
    return;                                  // printing silenced
  }

  for(int i=0; cmd->tokens[i] != NULL; i++){
    printf("%s ",cmd->tokens[i]);
  }
  if( cmd->input_redirect != NULL ){         // print input redirection
    printf("< %s ",cmd->input_redirect);
  }
  if( cmd->output_redirect != NULL ){        // print output redirection
    printf("> %s ",cmd->output_redirect);
  }
  printf("\n");
}

////////////////////////////////////////////////////////////////////////////////
// PROBLEM 2
////////////////////////////////////////////////////////////////////////////////

// PROBLEM 2: Called during bake_do_update(). Prints the command using
// bake_print_cmd() unless its SILENCE bit is set. fork()'s a child
// process which exec's the command specified in cmd->tokens.  Sets up
// I/O redirection in child process if indicated by cmd flags and
// fields. Uses a wait() call to wait until the child process is
// done. If the child completes normally, its exit code is passed up,
// 0 or non-zero. If the child process fails to complete normally or
// prints an error message with line number of command
// CMD_NONSTAND_EXIT. Non-zero returns from this function will usually
// be handled in a build by cancelling the build whil 0 return will
// cause the build to prceed and execute subsequent commands.
//
// During Input and Output redirection, if the requrested files cannot
// be opened, the child process exits with code CMD_FAIL_INPREDI or
// CMD_FAIL_OUTREDI. Additionally, if the child fails to exec() a
// command, CMD_FAIL_EXEC is used as its return code. All of these are
// non-zero and trigger builds to fail. In the above failure cases,
// prints one of the below error messages appropriate to the error.
// 
// perror("ERROR: can't open file for output")
// perror("ERROR: can't open file for output")
// perror("ERROR: job failed to exec");
//
// CLARIFICATION: When open()'ing files for output redirection,
// certain options should be passed to ensure that the created file
// adheres to conventions
// - For the second argument to open(), pass options
//     O_WRONLY|O_CREAT|O_TRUNC
//   which will open the file for writing, create it if not present,
//   and truncate the file if it already exists
// - For the third argument to open(), pass the arguments
//     S_IRUSR|S_IWUSR
//   which will set the "rw" permissions on the created file for the
//   owner (user) of the file
int bake_execute_cmd(cmd_t *cmd){
  bake_print_cmd(cmd);
  pid_t pid = fork();
  if(pid==-1){                  // check for a fork error
    perror("ERROR: Failed to fork()");
    exit(EXIT_FAILURE);
  }
  if(pid == 0){                 // child process exec()'s command

    // INPUT REDIRECTION CASE 
    if(cmd->input_redirect != NULL){
      int infd = open(cmd->input_redirect, O_RDONLY);
      if(infd == -1){                                    // couldn't open input file
        perror("ERROR: can't open file for input");      // print an error and set
        exit(CMD_FAIL_INPREDI);
      }

      int ret = dup2(infd, STDIN_FILENO);
      if(ret == -1){
        perror("ERROR: dup2() failed unexpectedly for output redirection");
        exit(CMD_FAIL_INPREDI);
      }
    }

    // OUTPUT REDIRECTION CASE
    if(cmd->output_redirect != NULL){
      int outfd = open(cmd->output_redirect, O_WRONLY|O_CREAT|O_TRUNC, S_IRUSR|S_IWUSR);
      if(outfd == -1){                                   // couldn't open output file
        perror("ERROR: can't open file for output");     // print an error and set
        exit(CMD_FAIL_OUTREDI);
      }

      int ret = dup2(outfd, STDOUT_FILENO);
      if(ret == -1){
        perror("ERROR: dup2() failed unexpectedly for output redirection");
        exit(CMD_FAIL_OUTREDI);
      }
    }

    // exec the child process
    int result = execvp(cmd->tokens[0],cmd->tokens); // execute command
    if(result == -1){
      perror("ERROR: command failed to exec");
      // job_free(job);
      exit(CMD_FAIL_EXEC);
    }
  }
  else{                         // parent process waits for command and checks its status
    int status;
    int ret = waitpid(pid, &status, 0);
    // int ret = wait(&status);   // alternative
    if(ret == -1){
      perror("ERROR: -1 from watpid()");
      exit(EXIT_FAILURE);
    }
    if(ret != pid){
      Dprintf("wait return %d does not match pid %d\n",ret,pid);
      exit(EXIT_FAILURE);            // something seriously wront happened
    }

    if(WIFEXITED(status)){
      return WEXITSTATUS(status);    // child exited normally, pass up its exit code
    }
    else{                            
      return CMD_NONSTAND_EXIT;      // non-standard exit or non-zero exit code
    }
  }

  Dprintf("Reached unreachable code at end of bake_execute_cmd()\n");
  exit(EXIT_FAILURE);
  return -1;                    // should be unreachable 
}

////////////////////////////////////////////////////////////////////////////////
// PROBLEM 3
////////////////////////////////////////////////////////////////////////////////


// PROBLEM 3: Starting at `targname`, recurses down the
// target/dependency DAG setting the UPDATE bit in rule_flags to
// indicate whether a target requires updates. Makes use of the
// CLEAR_BIT(), CHECK_BIT(), and SET_BIT() macros when dealing with
// bit-manipulations. For a given rule, first visits all its
// dependencies to check if they require updates via recursion. Then
// determines if `targname` requires an update. The conditions that
// require an update are described in detail in the program
// specification and shoudl be consulted while implementing this
// function. Returns 1 if target needs to be updated so associated
// rule commands should be run later. Returns 0 if the named target
// does not need to be updated. Prints an error if targname is not
// found and returns -1. If any dependency returns -1, an error
// ocurred lower down the DAG. In case, nothing is printed nothing and
// -1 is returned up the nested recursion.
int bake_set_updates(bake_t *bake, char *targname){
  Dprintf("bake_set_updates(bake, %s)\n",targname);

  rule_t *targ_rule = bake_target_rule(bake, targname);
  if(targ_rule == NULL){
    printf("No rule to create target '%s'\n", targname);
    return -1;
  }

  // clears the update bit to default to false
  CLEAR_BIT(targ_rule->rule_flags, RULE_UPDATE_BIT); 

  // special case for implicit targets: enure that they have a file
  // present that is accessible
  if(CHECK_BIT(targ_rule->rule_flags, RULE_IMPLICIT_BIT)){
    if( access(targname, F_OK)==0 ){             // file exists
      return 0;
    }
    else{                                        // does not exist
      printf("Implicit rule cannot find file '%s'\n", targname);
      return -1;
    }
  }

  // visit each dependency of the target; run ALL iterations for this
  // loop unless a dependency returns an error. ALL depencies should
  // be checked even if one indicates tha the current target needs an
  // update, other depencies may also need updates and should be visited.
  for(int i=0; targ_rule->deps[i]!=NULL; i++){
    int dep_update = bake_set_updates(bake, targ_rule->deps[i]);
    if(dep_update == -1){            // dep check failed
      return -1;                     // note: traditional make checks this case to include target/dep in error message but we won't bother here
    }
    else if(dep_update == 1){        // dep needs update so this target also needs an update
      SET_BIT(targ_rule->rule_flags, RULE_UPDATE_BIT);
    }
    else if(access(targname,F_OK)==0 && access(targ_rule->deps[i],F_OK)==0){
      // both target and dep are files that exist, compare timestamps
      // for them as if the dependency file is newer than the target
      // file, an update is required
      struct stat sb;
      stat(targname, &sb);
      struct timespec targ_mtime = sb.st_mtim;           // target modfication time
      stat(targ_rule->deps[i], &sb);
      struct timespec dep_mtime = sb.st_mtim;            // dependency modification time
      long diff = diff_timespec(dep_mtime,targ_mtime);
      if(diff > 0){                                      // dependency newer than target
        SET_BIT(targ_rule->rule_flags, RULE_UPDATE_BIT); // update target
      }
    }
  }

  // special case for rules like 'clean : (nothing)'
  if(access(targname,F_OK)!=0 &&     // no file exists
     targ_rule->cmd_count>0)         // there are commands to run
  {
    SET_BIT(targ_rule->rule_flags, RULE_UPDATE_BIT); // update target
  }

  // return whether the UPDATE bit is set or not
  return CHECK_BIT(targ_rule->rule_flags, RULE_UPDATE_BIT) != 0;
}


// PROBLEM 3: Starting at `targname`, run commands if the UPDATE bit
// is set. Before running commands associated with `targname`,
// recursively visit dependencies and if their UPDATE bit is set, run
// their commands first. Returns number of rules that were updated or
// -1 to indicate an error ocurred while running commands.
int bake_do_updates(bake_t *bake, char *targname){
  Dprintf("bake_do_updates(bake, %s)\n",targname);
  rule_t *rule = bake_target_rule(bake, targname);
  if(rule == NULL){
    Dprintf("no rule for '%s' found\n",targname);
    return -1;
  }

  if( !CHECK_BIT(rule->rule_flags, RULE_UPDATE_BIT) ){ 
    return 0;                                    // rule doesn't need to update
  }

  int nupdates = 0;                                 // track how many updates are done
  for(int i=0; rule->deps[i] != NULL; i++){         // recurse on dependencies
    int ret = bake_do_updates(bake, rule->deps[i]); // build dependency
    if(ret == -1){                                  // 
      return -1;                                    // dep errors halt the build
    }                                               // 
    nupdates += ret;                                // total updates
  }

  // run commands associated with updating this rule
  printf("bake: updating '%s' via %d command(s)\n",
         targname, rule->cmd_count);
  for(int i=0; i < rule->cmd_count; i++){
    cmd_t *cmd = &rule->cmds[i];
    int ret = bake_execute_cmd(cmd);
    if(ret != 0){
      printf("%s:%d ERROR during target '%s', exit code %d\n",
             bake->filename, cmd->line_number, targname, ret);
      return -1;
    }
  }

  CLEAR_BIT(rule->rule_flags, RULE_UPDATE_BIT);  // rule has been updated
  return nupdates+1;                             // return total updates including this rule
}


////////////////////////////////////////////////////////////////////////////////
// PROBLEM 4
////////////////////////////////////////////////////////////////////////////////

// PROBLEM 4: Examines cmd->tokens to set cmd->flags and a few other
// fields. Used to post-process the raw tokens of a command. Likely
// uses the utility function array_shift() to ease the re-arrangment
// of arrays.
// 
// 1. If tokens[0] = "@", eliminates this token by shifting all tokens
// over and sets the SILENCED bit
// 
// 2. If tokens[i] = "<", input redirection is desired; if tokens[i+1]
// is not NULL, returns -1. Otherwise sets the INPREDI bit and
// input_redirect field to tokens[i+1]. Then shifts all tokens over to
// eliminate tokens[i] and tokens[i+1].
// 
// 3. If tokens[i] = ">", output redirection is desired and performs
// similar operations to #2 with the OUTREDI flag and output_redirect
// fields.
//
// Correctly handles any order of "< input" / "> output" and other
// tokens (ex: output redirection may appear first followed by normal
// tokens followed by input redirection)
// 
// If multiple "<" or ">" tokens appear, the behavior of this function
// is unspecified: it may return an error, segfault, or behave randomly.
// 
// Returns 0 on succesful completion.
//
// DESIGN NOTE: This function must be called prior to any commands
// being run. The ideal location is during parsing to modify commands
// as a bake_t structure is built. However, this functionality is
// separated out to enable future functionality such as variable
// substitution to be added to commands and tested separately from
// parsing. Any additional context needed for such things will be part
// of the 'bake' parameter (e.g. may contain a map of variable
// names/values for substitutions).
int bake_cmd_postprocess(bake_t *bake, cmd_t *cmd){
  int ntokens = 0;
  while(cmd->tokens[ntokens] != NULL){
    ntokens++;
  }

  // check for command silencing: starts with '@ some commands'
  if(strcmp(cmd->tokens[0],"@")==0){
    SET_BIT(cmd->cmd_flags, CMD_SILENCE_BIT);
    array_shift(cmd->tokens, 0, ntokens);
    ntokens--;
  }

  // check for input redirection via "<" "file" 
  for(int i=0; i<ntokens; i++){
    if( strcmp(cmd->tokens[i], "<")==0 ){
      if(i+1 >= ntokens){
        printf("ERROR: No file given for input redirection\n");
        return -1;
      }
      cmd->input_redirect = cmd->tokens[i+1];
      array_shift(cmd->tokens,i,ntokens);        // shift off "<"
      ntokens--;
      array_shift(cmd->tokens,i,ntokens);        // shift off "infile"
      ntokens--;
      SET_BIT(cmd->cmd_flags, CMD_INPREDI_BIT);
    }
  }

  // check for outpu redirection via ">" "file" 
  for(int i=0; i<ntokens; i++){
    if( strcmp(cmd->tokens[i], ">")==0 ){
      if(i+1 >= ntokens){
        printf("ERROR: No file given for output redirection\n");
        return -1;
      }
      cmd->output_redirect = cmd->tokens[i+1];
      array_shift(cmd->tokens,i,ntokens);        // shift off ">"
      ntokens--;
      array_shift(cmd->tokens,i,ntokens);        // shift off "outfile"
      ntokens--;
      SET_BIT(cmd->cmd_flags, CMD_OUTREDI_BIT);
    }
  }

  cmd->tokens[ntokens] = NULL;       // restore NULL terminator
  return 0;
}

// PROBLEM 4: Applies postprocessing operations to the bake after
// loading it from a file. Currently only iterates over all rules and
// applies bake_cmd_postprocess() to each of their commands.
//
// DESIGN NOTE: This function is where additional operations could be
// used to further modify the bakefile such as performing variable
// substitutions on rules / targets, including other bakefiles. etc.
void bake_post_process(bake_t *bake){
  for(int i=0; i<bake->rule_count; i++){
    rule_t *rule = &bake->rules[i];
    for(int j=0; j<rule->cmd_count; j++){
      bake_cmd_postprocess(bake, &rule->cmds[j]);
    }
  }
}
