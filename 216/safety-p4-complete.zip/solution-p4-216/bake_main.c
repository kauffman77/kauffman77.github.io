// bake_main.c: 

#include "bake.h"

// bake
// bake <target>
// bake -f <bake_file> <target>

void print_usage(){
  printf("usage: bake\n");
  printf("       bake <target>\n");
  printf("       bake -f <bake_file> <target>\n");
}

// PROBLEM 4: main funciton which combines functions to execute
// commands and update a target.
int main(int argc, char *argv[]){

  // NOTE: Command line processing is a bit more complex than it needs
  // to be as only the following command line structures are supported: 
  // 
  // >> bake                         
  // # use default "Bakefile" and 1st target in that file
  // 
  // >> bake all
  // # use Bakefile but build target "all" rather than 1st target
  // 
  // >> bake -f Bakefile2         
  // # use Bakefile2 with 1st target in that file
  // 
  // >> bake -f Bakefile2 all
  // # use Bakefile2 but build target "all" rather than 1st target
  // 
  // >> bake all -f Bakefile2         
  // # NOT SUPPORTED and not tested
  // 
  // This would allow looking for argc=1,2,3,4 for each case. The
  // logic below prepares for arbitrary placement of the "-f <file>"
  // and handling of multiple requested targets in a loop.a

  char *bakefile = "Bakefile";  // default bakefile

  if(argc > 1 && strcmp(argv[1],"-f")==0){ // check for non-default file specification
    if(argc < 3){
      print_usage();
      return 1;
    }
    bakefile = argv[2];
    array_shift(argv, 1, argc);
    argc--;
    array_shift(argv, 1, argc);
    argc--;
  }

  char *root_target = NULL;   // NOTE: if handling multiple targests,           
  if(argc > 1){               // convert this loop to iterate over non-NULL     
    root_target = argv[1];    // ARGV elements                                  
  }

  Dprintf("Loading bakefile '%s'\n",bakefile);
  bake_t *bake = bake_create_from_file(bakefile);
  Dprintf("Completed loading\n");

  if(bake == NULL){
    printf("ERROR: unable to process file '%s'\n",bakefile);
    return EXIT_FAILURE;
  }
  if(bake->rule_count == 0){
    printf("ERROR: '%s' has 0 rules\n",bakefile);
    bake_free(bake);
    return EXIT_FAILURE;
  }

  IF_DEBUG{ bake_show_bake(bake,0); }

  bake_add_implicit_rules(bake);
  bake_post_process(bake);

  if(root_target == NULL){      // no target specified, use the 0th rule in the bakefile
    root_target = bake->rules[0].target;
  }

  int needs_update = bake_set_updates(bake, root_target);

  if(needs_update == -1){       // update detection indicated failure of some sort
    printf("bake failed\n");    // usually due to missing targets
    bake_free(bake);
    return EXIT_FAILURE;
  }

  if(needs_update == 0){        // update indicated no action needed
    if(access(root_target, F_OK)==0){
      printf("bake: file '%s' is up to date\n",root_target);
    }
    else{
      printf("bake: nothing to be done for target '%s'\n",root_target);
    }
    bake_free(bake);
    return 0;
  }

  int nupdates = bake_do_updates(bake, root_target);
  if(nupdates == -1){
    printf("bake failed\n");    // usually due to missing targets
    bake_free(bake);
    return EXIT_FAILURE;
  }

  printf("bake complete, %d update(s) performed\n",nupdates);
  bake_free(bake);
  return 0;
}
