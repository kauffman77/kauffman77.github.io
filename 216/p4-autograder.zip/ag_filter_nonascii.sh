#!/bin/bash

# Filter non-ascii characters from a file. Leaves a backup copy file

file=$1
cp $file ${file}.bk

# tr will convert all non-printing or \n to ?
cat ${file}.bk |tr -c '[:print:]\n' '?' > $file
