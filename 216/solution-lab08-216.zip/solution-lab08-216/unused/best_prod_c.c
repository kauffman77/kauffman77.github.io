#include <limits.h>

int best_prod_indices(int *arr, int len, int *seti, int *setj){
  if(len < 2){
    return INT_MIN;
  }
  int besti=0, bestj=1, best=arr[0]*arr[1];
  for(int i=0; i<len-1; i++){
    for(int j=i+1; j<len; j++){
      int prod = arr[i]*arr[j];
      if(prod > best){
        best = prod;
        besti = i;
        bestj = j;
      }
    }
  }
  *seti = besti;
  *setj = bestj;
  return best;
}
