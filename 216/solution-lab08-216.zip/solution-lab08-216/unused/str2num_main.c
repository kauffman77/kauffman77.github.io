#include <stdio.h>

int str2num(char *str);
int main(int argc, char *argv[]){
  int a = str2num("123");
  printf("a: %d\n",a);

  int b = str2num("-20694");
  printf("b: %d\n",b);

  int c = str2num("90210");
  printf("c: %d\n",c);

  int d = str2num("-7865309");
  printf("d: %d\n",d);

  int sum = a+b+c+d;
  printf("sum: %d\n",a+b+c+d);
  return 0;
}
