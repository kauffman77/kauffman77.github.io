#define ERROR -1

void clobber_regs();
int str2num(char *str){
  if(str[0] == '\0'){
    return ERROR;
  }
  int negate = 0;
  int i = 0;
  if(str[0] == '-'){
    negate = 1;
    i++;
  }
  int num = 0;
  for(i; str[i]!='\0'; i++){
    char digit = str[i];
    if(digit < '0' || digit > '9'){
      return ERROR;
    }
    digit = digit - '0';
    num = num*10 + digit;
  }
  if(negate){
    num = -num;
  }
  return num;
}
