#include <stdio.h>
// int arr1[5] = { 10, 20, 30, 40, 50};
// int arr2[5] = { 60, 70, 80, 90,100};
// int arr3[5] = {110,120,130,140,150};
// int arr4[5] = {160,170,180,190,200};
// int arr5[5] = {210,220,230,240,250};
// int arr6[5] = {260,270,280,290,300};

// int dot(int *a, int *b, int len){
//   int sum = 0;
//   for(int i=0; i<len; i++){
//     sum += a[i] * b[i];
//   }
//   return sum;
// }

int best_prod_indices(int *arr, int len, int *seti, int *setj);

int arr1[10] = {-6, -4, -10, -8, -5, 6, 10, -8, 7, -9};
int arr2[10] = {10, 6, -6, -2, -2, -3, -1, -9, -5, -6};
int arr3[10] = {3, -7, 6, -7, 2, 1, -2, -6, -1, -4};

int main(int argc, char *argv[]){

  int i1,j1, i2,j2, i3,j3;
  int prod1 = best_prod_indices(arr1, 10, &i1, &j1);
  int prod2 = best_prod_indices(arr2, 10, &i2, &j2);
  int prod3 = best_prod_indices(arr3, 10, &i3, &j3);
  
  // int prod1 = arr1[i1] * arr1[j1];
  // int prod2 = arr2[i2] * arr2[j2];
  // int prod3 = arr3[i3] * arr3[j3];

  printf("1: best_prod is %d * %d = %d\n",arr1[i1],arr1[j1],prod1);
  printf("2: best_prod is %d * %d = %d\n",arr2[i2],arr2[j2],prod2);
  printf("3: best_prod is %d * %d = %d\n",arr3[i3],arr3[j3],prod3);

  return 0;
}
