// This is a C version of the add2strs() function for
// reference. Several assembly versions are studied in this lab. 
int convert(char *str);

int add2strs(char *astr, char *bstr){
  int anum = convert(astr);
  int bnum = convert(bstr);
  int sum = anum+bnum;
  return sum;
}
