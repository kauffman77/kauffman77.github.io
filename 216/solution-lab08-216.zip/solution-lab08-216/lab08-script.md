# Wed : Makefiles
- Discuss basic syntax of Makefiles surveyed in lab web page; students
  will have seen this in lecture but will likely need a refresher to
  stay oriented
- Discuss examples provided in subdirectories
  - makeproblem-demo-little/Makefile : simplest version for
    small project
  - makeproblem-demo-little/Makefile-shortcuts : introduces
    variables and pattern rules; DON'T spend a lot of time on this,
    just mention that like most programmatic systems, Makefiles have
    more features
  - makeproblem-demo-big/Makefile : larger version, verbose as
    it doesn't use any shortcuts
  - makeproblem-demo-big/Makefile-shortcuts : good use of variables
    and pattern rules to make the Makefile shorter
- Direct students to complete the provided template in
  prob1-makefile/Makefile
- Discuss the @ syntax which will omit printing commands being run by
  the Makefile which can make output look a bit nicer; EXAMPLE:
```makefile
targ1 :
   echo "hello world"

targ2 :
   @echo "hello world"
```
Shell run:
```shell
>> make targ1
echo "hello world"    # prints command to be run
hello world           # prints output of comand

>> make targ2
hello world           # @ omits printing command, only output shown
```  

NOTE: Keep an eye on automated tests; they are a bit tricky to write
for Makefiles but this problem has worked okay

