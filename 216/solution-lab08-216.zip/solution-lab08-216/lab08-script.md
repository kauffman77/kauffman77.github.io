# Lab08 SCRIPT

## Mon: Problem 1 addstrs (caller / callee registers)
- Bring up a copy of the x86-64 General Purpose Register diagram which
  shows registers as Blue "Caller Save" and Tan "Callee Save"
- Mention to students that this distinction will be important in this
  lab
- Tour the C `main()` function and the `convert()` function in
  `add2strs_main.c`; show that the assembly code is called by `main()`
  and in turn calls `convert()`
- The above means that the `add2strs()` function is both a Callee and
  a Caller
- Download the lab code and run `make` to produce the 3 executables
  - A : `add2strs_main_a` based on assembly `add2strs_asm_a.s`, buggy
  - B : `add2strs_main_b` based on assembly `add2strs_asm_b.s`, buggy
  - C : `add2strs_main_a` based on assembly `add2strs_asm_c.s`, empty
- Run the A version via `./add2strs_main_a` and again under Valgrind
  to observe the Segfaults that result and answer the first few quiz
  questions
- Use `gdb add2strs_main_a` to step into the `add2strs()` function in
  the A version and show that many registers change after the `call
  convert` instruction; all the changed registers are Caller Save
  registers so the code in `add2strs()` is faulty as it assumes these
  registers will not change but they can and do
- Again run the B version via `./ad2strs_main_b` and again under
  Valgrind noting this time that the problems occur in `main()`
- Examine the code in `add2strs_asm_b.s` and illustrate from the
  comments that the intent is to use Callee save registers to preserve
  pointers / values across the function call boundary for `convert()`
- Use `gdb add2strs_main_b` to step through the function and show that
  using the callee save registers works to preserve data across the
  functino call boundary of `convet()` BUT on returning from
  `add2strs()`, `main()` also expects that registers like `%rbp` will
  not have changed - use the `layout asm` to show the assembly
  instructions associated with the C code in `main()`
- The problem now is to save/restore the Callee save registers use
  during `add2strs()`
- Let students work on a correct version in `add2strs_asm_c.s`; remind
  them about the push/pop instructions and also that stack alignment
  is still needed (not aligning the stack may work fine on Grace but
  fail on other machines like Gradescope)
  
## Wed: Problem 2 prime_funcs (global variables in assembly)
- Use `make` to compile the lab code and briefly run the
  `prime_main_c` program which combines a `main()` with calls to the
  functions in `prime_funcs.c` to produce its output
- Indicate that the task will be to finish an assembly function
  version of one of the functions in `prime_funcs_asms.`
- Pull up `prime_funcs.c` and `prime_funcs_asm.s` Side By Side to
  compare then
- Focus attention first on the overall structure of the assembly file
  which has 3 functions declared in a `.text` section and a global
  variable `primes` which is an array of integers at the end in a
  `.data` section; note that these two sections are for Executable
  Code (Text) and Global Variables (Data)
- Turn attention to comparing the C/Assembly implementations of
  `primprod()` 
- Discuss how the multi-part OR condition is handled in assembly (a
  QUIZ question); you can note that this is NOT the only way to handle
  this but is a straight-forward method to do so
- Discuss the syntax for loading a global variable's address (a QUIZ
  question) and how it uses an offset from the RIP. This is a "modern"
  technique (only 20-ish years old) that helps with security and will
  be discussed in lecture. Student only need to understand that to use
  global variables, they must employ this `NAME(%rip)` syntax.
- Mention that since the global variable in this case is an Array, it
  is most prudent to load an address for that array into a register
  the use the `(%base,%index,size)` addressing mode to access array
  elements in it (a QUIZ question)
- Give students time to work on completing the CODE portion, a second
  function which uses similar techniques but involves a loop
- Mention at the end that those wanting more practice can complete the
  OPTIONAL code problem
  

