# Lab08 SCRIPT

## Mon: Demo for Lab08
- Bring up a copy of the x86-64 General Purpose Register diagram which
  shows registers as Blue "Caller Save" and Tan "Callee Save"
- Mention to students that this distinction will be important in this
  lab
- Tour the C `main()` function and the `convert()` function in
  `add2strs_main.c`; show that the assembly code is called by `main()`
  and in turn calls `convert()`
- The above means that the `add2strs()` function is both a Callee and
  a Caller
- Download the lab code and run `make` to produce the 3 executables
  - A : `add2strs_main_a` based on assembly `add2strs_asm_a.s`, buggy
  - B : `add2strs_main_b` based on assembly `add2strs_asm_b.s`, buggy
  - C : `add2strs_main_a` based on assembly `add2strs_asm_c.s`, empty
- Run the A version via `./add2strs_main_a` and again under Valgrind
  to observe the Segfaults that result and answer the first few quiz
  questions
- Use `gdb add2strs_main_a` to step into the `add2strs()` function in
  the A version and show that many registers change after the `call
  convert` instruction; all the changed registers are Caller Save
  registers so the code in `add2strs()` is faulty as it assumes these
  registers will not change but they can and do
- Again run the B version via `./ad2strs_main_b` and again under
  Valgrind noting this time that the problems occur in `main()`
- Examine the code in `add2strs_asm_b.s` and illustrate from the
  comments that the intent is to use Callee save registers to preserve
  pointers / values across the function call boundary for `convert()`
- Use `gdb add2strs_main_b` to step through the function and show that
  using the callee save registers works to preserve data across the
  functino call boundary of `convet()` BUT on returning from
  `add2strs()`, `main()` also expects that registers like `%rbp` will
  not have changed - use the `layout asm` to show the assembly
  instructions associated with the C code in `main()`
- The problem now is to save/restore the Callee save registers use
  during `add2strs()`
- Let students work on a correct version in `add2strs_asm_c.s`; remind
  them about the push/pop instructions and also that stack alignment
  is still needed (not aligning the stack may work fine on Grace but
  fail on other machines like Gradescope)
  
## Wed: HW08 #3 Discussion and Project Help
- Discuss HW08 Problem 3: Valgrind Debugging Assembly for 15-20min
- Open the code `badstack.c` which is correct and `badstack_asm.s`
  which has errors
- Compile and run the C version to show intended behavior
- Compile and run the ASM version to show segfaults
- Compile via `gcc -g badstack_asm.s` then run via `valgrind ./a.out`
  to show more detailed memory errors
- Focus student attention on the Valgrind error messages
- Give students 2-3min with both code and error message displayed to
  discuss what the problem might be; solicit answers and discuss them
- Make corrections to the buggy code to fix the problems: initial
  version overwrites return address with local variable values so need
  to grow the stack in `main` to make space for local variables then
  shrink it before returning

Remaining time should questions from students and provide support to
help students complete Project 3 and Lab08.

