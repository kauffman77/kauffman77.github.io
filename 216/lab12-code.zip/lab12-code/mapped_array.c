#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>

typedef struct{
  int *data;             // pointer to memory mapped region
  int count;             // count of integers in data; <= capacity
  int pages;             // total pages allocated for the array
} mappedarr_t;

#define PAGEBYTES 4096   // bytes in a page; can be gotten via sysconf(PAGESIZE)

// intitializes a single page of memory for the array
int mappedarr_init(mappedarr_t *marr, int *start_address, int init_count){
  // calculates number of pages required using a bit of arithmetic; OS
  // can only map page-sized chunks into virtual memory 
  int init_pages = (init_count*sizeof(int) + PAGEBYTES-1) / PAGEBYTES;
  // printf("Mapping addres %p for %d ints with %d pages\n",
  //        start_address, init_count, init_pages);
  
  // call mmap() with options that reflect usage. Pass MAP_FIXED
  // option so that if `start_addresss1 it is not available, MAP_FAIL
  // is returned by mmap() and this funcion returns -1. Mapped memory
  // is not associated with any file and is only used by this proc,
  // will read/write the page bytes as normal data.
  marr->data =
    mmap(start_address, init_pages*PAGEBYTES,     // map to start address, enough bytes for `count`
         PROT_READ | PROT_WRITE,                  // can read and write this mapped block
         MAP_PRIVATE | MAP_ANONYMOUS,             // not shared or tied to a file
         -1, 0);                                  // default options for anonymous block

  if(marr->data != start_address){                // failure to map start_address
    printf("Failed mapping for address %p of %d pages\n",
           start_address, init_pages);
    if(marr->data == MAP_FAILED){
      perror("mmap() failed");                    // report system error cause
    }
    else{
      printf("  Mapped pages at alternate address\n");
      munmap(marr->data,init_pages*PAGEBYTES);    // mapped to a different address; unmap()
    }
    return -1;
  }

  // initialize remaining fields of `marr` to indicate its count of
  // integers and number of mapped pages; return 1 for success
  marr->count = init_count;
  marr->pages = init_pages;
  printf("Created marr at %p for %d ints / %ld bytes and %d pages\n",
         marr->data, marr->count, marr->count*sizeof(int), marr->pages);
  return 1;
}

// map additional pages onto the end of `marr->data` if possible to
// extend the array and accomodate more data without copying over the
// entire array; on failures `marr` is left unchanged and 0 is
// returned. If the expansion fails due to the needed virtual
// addresses being unavialable, `marr` is left unchanged and -1 is
// returned. Otherwise new pages are added on the end of the array and
// 1 is returned.
//
// TODO: Complete this function
int mappedarr_resize(mappedarr_t *marr, int new_count){
  // TODO: Calculate number of additional pages to map on top of those
  // already mapped for the array.
  int new_pages = 0;
  printf("Current pages: %d, Required pages: %d\n",
         marr->pages, new_pages);

  // TODO: Check if NOT expanding (e.g. current number of pages is
  // sufficient). Only adjust the internal `count` field if no
  // expanding.
  if(0){
    printf("Sufficient pages for requested size, no changes made\n");
    marr->count = 0;            // could munmap() pages here to reflect smaller size
    return 0;                   // but that's an optimization for a different day
  }
  
  // TODO: Calculate the desired start address AFTER the currently
  // allocated pages. WARNING: this is pointer arithmetic that will be
  // scaled by the compiler UNLESS one caste's data to the (char *)
  // type which does pointer arithmetic with size of 1.
  void *start_address = NULL;
  int add_pages = 0;            // number of pages to add on

  // TODO: Call mmap() with appropriate options to map new pages at
  // the end of the existing array to expand it.
  void *added_address = 
    NULL;     //mmap(...);

  // TODO: Check for failure to map the desired address which makes it
  // imposible to expand the array in place.
  if(0){
    printf("Failed expansion to address %p with %d pages\n",
           start_address, add_pages);              

    {
      perror("  mmap() failed");                  // report system error cause
    }
    {
      printf("  Mapped pages at alternate, non-contiguous address\n");
    }
    return -1;
  }

  // Report successful expansion and update fields accordingly
  printf("Expanded to address %p adding %d pages\n",
         start_address, add_pages);
  marr->count = new_count;                        // update count/pages mapped
  marr->pages = new_pages;
  return 1;
}
  
// Deallocate the array by unmapping pages associated from memory
int mappedarr_deallocate(mappedarr_t *marr){
  printf("Unmapping %p with %d pages\n",
         marr->data, marr->pages);
  int ret = munmap(marr->data, marr->pages*PAGEBYTES);
  if(ret == -1){
    perror("Unmap failed");
    return -1;
  }
  return 1;
}  

// Do some basic operations with some mapped arrays and print results
// for testing
int main(int argc, char *argv[]){
  mappedarr_t marr1;
  void *start1 = (void *) 0x0000600000000000;
  mappedarr_init(&marr1, start1, 200);
  marr1.data[100] = 1;
  marr1.data[199] = 2;

  mappedarr_resize(&marr1, 800);

  marr1.data[500] = 3;
  marr1.data[799] = 4;

  mappedarr_resize(&marr1, 3000);
  marr1.data[2500] = 5;
  marr1.data[2999] = 6;

  mappedarr_resize(&marr1, 4100);
  marr1.data[3500] = 7;
  marr1.data[3999] = 8;

  mappedarr_resize(&marr1, 4200);
  marr1.data[4000] =  9;
  marr1.data[4199] = 10;

  mappedarr_t marr2;
  void *start2 = (void *) 0x0000610000002000;
  mappedarr_init(&marr2, start2, 1000);
  mappedarr_resize(&marr2, 9000);

  mappedarr_t marr3;
  void *start3 = (void *) 0x0000610000000000;
  mappedarr_init(&marr3, start3, 2000);
  mappedarr_resize(&marr3, 3000);

  if(argc > 1){                                   
    printf("PID: %d\n",getpid());                 // print PID to allow use of
    printf("press any key to continue\n");        // pmap on the process to its pages
    getc(stdin);                                  // pause for debugging
  }  
  
  mappedarr_deallocate(&marr1);
  mappedarr_deallocate(&marr2);
  mappedarr_deallocate(&marr3);

  return 0;
}
