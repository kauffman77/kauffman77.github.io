// Compare performance of single / multi-threaded column summing

#include "csums_thread.h"

struct timeval beg_time, end_time;
clock_t begin, end;

void timing_start(){
  // begin = clock();
  gettimeofday(&beg_time, NULL);
}

double timing_stop(){
  // end = clock();
  // double cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;

  gettimeofday(&end_time, NULL);
  double wall_time = 
    ((end_time.tv_sec-beg_time.tv_sec)) + 
    ((end_time.tv_usec-beg_time.tv_usec) / 1000000.0);
  return wall_time;             // real-world time
}

int REPEATS = 10;               // repetitions to average
int WARMUP  =  2;               // warmup iterations to warm cache

int main(int argc, char *argv[]){
  if(argc < 4){
    printf("usage: %s <rows> <cols> <thread_count>\n",argv[0]);
    return 1;
  }
  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);
  int thread_count = atoi(argv[3]);

  // Allocate the matrix and fill it in with 1,2,3,4...
  matrix_t mat;
  int ret = matrix_init(&mat, rows,cols);
  if(ret){ return ret; }
  matrix_fill_sequential(mat);

  // COL SUMS SINGLE THREADED
  vector_t ssums;
  vector_init(&ssums, mat.cols);
  vector_fill_sequential(ssums);
  
  double wall_time_SINGLE = 0.0;
  for(int i=0; i<WARMUP; i++){
    ret = col_sums_single(mat,ssums);
  }
  for(int i=0; i<REPEATS; i++){
    timing_start();
    ret = col_sums_single(mat,ssums);
    wall_time_SINGLE += timing_stop();
  }
  printf("%16s wall time: %10.4e sec\n",
         "col_sums_single",wall_time_SINGLE);
  
  // COL SUMS THREADED
  vector_t tsums;
  vector_init(&tsums, mat.cols);
  vector_fill_sequential(tsums);
  double wall_time_THREADED = 0.0;
  for(int i=0; i<WARMUP; i++){
    ret = col_sums_threaded(mat,tsums,thread_count);
  }
  for(int i=0; i<REPEATS; i++){
    timing_start();
    ret = col_sums_threaded(mat,tsums,thread_count);
    wall_time_THREADED += timing_stop();
  }
  printf("%16s wall time: %10.4e sec\n",
         "col_sum_threaded",wall_time_THREADED);

  double speedup = wall_time_SINGLE / wall_time_THREADED;
  printf("%d threads speedup: %.2f\n",
         thread_count,speedup);

  // ensure threaded answer is correct vs standard
  for(int i=0; i<ssums.len; i++){
    int ss = VGET(ssums,i);    
    int ts = VGET(tsums,i);
    if(ss != ts){
      printf("ERROR: opt_col_sums produced incorrect results\n");
      printf("Element %d: expect %d  actual %d\n",i,ss,ts);
      break;
    }
  }

  matrix_free_data(&mat);       // clean up data
  vector_free_data(&ssums);
  vector_free_data(&tsums);

  return 0;
}
