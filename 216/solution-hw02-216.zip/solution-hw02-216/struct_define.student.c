// struct_define.c: Fill in a struct defition and use of it below
#include <stdio.h>


// cats have these fields
// 1. an integer views which is how many views/likes they have
// 2. a double precision floating point weight in pounds (lbs)
// 3. an short integer age
// 4. a character is_active indicating 'Y' is still actie only or 'N' otherwise
// 5. a character is_grumpy indicating 'Y' or 'N'
//
// YOUR DEFINITION OF A CAT STRUCT HERE

int main(int argc, char *argv[]){
  cat_t nyancat;
  nyancat.views = 205000000;    // on youtube
  nyancat.weight_lbs = 0.1;     // he's flying so minimal
  nyancat.age = 14;             // born 2011
  nyancat.is_active = 'Y';      // forever and ever...
  nyancat.is_grumpy = 'N';      // never ever

  cat_t grumpycat;
  grumpycat.views = 8300000;    // on facebook
  grumpycat.weight_lbs = 7.5;   // approximately...
  grumpycat.age = 13;           // born 2012
  grumpycat.is_active = 'N';    // we miss you...
  grumpycat.is_grumpy = 'Y';    // of course

  // print fields of the two cats here; %hd will print a short in
  // printf(); look up other format specifiers for the other field
  // types
  // YOUR CODE HERE

  return 0;
}
// EXPECTED OUTPUT
// nyancat: views 205000000 weight: 0.100000 age: 14 active: Y grumpy: N
// grumpycat: views 8300000 weight: 7.500000 age: age 13 active: N grumpy: Y

