// SOLUTION struct_define.c: Fill in a struct defition and use of it below

#include <stdio.h>
// cats have these fields
// 1. an integer views which is how many views/likes they have
// 2. a double precision floating point weight in pounds (lbs)
// 3. an short integer age
// 4. a character is_active indicating 'Y' is still actie only or 'N' otherwise
// 5. a character is_grumpy indicating 'Y' or 'N'
//
// YOUR DEFINITION OF A CAT STRUCT HERE

typedef struct {
  int views;
  double weight_lbs;
  short age;
  char is_active;
  char is_grumpy;
} cat_t;


// reduces the weight of the cat to 90% of what it was
void cat_diet(cat_t *cat){
  cat->weight_lbs = cat->weight_lbs * 0.9;
}

// prints all fields of the cat using a format like the following
// views 205000000 weight: 0.100000 age: 14 active: Y grumpy: N
void cat_print(cat_t *cat){
  printf("views %d weight: %f age: age %hd active: %c grumpy: %c\n",
         cat->views, cat->weight_lbs,
         cat->age, cat->is_active, cat->is_grumpy);
}  

// age goes up by one and due to a viral birthday video, views doubles
void cat_birthday_viral(cat_t *cat){
  cat->age++;
  cat->views = cat->views*2;
}


// in main(), after data is initialzed as before, grumpycat goes on a
// diet, nyancat has a viral birthday, and both cats are printed using
// the new printing function.
int main(int argc, char *argv[]){
  cat_t nyancat;
  nyancat.views = 205000000;    // on youtube
  nyancat.weight_lbs = 0.1;     // he's flying so minimal
  nyancat.age = 14;             // born 2011
  nyancat.is_active = 'Y';      // forever and ever...
  nyancat.is_grumpy = 'N';      // never ever

  cat_t grumpycat;
  grumpycat.views = 8300000;    // on facebook
  grumpycat.weight_lbs = 7.5;   // approximately...
  grumpycat.age = 13;           // born 2012
  grumpycat.is_active = 'N';    // we miss you...
  grumpycat.is_grumpy = 'Y';    // of course

  cat_diet(&grumpycat);
  cat_birthday_viral(&nyancat);
  cat_print(&nyancat);
  cat_print(&grumpycat);

  return 0;
}
// EXPECTED OUTPUT
// views 410000000 weight: 0.100000 age: age 15 active: Y grumpy: N
// views 8300000 weight: 6.750000 age: age 13 active: N grumpy: Y

