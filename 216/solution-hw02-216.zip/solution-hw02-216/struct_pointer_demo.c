#include <stdio.h>

typedef struct {                // most common syntax; declares new type mytype_t
  int an_int_field;
  double a_double_field;
  char *a_char_ptr_field;
} mytype_t;

void mytype_halve_double(mytype_t *mine){
  mine->a_double_field = mine->a_double_field / 2.0;
}

int main(int argc, char *argv[]){
  mytype_t mine1;               // first struct
  mine1.an_int_field = 5;
  mine1.a_double_field = 11.6;
  char mychar = 'h';
  mine1.a_char_ptr_field = &mychar;

  mytype_halve_double(&mine1);

  // print out the fields of the two structs
  printf("mine1: %d %f %p\n",
         mine1.an_int_field, mine1.a_double_field, mine1.a_char_ptr_field);

  return 0;
}
