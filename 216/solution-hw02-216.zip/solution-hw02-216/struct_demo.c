#include <stdio.h>

typedef struct {                // most common syntax; declares new type mytype_t
  int an_int_field;
  double a_double_field;
  char *a_char_ptr_field;
} mytype_t;

typedef struct othertype {      // variant used when a pointer to the type being
  int first_field;              // defined is required such as in linked lists
  char second_field;
  struct othertype *pointer_field;
} othertype_t;  

int main(int argc, char *argv[]){
  mytype_t mine1;               // first struct
  mine1.an_int_field = 5;
  mine1.a_double_field = 11.6;
  char mychar = 'h';
  mine1.a_char_ptr_field = &mychar;

  mytype_t mine2;               // second struct
  mine2.an_int_field = 222;
  mine2.a_double_field = 333.4;
  mine2.a_char_ptr_field = &mychar; // points to same place as first struct does

  // print out the fields of the two structs
  printf("mine1: %d %f %p\n",
         mine1.an_int_field, mine1.a_double_field, mine1.a_char_ptr_field);
  printf("mine2: %d %f %p\n",
         mine2.an_int_field, mine2.a_double_field, mine2.a_char_ptr_field);

  return 0;
}
