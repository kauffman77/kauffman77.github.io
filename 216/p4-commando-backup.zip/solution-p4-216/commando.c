// commando.c: main routine for the commando program.

#include "commando.h"

// Check for a valid job in from main loop and return job if one is
// given. Otherwise error out.
cmd_t *get_cmd(int ntoks, char *tokens[], cmdcol_t *col, char *builtin){
  if(ntoks < 2){
    printf("ERROR: %s id : need a job id\n",builtin);
    return NULL;
  }
  int job = atoi(tokens[1]);
  if(job >= col->size){
    printf("No job %d\n",job);
    return NULL;
  }
  return col->cmd[job];
}


void commando_output(cmd_t *cmd){
  printf("@<<< Output for %s[#%d] (%d bytes):\n",
         cmd->name,cmd->pid,cmd->output_size);
  printf("----------------------------------------\n");
  cmd_print_output(cmd);
  printf("----------------------------------------\n");
}

char *helps[] = {
  "help","show this message",
  "exit","exit the program",
  "list","list all jobs that have been started giving information on each",
  "pause nanos secs","pause for the given number of nanseconds and seconds",
  "output-for int","print the output for given job number",
  "output-all","print output for all jobs",
  "wait-for int","wait until the given job number finishes",
  "wait-all","wait for all jobs to finish",
  "command arg1 ...","non-built-in is run as a job",
  NULL
};

void commando_help(){
  printf("COMMANDO COMMANDS\n");
  for(int i=0; helps[i]!=NULL; i+=2){
    printf("%-18s : %s\n",helps[i],helps[i+1]);
  }
}

int main(int argc, char *argv[]){
  setvbuf(stdout, NULL, _IONBF, 0); // Turn off buffering

  // dup2(STDOUT_FILENO, STDERR_FILENO);

  int echo = 0;                 // Check for command echoing
  if(argc > 1 && strcmp(argv[1],"--echo")==0){
    echo = 1;
  }
  if(getenv("COMMANDO_ECHO") != NULL){
    echo = 1;
  }

  cmdcol_t cmdcol1 = {};            // Initialie to zeros
  cmdcol_t *col = &cmdcol1;         // Easy handle for passing as argument

  // col = NULL;                       // obvious bug for testing

  while(1){
    char input_command[MAX_LINE+1]; // Buffers to re-use for reading
    char *tokens[ARG_MAX+1];

    printf("@> ");

    char *ret = fgets(input_command,MAX_LINE,stdin); // get input line
    if(ret == NULL){                                 // NULL on end of input
      printf("\nEnd of input\n");
      break;
    }

    if(echo){                   // echo if on
      printf("%s",input_command);
    }

    int ntoks;
    parse_into_tokens(input_command,tokens,&ntoks); // split up the line
    if(ntoks == 0){
      // printf("No tokens\n");
    }
    else if(strncmp("help",tokens[0],MAX_LINE)==0){ // list all running jobs 
      commando_help();
    }
    else if(strncmp("list",tokens[0],MAX_LINE)==0){ // list all running jobs 
      cmdcol_print(col);
    }
    else if(strncmp("exit",tokens[0],MAX_LINE)==0){ // exit
      break;
    }
    else if(strncmp("pause",tokens[0],MAX_LINE)==0){ // pause for given nanos / secs
      int nanos = atoi(tokens[1]);
      int secs = (ntoks>=3 ? atoi(tokens[2]) : 0);
      pause_for(nanos,secs);
    }
    else if(strncmp("wait-for",tokens[0],MAX_LINE)==0){ // wait for given job to complete
      cmd_t *cmd = get_cmd(ntoks, tokens, col, "waitfor");
      if(cmd != NULL && !(cmd->finished)){
        cmd_update_state(cmd, DOBLOCK);
      }
    }
    else if(strncmp("wait-all",tokens[0],MAX_LINE)==0){ // wait for all jobs to finish
      for(int i=0; i<col->size; i++){
        cmd_t *cmd = col->cmd[i];
        cmd_update_state(cmd, DOBLOCK);
      }
    }
    else if(strncmp("output-for",tokens[0],MAX_LINE)==0){ // show output for specified job
      cmd_t *cmd = get_cmd(ntoks, tokens, col, "waitfor");
      if(cmd != NULL){
        commando_output(cmd);
      }
    }
    else if(strncmp("output-all",tokens[0],MAX_LINE)==0){ // output for all jobs
      for(int i=0; i<col->size; i++){
        cmd_t *cmd = col->cmd[i];
        commando_output(cmd);
      }
    }
    else if(strncmp("remove",tokens[0],MAX_LINE)==0){ // undocumented remove
      int index = atoi(tokens[1]);
      cmd_free(col->cmd[index]);
      col->size--;
      for(int i=index; i<col->size; i++){
        col->cmd[i] = col->cmd[i+1];
      }        
    }
    else{
      cmd_t *cmd = cmd_new(tokens);            // Create cmd with given argv, pass input for stdin
      cmdcol_add(col, cmd);
      cmd_start(cmd);
    }
    cmdcol_update_state(col,NOBLOCK);
  }
  // end main control loop

  // printf("END MAIN LOOP\n");
  // printf("\n");

  // printf("WAITING on remaining children\n");
  // cmdcol_update_state(col,DOBLOCK);

  // printf("OUTPUT\n");
  // for(int i=0; i<col->size; i++){
  //   cmd_t *cmd = col->cmd[i];
  //   cmd_fetch_output(cmd);
  //   printf("%d: output for %s[%d] (%d bytes):\n",
  //          i,cmd->cmd,cmd->pid,cmd->output_size);
  //   printf("========================\n");
  //   cmd_print_output(cmd);
  //   printf("========================\n");
  //   printf("\n");
  // }  

  // printf("FINAL STATES\n");
  // cmdcol_print(col);

  // commando_output(col->cmd[col->size]);

  // printf("Parent cleaning up\n");
  for(int i=0; i<col->size; i++){
    cmd_free(col->cmd[i]);
  }


  return 0;
}

