{
  char input[1024] = "ls -l -A test-results/";
  char *tokens[ARG_MAX];        // will be set by parse..()
  int ntoks;                    // will be set by parse..()

  parse_into_tokens( input, tokens, &ntoks);

  // effect of parse_into_tokens() on the above data
  tokens[0] == "ls";
  tokens[1] == "-l";
  tokens[2] == "-A";
  tokens[3] == "test-results/";
  ntoks     == 4;
}
