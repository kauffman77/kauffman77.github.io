#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


int main(){
  fprintf(stdout, "Execing a program\n");

  execlp("foobar","ls","-l",NULL);

  perror("Couldn't exec");

  int fd = open("/home/kauffman/not-there.txt", O_RDONLY);

  if(fd == -1){
    perror("couldn't open file");
  }
 
  return 1;
}
  
