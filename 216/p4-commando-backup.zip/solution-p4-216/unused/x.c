

void cmd_update_state(cmd_t cmd, int block_options){
  ...;

  int status;                     
  waitpid(pid, &status, WNOHANG); // from block_options
  // if ret==0: process is not done, status has not be set, DON'T call WIFEXITED()
  // if ret==pid: process IS done, proceed

  if(WIFEXITED(status)){
    ...;
  }
    

  pid_t pid = ...;
  int status = -11111;
  int ret = waitpid(pid, &status, WNOHANG);
  
  if(ret == -1){
    perror("waitpid() failed\n");
    exit(1);
  }
  else if(ret == 0){
    // pid process is NOT complete
    // status is still -11111
    // DON'T call WIFEXITED(status)
  }
  else if(ret == pid){
    // pid process is complete
    // status has been changed
    if(WIFEXITED(status)){  // safe to check on exit status
      ...;
    }
  }
  else {
    // this shouldn't happen...
  }
    
  
