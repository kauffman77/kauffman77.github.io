// Sample children
childcmd_t child1 = {
  .cmd = "gcc",
  .argv = {"gcc", "--help", (char *)NULL},
  .pid = -1,
  .status = 0,
};
childcmd_t child2 = {
  .cmd = "ls",
  .argv = {"ls", "-lF", "-a", "..", (char *)NULL},
  .pid = -1,
  .status = 0,
};

