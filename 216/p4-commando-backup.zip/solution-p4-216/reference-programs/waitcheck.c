#include "commando.h"
#include <time.h>

void wait_check(pid_t pid, int nohang){
  int status = 0;
  int options = WCONTINUED | WUNTRACED | (nohang ? WNOHANG : 0);
  pid_t ret = waitpid(pid, &status, options);
  printf("%s ret: %d ",(nohang ? "no" : "bl"), ret);
  if(pid != ret){
    printf("no change\n");
    return;
  }
  if(WIFEXITED(status)){                            // exited?
    int exit_status = WEXITSTATUS(status);          // get status
    printf("EXIT(%d)\n",exit_status);
  } else if(WIFSIGNALED(status)){                   // signaled?
    int term_signal = WTERMSIG(status);             // which signal
    printf("SIG(%d)\n",term_signal);
  } else if(WIFSTOPPED(status)){                    // stopped?
    int stop_signal = WSTOPSIG(status);             // which signal
    printf("STOP(%d)\n",stop_signal);
  } else if(WIFCONTINUED(status)){                  // continued
    printf("RUN/CONT\n");
  } else{                                                // must be running
    printf("RUN\n");
  }
}

int main(int argc, char *argv[]){
  printf("Starting\n");
  pid_t pid = fork();
  if(pid==0){                   // CHILD
    //printf("sleeping\n");
    struct timespec tm = {
      .tv_nsec = 100,
      .tv_sec  = 0,
    };
    nanosleep(&tm,NULL);
    return 1;
  }
  else{                         // PARENT
    struct timespec tm = {
      .tv_nsec = 1000000,
      .tv_sec  = 0,
    };
    printf("child pid: %d\n",pid);
    wait_check(pid,1);
    nanosleep(&tm,NULL);
    wait_check(pid,1);
    wait_check(pid,0);
    wait_check(pid,1);
    wait_check(pid,1);
    wait_check(pid,0);
  }
  return 0;
}
