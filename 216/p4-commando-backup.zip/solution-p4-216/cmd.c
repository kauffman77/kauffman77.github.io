// cmd.c: functions related the cmd_t struct abstracting a
// command. Most functions maninpulate cmd_t structs.

#include "commando.h"

#define EXEC_FAIL 128

// Allocates a new cmd_t with the given argv[] array. Makes string
// copies of each of the strings contained within argv[] using
// strdup() as they likely come from a source that will be
// altered. Ensures that cmd->argv[] is ended with NULL. Sets the name
// field to be the argv[0]. Sets finished to 0 (not finished yet). Set
// str_status to be "INIT" using snprintf(). Initializes the remaining
// fields to obvious default values such as -1s, and NULLs.
cmd_t *cmd_new(char *argv[]){
  cmd_t *cmd = malloc(sizeof(cmd_t));                    // allocate struct
  strncpy(cmd->name, argv[0], NAME_MAX);                 // copy 0th of argv which should always be ther
  int i;
  for(i=0; i<ARG_MAX && argv[i]!=NULL; i++){             // copy all argv elems over
    cmd->argv[i] = strdup(argv[i]);                      // need to free them later as they are malloc'd
  }
  cmd->argv[i] = NULL;                                   // must null terminate
  cmd->pid              = -1;                            // init remaining fields to semi-obvios
  cmd->out_pipe[PREAD]  = -1;                            // bogus values
  cmd->out_pipe[PWRITE] = -1;
  cmd->status           = -1;
  snprintf(cmd->str_status,STATUS_LEN,"INIT");
  cmd->finished         =  0;
  cmd->output           = NULL;
  cmd->output_size      = -1;
  return cmd;
}  

// Deallocates a cmd structure. Deallocates the strings in the argv[]
// array. Also deallocats the output buffer if it is not
// NULL. Finally, deallocates cmd itself.
void cmd_free(cmd_t *cmd){
  for(int i=0; i<ARG_MAX && cmd->argv[i]!=NULL; i++){    // free strings in argv
    free(cmd->argv[i]);
  }
  if(cmd->output != NULL){
    free(cmd->output);
  }
  free(cmd);                                             // free cmd itself
}

// Forks a process and executes command in cmd in the process.
// Changes the str_status field to "RUN" using snprintf().  Creates a
// pipe for out_pipe to capture standard output.  In the parent
// process, ensures that the pid field is set to the child PID. In the
// child process, directs standard output to the pipe using the dup2()
// command. For both parent and child, ensures that unused file
// descriptors for the pipe are closed (write in the parent, read in
// the child).
void cmd_start(cmd_t *cmd){
  if( pipe(cmd->out_pipe) == -1 ){                       // Create a pipe for cmd output
    perror("pipe creation error");
    exit(1);
  }
  snprintf(cmd->str_status,STATUS_LEN,"RUN");

  cmd->pid = fork();                                     // fork off child for cmd

  // PARENT CODE
  if(cmd->pid != 0){
    if(cmd->pid==-1){                                    // check for a fork error
      perror("Parent failed to fork cmd");
      exit(1);
    }
    if( close(cmd->out_pipe[PWRITE]) == -1 ){            // parent doesn't need to write
      perror("Parent failed to close write end of pipe");
      exit(1);
    }
    return;                                              // parent returns immediately
  }
  // CHILD CODE
  else{
    if( close(cmd->out_pipe[PREAD]) == -1 ){             // close read part of the pipe
      perror("Cmd failed to close read end of pipe");
      exit(1);
    }
    if( dup2(cmd->out_pipe[PWRITE], STDOUT_FILENO) == -1 ){ // redirect cmd output to pipe
      perror("Cmd failed to redirect output");
      exit(1);
    }
    if( dup2(cmd->out_pipe[PWRITE], STDERR_FILENO) == -1 ){ // redirect cmd output to pipe
      perror("Cmd failed to redirect output");
      exit(1);
    }
    if( close(cmd->out_pipe[PWRITE]) == -1 ){            // close write part of the pipe, now in STDOUT
      perror("Cmd failed to close write end of pipe");
      exit(1);
    }

    int result = execvp(cmd->name,cmd->argv);            // execute cmd command
    if(result == -1){
      perror("Cmd failed to start exec");
      exit(EXEC_FAIL);
    }
    printf("Shouldn't get here");                        // unreachable
    exit(1);
  }
}

// If the finished flag is 1, does nothing. Otherwise, updates the
// state of cmd.  Uses waitpid() and the pid field of command to wait
// selectively for the given process. Passes block (one of DOBLOCK or
// NOBLOCK) to waitpid() to cause either non-blocking or blocking
// waits.  Uses the macro WIFEXITED to check the returned status for
// whether the command has exited. If so, sets the finished field to 1
// and sets the cmd->status field to the exit status of the cmd using
// the WEXITSTATUS macro. Calls cmd_fetch_output() to fill up the
// output buffer for later printing.
//
// When a command finishes (the first time), prints a status update
// message of the form
//
// @!!! ls[#17331]: EXIT(0)
//
// which includes the command name, PID, and exit status.
void cmd_update_state(cmd_t *cmd, int block){
  if(cmd->finished){
    return;                                              // don't wait twice
  }      
  int status;
  pid_t ret = waitpid(cmd->pid, &status, block);         // "wait" w/ or w/o stopping
  if(ret != cmd->pid){                                   // status of child not changed
    return;                                              // exit immediately
  }
    
  if(WIFEXITED(status)){                                 // exited?
    int exit_status = WEXITSTATUS(status);               // get status
    if(exit_status == EXEC_FAIL){
      snprintf(cmd->str_status, STATUS_LEN, "EXEC FAIL");
    }
    else{
      snprintf(cmd->str_status, STATUS_LEN, "EXIT(%d)",exit_status);
    }
    cmd->status = exit_status;
    cmd->finished = 1;
  } else if(WIFSIGNALED(status)){                        // OPTIONAL: signaled?
    int term_signal = WTERMSIG(status);                  // which signal
    snprintf(cmd->str_status, STATUS_LEN, "SIG(%d)",term_signal);
    cmd->status = term_signal;
    cmd->finished = 1;
  } else if(WIFSTOPPED(status)){                         // OPTIONAL: stopped?
    int stop_signal = WSTOPSIG(status);                  // which signal
    snprintf(cmd->str_status, STATUS_LEN, "STOP(%d)",stop_signal);
    cmd->status = stop_signal;
  } else if(WIFCONTINUED(cmd->status)){                  // OPTIONAL: continued?
    snprintf(cmd->str_status, STATUS_LEN, "RUN/CONT");
  } else{                                                // must be running
    snprintf(cmd->str_status, STATUS_LEN, "RUN");
  }
  printf("@!!! %s[#%d]: %s\n",cmd->name,cmd->pid,cmd->str_status);

  if(cmd->finished){
    cmd_fetch_output(cmd);
  }
}

// Reads all input from the open file descriptor fd. Assumes
// character/text output and null-terminates the character output with
// a '\0' character allowing for printf() to print it later. Stores
// the results in a dynamically allocated buffer which may need to
// grow as more data is read.  Uses an efficient growth scheme such as
// doubling the size of the buffer when additional space is
// needed. Uses realloc() for resizing.  When no data is left in fd,
// sets the integer pointed to by nread to the number of bytes read
// and return a pointer to the allocated buffer. Ensures the return
// string is null-terminated. Does not call close() on the fd as this
// is done elsewhere.
char *read_all(int fd, int *nread){
  int out_size = BUFSIZE;                              // prepare to read in from out_pipe
  char *out_buf = malloc(BUFSIZE+1);                   // into a buffer for cmd output
  ssize_t bytes_read = 0;
  ssize_t total_bytes_read = 0;

  do{                                                  
    bytes_read = read(fd,                              // read from file descriptor
                      out_buf  + total_bytes_read,     // read in at this position
                      out_size - total_bytes_read);    // maximum read per iteration
    if(bytes_read > 0){                                
      total_bytes_read += bytes_read;                  // added more
    }
    if(total_bytes_read == out_size){                  // check if more space is needed
      out_size *= 2;                                   // double in size
      char *bigger = realloc(out_buf, out_size+1);     // realloc
      if(bigger == NULL){
        eprintf("Could not allocate larger output buffer for sized %d bytes\n",
                out_size);
        exit(1);
      }
      out_buf = bigger;                                // now have more buffer space
    }
  } while(bytes_read > 0);

  // out_buf = realloc(out_buf, total_bytes_read);        // shrink the buffer if needed
  *nread = total_bytes_read;
  out_buf[total_bytes_read] = '\0';
  return out_buf;
}

// If cmd->finished is zero, prints an error message with the format
// 
// ls[#12341] not finished yet
// 
// Otherwise retrieves output from the cmd->out_pipe and fills
// cmd->output setting cmd->output_size to number of bytes in
// output. Makes use of read_all() to efficiently capture
// output. Closes the pipe associated with the command after reading
// all input.
void cmd_fetch_output(cmd_t *cmd){
  if(!cmd->finished){
    printf("%s[#%d] not finished yet\n",cmd->name,cmd->pid);
    return;
  }
  if(cmd->output == NULL){                               // output not captured yet
    void *out_buf = NULL;
    int total_bytes_read = -1;
    out_buf = read_all(cmd->out_pipe[PREAD], &total_bytes_read);

    cmd->output = out_buf;                               // cmd gets output
    cmd->output_size = total_bytes_read;

    if( close(cmd->out_pipe[PREAD]) == -1 ){
      eprintf("Parent failed to close read end of pipe for %s[%d] : %s\n",
              cmd->name,cmd->pid,strerror(errno));
      exit(1);
    }
  }
}


// Prints the output of the cmd contained in the output field if it is
// non-null. Prints the error message
// 
// ls[#17251] : output not ready
//
// if output is NULL. The message includes the command name and PID.
void cmd_print_output(cmd_t *cmd){
  if(cmd->output==NULL){
    printf("%s[#%d] : output not ready\n",cmd->name,cmd->pid);
    return;
  }
  write(STDOUT_FILENO, cmd->output, cmd->output_size);
}

