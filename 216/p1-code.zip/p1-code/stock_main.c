// stock_main.c: Load a stock file and print it. 

#include "stock.h"

int main(int argc, char *argv[]){

  // PROVIDED: 2 arguments are required in addition to the program
  // name; if less 3 items appear on the command line, print the below
  // usage message with the name of the program and immediately return
  // with an "error" code of 1 to indicate the program did not run
  // normally.
  if(argc < 3){
    printf("usage: %s <stockfile> <max_height> [start] [stop]\n",argv[0]);
    return 1;
  }
  
  // PROVIDED: access the required command line arguemtns for the
  // filename and maxiumum height; convert the height to an integer
  // from its string representation with a conversion function
  char *filename = argv[1];      
  int max_width = atoi(argv[2]); // read width from the command line

  // REQUIRED: Create a new stock then load data from 'filename' into
  // that stock structure. If loading the stock fails, free the struct
  // and print the message
  //   Failed to load stock 'XXX', exiting
  // with XXX substituted for the file name. Then return 0.
  //
  // Note: load the stock here so that the size of its 'prices' array
  // is known and can be used in the next few steps.
  


  // REQUIRED: Check for the presence of additional command line
  // arguments by checing argc; if it is at least 4, then there will
  // be a start index to print; if it is 5 or more, then there is also
  // a stop index.  If these are not present, then the entire 'prices'
  // array of the stock should be printed.  It's best to set default
  // values for the initial and final printing indices and then check
  // for command line arguments that would modify these.



  // REQUIRED: Call function(s) to determine the High and Low prices
  // for the stock.



  // REQUIRED: Call function(s) to determine the best time to buy/sell
  // for the prices. If there is no vible buy/sell piont print the
  // message:
  //   No viable buy/sell point
  // and continue execution.  The printing and plotting functions need
  // to handle the case where there is no viable buy/sell point.



  // REQUIRED: call function(s) to print the stock and plot it based
  // on the range (initial/final index) determined above.



  // REQUIRED: free memory associated with the stock



  // PROVIDED: return 0 which indicates a successful run of the
  // program on Unix systems.
  return 0;
}
