// cmdline_args.c: demonstrates how main() receives command line
// arguments in the argv[] array and the number of arguments is
// conveyed in argc.  Try running this program with various numbers
// and kinds of command line arguments like the following examples
//
// >> gcc cmdline_args.c
// 
// >> ./a.out
// There are 1 command line arguments
// argv[0] is './a.out', ignoring...
// intopt is: 0
// 
// >> ./a.out apple
// There are 2 command line arguments
// argv[0] is './a.out', ignoring...
// argv[1] is 'apple', ignoring...
// intopt is: 0
// 
// >> ./a.out apple --theoption banana
// There are 4 command line arguments
// argv[0] is './a.out', ignoring...
// argv[1] is 'apple', ignoring...
// argv[2] is --theoption, turning on theoption
// argv[3] is 'banana', ignoring...
// The option was set: HURRAY!
// intopt is: 0
// 
// >> ./a.out --intopt 5 apple --theoption banana
// There are 6 command line arguments
// argv[0] is './a.out', ignoring...
// argv[1] is --intopt, setting intop to 5
// argv[3] is 'apple', ignoring...
// argv[4] is --theoption, turning on theoption
// argv[5] is 'banana', ignoring...
// The option was set: HURRAY!
// intopt is: 5

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]){

  int theoption = 0;
  int intopt = 0;
  printf("There are %d command line arguments\n",argc);
  for(int i=0; i<argc; i++){
    if( strcmp(argv[i],"--theoption")==0 ){
      printf("argv[%d] is --theoption, turning on theoption\n",i);
      theoption = 1;
    }
    else if( strcmp(argv[i],"--intopt")==0 ){
      printf("argv[%d] is --intopt, setting intop to %s\n",i,argv[i+1]);
      intopt = atoi(argv[i+1]);
      i++;
    }
    else{
      printf("argv[%d] is '%s', ignoring...\n",i,argv[i]);
    }
  }

  if(theoption){
    printf("The option was set: HURRAY!\n");
  }
  printf("intopt is: %d\n",intopt);
  return 0;
}
