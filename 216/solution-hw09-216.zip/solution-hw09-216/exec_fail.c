// exec_fail.c: checks that exec actually works properly (OPTIONAL CODE)
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
int main(void){
    char *child_argv[] = {"--version"}; // BUGGED
    // char *child_argv[] = {"gcc","--version",NULL};  // correct
    char *child_cmd = "gcc";
    printf("Running command '%s'\n",child_cmd);
    printf("------------------\n");
    int ret = execvp(child_cmd,child_argv);
    if(ret == -1){
      perror("exec() failed");
    }
    else{
      printf("------------------\n");
      printf("Child Finished\n"); // show that the child process has finished
    }
    return 0;
}
