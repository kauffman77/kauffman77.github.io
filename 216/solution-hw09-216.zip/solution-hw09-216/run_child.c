// run_child_solution.c: run a child process. This version correctly
// uses fork() to create a child process. It then waits for the child
// to finish before reporting as much.

#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void){

  char *child_argv[] = {"ls","-l","-ah",NULL};
  char *child_cmd = "ls";

  printf("Running command '%s'\n",child_cmd);
  printf("------------------\n");

  pid_t pid = fork();                 // fork a child
  if(pid == 0){                       // check if child or parent is running
    execvp(child_cmd,child_argv);     // only the child executes this code
  }                                   // only the parent executes code after the conditional

  wait(NULL);                         // wait for child to complete
  printf("------------------\n");
  printf("Child Finished\n");         // show that the child process has finished
  return 0;
}
  
