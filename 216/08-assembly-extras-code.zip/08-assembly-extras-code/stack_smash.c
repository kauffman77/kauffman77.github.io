// stack_smash.c: demonstrates problems with the function call stack
// which arise when writing past the data in the local frame. When
// compiled normally this code usually gives output like the following
// 
// > gcc stack_smash.c
// > ./a.out
// About to do the demo
// [0]: 2
// [1]: 4
// [2]: 6
// [3]: 8
// *** stack smashing detected ***: terminated
// Aborted (core dumped)
//
// One can disable the stack protections and see it run to completion
// via `gcc -fno-stack-protector stack_smash.c` but this does not mean
// the code will always behave properly.
#include <stdio.h>

void demo(){
  int arr[4];                   
  for(int i=0; i<8; i++){           // fill array off the end
    arr[i] = (i+1)*2;
  }

  for(int i=0; i<8; i++){           // print elements; w/o printing, compiler 
    printf("[%d]: %d\n",i,arr[i]);  // may optimize away the above loop
  }
}  

int main(){
  printf("About to do the demo\n");
  demo();
  printf("Demo Complete\n");
  return 0;
}
