// float_convert.c: compile via 'gcc -Og -S ...' to see conversion
// instructions inserted to interconvert between floating point and
// integer formats

long double2long(double x){
  long l = (long) x;
  return l;
}

double int2double(int i){
  double x = (double) i;
  return i;
}
