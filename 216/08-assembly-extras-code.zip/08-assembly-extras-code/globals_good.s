### globals_good.s: Demonstrates the modern syntax to access global
### variables. This uses indirect/rip-relative addressing of
### globals. A proper compile/run of this program yields the
### following
### 
### > gcc globals_good.s
### > ./a.out
### > echo $?
### 29        

.data
an_int:                               # single int
        .int 17
some_shorts:                          # array of shorts
	.short 10
        .short 12
        .short 14

.text
.global  main
main:
        movl an_int(%rip),  %eax      # proper syntax to access global an_int
	leaq some_shorts(%rip), %rdi  # proper syntax to load address of array global some_shorts
	movq $0, %rdx                 # zero-out rdx register
	movq $1, %rsi                 # rsi is array index
        movw (%rdi,%rsi,2), %dx       # copy index 1 of some_shorts into %dx
        addl %edx, %eax
        ret
