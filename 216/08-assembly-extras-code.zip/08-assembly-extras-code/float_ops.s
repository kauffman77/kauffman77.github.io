	.file	"float_ops.c"
	.text
	.globl	array_add
	.type	array_add, @function
array_add:
.LFB0:
	.cfi_startproc
	movl	$0, %eax
	jmp	.L2
.L3:
	movslq	%eax, %r8
	leaq	(%rdi,%r8,4), %rcx
	movss	(%rsi,%r8,4), %xmm0
	addss	(%rcx), %xmm0
	movss	%xmm0, (%rcx)
	addl	$1, %eax
.L2:
	cmpl	%edx, %eax
	jl	.L3
	ret
	.cfi_endproc
.LFE0:
	.size	array_add, .-array_add
	.globl	array_sum
	.type	array_sum, @function
array_sum:
.LFB1:
	.cfi_startproc
	movl	$0, %eax
	pxor	%xmm0, %xmm0
	jmp	.L5
.L6:
	movslq	%eax, %rdx
	addsd	(%rdi,%rdx,8), %xmm0
	addl	$1, %eax
.L5:
	cmpl	%esi, %eax
	jl	.L6
	ret
	.cfi_endproc
.LFE1:
	.size	array_sum, .-array_sum
	.ident	"GCC: (GNU) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
