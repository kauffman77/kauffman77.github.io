// float_ops.c: some simple floating point operations that can be
// compiled to show how floating ops appear.
//
// To see unoptimized assembly:
// >> gcc -S -Og float_ops.c
//
// To see optimized assembly which includes packed vector instructions
// >> gcc -S -O3 float_ops.c
//
// To enable more extended machine-dependent code (AVX instructions):
// >> gcc -S -O3 -mavx float_ops.c

void array_add(float *arr1, float *arr2, int len){
  for(int i=0; i<len; i++){
    arr1[i] += arr2[i];
  }
}

double array_sum(double *arr, int len){
  double sum = 0.0;
  for(int i=0; i<len; i++){
    sum += arr[i];
  }
  return sum;
}
