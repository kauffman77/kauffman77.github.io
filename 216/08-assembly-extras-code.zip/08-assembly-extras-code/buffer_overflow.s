	.file	"buffer_overflow.c"
# GNU C17 (GCC) version 11.1.0 (x86_64-pc-linux-gnu)
#	compiled by GNU C version 11.1.0, GMP version 6.2.1, MPFR version 4.1.0, MPC version 1.2.1, isl version isl-0.24-GMP

# warning: MPFR header version 4.1.0 differs from library version 4.1.0-p13.
# GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
# options passed: -mtune=generic -march=x86-64 -Og
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"This should never happen"
	.text
	.globl	never
	.type	never, @function
never:
.LFB13:
	.cfi_startproc
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 16
# buffer_overflow.c:61:   printf("This should never happen\n");
	leaq	.LC0(%rip), %rdi	#, tmp82
	call	puts@PLT	#
# buffer_overflow.c:63: }
	addq	$8, %rsp	#,
	.cfi_def_cfa_offset 8
	ret	
	.cfi_endproc
.LFE13:
	.size	never, .-never
	.section	.rodata.str1.1
.LC1:
	.string	"This always happens"
.LC2:
	.string	"Address of never:  %0p\n"
.LC3:
	.string	"Address of main:   %0p\n"
.LC4:
	.string	"buf[0]:            %0p\n"
.LC5:
	.string	"buf[1]:            %0p\n"
.LC6:
	.string	"buf[2]:            %0p\n"
.LC7:
	.string	"buf[3]:            %0p\n"
.LC8:
	.string	"Enter 4 hex values: "
.LC9:
	.string	"%lx %lx %lx %lx"
	.text
	.globl	always
	.type	always, @function
always:
.LFB12:
	.cfi_startproc
	pushq	%r13	#
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12	#
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp	#
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx	#
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$24, %rsp	#,
	.cfi_def_cfa_offset 64
# buffer_overflow.c:36: void always(){
	movq	%fs:40, %rax	# MEM[(<address-space-1> long unsigned int *)40B], tmp122
	movq	%rax, 8(%rsp)	# tmp122, D.2402
	xorl	%eax, %eax	# tmp122
# buffer_overflow.c:37:   long buf[1] = {0xABCD};
	movq	$43981, (%rsp)	#, buf[0]
# buffer_overflow.c:39:   printf("This always happens\n");
	leaq	.LC1(%rip), %rdi	#, tmp92
	call	puts@PLT	#
# buffer_overflow.c:40:   printf("Address of never:  %0p\n",never);
	leaq	never(%rip), %rsi	#, tmp93
	leaq	.LC2(%rip), %rdi	#, tmp94
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:41:   printf("Address of main:   %0p\n",main);
	leaq	main(%rip), %rsi	#, tmp95
	leaq	.LC3(%rip), %rdi	#, tmp96
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:42:   printf("buf[0]:            %0p\n",buf[0]);
	movq	(%rsp), %rsi	# buf[0],
	leaq	.LC4(%rip), %r13	#, tmp98
	movq	%r13, %rdi	# tmp98,
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:43:   printf("buf[1]:            %0p\n",buf[1]);
	movq	8(%rsp), %rsi	# buf[1],
	leaq	.LC5(%rip), %r12	#, tmp100
	movq	%r12, %rdi	# tmp100,
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:44:   printf("buf[2]:            %0p\n",buf[2]);
	movq	16(%rsp), %rsi	# buf[2],
	leaq	.LC6(%rip), %rbp	#, tmp101
	movq	%rbp, %rdi	# tmp101,
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:45:   printf("buf[3]:            %0p\n",buf[3]);
	movq	24(%rsp), %rsi	# buf[3],
	leaq	.LC7(%rip), %rbx	#, tmp103
	movq	%rbx, %rdi	# tmp103,
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:47:   printf("Enter 4 hex values: ");
	leaq	.LC8(%rip), %rdi	#, tmp104
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:48:   fscanf(stdin,"%lx %lx %lx %lx",
	movq	%rsp, %rdx	#, tmp105
	leaq	8(%rsp), %rcx	#, tmp110
	leaq	24(%rsp), %r9	#,
	leaq	16(%rsp), %r8	#,
	leaq	.LC9(%rip), %rsi	#, tmp113
	movq	stdin(%rip), %rdi	# stdin,
	movl	$0, %eax	#,
	call	__isoc99_fscanf@PLT	#
# buffer_overflow.c:51:   printf("buf[0]:            %0p\n",buf[0]);
	movq	(%rsp), %rsi	# buf[0],
	movq	%r13, %rdi	# tmp98,
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:52:   printf("buf[1]:            %0p\n",buf[1]);
	movq	8(%rsp), %rsi	# buf[1],
	movq	%r12, %rdi	# tmp100,
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:53:   printf("buf[2]:            %0p\n",buf[2]);
	movq	16(%rsp), %rsi	# buf[2],
	movq	%rbp, %rdi	# tmp101,
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:54:   printf("buf[3]:            %0p\n",buf[3]);
	movq	24(%rsp), %rsi	# buf[3],
	movq	%rbx, %rdi	# tmp103,
	movl	$0, %eax	#,
	call	printf@PLT	#
# buffer_overflow.c:57: }
	movq	8(%rsp), %rax	# D.2402, tmp123
	subq	%fs:40, %rax	# MEM[(<address-space-1> long unsigned int *)40B], tmp123
	jne	.L6	#,
	addq	$24, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx	#
	.cfi_def_cfa_offset 32
	popq	%rbp	#
	.cfi_def_cfa_offset 24
	popq	%r12	#
	.cfi_def_cfa_offset 16
	popq	%r13	#
	.cfi_def_cfa_offset 8
	ret	
.L6:
	.cfi_restore_state
	call	__stack_chk_fail@PLT	#
	.cfi_endproc
.LFE12:
	.size	always, .-always
	.section	.rodata.str1.1
.LC10:
	.string	"Running always()"
.LC11:
	.string	"Done with always()"
	.text
	.globl	main
	.type	main, @function
main:
.LFB11:
	.cfi_startproc
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 16
# buffer_overflow.c:30:   printf("Running always()\n");
	leaq	.LC10(%rip), %rdi	#, tmp83
	call	puts@PLT	#
# buffer_overflow.c:31:   always();
	movl	$0, %eax	#,
	call	always	#
# buffer_overflow.c:32:   printf("Done with always()\n");
	leaq	.LC11(%rip), %rdi	#, tmp84
	call	puts@PLT	#
# buffer_overflow.c:34: }
	movl	$0, %eax	#,
	addq	$8, %rsp	#,
	.cfi_def_cfa_offset 8
	ret	
	.cfi_endproc
.LFE11:
	.size	main, .-main
	.ident	"GCC: (GNU) 11.1.0"
	.section	.note.GNU-stack,"",@progbits
