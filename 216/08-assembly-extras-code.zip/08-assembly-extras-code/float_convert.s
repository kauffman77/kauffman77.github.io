	.file	"float_convert.c"
	.text
	.globl	double2long
	.type	double2long, @function
double2long:
.LFB0:
	.cfi_startproc
	cvttsd2siq	%xmm0, %rax
	ret
	.cfi_endproc
.LFE0:
	.size	double2long, .-double2long
	.globl	int2double
	.type	int2double, @function
int2double:
.LFB1:
	.cfi_startproc
	pxor	%xmm0, %xmm0
	cvtsi2sdl	%edi, %xmm0
	ret
	.cfi_endproc
.LFE1:
	.size	int2double, .-int2double
	.ident	"GCC: (GNU) 12.2.1 20230201"
	.section	.note.GNU-stack,"",@progbits
