	.file	"stack_protect.c"
	.text
	.globl	stack_fine
	.type	stack_fine, @function
stack_fine:
.LFB11:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	jmp	.L2
.L3:
	leal	1(%rax), %edx
	leal	(%rdx,%rdx), %ecx
	cltq
	movl	%ecx, (%rsp,%rax,4)
	movl	%edx, %eax
.L2:
	cmpl	$3, %eax
	jle	.L3
	movl	$0, %eax
	movl	$0, %edx
	jmp	.L4
.L5:
	movslq	%eax, %rcx
	addl	(%rsp,%rcx,4), %edx
	addl	$1, %eax
.L4:
	cmpl	$3, %eax
	jle	.L5
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L8
	movl	%edx, %eax
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L8:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE11:
	.size	stack_fine, .-stack_fine
	.globl	stack_smashed
	.type	stack_smashed, @function
stack_smashed:
.LFB12:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	jmp	.L10
.L11:
	leal	1(%rax), %edx
	leal	(%rdx,%rdx), %ecx
	cltq
	movl	%ecx, (%rsp,%rax,4)
	movl	%edx, %eax
.L10:
	cmpl	$7, %eax
	jle	.L11
	movl	$0, %eax
	movl	$0, %edx
	jmp	.L12
.L13:
	movslq	%eax, %rcx
	addl	(%rsp,%rcx,4), %edx
	addl	$1, %eax
.L12:
	cmpl	$7, %eax
	jle	.L13
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L16
	movl	%edx, %eax
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L16:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE12:
	.size	stack_smashed, .-stack_smashed
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"Running stack_fine()"
.LC1:
	.string	"ret: %d\n"
.LC2:
	.string	"Running stack_smashed()"
	.text
	.globl	main
	.type	main, @function
main:
.LFB13:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	.LC0(%rip), %rdi
	call	puts@PLT
	movl	$0, %eax
	call	stack_fine
	movl	%eax, %esi
	leaq	.LC1(%rip), %rbx
	movq	%rbx, %rdi
	movl	$0, %eax
	call	printf@PLT
	leaq	.LC2(%rip), %rdi
	call	puts@PLT
	movl	$0, %eax
	call	stack_smashed
	movl	%eax, %esi
	movq	%rbx, %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	$0, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE13:
	.size	main, .-main
	.ident	"GCC: (GNU) 11.2.0"
	.section	.note.GNU-stack,"",@progbits
