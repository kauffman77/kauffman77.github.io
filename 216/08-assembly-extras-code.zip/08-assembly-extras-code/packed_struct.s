### packed_struct.s: illustrates how a small struct can be packed
### into a single register when it is passed as an argument. Used with
### accompanying C main file. Compile and run with
### 
### > gcc packed_struct.s packed_struct_main.c 
	
.text
.global  sub_struct
sub_struct:
        ## %rdi has 2 packed integers in it
        ## bits 0-15 are twoints.first
        ## bits 16-32 are twoints.second
        ## upper bits could be anything

        movl %edi,%eax          # eax = twoints;
        andl $0xFFFF,%eax       # eax = twoints.first; via masking
        sarl $16,%edi           # edi = edi >> 16;
        andl $0xFFFF,%edi       # edi = twoints.second; via masking
        subw %di,%ax            # ax = ax - di
        ret                     # return with answer in ax

        ## NOTE: variants of the above exist such as NOT masking as
        ## the last addition is in 16-bits
