### globals_bad.s: Demosntrates the traditional method for accessing
### globals in assembly which is no longer accepted by default by
### gcc. Attempts to compile this code will yield errors such as:
### 
### > gcc globals_bad.s
### /usr/bin/ld: /tmp/ccocSiw5.o: relocation R_X86_64_32S against `.data' can not be used when making a PIE object; recompile with -fPIE
### /usr/bin/ld: final link failed: nonrepresentable section on output
### collect2: error: ld returned 1 exit status
###
### This is because the global variables are accessed using direct
### syntax which is no longer the default for gcc. Fix this by
### converting to use indirect/rip-relative syntax like
###   movl an_int(%rip), %eax
### as demonstrated in globals_good.s
.data
an_int:                               # single int
        .int 17
some_shorts:                          # array of shorts
	.short 10
        .short 12
        .short 14

.text
.global  main
main:
        movl an_int,  %eax            # ERROR: this line causes problems for the compiler chain
	leaq (some_shorts), %rdi      # ERROR: this line causes problems for the compiler chain
	movq $0, %rdx                 # zero-out rdx register
	movq $1, %rsi                 # rsi is array index
        movw (%rdi,%rsi,2), %dx       # copy index 1 of some_shorts into %dx
        addl %edx, %eax
        ret

