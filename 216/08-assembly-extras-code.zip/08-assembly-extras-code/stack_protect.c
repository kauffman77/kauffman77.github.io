// stack_protect.c : generate assembly code for this program via
//
// gcc -Og -S stack_protect.c
//
// and use this to show features of GCC's stack protection
// mechanisms. These are described in stack_protect.txt
// (stack_protect.org)
#include <stdio.h>

int stack_fine(){
  int arr[4];                   
  for(int i=0; i<4; i++){           // fill array in bounds
    arr[i] = (i+1)*2;
  }
  int sum = 0;
  for(int i=0; i<4; i++){
    sum += arr[i];
  }
  return sum;
}

int stack_smashed(){
  int arr[4];                   
  for(int i=0; i<8; i++){           // fill array off the end
    arr[i] = (i+1)*2;
  }
  int sum = 0;
  for(int i=0; i<8; i++){
    sum += arr[i];
  }
  return sum;
}

int main(){
  printf("Running stack_fine()\n");
  int ret1 = stack_fine();
  printf("ret: %d\n",ret1);

  printf("Running stack_smashed()\n");
  int ret2 = stack_smashed();
  printf("ret: %d\n",ret2);

  return 0;
}
