void print_vote(vote_t *vote);
// PROBLEM 1

int vote_next_candidate(vote_t *vote, char *candidate_status);
// PROBEM 1
// Advance the vote to the next live candidate 

void tally_print_table(tally_t *tally);
// PROBLEM 1

void tally_print_votes(tally_t *tally);
// PROBLEM 1

vote_t *vote_make_empty();
// PROBLEM 2

void tally_free(tally_t *tally);
// PROBLEM 2

void tally_set_minvote_candidates(tally_t *tally);
// PROBLEM 2
// Find the minimum vote count among active candidates in the tally

int tally_condition(tally_t *tally);
// PROBLEM 2

void tally_transfer_first_vote(tally_t *tally, int candidate_index);
// PROBLEM 3

void tally_drop_minvote_candidates(tally_t *tally);
// PROBLEM 3

void tally_election(tally_t *tally);
// PROBLEM 3

void tally_add_vote(tally_t *tally, vote_t *vote);
// PROBLEM 4

tally_t *tally_from_file(char *fname);
// PROBLEM 4

int main(int argc, char *argv[]);
// PROBLEM 5: Main
