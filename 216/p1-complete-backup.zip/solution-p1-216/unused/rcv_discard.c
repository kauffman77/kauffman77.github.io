
int array_element_present(int query, int arr[], int arr_count){
  for(int i=0; i<arr_count; i++){
    if(query == arr[i]){
      return 1;
    }
  }
  return 0;
}

// Shift all elements in the array left by 1 starting above `index`
// which "drops" the element at `index` from the array. The last
// element of the array is set to `fill`.
//
// EXAMPLE:
//
// int arr[5] = {10, 20, 30, 40, 50};
// array_drop_index(arr, 5, 2, -1);  // drop 30 at index 2
//   arr is now {10, 20, 40, 50, -1); 
void array_drop_index(int arr[], int count, int index, int fill){
  if(index < 0 || index >= count){
    printf("ERROR: index %d out of bounds in array of length %d\n",index,count);
    return;
  }
  for(int i=index; i<count-1; i++){
    arr[i] = arr[i+1];
  }
  arr[count-1] = fill;
}

// Drop `elem` from the array by searching for it and then calling
// `array_drop_index()` on the index of its location.
// 
// EXAMPLE:
//
// int arr[5] = {10, 20, 30, 40, 50};
// array_drop_element(arr, 5, 20, -1);  // drop 20 at index 1
//   arr is now {10, 30, 40, 50, -1); 
void array_drop_element(int arr[], int count, int elem, int fill){
  int index = -1;
  for(int i=0; i<count; i++){
    if(elem == arr[i]){
      index = i;
      break;
    }
  }
  array_drop_index(arr, count, index, fill);
}




// int tally_set_dropped_candidates(tally_t *tally){
//   if(tally->valid_candidate_count == 0){
//     return DROP_NONE;
//   }
//   int min_count = tally_minimum_active_votecount(tally);
//   for(int i=0; i<tally->candidate_count; i++){
//     if(tally->candidate_vote_count[i] == min_count){
//       tally->canddiate_status[i] = CANDIDATE_DROPPED;
//     }
//   }
// }
