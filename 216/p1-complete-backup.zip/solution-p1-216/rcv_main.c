////////////////////////////////////////////////////////////////////////////////
// PROBLEM 4: main() function
#include "rcv.h"

int main(int argc, char *argv[]){
  // check for correct number/content of commandline args
  if(!((argc==2) ||
       (argc==4 && strcmp(argv[1],"-log")==0)))
  {
    printf("usage: %s [-log int] <votefile>\n",argv[0]);
    return 1;
  }

  char *fname = argv[1];        // default to 2-arg form
  if(argc == 4){                // detect log level set
    LOG_LEVEL = atoi(argv[2]);  // set global LOG_LEVEL based on command line
    fname = argv[3];            // adjust filename to open
  }

  tally_t *tally = tally_from_file(fname);
  if(tally == NULL){
    printf("Could not load votes file. Exiting with error code 1\n");
    return 1;
  }
  tally_election(tally);
  tally_free(tally);
  return 0;
}
