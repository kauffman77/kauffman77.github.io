from random import shuffle, randrange

ncand = 12
nvotes = 300

v = list(range(ncand))
for _ in range(nvotes):
  shuffle(v)
  u = v.copy()
  invalid = randrange(ncand+1)
  u[invalid:] = [-1]*(ncand-invalid)
  for x in u:
    print(f"{x:3} ",end="")
  print()

