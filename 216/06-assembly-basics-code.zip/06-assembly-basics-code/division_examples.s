### division_examples.s: illustrates examples of division in
### x86-64. The general pattern is
### 1. Set a register to divide by (cannot divide by constants)
### 2. Load the ax-family register being divided (ax-family: rax, eax,
###    ax, al depending on size)
### 3. Use a division preparation instruction which copies the sign
###    bit (leading bit) of the ax-family register elsewhere, usually
###    to the dx-family register (exception is 8-bit); preparation
###    instructions look like cqto, cltd, cwtd, cbtw and are specific
###    to the bit-width of the division.
### 4. Issue the `idivX` instruction which will leave the quotient and
###    remainder in two separate locations, usually the ax-family and
###    dx-family registers (exception 8-bit division)
###
### It is recommended to walk through this in a debugger showing
### register values after each preparation and division
### instruction. Keep in mind that "small" operations like idivw
### (16-bit) won't overwrite the entire registers, only the 16-bit
### portions of them so using GDB commands like `print $ax` and `print
### $dx` to see the values in the lower portions of registers is a
### good idea to get clarity.

.section .text
.global  main
main:
        movq $5, %rcx           # divide everything by 5

        movq $-1, %rax          # reset rax, rdx
        movq $-1, %rdx

        movq $23, %rax          # divide `long a=23;` by 5
        cqto                    # prepare for 64-bit division
        idivq %rcx              # rax = 4, rdx = 3

        movq $-1, %rax          # reset rax, rdx
        movq $-1, %rdx

        movl $19, %eax          # divide `int a=19;` by 5
        cltd                    # prepare for 32-bit division
        idivl %ecx              # eax = 3, edx = 4

        movq $-1, %rax          # reset rax, rdx
        movq $-1, %rdx

        movw $37, %ax           # divide `short a=37;` by 5
        cwtd                    # prepare for 16-bit division
        idivw %cx               # ax = 7, dx = 2

        movq $-1, %rax          # reset rax, rdx
        movq $-1, %rdx

        ## 8-Bit is a SPECIAL CASE
        movb $42, %al           # divide `char a=42;` by 5
        cbtw                    # prepare for 8-bit division
        idivb %cl               # al = 8, ah = 2 
        ## NOTE: quotient AND remainder in ax-family reg

        movl $0, %eax
        ret
