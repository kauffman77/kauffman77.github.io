### x86-64 assembly on Linux
.data
msg:
  .ascii "Hello students!\n"
.text
  .global _start
_start:
  movq    $1,  %rax
  movq    $1,  %rdi
  movq    $msg,%rsi
  movq    $16, %rdx
  syscall
  movq    $60,%rax
  movq    $0, %rdi
  syscall
