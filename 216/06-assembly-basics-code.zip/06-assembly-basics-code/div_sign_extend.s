### div_sign_extend.s: demonstrates various scenarios for sign
### extension preceding division instructions. Step through in a
### debugger looking for results as noted in comments.
	
.text
.global  main
main:
	
.GOOD_NEG_DIV64:	
	movq    $0x1122334455667788, %rax # move garbage vale to rax
	movq    $0x1122334455667788, %rdx # move garbage vale to rdx
        movq    $-37, %rax                # move to 64-bit reg extends sign correctly
        movq    $5, %rdi                  # divisor
        cqto                              # extend sign from 64-bit rax to 128-bit rax:rdx, modifies rdx
        idivq   %rdi                      # divide
	## examine rax and rdx regs now

.GOOD_POS_DIV32:	
	movq	$0x1122334455667788, %rax # move garbage vale to rax
	movq	$0x1122334455667788, %rdx # move garbage vale to rdx
        movl    $37, %eax                 # move to 32-bit reg zeros upper 32-bits, okay due to positive number
        movl    $5, %edi                  # divisor
        cqto                              # extend sign from 64-bit rax to 128-bit rax:rdx, modifies rdx
        idivl   %edi                      # divide
	## examine eax and edx regs now

.GOOD_NEG_DIV32:	
	movq	$0x1122334455667788, %rax # move garbage vale to rax
	movq	$0x1122334455667788, %rdx # move garbage vale to rdx
        movl    $-37, %eax                # move to 32-bit reg zeros upper 32 bits but WANT sign extension
        movl    $5, %edi                  # divisor
        cltq                              # extend sign from 32-bit eax to 64-bit rax, DOES NOT MODIFY rdx
        cqto                              # extend sign from 64-bit rax to 128-bit rax:rdx, modifies rdx
        idivl   %edi                      # divide
	## examine eax and edx regs now

.GOOD_NEG_DIV16:	
	movq	$0x1122334455667788, %rax # move garbage vale to rax
	movq	$0x1122334455667788, %rdx # move garbage vale to rdx
        movw    $-37, %ax                 # move to 16-bit does not change any other bits in reg
        movw    $5, %di                   # divisor
	cwtl                              # extend sign from 16-bit ax to 32-bit eax
        cltq                              # extend sign from 32-bit eax to 64-bit rax, DOES NOT MODIFY rdx
        cqto                              # extend sign from 64-bit rax to 128-bit rax:rdx, modifies rdx
        idivw   %di                       # divide
	## examine ax and dx regs now

.BAD_NEG_DIV64:
        movq	$-37, %rax               # negative value in rax
        movq    $5, %rdi
	movq    $0, %rdx                 # no cqto, explicit 0 in rdx: mismatch of sign
        idivq   %rdi
	## examine rax and rdx: WRONG ANSWERS
        
.BAD_NEG_DIV32:
        movl	$-37, %eax               # negative value in eax, high order bytes are 0
        movl    $5, %edi
        cqto                             # extends WRONG sign from 64-bit rax to 128-bit rax:rdx, modifies rdx
        idivl   %edi                     # will cause SIGFPE due to edx not being set correctly
	## examine eax and edx: WRONG ANSWERS

	movl $0, %eax
        ret
