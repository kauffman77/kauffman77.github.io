// exchange.c: sample C function to compile to assembly via
//
// > gcc -Og -S exchange.c
//
// Examine results in exchange.s
long exchange(long *xp, long y){
  long x = *xp;
  *xp = y;
  return x;
}
