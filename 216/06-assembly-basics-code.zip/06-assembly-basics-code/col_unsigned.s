	.file	"col_unsigned.c"
	.text
	.globl	main
	.type	main, @function
main:
.LFB22:
	.cfi_startproc
	movl	$0, %edx
	movl	$10, %eax
	jmp	.L2
	.p2align 4
.L3:
	shrl	%eax
.L4:
	addl	$1, %edx
.L2:
	cmpl	$1, %eax
	jbe	.L6
	testb	$1, %al
	je	.L3
	leal	1(%rax,%rax,2), %eax
	jmp	.L4
.L6:
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE22:
	.size	main, .-main
	.ident	"GCC: (GNU) 15.2.1 20260103"
	.section	.note.GNU-stack,"",@progbits
