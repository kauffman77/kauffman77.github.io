// Call code in divide.s to demonstrate division
// Compile with
// > gcc division_main.c division.s

#include <stdio.h>
#include <stdlib.h>

int div_small();
long div_big();
short div_short();
short div_short2();
int div_small_broken();

int main(int argc, char *argv[]){
  // int sb = div_small_broken();
  // printf("div_small() is: %d\n",sb);

  int sm = div_small();
  printf("div_small() is: %d\n",sm);

  long bg = div_big();
  printf("div_big() is: %ld\n",bg);

  short sh = div_short();
  printf("div_short() is: %hd\n",sh);

  short sh2 = div_short2();
  printf("div_short2() is: %hd\n",sh2);

  return 0;
}
