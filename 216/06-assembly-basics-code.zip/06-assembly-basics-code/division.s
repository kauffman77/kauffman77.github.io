### Demonstrate division in assembly. Use in combination with division_main.c
### Compile with
### > gcc division_main.c division.s

.text
.global div_small
.global div_big
.global div_short
.global div_short2
.global div_small_broken
	
div_small:  
### division with 32-bit ints
        movl $15, %eax          # set eax to int 15
	cqto                    # extends 0 sign bit (positive) to edx
        ## combined 64-bit register %edx:%eax is 
        ## eax: 0x00000000 0000000F = 15
        ## exx: 0x00000000 00000000 =  0
	movl $2, %esi           # set esi to 2
        idivl %esi              # divide combined register by 2
	## 15 div 2 = 7 rem 1
        ## %eax == 7, quotient
        ## %edx == 1, remainder
	
        # answer in eax, return
	ret
        
div_big:        
### division with 64-bit longs
        movq $0x0000000300000001, %rax # set rax to long 1
	movq $0, %rdx                  # set rdx to long 0
        ## combined 128-bit register %rdx:%rax is
        ## now 0x00000000 00000000 00000003 00000001 = 12,884,901,889
	movq $13,  %rcx         # set rcx to long 13
        idivq %rcx              # divide combined register by 13
	## 12,884,901,889 div 13 = 991,146,299 rem 2
        ## %rax == 991146299, quotient
        ## %rdx == 2, remainder
	## movq %rdx, %rax
	
	## answer in rax, return
        ret

div_short:        
### division with 16-bit shorts
	movq $0,%rax                   # set rax to all 0's
	movq $0,%rdx                   # set rdx to all 0's
	## rax = 0x00000000 00000000
	## rdx = 0x00000000 00000000
        movw $-17, %ax                 # set ax to short -17
        ## rax = 0x00000000 0000FFEF
	## rdx = 0x00000000 00000000
	cwtl                           # "convert word to long" sign extend ax to eax
        ## rax = 0x00000000 FFFFFFEF
	## rdx = 0x00000000 00000000
        cltq                           # "convert long to quad" sign extend eax to rax
        ## rax = 0xFFFFFFFF FFFFFFEF
	## rdx = 0x00000000 00000000
	cqto                           # sign extend rax to rdx
        ## rax = 0xFFFFFFFF FFFFFFEF
	## rdx = 0xFFFFFFFF FFFFFFFF
	movq $3, %rcx                  # set rcx to long 3
        idivq %rcx                     # divide combined rax/rdx register by 3
        ## rax = 0xFFFFFFFF FFFFFFFB  = -5 (quotient)
	## rdx = 0xFFFFFFFF FFFFFFFE  = -2 (remainder)
        ret
        
div_short2:        
### division with 16-bit shorts
	movq $0,%rax                   # set rax to all 0's
	movq $0,%rdx                   # set rdx to all 0's
	## rax = 0x00000000 00000000
	## rdx = 0x00000000 00000000
        movw $-17, %ax                 # set ax to short -17
        ## rax = 0x00000000 0000FFEF
	## rdx = 0x00000000 00000000
	cwtl
        cltq
        cqto
        ## rax = 0xFFFFFFFF FFFFFFEF
	## rdx = 0xFFFFFFFF FFFFFFFF
	movq $3, %rcx                  # set rcx to long 3
        idivq %rcx                     # divide combined rax/rdx register by 3
        ## rax = 0xFFFFFFFF FFFFFFFB  = -5 (quotient)
	## rdx = 0xFFFFFFFF FFFFFFFE  = -2 (remainder)
        ret
        
div_small_broken:  
### division with 32-bit ints BUT uses only cltq which will trigger a
### floation point exception at the division instruction if rdx is not
### by chance all 0s
        movl $15, %eax          # set eax to int 15
	cltq                    # eax to rax
        ## combined 64-bit register %edx:%eax is 
        ## now 0x00000000 0000000F = 15
	movl $2, %esi           # set esi to 2
        idivl %esi              # divide combined register by 2
	## 15 div 2 = 7 rem 1
        ## %eax == 7, quotient
        ## %edx == 1, remainder
	
        # answer in eax, return
	ret
