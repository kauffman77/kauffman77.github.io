	.file	"col_signed.c"
	.text
	.globl	main
	.type	main, @function
main:
.LFB22:
	.cfi_startproc
	movl	$0, %esi
	movl	$10, %eax
	jmp	.L2
	.p2align 5
.L7:
	leal	1(%rax,%rax,2), %eax
.L4:
	addl	$1, %esi
.L2:
	cmpl	$1, %eax
	jle	.L6
	movl	%eax, %ecx
	shrl	$31, %ecx
	leal	(%rax,%rcx), %edx
	andl	$1, %edx
	subl	%ecx, %edx
	cmpl	$1, %edx
	je	.L7
	movl	%eax, %edx
	shrl	$31, %edx
	addl	%edx, %eax
	sarl	%eax
	jmp	.L4
.L6:
	movl	%esi, %eax
	ret
	.cfi_endproc
.LFE22:
	.size	main, .-main
	.ident	"GCC: (GNU) 14.2.1 20250207"
	.section	.note.GNU-stack,"",@progbits
