### movx_exercise.s: In-class exercise to study data movement
### Compile with
### > gcc movX_exercise.s
###
### Run in debugger with Text User Interface via
### > gdb -tui a.out 
###
### In gdb use the command
###   gdb> x/4dg $rsp
### to print the 4 elements of the stack; d for decimal, g for "giant
### word" of 8 bytes, $rsp for the value of the stack pointer register
.section        .text
.global  main
main:
.SETUP:
        pushq $5                # a[3] = 5
        pushq $15               # a[2] = 15
        pushq $25               # a[1] = 25
        pushq $35               # a[0] = 35
        movq %rsp, %rcx         # rcx = &a[0];
        leaq 8(%rsp), %rdx      # rdx = rcx+1 = &a[1];
	movq $0,%rax            # rax = 0
	movq $0,%rbx            # rbx = 0

.EXERCISE:
        movl $16, %eax          # constants to regs
        movl $20, %ebx
        movq $24, %rbx
	## POS A

        movl %eax,%ebx          # reg to reg
	movq %rcx,%rax          # always 64-bit moves for memory addresses
	## POS B

        movq $45,(%rdx)         # const to memory
	movq %rbx,(%rcx)        # reg to memory
        movq $55,16(%rdx)       # const to mem+const-offset
	## POS C

        movq $65,(%rcx,%rbx)    # const to mem+reg-offset
	movq $3,%rbx            # const to reg
        movq $75,(%rcx,%rbx,8)  # const to mem+reg*size
	## POS D
        
.CLEANUP:
        popq %rax
        popq %rax
        popq %rax
        popq %rax
        movq $0, %rax
        ret
