### movz_examples.s: demonstrate differences of movX and
### variants. Particular attention is devoted to movement of
### smaller bit quantities like 16-bit to larger regisers like
### 64-bit and how high order bits are not necessarily zeroed out.
### 
### Compile with
### > gcc movz_examples.s
###
### In gdb use the commands like
###   gdb> print/x $rax
### to print registers in hex to easily see their byte layout
.text
.global  main
main:
	## moving 32-bit quantities to 64-bit registers automatically
        ## zeros the high-order bits
	movabsq $0x1122334455667788, %rax  	# 8 bytes to %rax
	movl $0xAABBCCDD, %eax                  # 4 bytes to %eax	
	## %rax is now 0x00000000AABBCCDD
	
	## moving less than 32-bits DOES NOT zero high-order bits
        movabsq $0x1122334455667788, %rax       # 8 bytes to %rax
        movw $0xAABB, %ax                       # 2 bytes to %ax
        ## %rax is now 0x0x112233445566AABB
	
        ## movzXY: move zero extend, DOES zero high-order bits, must move
        ## between registers: no constants
	movabsq $0x112233445566AABB,%rdx        # %rdx now 0x112233445566AABB
        movzwq %dx, %rax                        # %rax now 0x000000000000AABB
	movq $-1, %rdx                          # %rdx now 0xFFFFFFFFFFFFFFFF
        movzwq %ax, %rdx                        # %rdx now 0x000000000000AABB
	
	## Negative values have leading 1's, are NOT sign extended with normal
        ## movX instructions, 0 extended with movzXY instructions
	movq   $-1,%rdx                         # %rdx now 0xFFFFFFFFFFFFFFFF
	movq   $0,%rax                          # %rax now 0x0000000000000000
	movw   %dx,%ax                          # %rax now 0x000000000000FFFF
	movzwq %dx,%rax                         # %rax now 0x000000000000FFFF
	
        ## movsXY: move sign extend
        movswq %dx,%rax                         # %rax now 0xFFFFFFFFFFFFFFFF	

        movq $0, %rax
        ret
