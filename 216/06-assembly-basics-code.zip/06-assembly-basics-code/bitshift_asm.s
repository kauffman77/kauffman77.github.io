.section .text
.globl  main
main:
        movq    $0b111001, %rdx
        sarq    $4,%rdx

        movq    $0b111001, %rcx
        salq    $3, %rcx

        movq    $0b111001, %rdi
        movq    $2, %rax
        ## salq    %rax, %rdi
        salq    %cl, %rdi

        movl    $0, %eax
        ret
