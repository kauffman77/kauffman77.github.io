// negative_shift.c: takes an integer and a shift amount from the
// command line and prints the original bits and shifted bits. Shows
// how negative shifts yield "bad" results.

#include <stdlib.h>
#include <stdio.h>

#define INT_BITS 32

void showbits(int x){
  for(int i=INT_BITS-1; i>=0; i--){
    (x&(1<<i)) ? putchar('1'): putchar('0');
  }
}

int main(int argc, char **argv){
  if(argc < 3){
    printf("usage: ./a.out int shift\n");
    return 1;
  }
  int num = atoi(argv[1]);
  int shift = atoi(argv[2]);
  printf("%-8s %4s: ","ORIGINAL","");
  showbits(num);

  printf("\n");

  printf("%-8s %4d: ","SHIFTED",shift);
  num = num << shift;
  showbits(num);
  printf("\n");
  return 0;
}
