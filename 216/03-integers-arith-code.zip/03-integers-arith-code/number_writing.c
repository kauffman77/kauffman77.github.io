// number_writing.c: Demonstrate flavors of constants for various
// bases and as character data
#include <stdio.h>
int main(){
  unsigned int d = 125;                 // decimal
  unsigned int b = 0b1111101;           // binary
  unsigned int h = 0x7D;                // hexadecimal
  unsigned int o = 0175;                // octal
  unsigned int c = '}';                 // ASCII character

  printf("%d %x %o %c\n",d,d,d,d);
  printf("%d %x %o %c\n",b,b,b,b);
  printf("%d %x %o %c\n",h,h,h,h);
  printf("%d %x %o %c\n",o,o,o,o);
  printf("%d %x %o %c\n",c,c,c,c);
  
  return 0;
}
