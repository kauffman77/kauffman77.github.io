// overflow_detect.c: intentionally generate overflows in C; try
// compiling normally and with GCC's overflow detection enabled:
// 
// >> gcc overflow.c
// >> ./a.out
// i is -2147483648
// 
// >> gcc -ftrapv overflow.c
// >> ./a.out
// Aborted (core dumped)

#include <stdio.h>
int main() {
  int i = 1;
  while(i > 0) {
    i += 1;
  } // loop ends when i overflows to become negative
  printf("i is %d\n",i);
}
