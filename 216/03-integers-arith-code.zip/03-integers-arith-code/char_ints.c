// char_ints.c: demonstrates equivalences between the
// bit-representation of characters. The function shows two ways to
// lay out the bits of the string "Hello World!", the standard stringy
// way with ASCII characters, and alternatively as an array of ints
// that correspond to the ASCII table entries of the characters.

#include <stdio.h>
#include <string.h>

int main(){
  char msg[64] = "Hello World!"; // string encoded as characters
  printf("%s\n",msg);
  int len = strlen(msg);
  for(int i=0; i<len; i++){
    printf("[%2d] %c %3d %02X\n", 
           i,msg[i],msg[i],msg[i]);
  }
  // print each array element as 
  // - ~%c~ : a character (ASCII table lookup for the glyph to draw)
  // - ~%3d~ : a decimal number (padding to width 3)
  // - ~%02X~ : as a hexadecimal number (with leading 0's if needed and
  //   padded with width 2)
  printf("\n");

  char nums[64] = {             // string encoded as ASCII values
    72, 101, 108, 108, 111, 32,
    87, 111, 114, 108, 100, 33,
    0
  };
  printf("%s\n",nums);          // print whole array as a string
  len = strlen(nums);
  for(int i=0; i<len; i++){
    printf("[%2d] %c %3d %02X\n", // same as above
           i,nums[i],nums[i],nums[i]);
  }

  return 0;
}
