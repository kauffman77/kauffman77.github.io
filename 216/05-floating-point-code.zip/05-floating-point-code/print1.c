// print1.c: demonstrate that 0.1 is NOT exactly represented in binary
// due to a limit on the number of bits that is used.

#include <stdio.h>
int main(){
  float f = 0.1;
  printf("0.1 = %.20e\n",f);
  return 0;
}
