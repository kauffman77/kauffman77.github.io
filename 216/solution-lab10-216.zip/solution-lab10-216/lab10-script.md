# Mon : I/O Redirection via dup2()
- Students will come to lab knowing a bit about File Descriptors and
  the presence of STDOUT_FILENO; will have *briefly* seen something
  seen the dup2() system call 
- Walk through the use switch_stdout.c program noting the use dup2()
- Show the program output and the contents of mystery.txt: printf()
  calls go to screen but then go into mystery.txt after the dup2() call
- Use the diagram provided in the lab HTML page to show file
  descriptor tables and how they can be re-arranged
- Guide students in filling in the redirect_child.c template file;
  intent of the file is to
  - fork() a child process
  - have the child process eventually print some output via an exec()
    of `wc`
  - before calling exec() use dup2() to redirect output into a file
- TODO items indicate where code should be filled in

# Wed : File statistics with stat() 
- Students will have seen `stat()` briefly in lecture and know that it
  reports file statistics
- Walk through the `stat_demo.c` file and point out items of interest
  such as
  - use of `access(filename, F_OK)` to check if a file exists; note
    that `stat(filename, &sb)` will return -1 to indicate that a file
    doesn't exit give alternatives
  - Use of macros like `S_ISDIR(sb.st_mode)` to determine the type of
    a file
  - Presence of fields like `stat.st_size` which gives the number of
    bytes in a file
  - Use of the `ctime(...)` function to create a string rendition of
    times encoded in fields like `sb.st_atime` (not pertinent to
    projects but of interest)
  - Note the "high resolution" timestamps on files at the end of the
    demo which include timestamps in nanoseconds in the `struct
    timespec` fields. These are used in the functions students will
    use in the next part.
- Point students at the `newer_file.c` template which they must fill
  in to pass the tests associated with the problem
- Help students copy over code from the `stat_demo.c` that is relevant
  and complete template
  
  
