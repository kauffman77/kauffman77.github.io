# Mon : Structs and Memory Stride
- Students will have discussed cache memory and the benefit of
  accessing memory in a sequential fashion without strides during
  lecture
- Students will also have seen the clock function so should know the
  basics of timing code
- Walk briefly through the content on clock() in the lab11.html
  document to orient students on its use, use ~clock_demo.c~ as a
  concrete example: compile and run it to show times
- Warn students that when examining times, time values LESS THAN
  0.001s ARE NOT RELIABLE in most cases and ON GRACE TIMES LESS THAN
  1.000s are usually unreliable (GRACE has poor time resolution)
- Runs the ~clock_demo~ program with several parameters to show how it
  reports time
```shell
>> ./clock_demo
usage: ./clock_demo <arrlen> <repeats>
>> ./clock_demo 100 100
Summing array length 100 with 100 repeats, ascending
Summing array length 100 with 100 repeats, descending
method:  sum ascending CPU time: 3.4000e-05 sec   sum: 4950
method: sum descending CPU time: 3.1000e-05 sec   sum: 4950
>> ./clock_demo 100 10000
Summing array length 100 with 10000 repeats, ascending
Summing array length 100 with 10000 repeats, descending
method:  sum ascending CPU time: 2.7670e-03 sec   sum: 4950
method: sum descending CPU time: 2.7890e-03 sec   sum: 4950
>> ./clock_demo 10000 1000
Summing array length 10000 with 1000 repeats, ascending
Summing array length 10000 with 1000 repeats, descending
method:  sum ascending CPU time: 2.5740e-02 sec   sum: 49995000
method: sum descending CPU time: 2.5551e-02 sec   sum: 49995000
>> ./clock_demo 100000 1000
Summing array length 100000 with 1000 repeats, ascending
Summing array length 100000 with 1000 repeats, descending
method:  sum ascending CPU time: 1.7423e-01 sec   sum: 704982704
method: sum descending CPU time: 8.3510e-02 sec   sum: 704982704
```
- Indicate to students that they will be measuring time in the
  `struct_stride.c` program for several different blocks of code
- Give students some time to fill in clock() calls for the TODO
  sections to complete the CODE portion of the lab
- Demonstrate your own runs of this code to show timing which will
  answer the first QUIZ question
- Discuss with students the remaining QUIZ questions which offer
  explanations for the relative speeds
- Pay particular attention to the varying struct layout
  - `int_field_t`: places data in an a/b/a/b pattern
  - `arr_field_t`: places data in an aaa/bbb pattern
- Help students to understand that that the memory layout along with
  the order it is visited in affects performance 

# Wed : Matrix Summing Optimization
- Inspect the two summing algorithms in `matsums_funcs.c` which sum
  the rows and columns of a matrix
- Discuss the Structs and Macros used here: inspect `matvec.h` to show
  the matrix layout as a large, contiguous array and the macros like
  `MGET(mat,i,j)` which access elements by calculating an index into
  that array
- Draw some pictures of how the algorithms traverse the large array by
  going across rows or down columns, ask students for a general
  prediction of which will be faster: summing rows or columns?
- Then compile the `matsums_main` program and run it on Zaratan on
  large-sized matrices which show timing comparison to confirm that
  row-wise access is faster; the test cases use runs like
  ```sh
  ./matsums_main 30000 8000
  ```
- Indicate to students that the next step is to determine a method to
  sum the columns that rivals the speed of the row-based algorithm
- Indicate that the trick will be to adjust the access pattern while
  still computing column sums
- Ask for input / give students a chance to discuss with their
  colleagues
- Collect ideas and guide folks towards traversing rows and adding on
  a each element to the column sums vector so that after visiting the
  whole matrix, all column sums are complete
- Ask students to complete the code for `opt_col_sums()`, uncomment
  the timing code in `matsums_main.c` and time their results on
  Zaratan
