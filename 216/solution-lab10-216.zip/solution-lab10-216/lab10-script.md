# Mon : I/O Redirection via dup2()
- Show a few examples of how I/O redirection looks on the command line
  knowing that students have seen things like this but may not
  remember or know the terminology. Showing some commands like the
  following to demonstrate the utility of Output and Input redirection.
  ```sh
  >> seq 5
  1
  2
  3
  4
  5
  >> seq 5 > nums.txt
  >> sort -r < nums.txt
  5
  4
  3
  2
  1
  ``` 
- Indicate that this capability on the shell is general and is
  accomplished via some system calls in C programs
- Students will come to lab knowing a bit about File Descriptors.  The
  presence of STDOUT_FILENO and the general file descriptor table will
  havebeen discussed and likely discussion as well of the dup2()
  system call
- Walk through the use switch_stdout.c program noting the use dup2()
  and use the provided diagrams in the lab spec to discuss how the FD
  table for processes is manipulated using this call
- Show the program output and the contents of mystery.txt: printf()
  calls go to screen but then go into mystery.txt after the dup2() call
- Guide students in filling in the redirect_child.c template file;
  intent of the file is to
  - fork() a child process
  - have the child process eventually print some output via an exec()
    of `wc`
  - before calling exec() use dup2() to redirect output into a file
- TODO items indicate where code should be filled in

# Mon : Structs and Memory Stride
- Students will have discussed cache memory and the benefit of
  accessing memory in a sequential fashion without strides during
  lecture
- Students will also have seen the clock function so should know the
  basics of timing code
- Walk briefly through the content on clock() in the lab11.html
  document to orient students on its use, use ~clock_demo.c~ as a
  concrete example: compile and run it to show times
- Warn students that when examining times, time values LESS THAN
  0.001s ARE NOT RELIABLE in most cases and ON GRACE TIMES LESS THAN
  1.000s are usually unreliable (GRACE has poor time resolution)
- Runs the ~clock_demo~ program with several parameters to show how it
  reports time
```shell
>> ./clock_demo
usage: ./clock_demo <arrlen> <repeats>
>> ./clock_demo 100 100
Summing array length 100 with 100 repeats, ascending
Summing array length 100 with 100 repeats, descending
method:  sum ascending CPU time: 3.4000e-05 sec   sum: 4950
method: sum descending CPU time: 3.1000e-05 sec   sum: 4950
>> ./clock_demo 100 10000
Summing array length 100 with 10000 repeats, ascending
Summing array length 100 with 10000 repeats, descending
method:  sum ascending CPU time: 2.7670e-03 sec   sum: 4950
method: sum descending CPU time: 2.7890e-03 sec   sum: 4950
>> ./clock_demo 10000 1000
Summing array length 10000 with 1000 repeats, ascending
Summing array length 10000 with 1000 repeats, descending
method:  sum ascending CPU time: 2.5740e-02 sec   sum: 49995000
method: sum descending CPU time: 2.5551e-02 sec   sum: 49995000
>> ./clock_demo 100000 1000
Summing array length 100000 with 1000 repeats, ascending
Summing array length 100000 with 1000 repeats, descending
method:  sum ascending CPU time: 1.7423e-01 sec   sum: 704982704
method: sum descending CPU time: 8.3510e-02 sec   sum: 704982704
```
- Indicate to students that they will be measuring time in the
  `struct_stride.c` program for several different blocks of code
- Give students some time to fill in clock() calls for the TODO
  sections to complete the CODE portion of the lab
- Demonstrate your own runs of this code to show timing which will
  answer the first QUIZ question
- Discuss with students the remaining QUIZ questions which offer
  explanations for the relative speeds
- Pay particular attention to the varying struct layout
  - `int_field_t`: places data in an a/b/a/b pattern
  - `arr_field_t`: places data in an aaa/bbb pattern
- Look the pictures provided in the QUESITONS.txt file that show the
  two different layouts and guide students towards the difference in
  layouts dictated by the struct definitions as shown below

`int_field` layout
|-------------+-----+-----+-----+-----+-----+-----+-----+-----+----+-----+-----|
| Byte Offset | +00 | +04 | +08 | +12 | +16 | +20 | +24 | +28 | 32 | +36 |     |
| LAYOUT 2    |  A0 |  B0 |  A1 |  B1 |  A2 |  B2 |  A3 |  B3 | A4 |  B4 | ... |
|-------------+-----+-----+-----+-----+-----+-----+-----+-----+----+-----+-----|

`int_field_base()` visits memory in this order:
- A0 at 00, A1 at 08, A2 at 16, A3 at 24, A4 at 32... 
- AND THEN
- B0 at 04, B1 at 12, B2 at 20, B3 at 28, B4 at 36... 

`arr_field` layout
|-------------+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----|
| Byte Offset | +00 | +04 | +08 | +12 | +16 |     | +80 | +84 | +88 | +92 | +96 |     |
| LAYOUT1     |  A0 |  A1 |  A2 |  A3 |  A4 | ... |  B0 |  B1 |  B2 |  B3 |  B4 | ... |
|-------------+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----|

`arr_field_base()` visits memory in this order:
- A0 at 00, A1 at 04, A2 at 08, A3 at 12, A4 at 16... 
- AND THEN
- B0 at 80, B1 at 84, B2 at 88, B3 at 92, B4 at 96... 


Help students to understand that that the memory layout along with
the order it is visited in affects performance: visiting memory in
order without a stride utilizes memory caches better; this will
discussed in lecture in more detail

Help students understand why the `int_field_opt()` and
`arr_field_opt()` approaches yield faster times: 
