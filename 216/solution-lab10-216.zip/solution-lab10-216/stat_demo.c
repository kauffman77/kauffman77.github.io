// stat_demo.c: demo of the stat() and access() system calls.
// 
// This program is taken (almost) directly from the manual page
// 
//   man 2 stat
// 
// and demonstrates typical fields available via a stat calls. Minor
// modifications have been made to focus attention on important
// facets. Included at the end is a function that converts the bits in
// st_mode to show the symbolic permissions like 'rwx'; that code was
// lifted from an open source project and includes the associated
// copyright.

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sysmacros.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>

#define NAMELEN 2048
#define BUFSIZE 1024

#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

char *strmode(mode_t mode);                                    // nasty function below this one

int main(int argc, char *argv[]) {
  if (argc != 2) {
    fprintf(stderr, "Usage: %s <pathname>\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  if(access(argv[1], F_OK)!=0){                                // check file exists
    perror("Couldn't access file");
    exit(EXIT_FAILURE);
  }

  struct stat sb;
  if (stat(argv[1], &sb) == -1) {                             // call to stat(), fills sb, distinguishes symbolic links 
    perror("stat");
    exit(EXIT_FAILURE);
  }

  printf("Filename: %s\n",argv[1]);
  printf("File type:                ");
  if(0){}                                                      // checks to determine file type
  else if S_ISBLK (sb.st_mode) {   printf("block device\n");     }
  else if S_ISCHR (sb.st_mode) {   printf("character device\n"); }
  else if S_ISDIR (sb.st_mode) {   printf("directory\n");        }
  else if S_ISFIFO(sb.st_mode) {   printf("FIFO/pipe\n");        }
  else if S_ISLNK (sb.st_mode) {   printf("symlink\n");          }
  else if S_ISREG (sb.st_mode) {   printf("regular file\n");     }
  else if S_ISSOCK(sb.st_mode) {   printf("socket\n");           }
  else{                            printf("unknown?\n");         }
  
  // Use various fields to display information
  printf("I-node number:            %lu\n"              , sb.st_ino);
  printf("Permissions:              %o (octal)\n"       , sb.st_mode);
  char *str_mode = strmode(sb.st_mode);                        // use strmode() form strmode.c to construct permissions string
  printf("Permissions:              %s\n", str_mode);
  printf("Link count:               %lu\n"              , sb.st_nlink);
  printf("Ownership:                UID=%u   GID=%u\n"  , sb.st_uid,  sb.st_gid);
  printf("Preferred I/O block size: %lu bytes\n"        , sb.st_blksize);
  printf("File size:                %lu bytes\n"        , sb.st_size);
  printf("Blocks allocated:         %lu\n"              , sb.st_blocks);

  // Print times of last access
  printf("Last status change:       %s", ctime(&sb.st_ctime)); // formats time as a string
  printf("Last file access:         %s", ctime(&sb.st_atime)); // fields like st_atime are of 
  printf("Last file modification:   %s", ctime(&sb.st_mtime)); // type time_t taken by ctime()


  // Modern unix systems provide high-resolution structs giving the
  // access, change, and modification time for files as a number of
  // seconds + nanoseconds since 12am 01/01/1970 which allows
  // detecting if one file has been modified 0.5 seconds later than
  // another file. WARNING: some file sytems like the one GRACE uses
  // do not suport nonsecond resolution so the tv_nsec field is always
  // zero.
  struct timespec ctim = sb.st_ctim;
  struct timespec mtim = sb.st_mtim;
  struct timespec atim = sb.st_atim;
  int width = 10;
  printf("Since 12am 01/01/1970 %*s %*s\n",width,"Seconds",width,"Nanosecs");
  printf("Access Time           %*lu %*lu\n",width,atim.tv_sec,width,atim.tv_nsec);
  printf("Change Time           %*lu %*lu\n",width,ctim.tv_sec,width,ctim.tv_nsec);
  printf("Modification Time     %*lu %*lu\n",width,mtim.tv_sec,width,mtim.tv_nsec);

  // Optionally report device number
  // printf("ID of containing device:  [%lx,%lx]\n", (long) major(sb.st_dev), (long) minor(sb.st_dev));

  exit(EXIT_SUCCESS);
}


// https://github.com/ddeville/libc/blob/master/src/string/FreeBSD/strmode.c
/*-
 * Copyright (c) 1990, 1993
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

// #if defined(LIBC_SCCS) && !defined(lint)
// static char sccsid[] = "@(#)strmode.c	8.3 (Berkeley) 8/15/94";
// #endif /* LIBC_SCCS and not lint */
#include <sys/cdefs.h>
// __FBSDID("$FreeBSD: src/lib/libc/string/strmode.c,v 1.8 2009/04/14 11:39:56 trasz Exp $");

#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>


// Create a printable string version a file mode encoded in the
// parameter 'mode'. This function returns a 'static' char*
// (equivalent to a global variable) making it unsafe for threaded
// programs.
char *strmode(mode_t mode){
  static char mode_str[16];
  char *p = &mode_str[0];
  /* print type */
  switch (mode & S_IFMT) {
    case S_IFDIR:			/* directory */
      *p++ = 'd';
      break;
    case S_IFCHR:			/* character special */
      *p++ = 'c';
      break;
    case S_IFBLK:			/* block special */
      *p++ = 'b';
      break;
    case S_IFREG:			/* regular */
      *p++ = '-';
      break;
    case S_IFLNK:			/* symbolic link */
      *p++ = 'l';
      break;
    case S_IFSOCK:			/* socket */
      *p++ = 's';
      break;
      #ifdef S_IFIFO
    case S_IFIFO:			/* fifo */
      *p++ = 'p';
      break;
      #endif
      #ifdef S_IFWHT
    case S_IFWHT:			/* whiteout */
      *p++ = 'w';
      break;
      #endif
    default:			/* unknown */
      *p++ = '?';
      break;
  }
  /* usr */
  if (mode & S_IRUSR)
    *p++ = 'r';
  else
    *p++ = '-';
  if (mode & S_IWUSR)
    *p++ = 'w';
  else
    *p++ = '-';
  switch (mode & (S_IXUSR | S_ISUID)) {
    case 0:
      *p++ = '-';
      break;
    case S_IXUSR:
      *p++ = 'x';
      break;
    case S_ISUID:
      *p++ = 'S';
      break;
    case S_IXUSR | S_ISUID:
      *p++ = 's';
      break;
  }
  /* group */
  if (mode & S_IRGRP)
    *p++ = 'r';
  else
    *p++ = '-';
  if (mode & S_IWGRP)
    *p++ = 'w';
  else
    *p++ = '-';
  switch (mode & (S_IXGRP | S_ISGID)) {
    case 0:
      *p++ = '-';
      break;
    case S_IXGRP:
      *p++ = 'x';
      break;
    case S_ISGID:
      *p++ = 'S';
      break;
    case S_IXGRP | S_ISGID:
      *p++ = 's';
      break;
  }
  /* other */
  if (mode & S_IROTH)
    *p++ = 'r';
  else
    *p++ = '-';
  if (mode & S_IWOTH)
    *p++ = 'w';
  else
    *p++ = '-';
  switch (mode & (S_IXOTH | S_ISVTX)) {
    case 0:
      *p++ = '-';
      break;
    case S_IXOTH:
      *p++ = 'x';
      break;
    case S_ISVTX:
      *p++ = 'T';
      break;
    case S_IXOTH | S_ISVTX:
      *p++ = 't';
      break;
  }
  *p++ = ' ';
  *p = '\0';
  return mode_str;
}
