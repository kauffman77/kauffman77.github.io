#!/usr/bin/awk -f
# 
# scan through test output and format it as a json file element

BEGIN{
  OUTLIMIT = -1;                # no limit on output size
  # OUTLIMIT = 32768-100;         # 32K limit on strings
  # OUTLIMIT = 16384-100;         # 16K limit on strings
  # OUTLIMIT = 0;                 # eliminate test output
  score=0
}

/^PROBLEM/{
  name =$0
}
/^RESULTS/{
  score = $2
  max_score = $4
}

{
  # order is important here as \t tab is considered a control
  # character; sub them first for plain ascii double-backspaced tabs
  # then screen for control characters
  gsub("[\\\\]","\\\\")         #escape backslashes
  gsub("\t","\\t")              #eliminate any raw tabs as they are not allowed in json
  gsub("\r","")                 #eliminate carriage returns
  gsub("\"","\\\"")             #escape double quotes
  # gsub("\\\\0","\\\\0")         #sometimes null chars appear and JSON doesn't like em
  gsub("[\\\\]+0","\\\\0");     #sometimes null chars appear and JSON doesn't like em
  gsub("[^\x00-\x7F]","#");     #eliminate non-ascii characters
  gsub("[[:cntrl:]]","#");      #eliminate control characters
  output = output $0 "\\n"
}

END{
  printf("{\n");
  printf("  \"visibility\": \"visible\",\n");
  printf("  \"name\": \"%s\",\n",name);
  printf("  \"score\": \"%s\",\n",score);
  printf("  \"max_score\": \"%s\",\n",max_score);
  if(OUTLIMIT>=0 && length(output) > OUTLIMIT) {
    output = substr(output, 0, OUTLIMIT);
    output = output "\\n---Output Truncated---\\n";
  }
  printf("  \"output\": \"%s\" \n", output); #no comma - last field
  printf("}\n");
}
