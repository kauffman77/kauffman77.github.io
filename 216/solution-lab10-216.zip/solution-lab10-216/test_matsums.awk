{ time[NR]=$4 }
END{
  row = time[1]
  col = time[2]
  opt = time[3]
  # check for sane times for optimized column
  #   0.7*row <= opt_col <= 2.5*row
  if(0.7*row<=opt && opt<=2.5*row){
    print "Fast!"
  }
  else{
    print "Too Slow"
    exit 1
  }
}
