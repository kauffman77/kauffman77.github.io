#include <stdio.h>
void func_18(){
  printf("Calling function func_18\n");
}
