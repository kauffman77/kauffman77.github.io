// 
// childout_query.c: starts a child process which will print into a
// file instead of onto the screen. Parent will search output for
// query_letter and count it as well as printing all output.
//
// COMPLETE this code by filling in the TODO/??? items

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

#define BUFSIZE 16              // size of input buffers

int main(int argc, char *argv[]){
  if(argc < 4){                                
    printf("usage: %s <childfile> <query_letter> <child_arg0> [child_arg1] ...\n",
           argv[0]);
    return 1;
  }
           
  char *child_file = argv[1];                // output file that child process will print into
  char query_letter = argv[2][0];            // letter that will be searched
  char **child_argv = &argv[3];              // command line to pass to child
  
  // TODO: Spawn a child process


  // TODO CHILD CODE: Redirect output and exec() the child_argv[]
  // command. Adopt code similar to what is in past labs and examples;
  // around 20 lines of code

    printf("Child redirecting output to '%s', then exec()ing\n",
           child_file);















  // PARENT CODE
  int status;                           // used to check return code of child

  // TODO: Block until child is finished; check for normal exit and
  // print exit code; about 10 lines of code.




    // Child  completed properly, exit(1) in this case
    printf("Parent waited, Child complete, exit code %d\n",???);


    // Child did not complete properly, exit(1) in this case
    printf("Parent waited, Child terminated abnormally\n");



  // TODO: Use system call to determine the number of bytes in the
  // output file and print it.
  struct ???;
  int ret = s??(??);
  if(ret == -1){
    fprintf(stderr,"Could not stat file '%s': %s\n",
            child_file, strerror(errno));
    return 1;
  }
  printf("child produced %lu bytes of output\n",???);

  // TODO: Open the file of child output
  int infd = o???(???, O_RDONLY);

  // TODO: check for failure to open
  if(infd == ???){
    fprintf(stderr,"Could not open child_file '%s': %s\n",
            child_file, strerror(errno));
    return 1;
  }

  printf("Scanning child output for '%c'\n",query_letter);
  char buf[BUFSIZE];            // holds portions of input file
  int query_count = 0;          // number of times query_letter appears in output

  // TODO: Iterate through the child output reading it into the above
  // buf[]; null terminate and print the content. Scan it for the
  // query_letter and count it. Use read() calls to get input into the
  // above buf[] with the indicated size.
  while(1){
    int nread = r???(???);      // read a chunk of input file into buf
    if(nread == ???){           // break nothing left in file
      break;
    }
    buf[???] = ???;             // null terminate and print
    printf("%s",buf);
    for(int i=0; i<???; i++){   // search for occurrences of query_letter
      if(buf[i] == query_letter){
        query_count++;
      }
    }
  }
  c???(???);                    // close input file

  printf("child output contained %d occurrences of '%c'\n",
         query_count,query_letter);
  
  return 0;
}
