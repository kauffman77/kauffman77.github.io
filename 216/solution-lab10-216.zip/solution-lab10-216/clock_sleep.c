// clock_sleep.c: demonstrates what clock() computes for sleeping
// programs: no CPU time is utilized during a sleep()
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]){
  clock_t begin, end;
  double cpu_time;
  begin = clock();                 // begin timing

  sleep(1);

  end = clock();                   // end timing and report

  cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;
  printf("cpu_time: %f\n",cpu_time);

  return 0;
}
