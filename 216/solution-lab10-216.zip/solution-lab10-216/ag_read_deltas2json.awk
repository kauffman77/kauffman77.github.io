#!/usr/bin/gawk -f

BEGIN{
  # num_tests = 0
  # first_test = 1
  # output = ""
  # number = 0
}



# /========================================/{
#   print_json();
#   exit(0);
# }

/PROBLEM/{
  name =$0
}
/RESULTS/{
  score = $2
  max_score = $4
}

{
  output = output $0 "\\n"
}

END{
  printf("{\n");
  printf("  \"visibility\": \"visible\",\n");
  printf("  \"name\": \"%s\",\n",name);
  printf("  \"score\": \"%s\",\n",score);
  printf("  \"max_score\": \"%s\",\n",max_score);
  printf("  \"output\": \"%s\" \n", output); #no comma - last field
  printf("}\n");
}
