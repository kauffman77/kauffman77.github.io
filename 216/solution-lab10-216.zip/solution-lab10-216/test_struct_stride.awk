{ time[NR]=$5 }
END{
  int_base = time[1]
  arr_base = time[2]
  int_optm = time[3]
  arr_optm = time[4]

  # check for a partial order of the times; previously sorted to do
  # this but this is unreliable on some platforms like zaratan which
  # have hardware that makes the middle two timings similar
  ordered = 1
  ordered = ordered && int_base > arr_base
  ordered = ordered && int_base > int_optm
  ordered = ordered && int_base > arr_optm
  # ordered = ordered && arr_base > int_optm  ## Zaratan puts these about equal
  ordered = ordered && arr_base > arr_optm
  ordered = ordered && int_optm > arr_optm
  if(ordered){
    print "Timings Okay"
  }
  else{
    print "Something is off..."
    exit 1
  }
}
