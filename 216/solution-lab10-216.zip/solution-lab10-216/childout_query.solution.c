// SOLUTION
// redirect_child.c: starts a child process which will print into a
// file instead of onto the screen. Uses dup2(), fork(), and wait()
// for this.
//
// COMPLETE this code by filling in the TODO/??? items

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

#define BUFSIZE 16                           // size of input buffers

int main(int argc, char *argv[]){
  if(argc < 4){                                
    printf("usage: %s <childfile> <query_letter> <child_arg0> [child_arg1] ...\n",
           argv[0]);
    return 1;
  }
           
  char *child_file = argv[1];                // output file that child process will print into
  char query_letter = argv[2][0];            // letter that will be searched
  char **child_argv = &argv[3];              // command line to pass to child
  

  // TODO: Spawn a child process
  int pid = fork();       

  // TODO CHILD CODE: Redirect output and exec() the child_argv[]
  // command. Adopt code similar to what is in child_redirect.c
  // if( ??? ){
  if(pid == 0){                         
    printf("Child redirecting output to '%s', then exec()ing\n",
           child_file);

    system("ls -d test-results");

    int out_fd = open(child_file, O_WRONLY|O_CREAT|O_TRUNC, S_IRUSR|S_IWUSR);
    if(out_fd == -1){
      fprintf(stderr,"ERROR: could not open output file '%s' : %s\n",
              child_file,strerror(errno));
      exit(1);
    }
    
    dup2(out_fd, STDOUT_FILENO);
    execvp(child_argv[0], child_argv);
    printf("exec() seems to have failed...\n"); // should not reach this 
    exit(1);
  }

  // PARENT CODE
  printf("Parent waiting for child to complete\n");
  int status;                           // used to check return code of child

  // TODO: Block until child is finished and check the output
  wait(&status);
  if(WIFEXITED(status)){
    int exit_code = WEXITSTATUS(status);
    printf("Child complete, exit code %d\n",exit_code);
  }
  else{                                        // Child did not complete properly
    printf("Child terminated abnormally\n");
    exit(1);
  }

  // TODO: Use system call to determine the number of bytes in the
  // output file and print it.
  struct stat sb;
  int ret = stat(child_file, &sb);
  if(ret == -1){
    fprintf(stderr,"Could not stat file '%s': %s\n",
            child_file, strerror(errno));
    return 1;
  }
  printf("child produced %lu bytes of output\n",sb.st_size);

  // TODO: Open the file of child output
  int infd = open(child_file, O_RDONLY);

  // TODO: check for failure to open
  if(infd == -1){
    fprintf(stderr,"Could not open child_file '%s': %s\n",
            child_file, strerror(errno));
    return 1;
  }

  printf("Scanning child output for '%c'\n",query_letter);
  char buf[BUFSIZE];
  int query_count = 0;

  // TODO: Iterate through the child output reading it into the above
  // buf[]; null terminate and print the content. Scan it for the query_letter
  while(1){
    int nread = read(infd, buf, BUFSIZE-1); // read a chunk of input file into buf
    if(nread == 0){                         // break nothing left in file
      break;
    }
    buf[nread] = '\0';                       // null terminate and print
    printf("%s",buf);
    for(int i=0; i<nread; i++){              // search for occurrences of query_letter
      if(buf[i] == query_letter){
        query_count++;
      }
    }
  }
  close(infd);                               // close input file


  printf("child output contained %d occurrences of '%c'\n",
         query_count,query_letter);
  
  return 0;
}
