#!/usr/bin/awk -f

BEGIN{
  printf( "{\"visibility\": \"visible\",\n" )
  printf( " \"stdout_visibility\": \"visible\",\n" )
  printf( " \"tests\": [\n" )
}

FNR==1 && NR>1 {
  printf(",\n");                #comma separate test results
}
{
  # gsub("	","\\t")        #eliminate any raw tabs as they are not allowed in json
  #  gsub("\"","\\\"")             #escape double quotes
  print
}

END{
  printf("]\n")                 #close array of tests
  printf("}\n")                 #close top-level json object
}
