// SOLUTION  //!
#include "mon.h"

void insertion_sort(mon_t *marr, int count){
// Sort the data in the `marr` array according to the numeric value of
// the base_points field in each. NOTE: I think one of the starting indices for
// the loop variables might be wrong but I didn't have time to review
// insertion sort fully when I wrote this... -Prof. Oak
  for(int i=1; i<count; i++){
    for(int j=i-1; j>=0; j--){     //!    for(int j=i; j>=0; j--){
      if(marr[j].base_points <= marr[j+1].base_points){
        break;
      }
      mon_t tmp = marr[j+1];
      marr[j+1] = marr[j];
      marr[j] = tmp;
    }
  }
  return;
}

int main(int argc, char *argv[]){
// main function with the program to be run as either
//   >> mon_main datafile.txt
// or with filtering on the 3rd element in lines as in
//   >> mon_main datafile.txt sometype

  // Check that at least one line argument is present; if not bail out
  // with return code 1 to indicate an error
  if(argc < 2){
    printf("usage: %s <input_file> [filter]\n",argv[0]);
    return 1;
  }

  // 1th arg on command line is the file to operate on
  char *fname = argv[1];

  // If a 2th command line arg is specified, it is used to filter the
  // type of the data (e.g. only 3rd column in the data files that
  // matches should be counted / loaded)
  char *filter;                 //!  char *filter = malloc(sizeof(char));
  if(argc > 2){                 // filter present
    filter = argv[2];
  }
  else{                         // default to no filtering
    filter = NULL;
  }

  // Open the file indicated on the command line
  FILE *fin = fopen(fname,"r");
  // If opening fails, print an error message and return 1
  if(fin == NULL){                               //!
    printf("Failed to open file '%s'\n",fname);  //!
    return 1;                                    //!
  }                                              //!

  // First Input Pass to count the size of the array needed by
  // scanning the entire file. Each line in the data files will have 3
  // fields of `name base_points type`. If filtering is not in use and filter
  // == NULL; count all lines. If filtering is not in use count only
  // lines where the type field is string equal to the filter field.
  int count = 0;
  while(1){
    mon_t tv;
    int ret = fscanf(fin,"%s %d %s", tv.name, &tv.base_points, tv.type);
    if(ret == EOF){
      break;
    }
    if(filter == NULL || (strcmp(tv.type,filter)==0)){
      count++;
    }
  }

  // Detect the special case of an empty file or no no elements matching the filter;
  // there is no median so print an error and return 1
  if(count == 0){
    printf("No elements left after filtering on '%s'\n",filter);
    fclose(fin);                //!
    return 1;                   //!
  }

  // Allocate memory for the contents of the needed items in the file
  mon_t *marr = malloc(sizeof(mon_t) * count); //!  mon_t *marr = malloc(sizeof(mon_t));

  // Use the rewind() function to return to the beginning of the file
  // to read the needed elements again
  rewind(fin);

  // Read the needed elements into the array
  int index = 0;
  while(1){
    mon_t mon;
    int ret = fscanf(fin,"%s %d %s", mon.name, &mon.base_points, mon.type);
    if(ret == EOF){
      break;
    }
    // if no filter is specified OR if mon.type matches the filter, add the element
    if(filter == NULL || (strcmp(mon.type,filter)==0)){   //!    if((strcmp(mon.type,filter)==0) || filter == NULL){
      marr[index] = mon;
      index++;
    }
  }

  // Call insertion sort to sort the elements by BASE_POINTS.
  insertion_sort(marr, count);

  // Print sorted array of data with indices
  printf("Sorted array:\n");
  for(int i=0; i<count; i++){
    printf("%3d: %-12s %3d %-12s\n",
           i,marr[i].name, marr[i].base_points, marr[i].type);
  }

  // Calculate the median (middle) element and print out the name, base_points,
  // and type of that element.
  int midx = count / 2;
  printf("Median BASE_POINTS is\n%3d: %s %d %s\n",
         midx, marr[midx].name, marr[midx].base_points, marr[midx].type);

  // Free memory, close files, and return success.
  free(marr);                   //!
  fclose(fin);                  //!
  return 0;
}
