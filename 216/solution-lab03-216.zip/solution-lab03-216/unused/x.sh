#!/bin/bash

EXPECT_USERID=$(python <<EOF
import json
# fname="sample_metadata.json"
fname = "/autograder/submission_metadata.json"
with open(fname) as f:
  email = json.load(f)["users"][0]["email"]
  print(email[:email.find("@")])
EOF
)
export EXPECT_USERID
echo "Expect userid '$EXPECT_USERID'"

