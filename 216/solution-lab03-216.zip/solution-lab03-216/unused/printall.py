# at gdb breakpoint, run via `source printall.py`
# prints all local vars in addr + name + value format

gdb.execute("break 76",True,False)
gdb.execute("run",True,False)

locs=""
locs+=gdb.execute("info args",False,True)
locs+=gdb.execute("info locals",False,True)
for line in locs.splitlines():
  toks = line.split()
  name = toks[0]
  valu = toks[-1]
  addr_line = gdb.execute(f"print &{name}",False,True)
  addr = addr_line.split()[-1]
  print(f"{addr:18} {name:20} {valu}")

gdb.execute("set confirm off",True,False)  # skip y/n for quit
gdb.execute("quit",True,False)

