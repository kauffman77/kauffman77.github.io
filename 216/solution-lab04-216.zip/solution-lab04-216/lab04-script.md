# Monday
- Indicate to students that the focus of the lab is to debug an
  existing program with memory problems and get practice and reading
  Valgrind messages and using them to solve the problems
- Have students grab the code pack and review the short "Note" from
  Prof Oak which is at the top of the QUESTIONS.txt file
- Talk through briefly the intended behavior of the program as shown
  in the QUESITONS.txt file and show the contents of some of the data
  files, named "mon-*.txt" such as
  ```
  >> cat mon-top5.txt 
  Pikachu 320 Electric
  Bulbasaur 318 Grass
  Charmander 309 Fire
  Squirtle 314 Water
  Psyduck 320 Water
  ```
- Files are set up with "name base_points type" on each line
- Show the students that the current `mon_main.c` program segfaults on
  running on any data files
- Run the test cases and start diagnosing the problems identified by
  Valgrind in the `test-results/*.md` files; point out to students
  that there are two places to look:
  1. The Side-by-Side output; memory problems are bad enough in this
     program that Valgrind complains here
  2. The VALGRIND REPORT further down which shows detailed output of
     where Valgrind finds errors
- Walk students through the QUIZ questions jumping between the QUIZ in
  QUESTIONS.txt, the test results for `make test-prob1 testnum=1`, and
  the source code for `mon_main.c` where changes are made to reduce
  and eventually eliminate the errors for Test #1
- Spot check students on Valgrind output; ask them parse report lines like
  ```
  ==155170== Invalid write of size 8
  ==155170==    at 0x4001718: main (mon_main.c:99)
  ==155170==  Address 0x4acb374 is 0 bytes after a block of size 132 alloc'd
  ==155170==    at 0x484E7A8: malloc (vg_replace_malloc.c:446)
  ==155170==    by 0x4001622: main (mon_main.c:83)
  ```
- Ask students the meanings of different parts of this line like
  - What is an invalid write?
  - What things in C are "size 8"?
  - What line of code would be useful to look at? How did you know
  - Is there any other information available in the message?
- Help students resolve this first Valgrind Complaint
- Let students continue to work on resolving the remaining tests which
  require some more code changes to resolve errors
- If in doubt, examine the QUESTIONS.SOLUTIONS.txt file which has some
  more information on how to fix some of the early bugs in the
  SOLUTION sections
- The `mon_main.solution.txt` has all bugs fixed and are marked with
  comments with the pattern //!  after which appears buggy code in the
  `mon_main.student.c` version

MENTION: when programs crash under Valgrind, they will often create a
"core dump" / "core file". This can be used with some additional
debugging techniques that won't be discussed in the course. Core files
are removed whenever `make clean` is run.

## Optional Additional Questions/Discussion Points
1. Q: How does one run a single test and see failure messages in the
   terminal?
   - `make test-prob1 testnum=1`
2. Q: What is an Invalid read? What is an invalid Write?
   - A: These are attempts to either read/access/get memory or
      write/change/store data at an address that seems out of bounds
      or very suspect according to Valgrind. That action is likely to
      lead to non-deterministic behavior anther program so is almost
      certainly a bug.
3. Q: What C types are associated with a read/write of size 4? of size 8?
   A: ints/floats are size 4 bytes, longs/doubles/pointers are size 8
4. Q: What are the lines that Valgrind shows after reporting an invalid
   Read/Write, specifically lines 2 and 3 below?
```
  1: ==217193== Invalid read of size 4
  2: ==217193==    at 0x10923F: insertion_sort (mon_main.c:11)
  3: ==217193==    by 0x1096F7: main (mon_main.c:105)
  4: ==217193==  Address 0x4a9f5c4 is 12 bytes before an unallocated block of size 4,188,688 in arena "client"
```
  - A This is a stack trace of the active functions when the problem
    occurred; this specific stack trace is what is shown after fixing
    the very first bug in the `mon_main.c` file (not allocating a big
    enough array of `mon_t` structs); after fixing that, execution
    proceeded to call the `insertion_sort()` function in `main()` but
    triggers a memory error there indicated in the error message

ADVANCED: mention to students that they can copy the command line
given in the VALGRIND REPORT and paste it in the terminal to run the
tests under valgrind outside of the testing framework. This will show
normal program output and Valgrind errors interleaved which is
sometimes useful:

```text
VALGRIND REPORT
---------------
The program is run on under valgrind as
  stdbuf -i 0 -o 0 -e 0 valgrind --error-exitcode=13 --leak-check=full --show-leak-kinds=all --track-origins=yes ./mon_main mon-lvl1.txt Fire
which may be pasted onto a command line to run it.
```

```console
>> stdbuf -i 0 -o 0 -e 0 valgrind --error-exitcode=13 --leak-check=full --show-leak-kinds=all --track-origins=yes ./mon_main mon-lvl1.txt Fire
...
```

# Wed : Makefiles
- Discuss basic syntax of Makefiles surveyed in lab web page; students
  will have seen this in lecture but will likely need a refresher to
  stay oriented
- Discuss examples provided in subdirectories
  - makeproblem-demo-little/Makefile : simplest version for
    small project
  - makeproblem-demo-little/Makefile-shortcuts : introduces
    variables and pattern rules; DON'T spend a lot of time on this,
    just mention that like most programmatic systems, Makefiles have
    more features
  - makeproblem-demo-big/Makefile : larger version, verbose as
    it doesn't use any shortcuts
  - makeproblem-demo-big/Makefile-shortcuts : good use of variables
    and pattern rules to make the Makefile shorter
- Direct students to complete the provided template in
  prob1-makefile/Makefile
- Discuss the @ syntax which will omit printing commands being run by
  the Makefile which can make output look a bit nicer; EXAMPLE:
```makefile
targ1 :
   echo "hello world"

targ2 :
   @echo "hello world"
```
Shell run:
```shell
>> make targ1
echo "hello world"    # prints command to be run
hello world           # prints output of comand

>> make targ2
hello world           # @ omits printing command, only output shown
```  

NOTE: Keep an eye on automated tests; they are a bit tricky to write
for Makefiles but this problem has worked okay

