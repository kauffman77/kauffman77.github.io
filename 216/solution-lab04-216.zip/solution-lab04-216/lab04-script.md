# Monday
- Indicate to students that the focus of the lab is to debug an
  existing program with memory problems and get practice and reading
  Valgrind messages and using them to solve the problems
- Have students grab the code pack and review the short "Note" from
  Prof Oak which is at the top of the QUESTIONS.txt file
- Talk through briefly the intended behavior of the program as shown
  in the QUESITONS.txt file and show the contents of some of the data
  files, named "mon-*.txt" such as

```
>> cat mon-top5.txt 
Pikachu 320 Electric
Bulbasaur 318 Grass
Charmander 309 Fire
Squirtle 314 Water
Psyduck 320 Water
```

- Files are set up with "name hp type" on each line
- Show the students that the current `mon_main.c` program segfaults on
  running on any data files
- Run the test cases and start diagnosing the problems identified by
  Valgrind; point out to students that there are two places to look:
  1. The Side-by-Side output; memory problems are bad enough in this
     program that Valgrind complains here
  2. The VALGRIND REPORT further down which shows detailed output of
     where Valgrind finds errors
- Walk students through the QUIZ questions jumping between the QUIZ in
  QUESTIONS.txt, the test results for `make test-code testnum=1`, and
  the source code for `mon_main.c` where changes are made to reduce
  and eventually eliminate the errors for Test #1
- Let students continue to work on resolving the remaining tests which
  require some more code changes to resolve errors
- If in doubt, examine the QUESTIONS.SOLUTIONS.txt file which has some
  more information on how to fix some of the early bugs in the
  SOLUTION sections
- The `mon_main.solution.txt` has all bugs fixed and are marked with
  comments with the pattern //!  after which appears buggy code in the
  `mon_main.student.c` version

# Wednesday
Review with students where to find Valgrind reports in the output for
running tests: the VALGRIND REPORT near the bottom of the
`test-results.md` files.

Do some quick spot checks with students on basic Valgrind error
messages that are part of the lab; here are some suggested
question/answers
1.  Q How does one run a single test and see failure messages  in the terminal?
  - `make test-code testnum=1`
2.  Q What is an Invalid read? What is an invalid Write?
  - A These are attempts to either read/access/get memory or
    write/change/store data at an address that seems out of bounds or
    very suspect according to Valgrind. That action is likely to lead
    to non-deterministic behavior anther program so is almost
    certainly a bug.
3.  Q What C types are associated with a read/write of size 4? of size 8?
  - A ints/floats are size 4 bytes, longs/doubles/pointers are size 8
4.  Q What are the lines that Valgrind shows after reporting an invalid
  Read/Write, specifically lines 2 and 3 below?
```
  1: ==217193== Invalid read of size 4
  2: ==217193==    at 0x10923F: insertion_sort (mon_main.c:11)
  3: ==217193==    by 0x1096F7: main (mon_main.c:105)
  4: ==217193==  Address 0x4a9f5c4 is 12 bytes before an unallocated block of size 4,188,688 in arena "client"
```
  - A This is a stack trace of the active functions when the problem
    occurred; this specific stack trace is what is shown after fixing
    the very first bug in the `mon_main.c` file (not allocating a big
    enough array of `mon_t` structs); after fixing that, execution
    proceeded to call the `insertion_sort()` function in `main()` but
    triggers a memory error there indicated in the error message

MENTION: when programs crash under Valgrind, they will often create a
"core dump" / "core file". This can be used with some additional
debugging techniques that won't be discussed in the course. Core files
are removed whenever `make clean` is run.

ADVANCED: mention to students that they can copy the command line
given in the VALGRIND REPORT and paste it in the terminal to run the
tests under valgrind outside of the testing framework. This will show
normal program output and Valgrind errors interleaved which is
sometimes useful:

```text
VALGRIND REPORT
---------------
The program is run on under valgrind as
  stdbuf -i 0 -o 0 -e 0 valgrind --error-exitcode=13 --leak-check=full --show-leak-kinds=all --track-origins=yes ./mon_main mon-lvl1.txt Fire
which may be pasted onto a command line to run it.
```

```console
>> stdbuf -i 0 -o 0 -e 0 valgrind --error-exitcode=13 --leak-check=full --show-leak-kinds=all --track-origins=yes ./mon_main mon-lvl1.txt Fire
...
```

Give students time work on completing the lab AND mention that staff
are willing to help with Project 1 questions as well.
