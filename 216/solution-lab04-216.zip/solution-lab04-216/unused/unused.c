// Original version of insertion sort that uses slightly different indexing 

// Sort the data in the `marr` array according to the numeric value
// of the hp field in each.
void insertion_sort(mon_t *marr, int count){
  for(int i=1; i<count; i++){   //!  for(int i=0; i<count; i++){
    for(int j=i; j>0; j--){
      if(marr[j].hp > marr[j-1].hp){
        break;
      }
      mon_t tmp = marr[j-1];
      marr[j-1] = marr[j];
      marr[j] = tmp;
    }
  }
  return;
}

