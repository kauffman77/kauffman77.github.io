// masking.c: Demonstrates various techniques for bit-wise
// manipulation. Complete the TODO items.
#include <stdio.h>

void print_intbits(int num);

int hash = 8765309;

int main(int argc, char *argv[]){
  int x;

  printf("x has only the 16th bit set\n");
  x = 1 << 16;
  print_intbits(x);

  printf("x as decimal: %d\n", x);
  printf("x as octal  : %o\n", x);
  printf("x as hex    : %x\n", x);
  printf("\n");

  printf("set 19th bit as well\n");
  x = x | (1 << 19);
  print_intbits(x);

  printf("set 3rd bit as well\n");
  // TODO: set the indicate bit in x
  // // ???
  x = x | (1 << 3);
  print_intbits(x);

  printf("invert the bits\n");
  x = ~x;
  print_intbits(x);

  printf("clear the 8th bit\n");
  x = x & ~(1 << 8);
  print_intbits(x);
  
  printf("clear the 25th bit\n");
  // TODO: clear given bit in x
  // // ???
  x = x & ~(1 << 25);
  print_intbits(x);
  
  printf("clear all bits via xor\n");
  x = x ^ x;
  print_intbits(x);

  printf("place the pattern 110101 starting at bit 8\n");
  x = x | (0b110101 << 8);
  print_intbits(x);

  printf("place the pattern 10011111 starting at bit 20\n");
  // TODO: place pattern at indicatd position
  // // ???
  x = x | (0b10011111 << 20);
  print_intbits(x);
  
  int y;
  printf("set y to be x shifted right by 4 bits\n");
  y = x >> 4;
  print_intbits(y);

  printf("set y to be x shifted right by 24 bits\n");
  // TODO: assign y based on shift
  // // ???
  y = x >> 24;
  print_intbits(y);
  
  printf("conditionally print 'x 13th bit SET' or 'x 13th bit CLEAR'\n");
  if( x & (1 << 13) ){
    printf("x 13th bit SET\n");
  }
  else{
    printf("x 13th bit CLEAR\n");
  }
  printf("\n");

  printf("conditionally print 'y 4th bit SET' or 'y 4th bit CLEAR'\n");
  // TODO: check given bit
  // if(0) { // ???
  if( y & (1 << 4) ){
    printf("y 4th bit SET\n");
  }
  else{
    printf("y 4th bit CLEAR\n");
  }
  printf("\n");

  // An interesting use of bit shifting
  int targ = 0;
  targ |= 1 << (hash % 13);
  targ = targ << (hash % 3);
  targ |= 1 << (hash % 19);
  targ = targ << (hash % 5);
  targ |= 1 << (hash % 31);
  targ = targ << (hash % 7);

  printf("Reading 4 ints from masking_input.txt to aim a shot\n");
  FILE *fin = fopen("masking_input.txt","r");
  int a,b,c,d;
  fscanf(fin, "%d %d %d %d", &a,&b,&c,&d);
  fclose(fin);

  int shot = 0;
  shot |= 1 << a;
  shot |= 1 << b;
  shot |= 1 << c;
  shot |= 1 << d;

  int hit = shot ^ targ;
  hit = !hit;

  if(hit){
    printf("Right on target: nice shootin' bitslinger!\n");
    return 0;
  }
  else{
    printf("Shifty bits hit? Xor not it seems...\n");
    printf("Ask your old friend GDB for help!\n");
    return 1;
  }
}

void print_intbits(int num){
  char *indexes = "\
  28   24   20   16   12    8    4    0\
";
  char bits[32+8+1] = {};       // 32 1/0, 8 spaces, 1 \0
  int idx = 0;
  for(int i=0; i<32; i++){
    if(i>0 && i%4==0){
      bits[idx] = ' ';
      idx++;
    }
    bits[idx] = num & (1 << (31-i)) ? '1' : '0';
    idx++;
  }
  printf("bits:  %s\n",bits);
  printf("index: %s\n",indexes);
  printf("\n");
}
