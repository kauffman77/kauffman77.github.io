#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  char name[64];
  int hp;
  char type[64];
} mon_t;

void insertion_sort(mon_t *marr, int count);
