// demo code for student discussion of C structs in assembly
#include <stdio.h>
typedef struct node_struct {
  char data[128];
  struct node_struct *next;
} node_t;


void node_copy(node_t *dest, node_t *src){
  *dest = *src;
}

int main(int argc, char *argv[]){
  node_t a = {.data="Chris Kauffman", .next=NULL};
  node_t b = {.data="EMPTY",          .next=&a  };

  // b = a;
  node_copy(&b, &a);

  printf("b.data: %s\n",b.data);
  printf("b.next: %p\n",b.next);

  return 0;
}

