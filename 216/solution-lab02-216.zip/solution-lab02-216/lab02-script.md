# NOTE for returning TAs
lab02 has one additional `remove` command/function in it that
was not present in past semesters

# Monday
- Demos this week pertain to Lab02 as Lab01 is already past due
- Download code pack, unzip it 
  - Possibly use right-click + copy link and then
    ```sh
    wget https://cs.umd.edu/~profk/216/lab02-code.zip
    unzip lab02-code.zip
    ```
    to show downloading / unpacking in a terminal
  - Alternatively download zip to local machine and use a
    Local->Remote Sync
- Open QUESTIONS.txt so students are aware of its instructions
- Demonstrate `make`, that it runs gcc commands and creates
  `list_main`
- Run `./list_main` and play with the code a bit, exit
- Demo how `make` has several other "targets" that are useful while
  working on projects
- Demonstrate several other build commands
```
>> make help    # show docs build targets
>> make clean   # removes all compiled files
>> make test    # run all tests

>> make test-quiz             # check quiz answers
>> make test-code testnum=3   # run single test on code portion of lab, show errors in terminal
```
- Call attention to structure of project
  - list.h header file with data types, function listings
  - list_funcs.c: functions manipulating lists
  - list_main.c: interactive application
- Indicate this basic project architecture is common
  - Header file with common data types and function prototypes
  - C files with service ("helper") functions
  - C file with a `main()` function in it
- Show students a cycle of 
  - Edit a source file
  - Run `make test-code` or `make test-code testnum=2` 
  - Check results, then edit again
  Call attention to how `make` will recompile a changed program and
  then run tests which is handy
- Focus attention on fixing the problems with `get / list_get()`
- Give work time to begin looking at the code and diagnosing bugs
- Before closing, walk through the QUIZ questions and call attention
  to items like use of the strcmp() function : likely to be used in
  a future project

# Wednesday
- Quickly review build commands 
  - How do you run a single code test?
  - How do you run all tests (QUIZ + CODE)
  - How do you create a zip file for completion?
- Demonstrate that students can edit code then do `make test-code` and
  their program will be rebuilt automatically before running tests
- Show test results file for several of the failing tests
- MAKE SURE STUDENTS KNOW HOW TO LOOK AT TEST RESULTS FILES LIKE
  `test-results/list_main-02-result.md`
  as these files will contain the first information to look at when
  debugging labs and projects
  - May require a "Remote->Local" sync to see the `test-results/`
    folder
  - Alternatively show
    `cat test-results/list_main-02-result.md`
    to show contents of a file in terminal or
    `less test-results/list_main-02-result.md`
    to page results, Space scrolls down, with "q" quits
- Identify in test results files
  1. Failure Messages which summarize what is wrong 
  2. Side-by-side differences
  3. Note the use of the "insert" command
- Guide students first to the portion of `list_main.c` where "insert"
  is handled, tie this to the function `list_insert()` which is in
  `list_functions.c`
- Give students some time to work out this bug
- Demo the Fix and the results of `make test-code`
- After code changes, re-run the tests to see that one more is passing
- Mention that the last test requires modifying both C source files to
  add new functionality
- Let students attend to remaining code to fixes, `contains /
  list_contains()` function is straight-forward
- Warn students that getting `list_remove()` correct is a bit tricky
  as there are risks with memory problems: no use after free() if you
  want to avoid Valgrind errors; students may want to consult a
  reference for some help
  
