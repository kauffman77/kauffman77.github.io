(TEST 1) QUIZ: QUESTIONS.txt : ok
=================================

COMMENTS
--------
This test determines if the answers in QUESTIONS.txt are correct. This
file must be edited so that the correct ( ) choices are replaced with
(X) AND no other changes are made to the file. If you are confident in
your answers but think you may have made inadvertent changes to
QUESTIONS.txt, you can try restoring it with the provided
QUESTIONS.txt.bk file.
The correct output for the test should be 
: -: OK
Note: the md5sum program is used for to verify and must be installed
to work.

PROGRAM: bash -v
----------------
To run this individual test in GDB use the command:
  gdb --args bash -v
but any input to the program must be typed within the debugger

FAILURE MESSAGES
----------------
None

SIDE-BY-SIDE DIFF of Expected vs Actual
---------------------------------------
. lines match; | lines differ; < expected line missing; > extra line in actual

```sdiff
===EXPECT===                                                    ===ACTUAL===
>> ./test_quiz_filter QUESTIONS.txt | md5sum -c QUESTIONS.md5 . >> ./test_quiz_filter QUESTIONS.txt | md5sum -c QUESTIONS.md5
-: OK                                                         . -: OK

```

LINE-BY-LINE DIFF of Expected vs Actual
---------------------------------------
No differences found

VALGRIND Not in Use
-------------------
SUMMARY
-------
Test Passed
