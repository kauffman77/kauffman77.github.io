(TEST 2) CODE: list_main : ok
=============================

COMMENTS
--------
Runs various tests on the list_main application; copies of the tests
in test_list_main.org.

Test Segment 1 : ok
-------------------
** Print then Exit
Print the empty list and exit

### PROGRAM: ./list_main -echo
To run this individual test in GDB use the command:
gdb --args ./list_main -echo
but any input to the program must be typed within the debugger

### FAILURE MESSAGES
None

### SIDE-BY-SIDE DIFF of Expected vs Actual
. lines match; | lines differ; < expected line missing; > extra line in actual

```sdiff
===EXPECT===                                                    ===ACTUAL===
Linked List Demo                                              . Linked List Demo
Commands:                                                     . Commands:
  print:          shows the current contents of the list      .   print:          shows the current contents of the list
  clear:          eliminates all elements from the list       .   clear:          eliminates all elements from the list
  exit:           exit the program                            .   exit:           exit the program
  insert thing:   inserts the given string into the list      .   insert thing:   inserts the given string into the list
  get index:      get the item at the given index             .   get index:      get the item at the given index
  contains thing: determine if the given thing is in the list .   contains thing: determine if the given thing is in the list
                  (NOT YET IMPLEMENTED)                       .                   (NOT YET IMPLEMENTED)
list> print                                                   . list> print
list> exit                                                    . list> exit

```

### LINE-BY-LINE DIFF of Expected vs Actual
No differences found

### VALGRIND REPORT
The program is run on under valgrind as
stdbuf -i 0 -o 0 -e 0 valgrind --error-exitcode=13 --leak-check=full --show-leak-kinds=all --track-origins=yes ./list_main -echo
which may be pasted onto a command line to run it.

```
==39== Memcheck, a memory error detector
==39== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==39== Using Valgrind-3.18.1 and LibVEX; rerun with -h for copyright info
==39== Command: ./list_main -echo
==39== 
==39== 
==39== HEAP SUMMARY:
==39==     in use at exit: 0 bytes in 0 blocks
==39==   total heap usage: 0 allocs, 0 frees, 0 bytes allocated
==39== 
==39== All heap blocks were freed -- no leaks are possible
==39== 
==39== For lists of detected and suppressed errors, rerun with: -s
==39== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

Test Segment 2 : ok
-------------------
** Insert 3 and Print
Add several items then print them back.

### PROGRAM: ./list_main -echo
To run this individual test in GDB use the command:
gdb --args ./list_main -echo
but any input to the program must be typed within the debugger

### FAILURE MESSAGES
None

### SIDE-BY-SIDE DIFF of Expected vs Actual
. lines match; | lines differ; < expected line missing; > extra line in actual

```sdiff
===EXPECT===                                                    ===ACTUAL===
Linked List Demo                                              . Linked List Demo
Commands:                                                     . Commands:
  print:          shows the current contents of the list      .   print:          shows the current contents of the list
  clear:          eliminates all elements from the list       .   clear:          eliminates all elements from the list
  exit:           exit the program                            .   exit:           exit the program
  insert thing:   inserts the given string into the list      .   insert thing:   inserts the given string into the list
  get index:      get the item at the given index             .   get index:      get the item at the given index
  contains thing: determine if the given thing is in the list .   contains thing: determine if the given thing is in the list
                  (NOT YET IMPLEMENTED)                       .                   (NOT YET IMPLEMENTED)
list> insert Mario                                            . list> insert Mario
list> insert Luigi                                            . list> insert Luigi
list> insert Toad                                             . list> insert Toad
list> print                                                   . list> print
0: Luigi                                                      . 0: Luigi
1: Mario                                                      . 1: Mario
2: Toad                                                       . 2: Toad
list> exit                                                    . list> exit

```

### LINE-BY-LINE DIFF of Expected vs Actual
No differences found

### VALGRIND REPORT
The program is run on under valgrind as
stdbuf -i 0 -o 0 -e 0 valgrind --error-exitcode=13 --leak-check=full --show-leak-kinds=all --track-origins=yes ./list_main -echo
which may be pasted onto a command line to run it.

```
==40== Memcheck, a memory error detector
==40== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==40== Using Valgrind-3.18.1 and LibVEX; rerun with -h for copyright info
==40== Command: ./list_main -echo
==40== 
==40== 
==40== HEAP SUMMARY:
==40==     in use at exit: 0 bytes in 0 blocks
==40==   total heap usage: 3 allocs, 3 frees, 408 bytes allocated
==40== 
==40== All heap blocks were freed -- no leaks are possible
==40== 
==40== For lists of detected and suppressed errors, rerun with: -s
==40== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

Test Segment 3 : ok
-------------------
** Get Command 
Checks that the ~get N~ command works correctly to return the value at
the Nth index of the list.

### PROGRAM: ./list_main -echo
To run this individual test in GDB use the command:
gdb --args ./list_main -echo
but any input to the program must be typed within the debugger

### FAILURE MESSAGES
None

### SIDE-BY-SIDE DIFF of Expected vs Actual
. lines match; | lines differ; < expected line missing; > extra line in actual

```sdiff
===EXPECT===                                                    ===ACTUAL===
Linked List Demo                                              . Linked List Demo
Commands:                                                     . Commands:
  print:          shows the current contents of the list      .   print:          shows the current contents of the list
  clear:          eliminates all elements from the list       .   clear:          eliminates all elements from the list
  exit:           exit the program                            .   exit:           exit the program
  insert thing:   inserts the given string into the list      .   insert thing:   inserts the given string into the list
  get index:      get the item at the given index             .   get index:      get the item at the given index
  contains thing: determine if the given thing is in the list .   contains thing: determine if the given thing is in the list
                  (NOT YET IMPLEMENTED)                       .                   (NOT YET IMPLEMENTED)
list> get 0                                                   . list> get 0
out of bounds                                                 . out of bounds
list> get 5                                                   . list> get 5
out of bounds                                                 . out of bounds
list> insert apple                                            . list> insert apple
list> insert pair                                             . list> insert pair
list> insert banana                                           . list> insert banana
list> print                                                   . list> print
0: apple                                                      . 0: apple
1: banana                                                     . 1: banana
2: pair                                                       . 2: pair
list> get 0                                                   . list> get 0
0: apple                                                      . 0: apple
list> get 1                                                   . list> get 1
1: banana                                                     . 1: banana
list> get 2                                                   . list> get 2
2: pair                                                       . 2: pair
list> get 3                                                   . list> get 3
out of bounds                                                 . out of bounds
list> exit                                                    . list> exit

```

### LINE-BY-LINE DIFF of Expected vs Actual
No differences found

### VALGRIND REPORT
The program is run on under valgrind as
stdbuf -i 0 -o 0 -e 0 valgrind --error-exitcode=13 --leak-check=full --show-leak-kinds=all --track-origins=yes ./list_main -echo
which may be pasted onto a command line to run it.

```
==41== Memcheck, a memory error detector
==41== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==41== Using Valgrind-3.18.1 and LibVEX; rerun with -h for copyright info
==41== Command: ./list_main -echo
==41== 
==41== 
==41== HEAP SUMMARY:
==41==     in use at exit: 0 bytes in 0 blocks
==41==   total heap usage: 3 allocs, 3 frees, 408 bytes allocated
==41== 
==41== All heap blocks were freed -- no leaks are possible
==41== 
==41== For lists of detected and suppressed errors, rerun with: -s
==41== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

Test Segment 4 : ok
-------------------
** Contains Items
Add several items then print them back.

### PROGRAM: ./list_main -echo
To run this individual test in GDB use the command:
gdb --args ./list_main -echo
but any input to the program must be typed within the debugger

### FAILURE MESSAGES
None

### SIDE-BY-SIDE DIFF of Expected vs Actual
. lines match; | lines differ; < expected line missing; > extra line in actual

```sdiff
===EXPECT===                                                    ===ACTUAL===
Linked List Demo                                              . Linked List Demo
Commands:                                                     . Commands:
  print:          shows the current contents of the list      .   print:          shows the current contents of the list
  clear:          eliminates all elements from the list       .   clear:          eliminates all elements from the list
  exit:           exit the program                            .   exit:           exit the program
  insert thing:   inserts the given string into the list      .   insert thing:   inserts the given string into the list
  get index:      get the item at the given index             .   get index:      get the item at the given index
  contains thing: determine if the given thing is in the list .   contains thing: determine if the given thing is in the list
                  (NOT YET IMPLEMENTED)                       .                   (NOT YET IMPLEMENTED)
list> insert Mario                                            . list> insert Mario
list> insert Luigi                                            . list> insert Luigi
list> insert Toad                                             . list> insert Toad
list> insert Bowser                                           . list> insert Bowser
list> insert Princess                                         . list> insert Princess
list> contains Mario                                          . list> contains Mario
'Mario' is present                                            . 'Mario' is present
list> contains Luigi                                          . list> contains Luigi
'Luigi' is present                                            . 'Luigi' is present
list> contains Princess                                       . list> contains Princess
'Princess' is present                                         . 'Princess' is present
list> contains Gumba                                          . list> contains Gumba
not found                                                     . not found
list> contains Bob-omb                                        . list> contains Bob-omb
not found                                                     . not found
list> exit                                                    . list> exit

```

### LINE-BY-LINE DIFF of Expected vs Actual
No differences found

### VALGRIND REPORT
The program is run on under valgrind as
stdbuf -i 0 -o 0 -e 0 valgrind --error-exitcode=13 --leak-check=full --show-leak-kinds=all --track-origins=yes ./list_main -echo
which may be pasted onto a command line to run it.

```
==42== Memcheck, a memory error detector
==42== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==42== Using Valgrind-3.18.1 and LibVEX; rerun with -h for copyright info
==42== Command: ./list_main -echo
==42== 
==42== 
==42== HEAP SUMMARY:
==42==     in use at exit: 0 bytes in 0 blocks
==42==   total heap usage: 5 allocs, 5 frees, 680 bytes allocated
==42== 
==42== All heap blocks were freed -- no leaks are possible
==42== 
==42== For lists of detected and suppressed errors, rerun with: -s
==42== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

### SUMMARY
Test Passed
