#include <stdio.h>
void func2(){
  printf("running func2\n");
}
