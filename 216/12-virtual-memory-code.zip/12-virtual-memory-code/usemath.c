#include <stdio.h>
#include <math.h>

int main(){
  double s2 = pow(2.1, 3.6);
  printf("pow() = %f\n",s2);
  getchar();
  return 0;
}
