// print_file.c: Standard method to print a file character by
// character. Requires a storage space for characters as they are read
// from the file. Contrast this approach with mmap_print_file.c
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <file>\n",argv[0]);
    return 0;
  }

  int fin = open(argv[1], O_RDONLY);           // open file to get file descriptor
  char inbuf[256];
  while(1){                                    // loop over the file
    int nread =
      read(fin, inbuf, sizeof(char)*256);      // read some characters from the file
    if(nread == 0){                            // check for end of file
      break;
    }
    for(int i=0; i<nread; i++){
      printf("%c",inbuf[i]);
    }
  }

  close(fin);                                  // close the file
  return 0;
}
