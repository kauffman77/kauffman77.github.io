// reversal_benchmark.c: Tests 2 versions of an array reversal
// code. Add timing information to determine which is more efficient
// and optionally implement a further optimized version.

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

void reverse_arr1(int *arr, long size){
  int *tmp = malloc(sizeof(int)*size);
  for(long i=0; i<size; i++){
    tmp[i] = arr[size-i-1];
  }
  for(long i=0; i<size; i++){
    arr[i] = tmp[i];
  }
  free(tmp);
}

void reverse_arr2(int *arr, long size){
  for(long i=0; i<size/2; i++){
    int tmp = arr[i];
    arr[i] = arr[size-i-1];
    arr[size-i-1] = tmp;
  }
}

int main(int argc, char *argv[]){
  if(argc < 4){
    printf("usage: %s <min_pow2> <max_pow2> <repeats>\n",argv[0]);
    return 1;
  }
  int minsize = atoi(argv[1]);
  int maxsize = atoi(argv[2]);
  int repeats = atoi(argv[3]);

  printf("%10s ","SIZE");
  printf("%8s ","rev1");
  printf("%8s ","rev2");
  printf("\n");

  for(long s=minsize; s<=maxsize; s++){
    long size = 1 << s;

    printf("%10ld ",size);

    int *arr1 = malloc(sizeof(int)*size);
    int *arr2 = malloc(sizeof(int)*size);
    for(long i=0; i<size; i++){
      arr1[i] = i;
      arr2[i] = i;
    }

    // TODO: Run reverse_array1() on arr1[] which has repeatedly in a
    // loop `repeats` times; time the entirety of this run and print
    // the time with 5 digits of accuracy
    

    // TODO: Run reverse_array2() on arr2[] repeatedly in a loop
    // `repeats` times; time the entirety of this run and print the
    // time with 5 digits of accuracy

    printf("\n");

    // check array contents are correct 
    if(repeats % 2 == 0){       // even # repeats: arrays ordered
      for(long i=0; i<size; i++){
        assert(arr1[i] == i);
        assert(arr2[i] == i);
      }
    }
    else{                       // odd # repeats: arrays reversed
      for(long i=0; i<size; i++){
        assert(arr1[i] == size-i-1);
        assert(arr2[i] == size-i-1);
      }
    }

    free(arr1);
    free(arr2);
  }

  return 0;
}
