#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sysmacros.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>

// returns difference in times between a-b; positive return means a is
// newer than b; negative indicates b is newer than a
long diff_timespec(struct timespec a, struct timespec b){
  long diff = a.tv_sec - b.tv_sec;
  if(diff != 0){
    return diff;
  }
  diff = a.tv_nsec - b.tv_nsec;
  return diff;
}

int main(int argc, char *argv[]) {
  if (argc < 3) {
    fprintf(stderr, "Usage: %s <file1> <file2>\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  char *file1 = argv[1];
  char *file2 = argv[2];

  // TODO: check that file1 and file2 both exist. If one of the
  // following situatinos arises, print an appropriate message and
  // exit with code 1.
  // 
  // Both FILE1 and FILE2 cannot be accessed
  // FILE1 cannot be accessed
  // FILE2 cannot be accessed
  //
  // Replace FILE1/FILE2 with the names of the files

  // YOUR LINES OF CODE HERE

  // Now that both files exist, compare time stamps for them

  // TODO: Call stat() on each file and extract their `st_mtim` field
  // which is a `struct timespec` indicating the last modification
  // time for the file. Pass these two to the provided diff_timespec()
  // function and use the result to print a message according the
  // following situations.
  //
  // FILE1 and FILE2 are EQUAL in age
  // FILE1 is OLDER than FILE2
  // FILE1 is NEWER than FILE2

  // YOUR LINS OF CODE HERE

  return 0;
}
