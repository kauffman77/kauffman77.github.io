// file instead of onto the screen. Uses dup2(), fork(), and wait()
// for this.
//
// COMPLETE this code by filling in the TODO/??? items

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

int main(int argc, char *argv[]){
  if(argc < 2){                                // check for at least 1 command line arg
    printf("usage: %s <childfile>\n", argv[0]);
    return 1;
  }
           
  char *child_file = argv[1];                 // output file that child process will print into
  char *child_argv[] = {"wc","nums.txt",NULL}; // child command/argumnets to execute; redirect output to file above

  printf("Removing file '%s' prior to run via a subshell\n",
         child_file);

  // recreate nums.txt in case of accidental modification
  printf("Recreating file 'nums.txt' prior to run via a subshell\n");
  system("rm -f nums.txt && seq 25 > nums.txt");
  
  printf("Creating a child to do '%s'\n", child_argv[0]);

  // TODO: Spawn a child process
  ??? = ???;

  // CHILD CODE
  // TODO: Conditional for child only
  if(pid == 0){ if( ??? ){
           child_file);

    // TODO: Open child_file for writing, same options as in switch_stdout.c
    int out_fd = ???
    if(out_fd == -1){
      fprintf(stderr,"ERROR: could not open output file '%s' : %s\n",
              child_file,strerror(errno));
      exit(1);
    }
    
    // TODO: Copy out_fd to standard output FD table entry
    d??? ( ??? );
    
    // TODO: Execute the command in child_argv[] replacing this process
    exec??( ??? );

    printf("exec() seems to have failed...\n"); // should not reach this 
    exit(1);
  }

  // PARENT CODE
  printf("Parent waiting for child to complete\n");
  int status;                           // used to check return code of child

  // TODO: Block until child is finished and check the output
  ???? ( ??? );


  // TODO: check if the child exited properly using wait macros
  if( ??? ){

    // TODO: extract exit/return code of child process using wait macros
    int retcode = ???;

    printf("Child complete, exit code %d\n",exit_code);
  }
  else{                                        // Child did not complete properly
    printf("Child terminated abnormally\n");
    exit(1);
  }

  printf("Showing output of '%s' via 'cat' command\n",
         child_file);
  // Create another command to show the contents of child_file; use
  // system() to 'cat' the contents to the screen
  char command[128];
  sprintf(command, "cat %s", child_file);
  system(command);

  return 0;
}
