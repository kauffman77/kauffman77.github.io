#include <stdio.h>
void func_02(){
  printf("Calling function func_02\n");
}
