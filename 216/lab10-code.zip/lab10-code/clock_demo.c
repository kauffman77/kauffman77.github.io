#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>               // for clock() and other functions
#include <stdio.h>
#include <sys/time.h>

int main(int argc, char *argv[]){

  if(argc < 3){
    printf("usage: %s <arrlen> <repeats>\n",argv[0]);
    return 1;
  }

  int length  = atoi(argv[1]);
  int repeats = atoi(argv[2]);

  int *data = malloc(length*sizeof(int));
  for(int i=0; i<length; i++){
    data[i] = i;
  }

  clock_t begin, end;

  printf("Summing array length %d with %d repeats, ascending\n",
         length,repeats);
  int suma=0;
  begin = clock();                 // get current cpu moment
  for(int r=0; r<repeats; r++){
    suma=0;
    for(int i=0; i<length; i++){
      suma += data[i];
    }
  }
  end = clock();                   // get later cpu moment 

  // convert to elapsed cpu time
  double ascend_time = ((double) (end - begin)) / CLOCKS_PER_SEC;

  printf("Summing array length %d with %d repeats, descending\n",
         length,repeats);
  int sumd=0;
  begin = clock();                 // get current cpu moment
  for(int r=0; r<repeats; r++){
    sumd=0;
    for(int i=length-1; i>=0; i--){
      sumd += data[i];
    }
  }
  end = clock();                   // get later cpu moment 
  // convert to elapsed cpu time
  double descend_time = ((double) (end - begin)) / CLOCKS_PER_SEC;

  const char *FORMAT =
    "method: %14s CPU time: %.4e sec   sum: %d\n";

  printf(FORMAT, "sum ascending", ascend_time, suma);
  printf(FORMAT, "sum descending", descend_time, sumd);

  free(data);
  return 0;
}

