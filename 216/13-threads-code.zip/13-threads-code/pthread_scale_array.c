// pthread_scale_array.c: Demonstrates combination of thread tactics
// including use of a Barrier (pthread_barrier) to coordinate multiple
// parts of a computation within worker threads.

#include <stdio.h>
#include <stdlib.h> 
#include <pthread.h>
#include <sys/time.h>

// Look mah, no globals!

// "Context" struct to carry needed data to a worker thread
typedef struct {                                 // struct giving info to each thread
  int thread_id;                                 // thread's logical id numbered 0,1,2,...
  int num_threads;                               // number of threads that will cooperate
  double *array;                                 // shared array among all threads
  long array_len;                                // length of the array set on command line
  pthread_mutex_t *lock;                         // lock to control access to total_sum
  pthread_barrier_t *barrier;                    // barrier to coordinate thread progress
  double *total_sum;                             // pointer to overall sum, shared var
} work_context_t;


void *workfunc(void *arg){                       // thread worker function
  work_context_t *context =
    (work_context_t*) arg;                       // caste parameter to context
  work_context_t ctx = *context;
  long count = (ctx.array_len / ctx.num_threads); // how many elements each thread should sum up
  long start = ctx.thread_id*count;               // where this thread start in the array, based on its ID
  long stop  = (ctx.thread_id+1)*count;           // where this thread should stop
  if(ctx.thread_id == ctx.num_threads-1){         // last thread goes to end of array in case 
    stop = ctx.array_len;                         // the array length is not evenly divisible by num_threads
  }
  printf("Thread %d summing elements %d to %d\n",
         ctx.thread_id,start,stop);

  double my_sum = 0.0;                           // local sum for this thread's portion of the array
  for(long i=start; i<stop; i++){
    my_sum += ctx.array[i];
  }
  printf("Thread %d sum is %.1f\n", ctx.thread_id, my_sum);

  // CRITICAL REGION
  pthread_mutex_lock(ctx.lock);                  // lock the shared data
  *ctx.total_sum += my_sum;                      // update it
  pthread_mutex_unlock(ctx.lock);                // unlock

  printf("Thread %d waiting for other threads\n", ctx.thread_id, my_sum);

  pthread_barrier_wait(ctx.barrier);             // threads wait until total sum is complete

  printf("Thread %d scaling elements %d to %d\n",
         ctx.thread_id,start,stop);
         
  my_sum = *ctx.total_sum;                       // get a local copy of the total

  for(long i=start; i<stop; i++){                // scale all elements by dividing by 
    ctx.array[i] /= my_sum;                      // the sum. No coordination needed due
  }                                              // threads working on separate parts of the array

  return NULL;
}

// For collecting timing
struct timeval beg_time, end_time;

void timing_start(){
  gettimeofday(&beg_time, NULL);
}

double timing_stop(){
  gettimeofday(&end_time, NULL);
  double wall_time = 
    ((end_time.tv_sec-beg_time.tv_sec)) + 
    ((end_time.tv_usec-beg_time.tv_usec) / 1000000.0);
  return wall_time;             // real-world time
}

int main(int argc, char *argv[]) { 
  if(argc < 3){
    printf("usage: %s <array_len> <num_threads>\n",argv[0]);
    printf("  array_len:   int, length of the array to sum\n");
    printf("  num_threads: int, number of threads to use for the computation\n");
    return -1;
  }

  int array_len = atoi(argv[1]);                 // set globals from command line
  int num_threads = atoi(argv[2]);

  double *array = malloc(sizeof(double)*array_len);
  for(int i=0; i<array_len; i++){
    array[i] = 1.0;                              // all 1.0 to make it easy to determine correctness
  }

  timing_start();
  pthread_mutex_t lock;                          // lock to control access to shared total_sum
  pthread_mutex_init(&lock,NULL);                

  pthread_barrier_t barrier;                     // barrier to coordinate thread progress
  pthread_barrier_init(&barrier,NULL,num_threads);                

  double total_sum = 0.0;                        // overall sum for all threads, control access with lock

  pthread_t threads[num_threads];                // structs for tracking each thread and
  work_context_t context[num_threads];           // passing each thread its own parameters

  for(int i=0; i<num_threads; i++){              
    context[i].thread_id = i;                    // give a unique ID
    context[i].num_threads = num_threads;
    context[i].array = array;
    context[i].array_len = array_len;
    context[i].lock = &lock;                     // pointers to lock,
    context[i].barrier = &barrier;               // barrier, and
    context[i].total_sum = &total_sum;           // shared data it protects

    pthread_create(&threads[i],NULL,             // launch each thread
                   workfunc, &context[i]);
  }

  for(int i=0; i<num_threads; i++){              // wait for each thread to finish
    pthread_join(threads[i], (void **) NULL);
  }
  double wall_time = timing_stop();

  printf("total_sum: %.1f\n",total_sum);
  printf("wall_time: %10.3f\n",wall_time);

  double end_sum = 0.0;
  for(int i=0; i<array_len; i++){
    end_sum += array[i];
  }
  printf("sum of scaled array elements: %.2f\n",end_sum);

  pthread_mutex_destroy(&lock);
  pthread_barrier_destroy(&barrier);

  free(array);
  return 0;
}
