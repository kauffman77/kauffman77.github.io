// picalc_rand.c: Like picalc_serial.c but uses the rand() function
// which thread safe but at a high cost. This serial code does no
// incur that cost as it only runs 1 thread.

#include <stdio.h>
#include <stdlib.h> 

int main(int argc, char **argv) { 
  if(argc < 2){
    printf("usage: %s <num_samples>\n",argv[0]);
    printf("  num_samples: int, how many sample points to try, higher gets closer to pi\n");
    return 1;
  }

  unsigned int rstate = 123456789; // seed state for random num generator
  srand(rstate);                   // seed the random number gen

  int npoints = atoi(argv[1]);
  int total_hits=0;

  for (int i = 0; i < npoints; i++) { 
    double x = ((double) rand()) / ((double) RAND_MAX);
    double y = ((double) rand()) / ((double) RAND_MAX);
    if (x*x + y*y <= 1.0){
      total_hits++;
    }
  } 

  double pi_est = ((double)total_hits) / npoints * 4.0;
  printf("npoints: %8d\n",npoints);
  printf("hits:    %8d\n",total_hits);
  printf("pi_est:  %f\n",pi_est);
  return 0;
}
