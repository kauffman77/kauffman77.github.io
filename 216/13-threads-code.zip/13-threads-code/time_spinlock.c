// time_spinlock.c: Demonstrates the "spin lock" which is like a mutex
// but uses busy waiting rather than than blocking. The "spin" here is
// that a thread attempting to acquire a lock that is not available
// will continuously check the lock using 100% CPU. This means the
// thread will get the lock as soon as possible (required in some real
// time situations) but the cost is a LOT of CPU compared to the OS
// blocking and unblocking threads as is the case with a mutex.
//
// > gcc pthread_time_spinlock.c -lpthread
// > time ./a.out
// BEFORE glob: 1
// AFTER glob: 4
// 
// real	0m2.004s
// user	0m1.000s
// sys	0m0.005s

#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

int glob = 1;
pthread_spinlock_t glob_lock;

void *doit(void *param){
  pthread_spin_lock(&glob_lock);
  glob = glob*2;
  sleep(1);
  pthread_spin_unlock(&glob_lock);
  return NULL;
}

int main(){
  printf("BEFORE glob: %d\n",glob);

  pthread_spin_init(&glob_lock, PTHREAD_PROCESS_PRIVATE);
  pthread_t thread_1;
  pthread_create(&thread_1, NULL, doit, NULL);
  pthread_t thread_2;
  pthread_create(&thread_2, NULL, doit, NULL);

  pthread_join(thread_1, (void **) NULL); 
  pthread_join(thread_2, (void **) NULL); 

  printf("AFTER glob: %d\n",glob);
  pthread_spin_destroy(&glob_lock);
  
  return 0;
}
