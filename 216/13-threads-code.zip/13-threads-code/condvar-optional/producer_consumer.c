// producer_consumer.c: Demonstrate the produces and consumers in
// threads. Invoke with 4 required options:
// - # of consumers
// - delay for consumers (higher means slower)
// - # of producers
// - delay for producers (higher means slower)
// 
// 
// 
// A typical invocation and output is below (3 consumers w/ delay 10, 4 producers w/ delay 50)
// 
// $> time ./a.out 3 10 4 50 COND
// CONS_COUNT: 3 CONS_DELAY: 10
// PROD_COUNT: 4 PROD_DELAY: 50
// LOCKMODE: COND
// successes: 10 / 10
// Buffer count:  0 front:  0 back 0
//   #  S  P  C  Front/Back
// ----------------------
// [ 0| .  3  0] Front Back
// [ 1| .  0  2]  
// [ 2| .  2  1]  
// [ 3| .  1  0]  
// [ 4| .  3  2]  
// [ 5| .  0  1]  
// [ 6| .  2  0]  
// [ 7| .  1  2]  
// [ 8| .  3  1]  
// [ 9| .  0  0]  
// 
// Thread Info:
// [ 0] mislocks:          0 items: 21 status: P0: Creating item
// [ 1] mislocks:          0 items: 20 status: P1: Item ready, adding to buffer
// [ 2] mislocks:          0 items: 19 status: P2: ADDING item at index 0 (53057)
// [ 3] mislocks:          0 items: 20 status: P3: Item ready, adding to buffer
// [ 4] mislocks:          1 items: 27 status: C0: Waiting for ITEMS in buffer
// [ 5] mislocks:          1 items: 27 status: C1: Waiting for ITEMS in buffer
// [ 6] mislocks:          1 items: 26 status: C2: Waiting for ITEMS in buffer
// 
// real	0m4.942s
// user	0m0.535s
// sys	0m0.943s


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>

#define COND 1                  // use condition variables when locking the buffer/notifying other threads
#define BUSY 2                  // use only mutexes when locking the buffer/queue
int LOCKMODE = COND;            // default to condition variables

#define MAX_SUCCESSES 10        // quantity of items to 'process' before ending
#define MAX_VALUE 100000        // maximum value for random number generation; higher means consumers may stall

int successes;                  // tracks how many total prime numbers have been identified, main terminates on reaching MAX_SUCCESSES
pthread_mutex_t success_lock;   // controls access to successes


// print a message to a designated location then delay for given
// number of milliseconds via 'usleep(delay*1000);'
void sprintf_delay(useconds_t delay, char* buf, char *fmt, ...){
  va_list myargs;
  va_start(myargs, fmt);
  vsprintf(buf,fmt,myargs);
  va_end(myargs);
  usleep(delay*1000);
}

#define EMPTY '.'                      // symbol to represent an empty item in the buffer/queue
#define FULL  'X'                      // symbol to represent an Item in the buffer/queue

typedef struct {                       // data structure to hold information on an 'item' 
  uint64_t value;                      // random number made by producer for consumer to check for primeness
  int producer;                        // producer that created the item
  int consumer;                        // consumer that checked the item, -1 if not yet consumed
  char state;                          // character indicating if item is EMPTY or FULL
} item_t;


#define BUFFER_SIZE 10
item_t buffer[BUFFER_SIZE];            // the shared bounded buffer of tiems
int buffer_count = 0;                  // indicates number of items in buffer
int buffer_front=0, buffer_back=0;     // indicates the front/back of the buffer as a queue

pthread_mutex_t buffer_lock;           // controls access to the buffer
pthread_cond_t buffer_has_space;       // notify Producer threads that the buffer has space (item removed)
pthread_cond_t buffer_has_items;       // notify Consumer threads that the buffer has an item (item added)

typedef struct {                       // producer/consumer thread information
  int id;                              // numeric id for thread 0,1,2,3,...
  int items;                           // number of items processed by the thread
  int mislocks;                        // number of times thread locked buffer but couldn't use it
  useconds_t delay;                    // delay for thread on producing a status message
  char status[256];                    // space for a status message printed in the main() loop
} pc_info_t;

////////////////////////////////////////////////////////////////////////////////
// producer thread function: creates random numbers and places them in
// the bounded buffer until the thread is cancelled.
void *producer_func(void *pci){
  pc_info_t *info = (pc_info_t *) pci;
  unsigned int rstate = 123456789 * (info->id+7);   // give each thread its own starting point

  while(1){                                                 // loop until thread is cancelled
    ////////////////////////////////////////////////////////////////////////////////
    // 'Produce' an item: generate a 64-bit random number, place it in an item_t 
    sprintf_delay(info->delay,info->status,"P%d: Creating item",info->id);
    uint64_t a=rand_r(&rstate), b=rand_r(&rstate);
    uint64_t value = ((a << 32) | b ) % MAX_VALUE; // create long from two 32-bit ints concatenated
    item_t item = {
      .value = value,   
      .producer = info->id,
      .consumer = -1,
      .state = FULL,
    };
    sprintf_delay(info->delay,info->status,"P%d: Item ready, adding to buffer",info->id);

    ////////////////////////////////////////////////////////////////////////////////
    // Repeatedly lock/check the buffer until an space is present
    if(LOCKMODE==BUSY){                                     // use BUSY locking to acquire the buffer
      pthread_mutex_lock(&buffer_lock);
      while(buffer_count == BUFFER_SIZE){                   // wait until space available in the buffer
        pthread_mutex_unlock(&buffer_lock);                 // unlock
        info->mislocks++;                                   // update mislocks
        pthread_mutex_lock(&buffer_lock);                   // relock and check again
      }
    }
    else{                                                   // use CONDition variables to improve locking efficiency
      pthread_mutex_lock(&buffer_lock);
      while(buffer_count == BUFFER_SIZE){                   // wait until space available in the buffer
        info->mislocks++;                                   // update mislocks
        pthread_cond_wait(&buffer_has_space, &buffer_lock); // sleep until notified space is available
      }
    }

    /////////////////////////////////////////////////////////////////////////////////
    // Place the item in the buffer
    sprintf_delay(info->delay,info->status,
                  "P%d: ADDING item at index %d (%lu)",
                  info->id,buffer_back,item.value);
    buffer[buffer_back] = item;
    buffer_count++;
    buffer_back = (buffer_back + 1) % BUFFER_SIZE;

    pthread_mutex_unlock(&buffer_lock);                     // unlock buffer
    if(LOCKMODE==COND){
      pthread_cond_signal(&buffer_has_items);               // notify consumers an item is present
    }
    info->items++;                                          // update items produced by this producer

  }                                                         // end of while(1) loop

  return NULL;                                              // thread will be cancelled, compiler requires a return value 
}


////////////////////////////////////////////////////////////////////////////////
// consumer thread: grab items (random numbers) from the buffer and check them for primeness
void *consumer_func(void *pci){
  pc_info_t *info = (pc_info_t *) pci;

  while(1){                                                 // loop until thread is cancelled
    sprintf_delay(info->delay,info->status,
                  "C%d: Waiting for ITEMS in buffer",
                  info->id);

    ////////////////////////////////////////////////////////////////////////////////
    // Repeatedly lock/check the buffer until an item is present
    if(LOCKMODE == BUSY){                                   // use BUSY locking to acquire the buffer
      pthread_mutex_lock(&buffer_lock);
      while(buffer_count == 0){                             // wait until items are available in the buffer
        pthread_mutex_unlock(&buffer_lock);                 // unlock
        info->mislocks++;                                   // update mislocks count
        pthread_mutex_lock(&buffer_lock);                   // relock and check again
      }
    }
    else{                                                   // use CONDition variables to improve locking efficiency
      pthread_mutex_lock(&buffer_lock);
      while(buffer_count == 0){                             // wait until items are available in the buffer
        info->mislocks++;                                   // update mislocks
        pthread_cond_wait(&buffer_has_items, &buffer_lock); // sleep until notified of items
      }
    }

    sprintf_delay(info->delay,info->status,                  // locked the buffer with an item in it
                  "C%d: REMOVING item at index %d (%lu)",
                  info->id, buffer_front, buffer[buffer_front].value);

    /////////////////////////////////////////////////////////////////////////////////
    // Extract the item from the buffer
    buffer[buffer_front].consumer = info->id;               // mark slot as consumed by this consumer
    buffer[buffer_front].state = EMPTY;
    item_t item = buffer[buffer_front];                     // extract the item and adjust the buffer
    buffer_count--;
    buffer_front = (buffer_front + 1) % BUFFER_SIZE;
    pthread_mutex_unlock(&buffer_lock);                     // unlock buffer
    if(LOCKMODE == COND){                                   // when using condition variables
      pthread_cond_signal(&buffer_has_space);               // notify produer threads space is available
    }

    ////////////////////////////////////////////////////////////////////////////////
    // 'Process' and item by determining if the number in the buffer is a prime number 
    sprintf_delay(info->delay,info->status,
                  "C%d: CHECKING item %lu",
                  info->id, item.value);

    int result = 1;                                         // check item.value for primeness
    for(uint64_t i=2; i<item.value; i++){                   // use a slow, dumb, but easy to code algorithm
      if(item.value % i == 0){
        result=0;                                           // evenly divisible, not prime
        break;
      }
    }

    if(result == 1){                                        // was prime
      sprintf_delay(info->delay,info->status,
                    "C%d: Item checked: SUCCESS (%lu)",
                    info->id, item.value);
      pthread_mutex_lock(&success_lock);                    // update the successes
      successes++;
      pthread_mutex_unlock(&success_lock);
    }
    else{
      sprintf_delay(info->delay,info->status,
                    "C%d: Item checked: FAILED (%lu)",
                    info->id, item.value);
    }
    info->items++;                                          // update # items process by this thread

  }                                                         // end of while(1) loop for thread

  return NULL;                                              // thread will be cancelled, compiler requires a return value 
}


////////////////////////////////////////////////////////////////////////////////
// main function to start threads and print output to screen while they run
int main(int argc, char *argv[]){
  if(argc < 5){
    printf("usage: %s <cons_count> <cons_delay> <prod_count> <prod_delay> [BUSY]\n",argv[0]);
    exit(1);
  }

  int CONS_COUNT = atol(argv[1]); // number of consumers
  int CONS_DELAY = atol(argv[2]); // delay for consumers (higher makes them slower)
  int PROD_COUNT = atol(argv[3]); // number of producers
  int PROD_DELAY = atol(argv[4]); // delay producers
  int TOT_THREADS = PROD_COUNT+CONS_COUNT;

  if( argc >= 6 && strcmp(argv[5],"BUSY")==0) {             // check for busy locking
    LOCKMODE = BUSY;
  }

  item_t empty = {.value = 0, .producer = -1,               // empty item to initialize buffer
                  .consumer = -1, .state = EMPTY };
  for(int i=0; i<BUFFER_SIZE; i++){                         // initialize all buffer elements with empty items
    buffer[i] = empty;
  }

  pthread_mutex_init(&buffer_lock, NULL);                   // Initialize mutex and condition variable 
  pthread_cond_init (&buffer_has_space, NULL);
  pthread_cond_init (&buffer_has_items, NULL);
  pthread_mutex_init(&success_lock, NULL);

  pthread_t threads[TOT_THREADS];                           // tracks thead for OS
  pc_info_t infos[TOT_THREADS];                             // information specific to each thread

  memset(infos, 0, sizeof(pc_info_t)*TOT_THREADS);          // initialize and start all threads
  for(int i=0; i<PROD_COUNT; i++){                          // start all producers
    int idx = i;
    infos[idx].id = idx;
    infos[idx].delay = PROD_DELAY;
    pthread_create(&threads[idx], NULL, producer_func, (void *) &(infos[idx]));
  }
  for(int i=0; i<CONS_COUNT; i++){                          // start all consumers
    int idx = i + PROD_COUNT;
    infos[idx].id = i;
    infos[idx].delay = CONS_DELAY;
    pthread_create(&threads[idx], NULL, consumer_func, (void *) &(infos[idx]));
  }
    
  ////////////////////////////////////////////////////////////////////////////////
  // main loop printing: reports information on what each thread is
  // doing, uses terminal control characters to move the terminal
  // cursor around and overwrite previous lines
  printf("\33[s");                                          // save cursor position
  printf("\33[?25l");                                       // hide cursor to avoid flicker

  int run = 1;
  while( run==1 ){                                          // keep running until triggered otherwise
    if(successes >= MAX_SUCCESSES){                         // if successes has reached max, print once more then stop
      run = 0;
    }
    printf("\33[u");                                        // restore cursor position to top of terminal
    usleep(200);                                            // sleep a moment
    printf("CONS_COUNT: %d CONS_DELAY: %d\n",CONS_COUNT,CONS_DELAY);
    printf("PROD_COUNT: %d PROD_DELAY: %d\n",PROD_COUNT,PROD_DELAY);
    printf("LOCKMODE: %s\n", LOCKMODE == BUSY ? "BUSY" : "COND");
    printf("successes: %d / %d\n",successes, MAX_SUCCESSES);
    printf("Buffer count: %2d front: %2d back %d\n",
           buffer_count, buffer_front, buffer_back);
    printf(" %2s  %c %2s %2s  %s\n",
           "#",'S', "P", "C", "Front/Back");
    printf("----------------------\n");
    for(int i=0; i<BUFFER_SIZE; i++){                       // print out contents of the buffer
      printf("%c[2K", 27);
      item_t item = buffer[i];
      printf("[%2d| %c %2d %2d] %s %s\n",
             i,item.state, item.producer, item.consumer,
             buffer_front==i ? "Front" : "",
             buffer_back==i  ? "Back"  : "");
    }
    printf("\n");
    printf("Thread Info:\n");                               // print info for each thread
    for(int i=0; i<TOT_THREADS; i++){
      printf("%c[2K", 27);
      printf("[%2d] mislocks: %10d items: %2d status: %s\n",
             i,infos[i].mislocks,infos[i].items,infos[i].status);
    }
  }                                                         // end of printing loop


  for(int i=0; i<TOT_THREADS; i++){                         // cancel all threads
    pthread_cancel(threads[i]);
  }
  
  printf("\33[?25h");                                       // show cursor to restore terminal

  return 0;
}
