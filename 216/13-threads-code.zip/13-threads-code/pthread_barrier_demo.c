// pthread_barrier_demo.c: Shows use of a pthread_barriers to
// cooridnate threads through multiple stages of a computation. The
// first set of thread launches do not coordinate so the simulated
// A,B,C sections appear interleaved with each thread. The second
// section uses a barrier to ensure all threads finish A before moving
// to B.

#include <stdio.h>
#include <stdlib.h> 
#include <pthread.h>
#include <sys/time.h>
#include <unistd.h>

pthread_barrier_t barrier;                    // barrier to coordinate thread progress

void *workfunc_barrier(void *arg){            // worker function which uses barrier to coordinate
  long lthread_id = (long) arg;               // this sequence ensures that gcc
  int thread_id = (int) lthread_id;           // does not complain about casting as loudly

  usleep(thread_id * 1000 * 250);             // sleep thread_id * 0.25sec
  printf("A finished by thread %d, waiting for others\n",thread_id);

  pthread_barrier_wait(&barrier);             // threads wait until others arrive

  usleep(thread_id * 1000 * 250);             // sleep thread_id * 0.25sec
  printf("B finished by thread %d, waiting for others\n",thread_id);

  pthread_barrier_wait(&barrier);             // threads wait until others arrive

  usleep(thread_id * 1000 * 250);             // sleep thread_id * 0.25sec
  printf("C finished by thread %d, exiting\n",thread_id);

  return NULL;
}

void *workfunc_nowait(void *arg){             // worker function with no coordination
  long lthread_id = (long) arg;               // this sequence ensures that gcc
  int thread_id = (int) lthread_id;           // does not complain about casting as loudly

  usleep(thread_id * 1000 * 250);             // sleep thread_id * 0.25sec
  printf("A finished by thread %d\n",thread_id);

  usleep(thread_id * 1000 * 250);             // sleep thread_id * 0.25sec
  printf("B finished by thread %d\n",thread_id);

  usleep(thread_id * 1000 * 250);             // sleep thread_id * 0.25sec
  printf("C finished by thread %d, exiting\n",thread_id);

  return NULL;
}

int main(int argc, char *argv[]) { 
  if(argc < 2){
    printf("usage: %s <num_threads>\n",argv[0]);
    printf("  num_threads: int, number of threads to use for the computation\n");
    return -1;
  }

  int num_threads = atoi(argv[1]);
  pthread_t threads[num_threads];                // structs for tracking each thread and

  pthread_barrier_init(&barrier,NULL,num_threads);                

  printf("SECTION: NO Barriers\n");

  for(long i=0; i<num_threads; i++){              
    pthread_create(&threads[i],NULL,             // launch each thread
                   workfunc_nowait, (void *) i);
  }
  for(int i=0; i<num_threads; i++){              // wait for each thread to finish
    pthread_join(threads[i], (void **) NULL);
  }

  printf("\n");
  printf("SECTION: WITH Barriers\n");

  for(long i=0; i<num_threads; i++){              
    pthread_create(&threads[i],NULL,             // launch each thread
                   workfunc_barrier, (void *) i);
  }
  for(int i=0; i<num_threads; i++){              // wait for each thread to finish
    pthread_join(threads[i], (void **) NULL);
  }

  pthread_barrier_destroy(&barrier);
  return 0;
}

