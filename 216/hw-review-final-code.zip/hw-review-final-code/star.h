#pragma once

typedef struct {
 char name[32];
 float gcoords_l;
 float gcoords_b;
 char star_class[8];
 float dist;
} star_t;

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <ctype.h>                    // isspace
#include <sys/mman.h>
#include <fcntl.h>
