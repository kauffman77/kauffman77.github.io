// star_search_commented.c: more information commenting on the
// progression of the computation.

#include "star.h"

int main(int argc, char *argv[]){
  if(argc < 3){
    printf("usage: %s <star_class> <filename>\n",argv[0]);
    return 1;
  }

  char *star_class = argv[1];
  char *star_file = argv[2];
  
  // find size of the data
  //
  // Use a child process that exec() the "stat" command line utility
  // get the size of the data file in bytes; uses I/O redirection to
  // channel output into a file which will be parsed by the parent
  // process.
  int pid = fork();

  if(pid == 0){                                     // CHILD CODE ONLY
    int outfd = open("statout.txt", O_WRONLY|O_TRUNC|O_CREAT, S_IRUSR|S_IWUSR);
    if(outfd == -1){
      perror("open() failed");
      exit(1);
    }
    int ret = dup2(outfd, STDOUT_FILENO);           // redirect output into the file
    if(ret == -1){
      perror("dup2() failed");
      exit(1);
    }
    char *argv[] = {"stat", star_file, NULL};       // exec the stat command
    execvp(argv[0], argv);                          // child will exit here or
    perror("exec() failed");                        // on a fail, bail out
    exit(EXIT_FAILURE);
  }

  int status;                                       // PARENT CODE ONLY
  int ret = waitpid(pid, &status, 0);               // wait until child is finished
  if( !WIFEXITED(status) || WEXITSTATUS(status)!=0 ){
    printf("Couldn't get the size of %s\n",star_file);
    return EXIT_FAILURE;
  }
  
  // get size
  //
  // extract the size in bytes of star_file from the text output of
  // stat; it's on the 2nd line after the word "Size:"
  FILE *statfile = fopen("statout.txt","r");        // open the output file the child created
  char buf[128], *res;
  res = fgets(buf, 128, statfile);                  // skip the first line
  res = fgets(buf, 128, statfile);                  // get the next line which will be "    Size: <bytes> ..."
  if(res == NULL){
    printf("I/O Failed\n");
    fclose(statfile);
    return EXIT_FAILURE;
  }
  int size;
  sscanf(buf, " Size: %d", &size);                  // get the size data from this line
  fclose(statfile);                                 // done with file
  printf("%d bytes in file %s\n",size,star_file);   // report bytes for ease of debugging

  // get stars
  //
  // open and process the main stars file until the end of the file;
  // use the size in bytes obtained above to terminate the input loop
  int starfd = open(star_file, O_RDONLY);           // open original file which contains the star data
  if(starfd == -1){
    perror("open() on starfile failed");
    return EXIT_FAILURE;
  }
  int total_bytes = 0;                              // total bytes procesed from the file
  int hits = 0;                                     // number of planets matching the star_type requested
  star_t cur_star;                                  // current star read from file
  while(total_bytes < size){
    int nbytes = read(starfd, &cur_star, sizeof(star_t));
    if( strcmp(cur_star.star_class, star_class)==0 ){ // check for a matching star_type
      printf("| %20s | %8s | %12.4f |\n",
             cur_star.name, cur_star.star_class, cur_star.dist);
      hits++;
    }
    total_bytes += nbytes;                          // tack on the total bytes as progress is made
  }
  close(starfd);
  printf("%d stars matched\n",hits);
  return 0;
}
