// star_search_read0.c: demonstrate use of return value from read() to
// simplify the input loop.

#include "star.h"

int main(int argc, char *argv[]){
  if(argc < 3){
    printf("usage: %s <star_class> <filename>\n",argv[0]);
    return 1;
  }

  char *star_class = argv[1];
  char *star_file = argv[2];
  
  // get stars
  //
  // open and process the main stars file until the end of the file;
  // use the size in bytes obtained above to terminate the input loop
  //
  // use the return value from read() to terminate the loop
  int starfd = open(star_file, O_RDONLY);           // open original file which contains the star data
  if(starfd == -1){
    perror("open() on starfile failed");
    return EXIT_FAILURE;
  }
  int hits = 0;                                     // number of planets matching the star_type requested
  star_t cur_star;                                  // current star read from file
  while(1){
    int nbytes = read(starfd, &cur_star, sizeof(star_t));
    if(nbytes == 0){
      break;
    }
    if( strcmp(cur_star.star_class, star_class)==0 ){ // check for a matching star_type
      printf("| %20s | %8s | %12.4f |\n",
             cur_star.name, cur_star.star_class, cur_star.dist);
      hits++;
    }
  }
  close(starfd);
  printf("%d stars matched\n",hits);
  return 0;
}
