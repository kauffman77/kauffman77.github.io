// star_search_stat.c: demonstrate use of the stat() system call to
// easily get the size of the input file.

#include "star.h"

int main(int argc, char *argv[]){
  if(argc < 3){
    printf("usage: %s <star_class> <filename>\n",argv[0]);
    return 1;
  }

  char *star_class = argv[1];
  char *star_file = argv[2];
  
  // find size of the data
  //
  // Use a call to stat() to get the size of the star_file in bytes
  struct stat statbuf;
  int ret = stat(star_file, &statbuf);
  if(ret == -1){
    perror("stat() failed");
    return EXIT_FAILURE;
  }
  int size = statbuf.st_size;
  printf("%d bytes in file %s\n",size,star_file);   // report bytes for ease of debugging

  // get stars
  //
  // open and process the main stars file until the end of the file;
  // use the size in bytes obtained above to terminate the input loop
  int starfd = open(star_file, O_RDONLY);           // open original file which contains the star data
  if(starfd == -1){
    perror("open() on starfile failed");
    return EXIT_FAILURE;
  }
  int total_bytes = 0;                              // total bytes procesed from the file
  int hits = 0;                                     // number of planets matching the star_type requested
  star_t cur_star;                                  // current star read from file
  while(total_bytes < size){
    int nbytes = read(starfd, &cur_star, sizeof(star_t));
    if( strcmp(cur_star.star_class, star_class)==0 ){ // check for a matching star_type
      printf("| %20s | %8s | %12.4f |\n",
             cur_star.name, cur_star.star_class, cur_star.dist);
      hits++;
    }
    total_bytes += nbytes;                          // tack on the total bytes as progress is made
  }
  close(starfd);
  printf("%d stars matched\n",hits);
  return 0;
}
