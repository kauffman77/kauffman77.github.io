// star_search_mmap.c: demonstrate use of the mmap() to memory map the
// data file and access it scontents.

#include "star.h"

int main(int argc, char *argv[]){
  if(argc < 3){
    printf("usage: %s <star_class> <filename>\n",argv[0]);
    return 1;
  }

  char *star_class = argv[1];
  char *star_file = argv[2];
  
  int starfd = open(star_file, O_RDONLY);           // open file which contains the star data
  struct stat statbuf;
  int ret = fstat(starfd, &statbuf);                // use fstat() to get info on an already-open fd
  if(ret == -1){
    perror("fstat() failed");
    return EXIT_FAILURE;
  }
  int size = statbuf.st_size;
  star_t *stars = mmap(NULL,                        // OS assigns virtual address
                       size,                        // map whole file
                       PROT_READ, MAP_SHARED,       // only reading file contents, could change perms later
                       starfd, 0);                  // map the open file starting at offset 0

  int nstars = size / sizeof(star_t);               // calculate number of star_t structs in the file
  int hits = 0;                                     // number of planets matching the star_type requested
  for(int i=0; i<nstars; i++){
    if( strcmp(stars[i].star_class, star_class)==0 ){ // check for a matching star_type
      printf("| %20s | %8s | %12.4f |\n",
             stars[i].name, stars[i].star_class, stars[i].dist);
      hits++;
    }
  }

  munmap(stars, size);
  close(starfd);
  printf("%d stars matched\n",hits);
  return 0;
}
