// star_search.c: search stars

#include "star.h"

int main(int argc, char *argv[]){
  if(argc < 3){
    printf("usage: %s <star_class> <filename>\n",argv[0]);
    return 1;
  }

  char *star_class = argv[1];
  char *star_file = argv[2];

  // find size of the data
  int pid = fork();
  if(pid == 0){
    int outfd = open("statout.txt", O_WRONLY|O_TRUNC|O_CREAT, S_IRUSR|S_IWUSR);
    if(outfd == -1){
      perror("open() failed");
      exit(1);
    }
    int ret = dup2(outfd, STDOUT_FILENO);
    if(ret == -1){
      perror("dup2() failed");
      exit(1);
    }
    char *argv[] = {"stat", star_file, NULL};
    execvp(argv[0], argv);
    perror("exec() failed");
    exit(EXIT_FAILURE);
  }

  int status;
  int ret = waitpid(pid, &status, 0);
  if( !WIFEXITED(status) || WEXITSTATUS(status)!=0 ){
    printf("Couldn't get the size of %s\n",star_file);
    return EXIT_FAILURE;
  }
  
  // get size
  FILE *statfile = fopen("statout.txt","r");
  char buf[128], *res;
  res = fgets(buf, 128, statfile);
  res = fgets(buf, 128, statfile);
  if(res == NULL){
    printf("I/O Failed\n");
    fclose(statfile);
    return EXIT_FAILURE;
  }
  int size;
  sscanf(buf, " Size: %d", &size);
  fclose(statfile);
  printf("%d bytes in file %s\n",size,star_file);

  // get stars
  int starfd = open(star_file, O_RDONLY);
  if(starfd == -1){
    perror("open() on starfile failed");
    return EXIT_FAILURE;
  }
  int total_bytes = 0;
  int hits = 0;
  star_t cur_star;
  while(total_bytes < size){
    int nbytes = read(starfd, &cur_star, sizeof(star_t));
    if( strcmp(cur_star.star_class, star_class)==0 ){
      printf("| %20s | %8s | %12.4f |\n",
             cur_star.name, cur_star.star_class, cur_star.dist);
      hits++;
    }
    total_bytes += nbytes;
  }
  close(starfd);
  printf("%d stars matched\n",hits);
  return 0;
}
  
  
