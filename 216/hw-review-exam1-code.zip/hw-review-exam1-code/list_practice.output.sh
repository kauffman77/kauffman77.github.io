>> gcc -g list_practice.student.c

>> ./a.out
LIST:
Banana
Grape
Kiwi
Orange
Pear
LIST:
Carrot
Onion
Potato

>> valgrind ./a.out
==81104== Memcheck, a memory error detector
==81104== Copyright (C) 2002-2024, and GNU GPLd, by Julian Seward et al.
==81104== Using Valgrind-3.24.0 and LibVEX; rerun with -h for copyright info
==81104== Command: ./a.out
==81104== 
LIST:
Banana
Grape
Kiwi
Orange
Pear
LIST:
Carrot
Onion
Potato
==81104== 
==81104== HEAP SUMMARY:
==81104==     in use at exit: 1,088 bytes in 8 blocks
==81104==   total heap usage: 11 allocs, 3 frees, 2,144 bytes allocated
==81104== 
==81104== LEAK SUMMARY:
==81104==    definitely lost: 272 bytes in 2 blocks
==81104==    indirectly lost: 816 bytes in 6 blocks
==81104==      possibly lost: 0 bytes in 0 blocks
==81104==    still reachable: 0 bytes in 0 blocks
==81104==         suppressed: 0 bytes in 0 blocks
==81104== Rerun with --leak-check=full to see details of leaked memory
==81104== 
==81104== For lists of detected and suppressed errors, rerun with: -s
==81104== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)

# Re-run with more information lines that allocate blocks
>> valgrind --leak-check=full ./a.out
==81109== Memcheck, a memory error detector
==81109== Copyright (C) 2002-2024, and GNU GPLd, by Julian Seward et al.
==81109== Using Valgrind-3.24.0 and LibVEX; rerun with -h for copyright info
==81109== Command: ./a.out
==81109== 
LIST:
Banana
Grape
Kiwi
Orange
Pear
LIST:
Carrot
Onion
Potato
==81109== 
==81109== HEAP SUMMARY:
==81109==     in use at exit: 1,088 bytes in 8 blocks
==81109==   total heap usage: 11 allocs, 3 frees, 2,144 bytes allocated
==81109== 
==81109== 408 (136 direct, 272 indirect) bytes in 1 blocks are definitely lost in loss record 2 of 4
==81109==    at 0x48457A8: malloc (vg_replace_malloc.c:446)
==81109==    by 0x1091D4: list_from_array (list_practice.student.c:30)
==81109==    by 0x1093D3: main (list_practice.student.c:77)
==81109== 
==81109== 680 (136 direct, 544 indirect) bytes in 1 blocks are definitely lost in loss record 4 of 4
==81109==    at 0x48457A8: malloc (vg_replace_malloc.c:446)
==81109==    by 0x1091D4: list_from_array (list_practice.student.c:30)
==81109==    by 0x109385: main (list_practice.student.c:68)
==81109== 
==81109== LEAK SUMMARY:
==81109==    definitely lost: 272 bytes in 2 blocks
==81109==    indirectly lost: 816 bytes in 6 blocks
==81109==      possibly lost: 0 bytes in 0 blocks
==81109==    still reachable: 0 bytes in 0 blocks
==81109==         suppressed: 0 bytes in 0 blocks
==81109== 
==81109== For lists of detected and suppressed errors, rerun with: -s
==81109== ERROR SUMMARY: 2 errors from 2 contexts (suppressed: 0 from 0)
