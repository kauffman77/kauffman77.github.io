// list_practice.c: converts an array to a linked list and prints it,
// has memory problems

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// struct for single data node in linked list
typedef struct node_struct {
  char data[128];               // string at this node
  struct node_struct *next;     // pointer to next node
} node_t;                       // type name for struct in programs: node_t nod;

// struct encapsulating entire linked list
typedef struct {
  node_t *head;                 // NULL or pointer to first node in list
  int size;                     // number of nodes in the list
} list_t;                       // type name for struct in programs: list_t lst;


list_t *list_from_array(char *arr[], int count){
  // Creates a linked list of nodes with data copied from `arr[]`.
  // Nodes are ordered as they appear in `arr[]`
  if(count < 0){
    return NULL;
  }
  list_t *list = malloc(sizeof(list_t));
  list->head = NULL;
  list->size = 0;
  if(count==0){
    return list;
  }
  list->head = malloc(sizeof(node_t));
  strcpy(list->head->data, arr[0]);
  list->head->next = NULL;
  list->size++;
  node_t *tail = list->head;
  for(int i=1; i<count; i++){
    tail->next = malloc(sizeof(node_t));
    tail = tail->next;
    strcpy(tail->data, arr[i]);
    tail->next = NULL;
    list->size++;
  }
  return list;
}

void list_print(list_t *list){
  // prints all elements of `list` on their own line
  printf("LIST:\n");
  node_t *ptr = list->head;
  for(int i=0; i<list->size; i++){
    printf("%s\n",ptr->data);
    ptr = ptr->next;
  }
}
  
void list_free(list_t* list){
  // de-allocates memory associated with `list`
  free(list);
}

int main(){
  char *fruits[5] = {
    "Banana",
    "Grape",
    "Kiwi",
    "Orange",
    "Pear",
  };
  list_t *flist = list_from_array(fruits, 5);
  list_print(flist);
  list_free(flist);

  char *veggies[3] = {
    "Carrot",
    "Onion",
    "Potato",
  };
  list_t *vlist = list_from_array(veggies, 3);
  list_print(vlist);
  list_free(vlist);

  return 0;
}  
