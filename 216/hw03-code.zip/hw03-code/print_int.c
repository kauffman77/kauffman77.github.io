#include <stdio.h>

void print_int(int anint){
  // your code here
}

int main(int argc, char *argv[]){
  int a1 = 1234;
  print_int(a1);
  printf("\n");
  
  int a2 = 8675309;             // Jenny!
  print_int(a2);
  printf("\n");

  int a3 = -5;
  print_int(a3);
  printf("\n");

  int a4 = -789123; 
  print_int(a4);
  printf("\n");

  int a5 = 0;
  print_int(a5);
  printf("\n");

  return 0;
}

// // INTERACTIVE MAIN
// int main(int argc, char *argv[]){
//   printf("Enter an integer: ");
//   int anint;
//   scanf("%d", &anint);
//   printf("You entered: ");
//   print_int(anint);
//   printf("\n");
//   return 0;
// }
