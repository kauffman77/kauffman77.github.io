#include <stdio.h>
#include <stdlib.h>


// Struct to count positive/negative
// numbers in arrays.
typedef struct {
  int poss, negs;
} pn_t;

void set_pn(int *arr, int len, pn_t *pn);
// Scans through array arr counting positive/negative numbers and
// adjusting the fields of the specified. Zero is considered a
// positive number. If arr is NULL or len is less than 0, does not
// change pn.

int main(){
  int arr1[5] = {3, 0, -1, 7, -4};
  pn_t *pn1 = malloc(sizeof(pn_t)); // alternatively, use stack variable and ...
  set_pn(arr1, 5, pn1);             // pass in &pn1
  // pn1: {.poss=3, .neg=2}
  printf("1: poss: %d negs: %d\n",
         pn1->poss, pn1->negs);
  
  int arr2[3] = {-1, -2, -4};
  pn_t *pn2 = malloc(sizeof(pn_t)); 
  set_pn(arr2, 3, pn2);
  // pn2: {.poss=0, .neg=3}
  printf("2: poss: %d negs: %d\n",
         pn2->poss, pn2->negs);

  int *arr3 = NULL;
  pn_t *pn3 = malloc(sizeof(pn_t));
  set_pn(arr3, -1, pn3);
  // pn3: {.poss = 0, .negs=0}
  printf("3: poss: %d negs: %d\n",
         pn3->poss, pn3->negs);

  free(pn1); free(pn2); free(pn3);
  return 0;
}
  
void set_pn(int *arr, int len, pn_t *pn){
  if(arr==NULL || len < 0){
    return;
  }
  pn->negs = 0;
  pn->poss = 0;
  for(int i=0; i<len; i++){
    if(arr[i] < 0){
      pn->negs++;
    }
    else{
      pn->poss++;
    }
  }
  return;
}
