	.file	"fizzbuzz.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"%s <int>\n"
.LC1:
	.string	"Fizz Buzz"
.LC2:
	.string	"Fizz"
.LC3:
	.string	"Buzz"
.LC4:
	.string	"%d\n"
	.text
	.globl	main
	.type	main, @function
main:
.LFB22:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	cmpl	$1, %edi
	jle	.L11
	movq	8(%rsi), %rdi
	movl	$10, %edx
	movl	$0, %esi
	call	strtol@PLT
	movl	%eax, %ebp
	movl	$1, %ebx
	jmp	.L4
.L11:
	movq	(%rsi), %rsi
	leaq	.LC0(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	$1, %eax
	jmp	.L1
.L13:
	leaq	.LC1(%rip), %rdi
	call	puts@PLT
.L6:
	addl	$1, %ebx
.L4:
	cmpl	%ebp, %ebx
	jg	.L12
	movslq	%ebx, %rax
	imulq	$-2004318071, %rax, %rax
	shrq	$32, %rax
	addl	%ebx, %eax
	sarl	$3, %eax
	movl	%ebx, %edx
	sarl	$31, %edx
	subl	%edx, %eax
	movl	%eax, %edx
	sall	$4, %edx
	subl	%eax, %edx
	cmpl	%edx, %ebx
	je	.L13
	movslq	%ebx, %rax
	imulq	$1431655766, %rax, %rax
	shrq	$32, %rax
	movl	%ebx, %edx
	sarl	$31, %edx
	subl	%edx, %eax
	leal	(%rax,%rax,2), %eax
	cmpl	%eax, %ebx
	je	.L14
	movslq	%ebx, %rax
	imulq	$1717986919, %rax, %rax
	sarq	$33, %rax
	movl	%ebx, %edx
	sarl	$31, %edx
	subl	%edx, %eax
	leal	(%rax,%rax,4), %eax
	cmpl	%eax, %ebx
	jne	.L8
	leaq	.LC3(%rip), %rdi
	call	puts@PLT
	jmp	.L6
.L14:
	leaq	.LC2(%rip), %rdi
	call	puts@PLT
	jmp	.L6
.L8:
	movl	%ebx, %esi
	leaq	.LC4(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	jmp	.L6
.L12:
	movl	$0, %eax
.L1:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE22:
	.size	main, .-main
	.ident	"GCC: (GNU) 14.2.1 20240910"
	.section	.note.GNU-stack,"",@progbits
