	.file	"ipow_for.c"
	.text
	.globl	ipow
	.type	ipow, @function
ipow:
.LFB0:
	.cfi_startproc
	movl	$0, %eax
	movl	$1, %edx
	jmp	.L2
	.p2align 4
.L3:
	imull	%edi, %edx
	addl	$1, %eax
.L2:
	cmpl	%esi, %eax
	jl	.L3
	movl	%edx, %eax
	ret
	.cfi_endproc
.LFE0:
	.size	ipow, .-ipow
	.ident	"GCC: (GNU) 15.2.1 20260103"
	.section	.note.GNU-stack,"",@progbits
