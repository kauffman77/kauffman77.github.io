// fizzbuzz.c: Solve the Fizz Buzz problem in C
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <int>\n",argv[0]);
    return 1;
  }

  int max = atoi(argv[1]);
  for(int i=1; i<=max; i++){
    if(i%15==0){
      printf("Fizz Buzz\n");
    }
    else if(i%3==0){
      printf("Fizz\n");
    }
    else if(i%5==0){
      printf("Buzz\n");
    }
    else {
      printf("%d\n",i);
    }
  }

  return 0;
}
