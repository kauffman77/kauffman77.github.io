## fizzbuzz_asm.s: 

.data
## string constants needed in the program
.usage_msg:
	.string	"usage: %s <int>\n"
.fizzbuzz_msg:
	.string	"Fizz Buzz\n"
.fizz_msg:
	.string	"Fizz\n"
.buzz_msg:
	.string	"Buzz\n"
.int_msg:
	.string	"%d\n"

## main function
.text
.global main
main:                                      # argc in %edi, argv[] in %rsi
	cmpl	$2, %edi                   # check if argc >= 2
        jge     .argc_ge_2                 # jump if greater/equal, fall through if not

	movl	$0, %eax                   # bad usage case:
	leaq	.usage_msg(%rip),%rdi      # print usage message and ...
	movq	(%rsi), %rsi               # 2nd arg is argv[0]
	call	printf@PLT
	movl	$1, %eax                   # return 1
        ret

.argc_ge_2:
	pushq	%r14                       # need callee-save regs as function calls used
        pushq   %r15                       # so push their values now to restore later
	subq	$8, %rsp                   # align stack for function calls

	movq	8(%rsi),%rdi               # move argv[1] to 1st arg reg
        call    atoi@PLT                   # convert string to integer
        movl    %eax, %r14d                # %r14d is 'max' : loop limit
        movl    $1,%r15d                   # %r15d is 'i' : loop variable, initially 1

.loop_top:
        cmpl    %r14d,%r15d                # check i < max
        jg      .loop_end                  # goto end of loop ifnot
        
        movl    $0,%eax                    # print the integer string
        leaq    .int_msg(%rip),%rdi
        movl    %r15d,%esi
        call    printf@PLT

.check_div15:
        movl    %r15d,%eax
        cltq
        cqto
        movl    $15,%ecx
        idivl   %ecx
        cmpl    $0,%edx
        jne     .check_div3
        movl    $0,%eax                    # print "Fizz Buzz" string
        leaq    .fizzbuzz_msg(%rip),%rdi
        call    printf@PLT
        jmp     .loop_update

.check_div3:
        movl    %r15d,%eax
        cltq
        cqto
        movl    $3,%ecx
        idivl   %ecx
        cmpl    $0,%edx
        jne     .check_div5
        movl    $0,%eax                    # print "Fizz" string
        leaq    .fizz_msg(%rip),%rdi
        call    printf@PLT
        jmp     .loop_update

.check_div5:
        movl    %r15d,%eax
        cltq
        cqto
        movl    $5,%ecx
        idivl   %ecx
        cmpl    $0,%edx
        jne     .loop_update
        movl    $0,%eax                    # print "Buzz" string
        leaq    .buzz_msg(%rip),%rdi
        call    printf@PLT
        jmp     .loop_update

.print_int:
        movl    $0,%eax                    # print just the integer
        leaq    .int_msg(%rip),%rdi
        movl    %r15d,%esi
        call    printf@PLT

.loop_update:
        incl    %r15d                      # i++
        jmp     .loop_top                  # goto top of loop

.loop_end:
        addq    $8,%rsp                    # restore callee regs
        popq    %r15
	popq    %r14
        movl    $0,%eax                    # return 0
        ret


# adds debug information that allows GDB to honor hand-written main
# function
.size	main, .-main                       
