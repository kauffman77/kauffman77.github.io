


#include <stdlib.h>
#include <stdio.h>



int *ones_array(int len){
  int *arr = malloc(sizeof(int)*len);
  for(int i=0; i<len; i++){
    arr[i] = 1;
  }
  free(arr);
  return arr;
}

int main(){
  int *ones = ones_array(5);
  for(int i=0; i<5; i++){       
    printf("ones[%d] is %d\n",i,ones[i]);
  }

  free(ones);
  return 0;
}
