#!/bin/bash

# Restore original versions of frequently edited files form their .bk
# backup version.

for f in *.bk; do
    mv $f ${f/\.bk/}
done
