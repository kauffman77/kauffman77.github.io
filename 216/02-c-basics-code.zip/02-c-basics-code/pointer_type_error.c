// pointer_type_error.c: compiler will detect and
// error when assigning a pointer to refer to the
// wrong type of data. This code has an
// intentional error and WILL NOT COMPILE.

#include <stdio.h>
int main(){
  int a = 10;
  int *aptr = &a;    // int pointer to int
  double b = 4.56;
  double *bptr = &b; // double pointer to double
  aptr = &b;         // ERROR: int pointer to double
  printf("*aptr is %d\n",*aptr);
  return 0;
}
// >> gcc pointer_type_error.c
// pointer_type_error.c: In function ‘main’:
// pointer_type_error.c:12:8:: error: assignment to
// ‘int *’ from incompatible pointer type ‘double *’
// [-Wincompatible-pointer-types]
