#include <stdio.h>
typedef struct {
  double x;
  int y;
  char c;
  char nm[4];
} small_t;

int main(){
  small_t a =
    {.x=1.23, .y=4, .nm="hi"};
  small_t b =
    {.x=5.67, .y=8, .nm="bye"};
  printf("sizeof(small_t): %d\n",sizeof(small_t));
}
