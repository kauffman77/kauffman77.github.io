// number_writing.c: Demonstrate flavors of constants for various
// bases and as character data
#include <stdio.h>
int main(){
  int d = 125;                 // decimal
  int b = 0b01111101;           // binary
  int h = 0x7D;                // hexadecimal
  int o = 0175;                // octal
  int c = '}';                 // ASCII character

  printf("%d %x %o %c\n",d,d,d,d);
  printf("%d %x %o %c\n",b,b,b,b);
  printf("%d %x %o %c\n",h,h,h,h);
  printf("%d %x %o %c\n",o,o,o,o);
  printf("%d %x %o %c\n",c,c,c,c);
  
  return 0;
}
