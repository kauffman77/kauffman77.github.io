!prefix=sleep4
!testdir=chester-test-sleep4

# sleepprint 3 Hello world A
Sleep then print

!program=bash data/sleepprint.sh 3 Hello world A

```output
Hello world A
```

# sleepprint 5 Hello world B
Sleep then print

!program=bash data/sleepprint.sh 5 Hello world B

```output
Hello world B
```

# sleepprint 2 Hello world C
Sleep then print

!program=bash data/sleepprint.sh 2 Hello world C

```output
Hello world C
```

# sleepprint 1 Hello world D
Sleep then print

!program=bash data/sleepprint.sh 1 Hello world D

```output
Hello world D
```

# sleepprint 1 Hello world E
Sleep then print

!program=bash data/sleepprint.sh 1 Hello world E

```output
Hello world E
```

# sleepprint 3 Hello world F
Sleep then print

!program=bash data/sleepprint.sh 3 Hello world F

```output
Hello world F
```

# sleepprint 2 Hello world G
Sleep then print

!program=bash data/sleepprint.sh 2 Hello world G

```output
Hello world G
```

# sleepprint 3 Hello world H
Sleep then print

!program=bash data/sleepprint.sh 3 Hello world H

```output
Hello world H
```

# sleepprint 2 Hello world I
Sleep then print

!program=bash data/sleepprint.sh 2 Hello world I

```output
Hello world I
```

# sleepprint 1 Hello world J
Sleep then print

!program=bash data/sleepprint.sh 1 Hello world J

```output
Hello world J
```

# sleepprint 2 Hello world K
Sleep then print

!program=bash data/sleepprint.sh 2 Hello world K

```output
Hello world K
```

# sleepprint 1 Hello world L
Sleep then print

!program=bash data/sleepprint.sh 1 Hello world L

```output
Hello world L
```

