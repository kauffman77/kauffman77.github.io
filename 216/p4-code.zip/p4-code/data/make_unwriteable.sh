#!/bin/bash
# usage: make_unwriteable.sh <file>
# Makes a given file unwriteable including on GRACE via ACL changes

file=$1
shift

rm -f $file
echo $* > $file

chmod a-w $file

# if on AFS like on Grace, adjust their ACL lists
if ls /usr/bin/fs >& /dev/null; then
    fs setacl $file $USER ra # read(r) adminster(a)
fi

    
