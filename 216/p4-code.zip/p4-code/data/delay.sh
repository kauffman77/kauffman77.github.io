#!/bin/bash

secs=$1
shift
sleep $secs

$*
