#!/bin/bash

sleep $1
shift
echo $*
