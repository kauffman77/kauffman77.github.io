#!/bin/bash

sleep 0.25
printf "I'm buried a bit but still important\n"
exit 50
