#include <stdio.h>

int main(){
  printf("\101\n");
  return 0;
}
