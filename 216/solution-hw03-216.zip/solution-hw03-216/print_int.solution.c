#include <stdio.h>

void print_int(int anint){
  if(anint == 0){               // special case
    putchar('0');
    return;
  }
  if(anint < 0){                // easier to work with positives
    putchar('-');               // so put the leading negative on the screen
    anint = -anint;
  }
  int divisor = 1;              // count digits to enable left to right printing
  while(divisor*10 < anint){
    divisor = divisor * 10;
  }

  char digit_chars[11] =        // array of characters for digits, 11
    "0123456789";               // long for \0 termination

  while(anint > 0){             
    int digit = anint / divisor;     // extract a left-side digit
    anint = anint % divisor;         // peel off left-side digit
    divisor = divisor / 10;          // adjust the divisor down
    char dchar = digit_chars[digit]; // select the character to print
    putchar(dchar);                  // put that on the screen
  }
  return;
}

int main(int argc, char *argv[]){
  int a1 = 1234;
  print_int(a1);
  printf("\n");
  
  int a2 = 8675309;             // Jenny!
  print_int(a2);
  printf("\n");

  int a3 = -5;
  print_int(a3);
  printf("\n");

  int a4 = -789123; 
  print_int(a4);
  printf("\n");

  int a5 = 0;
  print_int(a5);
  printf("\n");

  return 0;
}

// // INTERACTIVE MAIN
// int main(int argc, char *argv[]){
//   printf("Enter an integer: ");
//   int anint;
//   scanf("%d", &anint);
//   printf("You entered: ");
//   print_int(anint);
//   printf("\n");
//   return 0;
// }

