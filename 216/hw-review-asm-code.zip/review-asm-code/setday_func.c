// setday_fun.c: sample function to convert to assembly
int DAYS_SINCE_1970;

typedef struct {
  int day;  int year;
} yearday_t;

int setday(yearday_t yd){
  int day = yd.day;
  int year = yd.year;
  if(day < 0 || year < 1970){
    DAYS_SINCE_1970 = -1;
    return 1;
  }

  int totaldays = day + (year - 1970)*365;
  DAYS_SINCE_1970 = totaldays;
  return 0;
}
  
