# Lab07 SCRIPT

## Mon PROBLEM 1: GDB on Binaries
- Let students Problem 1 concerns using GDB and other tools analyze a
  program where there is no source code available
- Indicate to students that program is comprised of
  - `quote_main.c` : the `main()` function which calls some other
    functions and uses data not defined in that file; it reads an
    `input.txt` which requires the correct number to be in it
  - `quote_data.o` : an object file (compiled binary) that has the
    functions and data of interest
- Indicate that the code tests are easy to get right via a guess and
  check approach and all student will have the same number in
  `input.txt` to pass
- BUT the point is to understand tools and techniques to analyze the
  binary in cases where it is not tractable to brute force / guess and
  check the answers which will be the case in Project 3
- Walk students through the QUESTIONS.txt QUIZ questions and show them
  how to use some tools like `nm` and `objdump` to show information
  from the binary `quote_data.o`
- Compile the program via `make` and then run it in GDB to show how
  stepping into the `get_it()` function leads to "No Source Available"
- Show how to switch to assembly mode via `layout asm` and show the
  registers via `layout regs` and rerun to show the disassembled code
- Indicate to students that GDB will show instructions in a slightly
  different format than students should write their assembly but it
  should be understandable
- Take some steps and show students how to navigate using `stepi` and
  `nexti` to advance through the assembly instructions
- Hint that there is a linked list at play and it's a good idea to
  study the code to see how traversing a linked list looks in assembly 
- Give students time to explore on their own; indicate that the code
  is compiled from C by GCC and so may contain some unfamiliar
  instructions - they do not need to understand EVERY instruction,
  just enough to make progress
- Encourage students to try to reconstruct how the C code might look
  with loops, conditions, variables; be on the look out for Nodes in
  the list, NULL checks, etc.
- End the lab by asking for techniques students they found useful
- Don't be afraid to give away the correct response which is 6 in
  `input.txt`; just reiterate that the point is to learn how one might
  GET this answer if it weren't easy to brute force try all
  possibilities

## Wed PROBLEM 2: order2 and order3
- Let students know the idea of Problem 2 is to discuss how space for
  local variables is created in the stack via assembly instructions
- Survey some of the information in the Lab description web page on
  growing the stack in assembly
- Examine order2_c.c; note the need for local variables and use of
  several function calls
- Then examine the order2_asm.s file which is a template students will
  fill in; most of the code required is present already, discuss it
- Note the need in the TODO section to grow the stack by lowering the
  stack pointer.
- Point out the "layout" table describing where local variables will
  be in the stack
- Examine the PROVIDED setup for the first call to order2() which
  loads pointers to locals in the stack into argument registers; note
  to students that they will fill in subsequent versions of this as
  well as the later printf() setups
- Draw attention to the 'leaq' instructions for "Load Effective
  Address": useful to calculate memory addresses and load them into
  registers, associated with the &var syntax in C - we have discussed
  this in lecture
- Answer questions about provided code such as how arguments are set
  up in the %rdi and %rsi registers for the call to order2;
- Provide students with the means to grow the stack via the
  instruction
  `subq $8, %rsp`
  which makes enough space for Two 4-byte integers and later shrinks
  it via
  `addq $8, %rsp`
  which, if forgotten, will cause major problems
- We will likely have discussed this some in lecture but students will
  need to use similar techniques in Project 3 and this is practice
- Switch to examine the `order3_c.c` file which shows use of the
  `order3()` function used on local variables which must be in main
  memory; note the need for local variables and use of several
  function calls
- Then examine the `order3_asm.s` file which is a template students
  will fill in
- Point out the again "layout" table describing where local variables
  will be in the stack: this layout is more complex as there are many
  variables that need a memory address BUT the stack is still extended
  the same as before: with a single `subq` instruction
- Discuss with students the requirements for stack growth which are
  1. Enough space for all locals, in this case 36 bytes AND 
  2. Align the stack pointer %rsp to a 16-byte boundary knowing that
     it is at an 8-byte boundary at the beginning of all function
     calls due to the return address
  Coach students that `subq $36, %rsp` will not meet the requirement;
  instead `subq $40, %rsp` is required
- The rule of thumb is 
  - If N bytes are required for local variables in the stack
  - Grow the stack by (N+G) where G the smallest integer that
    satisfies `(N+G+8) % 16 == 0`
  - Common growth sizes are `8, 24, 40, 56, ... I*16+8` for integer I
    values.
- Examine the PROVIDED setup for the first call to order3() which
  loads pointers to locals in the stack into argument registers; note
  to students that they will fill in subsequent versions of this as
  well as the later printf() setups
- Draw attention to the `leaq .FORMAT1(%rip), %rdi` which loads the
  address of a global variable into memory; students don't need to
  know about the format strings but will need to work with global
  variables in P3

### OPTIONAL Topics if time and will permit:
- OPTIONAL: demonstrate how failing to shrink the stack looks, omit
  the `addq $8, %rsp` from `order2_asm.s`, compile and run under
  Valgrind to show the output of jumping to invalid address
- OPTIONALLY discuss the order2 assembly function itself which uses
  pointer-dereference, compares numbers, changes things in the stack
  frame of `main()`

