# Lab07 SCRIPT

## Mon
- Let students know the idea of the lab is to discuss how space for
  local variables is created in the stack via assembly instructions
- Survey some of the information in the Lab description web page on
  growing the stack in assembly
- Examine order2_c.c; note the need for local variables and use of
  several function calls
- Then examine the order2_asm.s file which is a template students will
  fill in; most of the code required is present already, discuss it
- Note the need in the TODO section to grow the stack by lowering the
  stack pointer.
- Point out the "layout" table describing where local variables will
  be in the stack
- Examine the PROVIDED setup for the first call to order2() which
  loads pointers to locals in the stack into argument registers; note
  to students that they will fill in subsequent versions of this as
  well as the later printf() setups
- Draw attention to the 'leaq' instructions for "Load Effective
  Address": useful to calculate memory addresses and load them into
  registers, associated with the &var syntax in C
- Answer questions about provided code such as how arguments are set
  up in the %rdi and %rsi registers for the call to order2; 
- Coach students through analyzing this code
- Provide students with the means to grow the stack via the
  instruction
  `subq $8, %rsp`
  which makes enough space for 2 4-byte integers
- Indicate that this MUST be paired with shrinking the stack at the
  end of the function via
  `addq $8, %rsp`
  If this is not done, the program will fail badly
- OPTIONAL: demonstrate how failing to shrink the stack looks, run the
  program under Valgrind to show the output of jumping to invalid
  address   
- OPTIONALLY discuss the order2 assembly function itself
- Indicate that the order3_c.c and order3_asm.s files will be
  discussed on Wednesday

## Wed
- First examine the order3_c.c file which shows use of the order3()
  function used on local variables which must be in main memory; note
  the need for local variables and use of several function calls
- Then examine the order3_asm.s file which is a template students will
  fill in
- Point out the "layout" table describing where local variables will
  be in the stack: this layout is more complex as there are many
  variables that need a memory address BUT the stack is still extended
  the same as before: with a single 'subq' instruction
- Examine the PROVIDED setup for the first call to order3() which
  loads pointers to locals in the stack into argument registers; note
  to students that they will fill in subsequent versions of this as
  well as the later printf() setups
- Discuss with students the requirements for stack growth which are
  (1) enough space for all locals, in this case 36 bytes AND (2) align
  the stack pointer %rsp to a 16-byte boundary knowing that it is at
  an 8-byte boundary at the beginning of all function calls due to the
  return address
- Help students understand that the stack could grow by 8, 24, 40, 56,
  etc. according to the pattern 8+(i*16) to get enough space and align
  properly; in this case 40 is the smallest size that fits the 36
  bytes of local variables
- Draw attention to the '.leaq .FORMAT1(%rip), %rdi' which loads the
  address of a global variable into memory; students don't need to
  know about the format strings but will need to work with global
  variables in P3
