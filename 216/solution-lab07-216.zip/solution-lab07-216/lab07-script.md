# Lab07 SCRIPT

# Mon: Problem 1 prime_funcs (global variables in assembly)
- Use `make` to compile the lab code and briefly run the
  `prime_main_c` program which combines a `main()` with calls to the
  functions in `prime_funcs.c` to produce its output
- Indicate that the task will be to finish an assembly function
  version of one of the functions in `prime_funcs_asms.`
- Pull up `prime_funcs.c` and `prime_funcs_asm.s` Side By Side to
  compare then
- Focus attention first on the overall structure of the assembly file
  which has 3 functions declared in a `.text` section and a global
  variable `primes` which is an array of integers at the end in a
  `.data` section; note that these two sections are for Executable
  Code (Text) and Global Variables (Data)
- Turn attention to comparing the C/Assembly implementations of
  `primprod()` 
- Discuss how the multi-part OR condition is handled in assembly (a
  QUIZ question); you can note that this is NOT the only way to handle
  this but is a straight-forward method to do so
- Discuss the syntax for loading a global variable's address (a QUIZ
  question) and how it uses an offset from the RIP. This is a "modern"
  technique (only 20-ish years old) that helps with security and will
  be discussed in lecture. Student only need to understand that to use
  global variables, they must employ this `NAME(%rip)` syntax.
- Mention that since the global variable in this case is an Array, it
  is most prudent to load an address for that array into a register
  the use the `(%base,%index,size)` addressing mode to access array
  elements in it (a QUIZ question)
- Mention that it's good to know about the `objdump -d program`
  utility which disassembles an executable and shows instructions
  within. Demonstrate this with a quiz question that compares the
  global variable access `primes` as it appears in source code as a
  name/symbol and the disassembled code where a numeric offset from
  the `%rip` has substituted in
- Give students time to work on completing the CODE portion, a second
  function which uses similar techniques but involves a loop
- Mention at the end that those wanting more practice can complete the
  OPTIONAL code problem
  
# Wed Problem 2: order2 and order3
- Let students know the idea of Problem 2 is to discuss how space for
  local variables is created in the stack via assembly instructions
- Survey some of the information in the Lab description web page on
  growing the stack in assembly
- Examine order2_c.c; note the need for local variables and use of
  several function calls
- Then examine the order2_asm.s file which is a template students will
  fill in; most of the code required is present already, discuss it
- Note the need in the TODO section to grow the stack by lowering the
  stack pointer.
- Point out the "layout" table describing where local variables will
  be in the stack
- Examine the PROVIDED setup for the first call to order2() which
  loads pointers to locals in the stack into argument registers; note
  to students that they will fill in subsequent versions of this as
  well as the later printf() setups
- Draw attention to the 'leaq' instructions for "Load Effective
  Address": useful to calculate memory addresses and load them into
  registers, associated with the &var syntax in C - we have discussed
  this in lecture
- Answer questions about provided code such as how arguments are set
  up in the %rdi and %rsi registers for the call to order2;
- Provide students with the means to grow the stack via the
  instruction
  `subq $8, %rsp`
  which makes enough space for Two 4-byte integers and later shrinks
  it via
  `addq $8, %rsp`
  which, if forgotten, will cause major problems
- We will likely have discussed this some in lecture but students will
  need to use similar techniques in Project 3 and this is practice
- Switch to examine the `order3_c.c` file which shows use of the
  `order3()` function used on local variables which must be in main
  memory; note the need for local variables and use of several
  function calls
- Then examine the `order3_asm.s` file which is a template students
  will fill in
- Point out the again "layout" table describing where local variables
  will be in the stack: this layout is more complex as there are many
  variables that need a memory address BUT the stack is still extended
  the same as before: with a single `subq` instruction
- Discuss with students the requirements for stack growth which are
  1. Enough space for all locals, in this case 36 bytes AND 
  2. Align the stack pointer %rsp to a 16-byte boundary knowing that
     it is at an 8-byte boundary at the beginning of all function
     calls due to the return address
  Coach students that `subq $36, %rsp` will not meet the requirement;
  instead `subq $40, %rsp` is required
- The rule of thumb is 
  - If N bytes are required for local variables in the stack
  - Grow the stack by (N+G) where G the smallest integer that
    satisfies `(N+G+8) % 16 == 0`
  - Common growth sizes are `8, 24, 40, 56, ... I*16+8` for integer I
    values.
- Examine the PROVIDED setup for the first call to order3() which
  loads pointers to locals in the stack into argument registers; note
  to students that they will fill in subsequent versions of this as
  well as the later printf() setups
- Draw attention to the `leaq .FORMAT1(%rip), %rdi` which loads the
  address of a global variable into memory; students don't need to
  know about the format strings but will need to work with global
  variables in P3

## OPTIONAL Topics if time and will permit:
- OPTIONAL: demonstrate how failing to shrink the stack looks, omit
  the `addq $8, %rsp` from `order2_asm.s`, compile and run under
  Valgrind to show the output of jumping to invalid address
- OPTIONALLY discuss the order2 assembly function itself which uses
  pointer-dereference, compares numbers, changes things in the stack
  frame of `main()`
