### SOLUTION
### order2_asm.s: assembly version of order2_c.c; complete the main()
### function which requires expanding the stack for local variables
### which need main memory addresses and making function calls to
### order() and printf().

.text
.global	main
main:
	## stack layout will be
	## |----------+-----+------|
	## |    Stack |     |      |
	## | Location | C   | init |
	## |  rsp + N | Var |  val |
	## |----------+-----+------|
	## |        0 | r   |   17 |
	## |        4 | t   |   12 |
	## 
	## Total space for local vars: 8 bytes (2 x 4-byte integers)
	## Expand stand stack by 8 bytes so that additional 8 bytes of return address
	## leaves %rsp divisible by 16 (aligned for function calls)

	## TODO: Use a subq instruction to expand stack for locals + alignment padding
	subq	$8, %rsp               # expand stack for locals + alignment padding
	
	## PROVIDED: Sample setup for first call to order2(&r, &t, &v);
	movl	$17, 0(%rsp)           # r=17 (stored 0 bytes above the stack pointer)
	movl	$12, 4(%rsp)           # t=12 (stored 4 bytes above the stack pointer)
	movq	%rsp, %rdi             # arg1 &r 
        leaq	4(%rsp), %rsi          # arg2 &t
	call	order2                 # function call
	
        ## PROVIDED: Sample setup for first printf("..",r,t) call
	leaq	.FORMAT1(%rip), %rdi   # arg1 .FORMAT1
	movl	(%rsp), %esi           # arg2 r
	movl	4(%rsp), %edx          # arg3 t
	movl	$0, %eax               # special setup for printf
	call	printf@PLT             # function call
	
        ## TODO: Use an addq instruction to undo stack changes made at the
        ## beginning of main; e.g. shrink stack / restore rsp to its
        ## original value before returning
	addq	$8, %rsp               # restore the stack before returning
	
        ## PROVIDED: return 0 for success
	movl	$0, %eax
	ret

.data
.FORMAT1:                       # format strings for printf calls
	.string	"r t: %2d %2d\n"

.text
.globl	order2                  # THIS FUNCTION IS CORRECT: do not modify it
order2:                         # a in %rdi, b in %rsi, c in %rdx
	movl	(%rdi), %eax    # load a
	movl	(%rsi), %ecx    # load b
	cmpl	%ecx, %eax      # if *a > *b
	jle	.AB_ORDERED     # false: don't swap
	movl	%ecx, (%rdi)    # true, swap a/b
	movl	%eax, (%rsi)
.AB_ORDERED:
	ret
