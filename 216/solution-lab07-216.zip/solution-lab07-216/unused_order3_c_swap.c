// uses swap() function which complicates the order3() function considerably at the assembly level
#include <stdio.h>

void swap(int *x, int *y){
  int tmp = *x;
  *x = *y;
  *y = tmp;
}

void order3(int *a, int *b, int *c){
  if(*a > *b){                  // bubble a up
    swap(a, b);
  }
  if(*b > *c){
    swap(b, c);                 // c is now largest
  }            
  if(*a > *b){                   
    swap(a, b);                 // b is no middle value
  }                             // a is min value
  return;
}

int main(){
  int r=17, t=12, v=13;
  order3(&r, &t, &v);

  int q=5, e=9, d=2;
  order3(&q, &e, &d);

  printf("r t v: %d %d %d\n",r,t,v);
  printf("q e d: %d %d %d\n",q,e,d);
  
  return 0;
}
