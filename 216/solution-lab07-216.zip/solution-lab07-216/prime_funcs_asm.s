### prime_funcs_asm.s: assembly implementation two functions that use
### a the global primes[] array that appears in the data section at
### the end of the code. One function is provided for study and
### demonstrates how to access the global array. The other TODO
### function must be completed to complete the lab. There is an
### OPTIONAL function which is more challenging that may be completed
### for additional practice.

### Provided: This function is complete. See its C version for
### documentation on its behavior.
.text                                 # TEXT section of executable code
.global primprod                      # makes primprod() function visible to C code
primprod:
        ## %edi is pidx1, %esi is pidx2
        cmpl    $0, %edi              # check arguments for ranges
        jl      .PRIMPROD_ERROR       # jump to error case if out of range
        cmpl    $0, %esi
        jl      .PRIMPROD_ERROR
        cmpl    $200, %edi
        jge     .PRIMPROD_ERROR
        cmpl    $200, %esi
        jge     .PRIMPROD_ERROR
        
        leaq    primes(%rip), %rcx    # rcx is pointer to primes array
        movl    (%rcx,%rdi,4), %eax   # copy first prime to return register
        movl    (%rcx,%rsi,4), %edx   # copy second prime another register
        imull   %edx, %eax            # calculate product in return register
        ret                           # return the product
.PRIMPROD_ERROR:                      # error case returns -1
        movl    $-1, %eax
        ret

### TODO: Complete this function See its C version for documentation
### on its behavior.
.global primsums                      # makes primsums() function visible to C code
primsums:
        ## %edi is start, %esi is stop
        cmpl    $0, %edi              # check arguments for ranges
        jl      .PRIMPROD_ERROR       # jump to error case if out of range
        cmpl    $0, %esi
        jl      .PRIMPROD_ERROR
        cmpl    $200, %edi
        jge     .PRIMPROD_ERROR
        cmpl    $200, %esi
        jge     .PRIMPROD_ERROR
        
        leaq    primes(%rip), %rcx    # rcx is pointer to primes array
        movl    $0, %eax              # start with a sum of zero
.LOOPTOP:                             # treat esi as i, edi is stop
        cmpl    %esi, %edi            # while(i < stop)
        jge     .LOOPBOT              # nope, done with loop
        addl    (%rcx,%rdi,4), %eax   # add on prime number
        incl    %edi                  # increment i
        jmp     .LOOPTOP              # back to top of the loop
.LOOPBOT:
        ret
.PRIMSUMS_ERROR:                      # error case returns -1
        movl    $-1, %eax
        ret


### OPTIONAL: A more challenging function that may be completed for
### additional practice.  See its C version for documentation on its
### behavior. It is called from the prime_factmain.c main program.
.global primfact
primfact:
        ## edi is target, rsi is fact1 ptr, rdx is fact2 ptr
        testl   %edi,%edi
        jns     .POSNUM
        movl    $-1,%eax
        ret
.POSNUM:
        movl    $0,%ecx             # ecx is i, set to 0
        leaq    primes(%rip),%r8    # r8 is address of primes
        movq    %rdx,%r10           # r10 is fact2 ptr, will ovewrite edx in division
.TOP:
        cmpl    $200,%ecx
        jge     .RET_ZERO
        movl    (%r8,%rcx,4),%r9d   # get primes[i] for dividend
        movl    %edi,%eax           # must divide eax, copy target number
        cltq                        # set up division by clobbering edx
        cqto                        # likely cqto is enough
        idivl   %r9d                # divide by primes[i]
        incl    %ecx                # cheat a little and do the loop increment here unconditionally
        cmpl    $0,%edx             # check for zero remainder
        jnz     .TOP                # nope, another iteration
.RET_ONE:                           # label just for documentation: found two factors, fall through here
        movl    %r9d,(%rsi)         # *fact1 = primes[i]
        movl    %eax,(%r10)         # *fact2 = quo
        movl    $1,%eax             # return 1
        ret
.RET_ZERO:
        movl    $0,%eax
        ret

#########################################################################
.data                                 # DATA section which contains global variables
.global primes                        # makes primes[] array visible to C code
primes:
	.int	2
	.int	3
	.int	5
	.int	7
	.int	11
	.int	13
	.int	17
	.int	19
	.int	23
	.int	29
	.int	31
	.int	37
	.int	41
	.int	43
	.int	47
	.int	53
	.int	59
	.int	61
	.int	67
	.int	71
	.int	73
	.int	79
	.int	83
	.int	89
	.int	97
	.int	101
	.int	103
	.int	107
	.int	109
	.int	113
	.int	127
	.int	131
	.int	137
	.int	139
	.int	149
	.int	151
	.int	157
	.int	163
	.int	167
	.int	173
	.int	179
	.int	181
	.int	191
	.int	193
	.int	197
	.int	199
	.int	211
	.int	223
	.int	227
	.int	229
	.int	233
	.int	239
	.int	241
	.int	251
	.int	257
	.int	263
	.int	269
	.int	271
	.int	277
	.int	281
	.int	283
	.int	293
	.int	307
	.int	311
	.int	313
	.int	317
	.int	331
	.int	337
	.int	347
	.int	349
	.int	353
	.int	359
	.int	367
	.int	373
	.int	379
	.int	383
	.int	389
	.int	397
	.int	401
	.int	409
	.int	419
	.int	421
	.int	431
	.int	433
	.int	439
	.int	443
	.int	449
	.int	457
	.int	461
	.int	463
	.int	467
	.int	479
	.int	487
	.int	491
	.int	499
	.int	503
	.int	509
	.int	521
	.int	523
	.int	541
	.int	547
	.int	557
	.int	563
	.int	569
	.int	571
	.int	577
	.int	587
	.int	593
	.int	599
	.int	601
	.int	607
	.int	613
	.int	617
	.int	619
	.int	631
	.int	641
	.int	643
	.int	647
	.int	653
	.int	659
	.int	661
	.int	673
	.int	677
	.int	683
	.int	691
	.int	701
	.int	709
	.int	719
	.int	727
	.int	733
	.int	739
	.int	743
	.int	751
	.int	757
	.int	761
	.int	769
	.int	773
	.int	787
	.int	797
	.int	809
	.int	811
	.int	821
	.int	823
	.int	827
	.int	829
	.int	839
	.int	853
	.int	857
	.int	859
	.int	863
	.int	877
	.int	881
	.int	883
	.int	887
	.int	907
	.int	911
	.int	919
	.int	929
	.int	937
	.int	941
	.int	947
	.int	953
	.int	967
	.int	971
	.int	977
	.int	983
	.int	991
	.int	997
	.int	1009
	.int	1013
	.int	1019
	.int	1021
	.int	1031
	.int	1033
	.int	1039
	.int	1049
	.int	1051
	.int	1061
	.int	1063
	.int	1069
	.int	1087
	.int	1091
	.int	1093
	.int	1097
	.int	1103
	.int	1109
	.int	1117
	.int	1123
	.int	1129
	.int	1151
	.int	1153
	.int	1163
	.int	1171
	.int	1181
	.int	1187
	.int	1193
	.int	1201
	.int	1213
	.int	1217
	.int	1223
