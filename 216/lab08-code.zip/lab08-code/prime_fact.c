// prime_fact.c: provided for those implementing the optional
// primfact() function in assembly; should match the behavior and
// output of the provided C version.

#include <stdio.h>
#include <stdlib.h>

int primfact(int target, int *fact1, int *fact2);

int main(int argc, char *argv[]){
  if(argc < 3){
    printf("usage: %s <start> <stop>\n",argv[0]);
    printf("  prints two factors of numbers in range <start> to <stop>\n");
    return 1;
  }
  int start = atoi(argv[1]);
  int stop  = atoi(argv[2]);

  for(int i=start; i<stop; i++){
    printf("%4d: ",i);
    int fact1=-1, fact2=-1;
    int ret = primfact(i, &fact1, &fact2);
    if(ret == -1){
      printf("Negative input\n");
    }
    else if(ret == 0){
      printf("No factors found\n");
    }
    else{
      printf("fact1: %4d  fact2: %4d\n",fact1,fact2);
    }
  }

  return 0;
}    
