// prime_funcs.c: provided C file which uses a global array in several
// functions.

// a list of primt numbers
#define NPRIMES 200
int primes[NPRIMES] = {
  2,    3,    5,    7,    11,   13,   17,   19,   23,   29,
  31,   37,   41,   43,   47,   53,   59,   61,   67,   71,
  73,   79,   83,   89,   97,   101,  103,  107,  109,  113,
  127,  131,  137,  139,  149,  151,  157,  163,  167,  173,
  179,  181,  191,  193,  197,  199,  211,  223,  227,  229,
  233,  239,  241,  251,  257,  263,  269,  271,  277,  281,
  283,  293,  307,  311,  313,  317,  331,  337,  347,  349,
  353,  359,  367,  373,  379,  383,  389,  397,  401,  409,
  419,  421,  431,  433,  439,  443,  449,  457,  461,  463,
  467,  479,  487,  491,  499,  503,  509,  521,  523,  541,
  547,  557,  563,  569,  571,  577,  587,  593,  599,  601,
  607,  613,  617,  619,  631,  641,  643,  647,  653,  659,
  661,  673,  677,  683,  691,  701,  709,  719,  727,  733,
  739,  743,  751,  757,  761,  769,  773,  787,  797,  809,
  811,  821,  823,  827,  829,  839,  853,  857,  859,  863,
  877,  881,  883,  887,  907,  911,  919,  929,  937,  941,
  947,  953,  967,  971,  977,  983,  991,  997,  1009, 1013,
  1019, 1021, 1031, 1033, 1039, 1049, 1051, 1061, 1063, 1069,
  1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151,
  1153, 1163, 1171, 1181, 1187, 1193, 1201, 1213, 1217, 1223,
};

// returns the product of two primes with indices given by the
// parameters pidx1,pidx2. Returns -1 if either index is out of bounds
// for the array.
int primprod(int pidx1, int pidx2){
  if(pidx1 < 0 || pidx2 < 0 || pidx1 >= NPRIMES || pidx2 >= NPRIMES){
    return -1;
  }
  int *arr = primes;
  int ans = arr[pidx1];
  int p2 = arr[pidx2];
  ans = ans*p2;
  return ans;
}

// returns the sum of elements in primes[] begining with index `start`
// and ending with index `stop`. If either index is out of bounds,
// returns -1.
int primsums(int start, int stop){
  if(start < 0 || stop < 0 || start >= NPRIMES || stop >= NPRIMES){
    return -1;
  }
  int *arr = primes;
  int sum = 0;
  for(int i=start; i<stop; i++){
    sum += arr[i];
  }
  return sum;
}

// Finds the first number in primes[] that evenly divides (is a
// factor) the number `target`.  Sets fact1 to be that first prime and
// fact2 to the remainder of dividing `target` by that prime and then
// returns 1. If no number in primes[] divides `target`, returns 0 and
// does not change fact1/fact2. If `target` is negative, returns -1
// without changing fact1/fact2.
// 
// OPTIONAL code to implement for practice.
int primfact(int target, int *fact1, int *fact2){
  if(target < 0){
    return -1;
  }
  for(int i=0; i<NPRIMES; i++){
    int prim = primes[i];
    int quo = target / prim;
    int rem = target % prim;
    if(rem == 0){
      *fact1 = prim;
      *fact2 = quo;
      return 1;
    }
  }
  return 0;
}
    
