// prime_main.c: main function combined with either C or Assembly
// service functions; calls those functions and shows their behavior
#include <stdio.h>

// defined in either C or Assembly files
int primprod(int pidx1, int pidx2);
int primsums(int start, int stop);
extern int primes[];

int main(int argc, char *argv[]){
  int pidx1, pidx2, prod;

  // primprod() calls
  pidx1=5; pidx2=10;
  printf("primes[%3d] is %8d\n",pidx1,primes[pidx1]);
  printf("primes[%3d] is %8d\n",pidx2,primes[pidx2]);
  prod = primprod(pidx1,pidx2);
  printf("their product: %8d\n\n",prod);

  pidx1=25; pidx2=62;
  printf("primes[%3d] is %8d\n",pidx1,primes[pidx1]);
  printf("primes[%3d] is %8d\n",pidx2,primes[pidx2]);
  prod = primprod(pidx1,pidx2);
  printf("their product: %8d\n\n",prod);

  pidx1=102; pidx2=199;
  printf("primes[%3d] is %8d\n",pidx1,primes[pidx1]);
  printf("primes[%3d] is %8d\n",pidx2,primes[pidx2]);
  prod = primprod(pidx1,pidx2);
  printf("their product: %8d\n\n",prod);

  pidx1=186; pidx2=207;
  prod = primprod(pidx1,pidx2);
  printf("primes[%3d] * primes[%3d] is %d\n",
         pidx1,pidx2,prod);

  pidx1=-15; pidx2=15;
  prod = primprod(pidx1,pidx2);
  printf("primes[%3d] * primes[%3d] is %d\n",
         pidx1,pidx2,prod);

  printf("\n");

  // primsums() calls
  int beg, end, sum;
  beg=0; end=10;
  sum = primsums(beg, end);
  printf("sum of primes[] %3d to %3d: %6d\n",
         beg, end, sum);

  beg=25; end=139;
  sum = primsums(beg, end);
  printf("sum of primes[] %3d to %3d: %6d\n",
         beg, end, sum);

  beg=168; end=199;
  sum = primsums(beg, end);
  printf("sum of primes[] %3d to %3d: %6d\n",
         beg, end, sum);

  beg=175; end=143;
  sum = primsums(beg, end);
  printf("sum of primes[] %3d to %3d: %6d\n",
         beg, end, sum);

  beg=180; end=251;
  sum = primsums(beg, end);
  printf("sum of primes[] %3d to %3d: %6d\n",
         beg, end, sum);

  beg=0; end=-7;
  sum = primsums(beg, end);
  printf("sum of primes[] %3d to %3d: %6d\n",
         beg, end, sum);


  return 0;
}
