#pragma once 

// size in bits of some types
#define INT_BITS   (sizeof(int)*8)
#define SHORT_BITS (sizeof(short)*8)
#define CHAR_BITS  (sizeof(char)*8)

////////////////////////////////////////////////////////////////////////////////
// clock_update.c structs/functions

// STRUCTS_BEGIN
// Breaks time down into 12-hour format
typedef struct{
  int   day_secs;    // seconds from start of day
  short time_secs;   // seconds in current minute
  short time_mins;   // minutes in current hour
  short time_hours;  // current hour of day
  char ampm;         // 1 for am, 2 for pm
} tod_t;

// Functions to implement for CLOCK Clock Problem
int set_tod_from_ports(tod_t *tod);
int set_display_from_tod(tod_t tod, int *display);
int clock_update();

// Accessing fields via a clock_t * pointer
// |-----------------+----------+-------------+-------------------|
// |                 |          | Destination | Assembly          |
// | C Field Access  | Offset   | Size        | Assign 5 to field |
// |-----------------+----------+-------------+-------------------|
// | tod->day_secs   | 0 bytes  | 4 bytes     | movl $5, 0(%reg)  |
// | tod->time_secs  | 4 bytes  | 2 bytes     | movw $5, 4(%reg)  |
// | tod->time_mins  | 6 bytes  | 2 bytes     | movw $5, 6(%reg)  |
// | tod->time_hours | 8 bytes  | 2 bytes     | movw $5, 8(%reg)  |
// | tod->ampm       | 10 bytes | 1 byte      | movb $5,10(%reg)  |
// |-----------------+----------+-------------+-------------------|
//
// Accessing fields via a clock_t packed struct
// |----------------+----------+--------+-------------+---------|
// |                |          |   Bits | Shift       |         |
// | C Field Access | Register | in reg | Required    | Size    |
// |----------------+----------+--------+-------------+---------|
// | tod.day_secs   | %rdi     |   0-31 | None        | 4 bytes |
// | tod.time_secs  | %rdi     |  32-47 | Right by 32 | 2 bytes |
// | tod.time_mins  | %rdi     |  48-63 | Right by 48 | 2 bytes |
// | tod.time_hours | %rsi     |   0-15 | None        | 2 bytes |
// | tod.ampm       | %rsi     |  16-23 | Right by 16 | 1 bytes |
// |----------------+----------+--------+-------------+---------|
//
// STRUCTS_END
//
////////////////////////////////////////////////////////////////////////////////
// clock_sim.c structs/functions; do not modify

extern int CLOCK_TIME_PORT;
// Time of day in units of 1/16th of a second. Tied to a hardware
// clock that automatically increments it 16 times per second starting
// at midnight. The simulatator provides a C global variable to
// emulate this part of the hardware. This variable is present when
// #include "clock.h" is used and should not be declared in any user
// code.

extern int CLOCK_DISPLAY_PORT;
// Global variable used to control the LCD display on the
// clock. Making changes to this variable will change the lighting
// patternon the LCD display.


// Use the global CLOCK_DISPLAY_PORT to print the time 
void print_clock_display();

// utility to show the bits of an integer
char *bitstr(int x, int bits);
char *bitstr_index(int bits);
