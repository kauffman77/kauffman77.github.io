#include <stdio.h>

void func1(){
  printf("I'm the Y version\n");
}
