// test_makeup.c: unit tests for chester makeup functions and data
#include "chester.h"
#include <time.h>

// macro to set up a test with given name, print the source of the
// test; very hacky, fragile, but useful
#define IF_TEST(TNAME) \
  if( RUNALL ) { printf("\n"); } \
  if( RUNALL || strcmp( TNAME, test_name)==0 ) { \
    sprintf(sysbuf,"awk 'NR==(%d){P=1;gsub(\"^ *\",\"\");} P==1 && /ENDTEST/{P=0; print \"}\\n---OUTPUT---\"} P==1{print}' %s", __LINE__, __FILE__); \
    system(sysbuf); nrun++;  \
  } \
  if( RUNALL || strcmp( TNAME, test_name)==0 )

char sysbuf[1024];
int RUNALL = 0;
int nrun = 0;
char cmdbuf[1024];

struct timespec beg, end;

double get_elapsed(){
  long secs = end.tv_sec -  beg.tv_sec;
  long nano = end.tv_nsec - beg.tv_nsec;
  double elapsed = ((double) secs) + 1e-9*nano;
  return elapsed;
}

void suite_test_print1(suite_t *suite, int testnum){
  test_t *test = &suite->tests[testnum];
  printf("  program: %s\n", test->program);
  printf("  description:\n---\n%s---", test->description);
  printf("  input:\n---\n%s---\n", test->input);
  printf("  output_expect:\n---\n%s---\n", test->output_expect);
  printf("  exit_code_expect: %d\n", test->exit_code_expect);
  printf("  exit_code_actual: %d\n", test->exit_code_actual);
  printf("  state: %s (%d)\n", test_state_str(test->state),test->state);
}


void suite_print_loaded(suite_t *suite){
  printf("\nLOADED SUITE\n");
  printf("suite->infile_name:  %s\n",suite->infile_name);
  printf("suite->testdir:      %s\n",suite->testdir);
  printf("suite->prefix:       %s\n",suite->prefix);
  printf("suite->max_procs:    %d\n",suite->max_procs);
  printf("suite->tests_count:  %d\n",suite->tests_count);
  printf("suite->tests_passed: %d\n",suite->tests_passed);
  printf("TEST DATA\n");
  for(int i=0; i<suite->tests_count; i++){
    printf("tests[%2d]:\n",i);
    suite_test_print1(suite,i);
    printf("------\n");
  }      
}  

void suite_test_setup(suite_t *suite, char *filename, char *key){
  suite_init_from_file_peg(suite,filename);
  free(suite->testdir);
  free(suite->prefix);
  sprintf(cmdbuf,"test-results/testdir%s",key);
  suite->testdir = strdup(cmdbuf);
  sprintf(cmdbuf,"pref%s",key);
  suite->prefix = strdup(cmdbuf);
  sprintf(cmdbuf,"rm -rf %s",suite->testdir);
  system(cmdbuf);
}

void suite_test_print_all(suite_t *suite){
  printf("\nCOMPLETED SUITE\n");
  printf("suite->infile_name: %s\n",suite->infile_name);
  printf("suite->testdir:     %s\n",suite->testdir);
  printf("suite->prefix:      %s\n",suite->prefix);
  printf("suite->max_procs:         %d\n",suite->max_procs);
  printf("suite->tests_torun_count: %d\n",suite->tests_torun_count);
  printf("suite->tests_passed:      %d\n",suite->tests_passed);
  printf("suite->tests_passed:      %d\n",suite->tests_passed);
  printf("\n");
  printf("CONTENTS OF TESTDIR\n");
  sprintf(cmdbuf,"ls %s",suite->testdir);
  system(cmdbuf);
  printf("\n");
  printf("TEST RESULTS\n");
  for(int i=0; i<suite->tests_torun_count; i++){
    int testnum = suite->tests_torun[i];
    test_t *test = &suite->tests[testnum];
    printf("tests[%d]->resultfile_name:\n%s\n",
           testnum,test->resultfile_name);
    printf("---Resultfile Contents---\n");
    sprintf(cmdbuf,"cat %s",test->resultfile_name);
    system(cmdbuf);
    printf("------\n\n");
  }      
}  

  
int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <test_name>\n", argv[0]);
    printf("       %s ALL\n", argv[0]);
    return 1;
  }
  char *test_name = argv[1];
  char sysbuf[1024];
  int ret;

  RUNALL = strcmp(test_name,"ALL")==0; // possibly run all tests

  system("mkdir -p test-results"); // ensure a subdirectory for data is present
    
  ////////////////////////////////////////////////////////////////////////////////
  // MULTIPROC
  ////////////////////////////////////////////////////////////////////////////////

  IF_TEST("//////////////////// MULTIPROC ////////////////////") {
  } // ENDTEST

  IF_TEST("suite_run_tests_multiproc1") { 
    // Runs small number of sleep tests with 2 processes. Should
    // complete in around second if executing the tests concurrently.
    suite_t suite;
    suite_test_setup(&suite,"data/sleep_tests1.md","RTMP1");
    suite.tests_torun_count = 0;
    for(int i=0; i<suite.tests_count; i++){
      suite.tests_torun[i] = i;
      suite.tests_torun_count++;
    }
    suite.max_procs = 2;          // set # procs to use
    printf("CALLING FUNCTION\n");
    clock_gettime(CLOCK_REALTIME, &beg);
    ret = suite_run_tests_multiproc(&suite);
    clock_gettime(CLOCK_REALTIME, &end);
    printf("FUNCTION DONE\n");
    printf("ret: %d\n",ret);
    Dprintf("Elapsed time: %f\n",get_elapsed());
    if(get_elapsed() < 1.5){
      printf("Elapsed time is in limit\n");
    }
    else{
      printf("Elapsed time is BEYOND LIMIT\n");
    }
    suite_test_print_all(&suite);
    suite_dealloc(&suite);
  } // ENDTEST

  
  IF_TEST("suite_run_tests_multiproc2") { 
    // Loads a test suite with 4 tests and runs all 4 of them
    // concurrently via suite_run_tests_multiproc(). 2 of the 4 tests
    // pass.. Checks that the results file for each test is formatted
    // correctly.
    suite_t suite;
    suite_test_setup(&suite,"data/four_tests.md","RTMP2");
    suite.tests_torun_count = 4;
    for(int i=0; i<4; i++){
      suite.tests_torun[i] = i;
    }
    suite.max_procs = 2;          // set # procs to use
    printf("CALLING FUNCTION\n");
    clock_gettime(CLOCK_REALTIME, &beg);
    ret = suite_run_tests_multiproc(&suite);
    clock_gettime(CLOCK_REALTIME, &end);
    printf("FUNCTION DONE\n");
    printf("ret: %d\n",ret);
    Dprintf("Elapsed time: %f\n",get_elapsed());             
    if(get_elapsed() < 1.0){
      printf("Elapsed time is in limit\n");
    }
    else{
      printf("Elapsed time is BEYOND LIMIT\n");
    }
    suite_test_print_all(&suite);
    suite_dealloc(&suite);
  } // ENDTEST

  IF_TEST("suite_run_tests_multiproc3") { 
    // Loads a suite that has some special cases of tests like test
    // programs that are signaled, have empty input, fail due to
    // mismatched exit codes, etc. Runs all tests in the suite
    // concurrently and checks shows results files to ensure they are
    // formatted correctly.
    suite_t suite;
    suite_test_setup(&suite,"data/special_cases.md","RTMP3");
    suite.tests_torun_count = suite.tests_count;
    for(int i=0; i<suite.tests_count; i++){
      suite.tests_torun[i] = i;
    }
    suite.max_procs = 4;          // set # procs to use
    printf("CALLING FUNCTION\n");
    clock_gettime(CLOCK_REALTIME, &beg);
    ret = suite_run_tests_multiproc(&suite);
    clock_gettime(CLOCK_REALTIME, &end);
    printf("FUNCTION DONE\n");
    printf("ret: %d\n",ret);
    Dprintf("Elapsed time: %f\n",get_elapsed());             
    if(get_elapsed() < 1.0){
      printf("Elapsed time is in limit\n");
    }
    else{
      printf("Elapsed time is BEYOND LIMIT\n");
    }
    suite_test_print_all(&suite);
    suite_dealloc(&suite);
  } // ENDTEST

  IF_TEST("suite_run_tests_multiproc4") { 
    // Loads a suite that has some special cases but only runs the
    // even numbered tests concurrently. If the tests_to_run[] field
    // is not honored by suite_run_tests_multiproc(), this test will
    // fail.
    suite_t suite;
    suite_test_setup(&suite,"data/special_cases.md","RTMP4");
    suite.tests_torun_count = 0;
    for(int i=0; i<suite.tests_count; i+=2){
      suite.tests_torun[i/2] = i; // run even # tests only
      suite.tests_torun_count++;
    }
    suite.max_procs = 3;          // set # procs to use
    printf("CALLING FUNCTION\n");
    clock_gettime(CLOCK_REALTIME, &beg);
    ret = suite_run_tests_multiproc(&suite);
    clock_gettime(CLOCK_REALTIME, &end);
    printf("FUNCTION DONE\n");
    printf("ret: %d\n",ret);
    Dprintf("Elapsed time: %f\n",get_elapsed());             
    if(get_elapsed() < 1.0){
      printf("Elapsed time is in limit\n");
    }
    else{
      printf("Elapsed time is BEYOND LIMIT\n");
    }
    suite_test_print_all(&suite);
    suite_dealloc(&suite);
  } // ENDTEST

    // double elapsed = get_elapsed(&beg,&end);
    // char *msg = elapsed < 2.5 ? "in limit" : "BEYOND LIMIT";
    // printf("Elapsed time is: %s\n",msg);

  IF_TEST("suite_run_tests_multiproc5") { 
    // Run sleep tests which should complete within 3 seconds when run
    // concurrently on 4 processes.
    suite_t suite;
    suite_test_setup(&suite,"data/sleep_tests2.md","RTMP5");
    suite.tests_torun_count = 0;
    for(int i=0; i<suite.tests_count; i++){
      suite.tests_torun[i] = i;
      suite.tests_torun_count++;
    }
    suite.max_procs = 4;          // set # procs to use
    printf("CALLING FUNCTION\n");
    clock_gettime(CLOCK_REALTIME, &beg);
    ret = suite_run_tests_multiproc(&suite);
    clock_gettime(CLOCK_REALTIME, &end);
    printf("FUNCTION DONE\n");
    printf("ret: %d\n",ret);
    Dprintf("Elapsed time: %f\n",get_elapsed());             
    if(get_elapsed() < 3.5){
      printf("Elapsed time is in limit\n");
    }
    else{
      printf("Elapsed time is BEYOND LIMIT\n");
    }
    suite_test_print_all(&suite);
    suite_dealloc(&suite);
  } // ENDTEST
  
  IF_TEST("suite_run_tests_multiproc6") { 
    // Runs sleep tests that overlap such that when 3 processes are
    // used, all tests should complete in 3 seconds. The following is
    // the likely sequencing of the tests with Duration, Start, and
    // End times.
    //
    // | Test | Dur | Start | End |
    // |------+-----+-------+-----|
    // |    0 |   3 |     0 |   3 |
    // |    1 |   1 |     0 |   1 |
    // |    2 |   2 |     0 |   2 |
    // |    3 |   2 |     1 |   3 |
    // |    4 |   1 |     2 |   3 |
    suite_t suite;
    suite_test_setup(&suite,"data/sleep_tests3.md","RTMP6");
    suite.tests_torun_count = 0;
    for(int i=0; i<suite.tests_count; i++){
      suite.tests_torun[i] = i;
      suite.tests_torun_count++;
    }
    suite.max_procs = 3;          // set # procs to use
    printf("CALLING FUNCTION\n");
    clock_gettime(CLOCK_REALTIME, &beg);
    ret = suite_run_tests_multiproc(&suite);
    clock_gettime(CLOCK_REALTIME, &end);
    printf("FUNCTION DONE\n");
    printf("ret: %d\n",ret);
    Dprintf("Elapsed time: %f\n",get_elapsed());             
    if(get_elapsed() < 3.5){
      printf("Elapsed time is in limit\n");
    }
    else{
      printf("Elapsed time is BEYOND LIMIT\n");
    }
    suite_test_print_all(&suite);
    suite_dealloc(&suite);
  } // ENDTEST

  IF_TEST("suite_run_tests_multiproc7") { 
    // Runs a large number of sleep tests which should complete in 6
    // seconds or less when run concurrently on 6 processes.
    suite_t suite;
    suite_test_setup(&suite,"data/sleep_tests4.md","RTMP7");
    suite.tests_torun_count = 0;
    for(int i=0; i<suite.tests_count; i++){
      suite.tests_torun[i] = i;
      suite.tests_torun_count++;
    }
    suite.max_procs = 6;          // set # procs to use
    printf("CALLING FUNCTION\n");
    clock_gettime(CLOCK_REALTIME, &beg);
    ret = suite_run_tests_multiproc(&suite);
    clock_gettime(CLOCK_REALTIME, &end);
    printf("FUNCTION DONE\n");
    printf("ret: %d\n",ret);
    Dprintf("Elapsed time: %f\n",get_elapsed());             
    if(get_elapsed() < 6.5){
      printf("Elapsed time is in limit\n");
    }
    else{
      printf("Elapsed time is BEYOND LIMIT\n");
    }
    suite_test_print_all(&suite);
    suite_dealloc(&suite);
  } // ENDTEST

  IF_TEST("DUMMY") {
  } // ENDTEST



  ////////////////////////////////////////////////////////////////////////////////
  // END OF ALL TESTS

  if(nrun == 0){                // check that at least one test was run
    printf("No test named '%s' found\n",test_name);
    return 1;
  }
  return 0;
}
