#include "commando.h"
// macro to set up a test with given name, print the source of the
// test; very hacky, fragile, but useful
#define IF_TEST(TNAME) \
  if( RUNALL || strcmp( TNAME, test_name)==0 ) { \
    sprintf(sysbuf,"awk 'NR==(%d){P=1;gsub(\"^ *\",\"\");} P==1 && /ENDTEST/{P=0; print \"}\\n---OUTPUT---\"} P==1{print}' %s", __LINE__, __FILE__); \
    system(sysbuf); nrun++;  \
  } \
  if( RUNALL || strcmp( TNAME, test_name)==0 )

char sysbuf[1024];
int RUNALL = 0;
int nrun = 0;


////////////////////////////////////////////////////////////////////////////////

char *set_testdir(char *testdir){
  char sysbuf[MAX_LINE];
  sprintf(sysbuf,"rm -rf %s",testdir);
  system(sysbuf);
  return testdir;
}

// print a summary of a cmdctl struct
void cmdctl_summary(cmdctl_t *cmdctl){
  printf("cmdctl_t {\n");
  printf("  cmddir: %s\n", cmdctl->cmddir);
  printf("  cmds_count: %d\n", cmdctl->cmds_count);
  printf("  cmds_capacity: %d\n", cmdctl->cmds_capacity);
  printf("  cmds[] : %s\n", cmdctl->cmds==NULL ? "NULL" : "NON-NULL");
  printf("}\n");
}

////////////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <test_name>\n", argv[0]);
    return 1;
  }
  char *test_name = argv[1];
  char sysbuf[1024];
  if(strcmp(test_name,"ALL")==0){
    RUNALL = 1;
  }  

  system("mkdir -p test-results"); // ensure test-results directory 

  ////// PROBLEM 1 TESTS 16 / 15 ////////////////////////////////////////////////////

  IF_TEST("cmdctl_new_free_1") {
    // Allocate and free an cmdctl
    char *testdir = set_testdir("test-results/commando_dir");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_summary(cmdctl);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_new_free_2") {
    // Allocate and free a few cmdctl structs
    char *testdir = set_testdir("test-results/commando_dirA");
    cmdctl_t *cmdctl = cmdctl_new(testdir, 1+DEFAULT_CMDCAP);
    cmdctl_summary(cmdctl);
    cmdctl_free(cmdctl);
    testdir = set_testdir("test-results/commando_dirB");
    cmdctl = cmdctl_new(testdir, 10*DEFAULT_CMDCAP);
    cmdctl_summary(cmdctl);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_create_cmddir_1") {
    // Use cmdctl to create the output directory
    char *testdir = set_testdir("test-results/commando_dir");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    int ret = cmdctl_create_cmddir(cmdctl);
    printf("ret: %d\n",ret);
    cmdctl_free(cmdctl);
    system("ls -dF test-results/commando_dir");
  } // ENDTEST

  IF_TEST("cmdctl_create_cmddir_2") {
    // Use cmdctl to create the output directory; does so a second
    // time which will show a message about a duplicate directory
    char *testdir = set_testdir("test-results/testdirA");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    int ret = cmdctl_create_cmddir(cmdctl);
    printf("ret: %d\n",ret);
    cmdctl_free(cmdctl);
    system("ls -dF test-results/testdirA");
    cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    ret = cmdctl_create_cmddir(cmdctl);
    // generates a message about existing directory
    printf("ret: %d\n",ret);
    cmdctl_free(cmdctl);
    system("ls -dF test-results/testdirA");
  } // ENDTEST

  IF_TEST("cmdctl_create_cmddir_3") {
    // Directory creation will fail as text file with the required
    // name exists already and should not be over-written.
    char *testdir = set_testdir("test-results/cmddir_3");
    system("echo 'Dont clobber me!' > test-results/cmddir_3");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    int ret = cmdctl_create_cmddir(cmdctl);
    // fails as text file already exists with that name
    printf("ret: %d\n",ret);
    cmdctl_free(cmdctl);
    system("echo Contents of cmddir_3: && cat test-results/cmddir_3");
  } // ENDTEST

  IF_TEST("cmdctl_add_cmd_print_1") {
    // Add a single command to a cmdctl and print the oneline and full
    // info results. This test will evaluate the printing routines and
    // checks if the cmd is added correctly.
    char *testdir = set_testdir("test-results/testdirX");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    int ret = cmdctl_add_cmd(cmdctl, "ls data");
    printf("ret: %d\n",ret);
    printf("==SUMMARY of cmdctl==\n");
    cmdctl_summary(cmdctl);
    printf("==ONELINE OUTPUT of cmd==\n");
    cmdctl_print_oneline(cmdctl,0);
    printf("==FULL INFO OUTPUT of cmd==\n");
    cmdctl_print_info(cmdctl,0);
    if(cmdctl->cmds[0].argv[cmdctl->cmds[0].argc] != NULL){
      printf("Last element in argv[] is not NULL\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_add_cmd_print_2") {
    // Add a single slightly longer commmand with more tokens and
    // check that it prints out correctly.
    char *testdir = set_testdir("test-results/testdirX");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    int ret = cmdctl_add_cmd(cmdctl, "seq 10 20 500");
    printf("ret: %d\n",ret);
    printf("==SUMMARY of cmdctl==\n");
    cmdctl_summary(cmdctl);
    printf("==ONELINE OUTPUT of cmd==\n");
    cmdctl_print_oneline(cmdctl,0);
    printf("==FULL INFO OUTPUT of cmd==\n");
    cmdctl_print_info(cmdctl,0);
    if(cmdctl->cmds[0].argv[cmdctl->cmds[0].argc] != NULL){
      printf("Last element in argv[] is not NULL\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_add_cmd_print_3") {
    // Add several commands and print each of them in full. None of
    // the commands has been run yet so their state is all default.
    char *testdir = set_testdir("test-results/output_directory");
    cmdctl_t *cmdctl = cmdctl_new(testdir, 8);
    int ret;
    char *cmds[] = {
      "seq 10",
      "gcc -c x.c",
      "ls -l -d -F -1 *.c *.h *.o",
      "make -f /usr/lib/project/Makefile",
      "data/sleep_print.sh 2 'Hello world'",
      "/usr/bin/bash data/table.sh 10",
      NULL
    };
    for(int i=0; cmds[i]!=NULL; i++){
      printf("Adding '%s'\n",cmds[i]);
      ret = cmdctl_add_cmd(cmdctl, cmds[i]);
      printf("ret: %d\n",ret);
    }
    printf("==SUMMARY of cmdctl==\n");
    cmdctl_summary(cmdctl);
    for(int i=0; cmds[i]!=NULL; i++){
      printf("==ONELINE OUTPUT of cmds[%d]==\n",i);
      cmdctl_print_oneline(cmdctl,i);
      printf("==FULL INFO OUTPUT of cmd[%d]==\n",i);
      cmdctl_print_info(cmdctl,i);
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_add_expand_1") {
    // Starts the cmdctl with capacity 3 and adds 4 commands which
    // should trigger an expansion of the internal cmds[]
    // array. Prints the results. Then adds the same 4 commands which
    // should trigger another expansion of the internal array. The
    // return value of cmdctl_add_cmd() should be 1 when an expansion
    // occurs. 
    char *testdir = set_testdir("outputdir");
    cmdctl_t *cmdctl = cmdctl_new(testdir, 3);
    int ret;
    char *cmds[] = {
      "seq 10",
      "gcc -c x.c",
      "ls -l -d -F -1 *.c *.h *.o",
      "make -f /usr/lib/project/Makefile",
      NULL
    };
    printf("\n===FIRST ROUND OF ADDS ===\n");
    for(int i=0; cmds[i]!=NULL; i++){
      printf("Adding '%s'\n",cmds[i]);
      ret = cmdctl_add_cmd(cmdctl, cmds[i]);
      printf("ret: %d\n",ret);
    }
    printf("==SUMMARY of cmdctl==\n");
    cmdctl_summary(cmdctl);
    for(int i=0; cmds[i]!=NULL; i++){
      printf("==ONELINE OUTPUT of cmds[%d]==\n",i);
      cmdctl_print_oneline(cmdctl,i);
      printf("==FULL INFO OUTPUT of cmd[%d]==\n",i);
      cmdctl_print_info(cmdctl,i);
    }
    printf("\n===SECOND ROUND OF ADDS ===\n");
    for(int i=0; cmds[i]!=NULL; i++){
      printf("Adding '%s'\n",cmds[i]);
      ret = cmdctl_add_cmd(cmdctl, cmds[i]);
      printf("ret: %d\n",ret);
    }
    printf("==SUMMARY of cmdctl==\n");
    cmdctl_summary(cmdctl);
    for(int i=0; cmds[i]!=NULL; i++){
      printf("==ONELINE OUTPUT of cmds[%d]==\n",i);
      cmdctl_print_oneline(cmdctl,i);
      printf("==FULL INFO OUTPUT of cmd[%d]==\n",i);
      cmdctl_print_info(cmdctl,i);
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_print_all_info_1") {
    // Creates an array of jobs in different states and prints them to
    // ensure handling of the formatting required for printing
    // functions. Uses the cmdctl_print_all() function to print
    // one-line summaries of all commands. Also calls
    // cmdctl_print_info() on each command to show the verbose
    // information about it.
    cmd_t cmds[] = {
      {.cmdline="seq 5 5 50",
       .argv={"seq","5","50",NULL},
       .argc=3,
       .cmdstate=CMDSTATE_EXIT,
       .pid=1234,
       .exit_code=0,
       .input_filename="",
       .output_filename="cmdout/0000-seq.out",
       .output_bytes=326,
      },
      {.cmdline="gcc -c x.c",
       .argv={"gcc","-c","x.c",NULL},
       .argc=3,
       .cmdstate=CMDSTATE_EXIT,
       .pid=1235,
       .exit_code=1,
       .input_filename="",
       .output_filename="cmdout/0001-gcc.out",
       .output_bytes=73,
      },
      {.cmdline="buggyprog fileA.c",
       .argv={"buggyprog","fileA.c",NULL},
       .argc=2,
       .cmdstate=CMDSTATE_SIGNALLED,
       .pid=1238,
       .exit_code=-11,
       .input_filename="",
       .output_filename="cmdout/0002-buggyprog.out",
       .output_bytes=100,
      },
      {.cmdline="/usr/bin/noprog ABC DEF 123 456",
       .argv={"/usr/bin/noprog","ABC","DEF","123","456",NULL},
       .argc=5,
       .cmdstate=CMDSTATE_FAIL_EXEC,
       .pid=1240,
       .exit_code=CMDSTATE_FAIL_EXEC,
       .input_filename="",
       .output_filename="cmdout/0003-_usr_bin_noprog.out",
       .output_bytes=100,
      },
      {.cmdline="wc < input.txt",
       .argv={"wc",NULL},
       .argc=1,
       .cmdstate=CMDSTATE_FAIL_INPUT,
       .pid=1242,
       .exit_code=CMDSTATE_FAIL_INPUT,
       .input_filename="input.txt",
       .output_filename="cmdout/0004-wc.out",
       .output_bytes=73,
      },
      {.cmdline="exising_out",
       .argv={"exising_out",NULL},
       .argc=1,
       .cmdstate=CMDSTATE_FAIL_OUTPUT,
       .pid=1243,
       .exit_code=CMDSTATE_FAIL_OUTPUT,
       .input_filename="",
       .output_filename="cmdout/0005-existing_out.out",
       .output_bytes=80,
      },
      {.cmdline="longrun",
       .argv={"longrun",NULL},
       .argc=1,
       .cmdstate=CMDSTATE_RUNNING,
       .pid=1248,
       .exit_code=-1,
       .input_filename="",
       .output_filename="cmdout/0006-longrun.out",
       .output_bytes=0,
      },
    };
    ssize_t count = sizeof(cmds) / sizeof(cmd_t);
    cmdctl_t cmdctl = {
      .cmddir = "cmdout",
      .cmds_count = count,
      .cmds_capacity = count+2,
      .cmds = cmds
    };
    printf("==SUMMARY of cmdctl==\n");
    cmdctl_summary(&cmdctl);
    printf("==ONELINE TABLE of cmds[]\n");
    cmdctl_print_all(&cmdctl);
    for(int i=0; i<cmdctl.cmds_count; i++){
      printf("==FULL INFO OUTPUT of cmd[%d]==\n",i);
      cmdctl_print_info(&cmdctl,i);
    }
    // no free as the structs are stack-alloc'd
  } // ENDTEST


  IF_TEST("cmdctl_add_cmd_input_1") {
    // Adds a command with input redirection specified via the
    //    cmd < input 
    // syntax. The 2nd to last command line arg should be checked and
    // if it is "<" then the last command line arg should be treated
    // as an input file. The last two argv[] elements are removed and
    // argc is adjusted. 
    char *cmdstr = "wc < Makefile";
    char *testdir = set_testdir("test-results/testdirX");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    int ret = cmdctl_add_cmd(cmdctl, cmdstr);
    printf("ret: %d\n",ret);
    printf("==ONELINE OUTPUT of cmd==\n");
    cmdctl_print_oneline(cmdctl,0);
    printf("==FULL INFO OUTPUT of cmd==\n");
    cmdctl_print_info(cmdctl,0);
    if(cmdctl->cmds[0].argv[cmdctl->cmds[0].argc] != NULL){
      printf("Last element in argv[] is not NULL\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_add_cmd_input_2") {
    // Adds a command with input redirection specified. This command
    // has more command line args to check for proper detection of "<"
    // in the 2nd to last position on the command line.
    char *cmdstr = "cat -n < somefile.txt";
    char *testdir = set_testdir("test-results/testdirX");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    int ret = cmdctl_add_cmd(cmdctl, cmdstr);
    printf("ret: %d\n",ret);
    printf("==ONELINE OUTPUT of cmd==\n");
    cmdctl_print_oneline(cmdctl,0);
    printf("==FULL INFO OUTPUT of cmd==\n");
    cmdctl_print_info(cmdctl,0);
    if(cmdctl->cmds[0].argv[cmdctl->cmds[0].argc] != NULL){
      printf("Last element in argv[] is not NULL\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_add_cmd_input_3") {
    // Adds a command with input redirection specified. This command
    // has more command line args to check for proper detection of "<"
    // in the 2nd to last position on the command line.
    char *cmdstr = "awk -F , -f s.awk < thedata.dat";
    char *testdir = set_testdir("test-results/testdirX");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    int ret = cmdctl_add_cmd(cmdctl, cmdstr);
    printf("ret: %d\n",ret);
    printf("==ONELINE OUTPUT of cmd==\n");
    cmdctl_print_oneline(cmdctl,0);
    printf("==FULL INFO OUTPUT of cmd==\n");
    cmdctl_print_info(cmdctl,0);
    if(cmdctl->cmds[0].argv[cmdctl->cmds[0].argc] != NULL){
      printf("Last element in argv[] is not NULL\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_1a") {
    // Checks behavior of cmdctl_show_output(). The system() function
    // is used to create the output file in each case.
    char syscmd[MAX_LINE], *cmdstr;
    char *testdir = set_testdir("test-results/showout1a");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    // zeroeth command
    cmdstr = "seq 1 10";
    cmdctl_add_cmd(cmdctl, cmdstr);
    cmdctl->cmds[0].cmdstate = CMDSTATE_EXIT;
    sprintf(syscmd, "%s > %s", cmdstr, cmdctl->cmds[0].output_filename);
    system(syscmd);             // run command to produce output
    printf("==OUTPUT of cmd[0]==\n");
    cmdctl_show_output(cmdctl,0);
    // 1th command
    cmdstr = "seq -w -s ' ' 1 20";
    cmdctl_add_cmd(cmdctl, cmdstr);
    cmdctl->cmds[1].cmdstate = CMDSTATE_EXIT;
    sprintf(syscmd, "%s > %s", cmdstr, cmdctl->cmds[1].output_filename);
    system(syscmd);             // run command to produce output
    printf("==OUTPUT of cmd[1]==\n");
    cmdctl_show_output(cmdctl,1);
    // cleanup
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_1b") {
    // Checks that output for unfinished commands is not printed and a
    // messages indicated the command is still running shows instead.
    char syscmd[MAX_LINE], *cmdstr;
    char *testdir = set_testdir("test-results/showout1b");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    // zeroeth command - still running
    cmdstr = "seq 1 10";
    cmdctl_add_cmd(cmdctl, cmdstr);
    cmdctl->cmds[0].cmdstate = CMDSTATE_RUNNING;
    sprintf(syscmd, "%s > %s", cmdstr, cmdctl->cmds[0].output_filename);
    system(syscmd);             // run command to produce output
    printf("==OUTPUT of cmd[0]==\n");
    cmdctl_show_output(cmdctl,0);
    // 1th command - just initialized
    cmdstr = "seq -w -s ' ' 1 20";
    cmdctl_add_cmd(cmdctl, cmdstr);
    cmdctl->cmds[0].cmdstate = CMDSTATE_INIT;
    sprintf(syscmd, "%s > %s", cmdstr, cmdctl->cmds[0].output_filename);
    system(syscmd);             // run command to produce output
    printf("==OUTPUT of cmd[1]==\n");
    cmdctl_show_output(cmdctl,0);
    // cleanup
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_large") {
    // Checks behavior on larger output files that require iteration
    // of read() calls to fully process.
    char *cmds[] = {
      "seq 282",                // exactly 1020 chars
      "seq 283",                // exactly 1024 chars
      "seq 284",                // exactly 1028 chars
      "cat -n data/gettysburg.txt",
      "data/table.sh",
      "data/table.sh 1000",
      NULL
    };
    char syscmd[MAX_LINE];
    char *testdir = set_testdir("test-results/showout_large");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_add_cmd(cmdctl, cmds[i]);
      cmdctl->cmds[i].cmdstate = CMDSTATE_EXIT;
      sprintf(syscmd, "%s > %s", cmds[i], cmdctl->cmds[i].output_filename);
      system(syscmd);             // run command to produce output
      printf("\n==OUTPUT of cmd[%d]==\n",i);
      cmdctl_show_output(cmdctl,i);
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_large_A") {
    // Checks behavior on larger output files that require iteration
    // of read() calls to fully process.
    char *cmd = "seq 282";      // exactly 1020 chars
    char syscmd[MAX_LINE];
    char *testdir = set_testdir("test-results/showout_large_A");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    int i=0;
    cmdctl_add_cmd(cmdctl, cmd);
    cmdctl->cmds[i].cmdstate = CMDSTATE_EXIT;
    sprintf(syscmd, "%s > %s", cmd, cmdctl->cmds[i].output_filename);
    system(syscmd);             // run command to produce output
    printf("\n==OUTPUT of cmd[%d]==\n",i);
    cmdctl_show_output(cmdctl,i);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_large_B") {
    // Checks behavior on larger output files that require iteration
    // of read() calls to fully process.
    char *cmd = "seq 283";                // exactly 1024 chars
    char syscmd[MAX_LINE];
    char *testdir = set_testdir("test-results/showout_large_B");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    int i=0;
    cmdctl_add_cmd(cmdctl, cmd);
    cmdctl->cmds[i].cmdstate = CMDSTATE_EXIT;
    sprintf(syscmd, "%s > %s", cmd, cmdctl->cmds[i].output_filename);
    system(syscmd);             // run command to produce output
    printf("\n==OUTPUT of cmd[%d]==\n",i);
    cmdctl_show_output(cmdctl,i);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_large_C") {
    // Checks behavior on larger output files that require iteration
    // of read() calls to fully process.
    char *cmd = "seq 284";                // exactly 1028 chars
    char syscmd[MAX_LINE];
    char *testdir = set_testdir("test-results/showout_large_C");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    int i=0;
    cmdctl_add_cmd(cmdctl, cmd);
    cmdctl->cmds[i].cmdstate = CMDSTATE_EXIT;
    sprintf(syscmd, "%s > %s", cmd, cmdctl->cmds[i].output_filename);
    system(syscmd);             // run command to produce output
    printf("\n==OUTPUT of cmd[%d]==\n",i);
    cmdctl_show_output(cmdctl,i);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_large_D") {
    // Checks behavior on larger output files that require iteration
    // of read() calls to fully process.
    char *cmd = "cat -n data/gettysburg.txt";
    char syscmd[MAX_LINE];
    char *testdir = set_testdir("test-results/showout_large_D");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    int i=0;
    cmdctl_add_cmd(cmdctl, cmd);
    cmdctl->cmds[i].cmdstate = CMDSTATE_EXIT;
    sprintf(syscmd, "%s > %s", cmd, cmdctl->cmds[i].output_filename);
    system(syscmd);             // run command to produce output
    printf("\n==OUTPUT of cmd[%d]==\n",i);
    cmdctl_show_output(cmdctl,i);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_large_E") {
    // Checks behavior on larger output files that require iteration
    // of read() calls to fully process.
    char *cmd = "data/table.sh";
    char syscmd[MAX_LINE];
    char *testdir = set_testdir("test-results/showout_large_E");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    int i=0;
    cmdctl_add_cmd(cmdctl, cmd);
    cmdctl->cmds[i].cmdstate = CMDSTATE_EXIT;
    sprintf(syscmd, "%s > %s", cmd, cmdctl->cmds[i].output_filename);
    system(syscmd);             // run command to produce output
    printf("\n==OUTPUT of cmd[%d]==\n",i);
    cmdctl_show_output(cmdctl,i);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_show_output_large_F") {
    // Checks behavior on larger output files that require iteration
    // of read() calls to fully process.
    char *cmd = "data/table.sh 1000";
    char syscmd[MAX_LINE];
    char *testdir = set_testdir("test-results/showout_large_F");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    int i=0;
    cmdctl_add_cmd(cmdctl, cmd);
    cmdctl->cmds[i].cmdstate = CMDSTATE_EXIT;
    sprintf(syscmd, "%s > %s", cmd, cmdctl->cmds[i].output_filename);
    system(syscmd);             // run command to produce output
    printf("\n==OUTPUT of cmd[%d]==\n",i);
    cmdctl_show_output(cmdctl,i);
    cmdctl_free(cmdctl);
  } // ENDTEST

  ////// PROBLEM 2 TESTS 15 / 15 ////////////////////////////////////////////////////

  IF_TEST("cmdctl_start_cmd_1") {
    // Adds and starts a command and prints information on it. The
    // command is not updated so should show as RUNNING.
    char *cmdstr = "seq 10";
    char *testdir = set_testdir("test-results/startcmd1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    cmdctl_add_cmd(cmdctl,cmdstr);
    int ret = cmdctl_start_cmd(cmdctl, 0);
    printf("ret: %d\n",ret);
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("===PRINT INFO===\n");
    cmdctl_print_info(cmdctl, 0);
    printf("===SHOW OUTPUT===\n");
    cmdctl_show_output(cmdctl, 0);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_start_cmd_2") {
    // Adds and starts several commands and prints information on
    // them. The commands are not updated so should show as RUNNING.
    char *testdir = set_testdir("test-results/startcmd2");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    int ret;
    printf("\n##### 0th COMMAND ####\n");
    cmdctl_add_cmd(cmdctl,"seq 2 8 50");
    ret = cmdctl_start_cmd(cmdctl, 0);
    printf("ret: %d\n",ret);
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("===PRINT INFO===\n");
    cmdctl_print_info(cmdctl, 0);
    printf("===SHOW OUTPUT===\n");
    cmdctl_show_output(cmdctl, 0);
    printf("\n##### 1th COMMAND ####\n");
    cmdctl_add_cmd(cmdctl,"sleep 3");
    ret = cmdctl_start_cmd(cmdctl, 1);
    printf("ret: %d\n",ret);
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("===PRINT INFO===\n");
    cmdctl_print_info(cmdctl, 1);
    printf("===SHOW OUTPUT===\n");
    cmdctl_show_output(cmdctl, 1);
    printf("\n##### 2th COMMAND ####\n");
    cmdctl_add_cmd(cmdctl,"data/sleep_print.sh 5 Done");
    ret = cmdctl_start_cmd(cmdctl, 2);
    printf("ret: %d\n",ret);
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("===PRINT INFO===\n");
    cmdctl_print_info(cmdctl, 2);
    printf("===SHOW OUTPUT===\n");
    cmdctl_show_output(cmdctl, 2);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_start_update_1") {
    // Adds and starts a command and prints information on it. The
    // command is later updated with Blocking (finish=1) so the state
    // should change to EXIT and the output should be available.
    char *cmdstr = "seq 10";
    char *testdir = set_testdir("test-results/start_update1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    cmdctl_add_cmd(cmdctl,cmdstr);
    printf("\n#### STARTING COMMAND ####\n");
    int ret = cmdctl_start_cmd(cmdctl, 0);
    printf("ret: %d\n",ret);
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("===PRINT INFO===\n");
    cmdctl_print_info(cmdctl, 0);
    printf("===SHOW OUTPUT===\n");
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### UPDATE BLOCKING ####\n");
    ret = cmdctl_update_one(cmdctl, 0, 1);
    printf("ret: %d\n",ret);
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("===PRINT INFO===\n");
    cmdctl_print_info(cmdctl, 0);
    printf("===SHOW OUTPUT===\n");
    cmdctl_show_output(cmdctl, 0);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_start_update_2") {
    char *cmds[] = {
      "seq 2 8 50",
      "data/sleep_print.sh 0.25 Done now",
      "wc data/gettysburg.txt",
      "cat -n data/gettysburg.txt",
      NULL,
    };
    char *testdir = set_testdir("test-results/start_update2");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    printf("\n##### COMMAND ADD/START ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_add_cmd(cmdctl,cmds[i]);
      cmdctl_start_cmd(cmdctl, i);
    }
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND UPDATE FINISH=1 ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      int ret = cmdctl_update_one(cmdctl,i,1);
      printf("=== cmds[%d] ret: %d===\n",i,ret);
      cmdctl_print_all(cmdctl);
    }
    printf("\n##### COMMAND OUTPUT ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_print_info(cmdctl, i);
      cmdctl_show_output(cmdctl, i);
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_update_noblock_1") {
    // Adds and starts a command and prints information on it. The
    // command is later updated with Blocking (finish=1) so the state
    // should change to EXIT and the output should be available.
    char *cmdstr = "data/sleep_print.sh 0.25 Done now";
    char *testdir = set_testdir("test-results/update_noblock1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    cmdctl_add_cmd(cmdctl,cmdstr);
    printf("\n#### START/UPDATE FINISH=0 NONBLOCKING ####\n");
    cmdctl_start_cmd(cmdctl, 0);
    int ret = cmdctl_update_one(cmdctl, 0, 0);
    printf("ret: %d\n",ret);
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("===PRINT INFO===\n");
    cmdctl_print_info(cmdctl, 0);
    printf("===SHOW OUTPUT===\n");
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### UPDATE FINISH=1 BLOCKING ####\n");
    ret = cmdctl_update_one(cmdctl, 0, 1);
    printf("ret: %d\n",ret);
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("===PRINT INFO===\n");
    cmdctl_print_info(cmdctl, 0);
    printf("===SHOW OUTPUT===\n");
    cmdctl_show_output(cmdctl, 0);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_update_all_1") {
    // Checks that calling cmdctl_upate_all() with finish=1 blocks
    // until all command complete making their output available.
    char *cmds[] = {
      "seq 2 8 50",
      "data/sleep_print.sh 0.25 Done now",
      "wc data/gettysburg.txt",
      "data/self_signal.sh 15",
      NULL,
    };
    char *testdir = set_testdir("test-results/update_all1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    printf("\n##### COMMAND ADD/START ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_add_cmd(cmdctl,cmds[i]);
      cmdctl_start_cmd(cmdctl, i);
    }
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND UPDATE ALL FINISH=1 ####\n");
    cmdctl_update_all(cmdctl,1);
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND OUTPUT ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_print_info(cmdctl, i);
      cmdctl_show_output(cmdctl, i);
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_update_all_2") {
    // Checks that calling cmdctl_upate_all() with finish=0 does not
    // block and only the later call with finish=1 blocks. In the
    // interim, the state of the commands is listed as RUNNING.
    char *testdir = set_testdir("test-results/update_all2");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    char *cmds[] = {
      "sleep 1",
      "data/sleep_print.sh 0.25 Done now",
      "data/table.sh 10 0.35",
      NULL,
    };
    printf("\n##### COMMAND ADD/START ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_add_cmd(cmdctl,cmds[i]);
      cmdctl_start_cmd(cmdctl, i);
    }
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND UPDATE ALL FINISH=0 NOBLOCK ####\n");
    cmdctl_update_all(cmdctl,0);
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND UPDATE ALL FINISH=1 BLOCK ####\n");
    cmdctl_update_all(cmdctl,1);
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND OUTPUT ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_print_info(cmdctl, i);
      cmdctl_show_output(cmdctl, i);
      printf("\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_update_all_3") {
    // Checks that calling cmdctl_upate_all() with finish=0 does not
    // block and only the later call with finish=1 blocks. In the
    // interim, the state of the commands is listed as RUNNING. One
    // command is signalled before the first update so should given an
    // alert that it has completed abnormally. The other commands
    // finish on the second Blocking update.
    char *testdir = set_testdir("test-results/update_all3");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    char *cmds[] = {
      "data/sleep_print.sh 0.50 Finished",
      "data/sleep_print.sh 0.50 Done now",
      "data/table.sh 10 0.40",
      NULL,
    };
    printf("\n##### COMMAND ADD/START ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_add_cmd(cmdctl,cmds[i]);
      cmdctl_start_cmd(cmdctl, i);
    }
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND UPDATE ALL FINISH=0 NOBLOCK ####\n");
    cmdctl_update_all(cmdctl,0);
    cmdctl_print_all(cmdctl);
    printf("\n##### KILLING 1, COMMAND UPDATE ALL FINISH=0 NOBLOCK ####\n");
    kill(cmdctl->cmds[1].pid, SIGTERM);
    pause_for(0.25);
    cmdctl_update_all(cmdctl,0);
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND UPDATE ALL FINISH=1 BLOCK ####\n");
    cmdctl_update_all(cmdctl,1);
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND OUTPUT ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_print_info(cmdctl, i);
      cmdctl_show_output(cmdctl, i);
      printf("\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_start_input_1") {
    // Runs a command with
    char *cmdstr = "wc < data/gettysburg.txt";
    char *testdir = set_testdir("test-results/start_input1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    cmdctl_add_cmd(cmdctl,cmdstr);
    printf("\n#### COMMAND INFO BEFORE START ####\n");
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### STARTING COMMAND ####\n");
    int ret = cmdctl_start_cmd(cmdctl, 0);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### UPDATE FINISH=1 BLOCKING ####\n");
    ret = cmdctl_update_one(cmdctl, 0, 1);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_start_input_2") {
    // Adds and starts a command and prints information on it. The
    // command is later updated with Blocking (finish=1) so the state
    // should change to EXIT and the output should be available.
    char *cmdstr = "cat -n < data/gettysburg.txt";
    char *testdir = set_testdir("test-results/start_input2");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    cmdctl_add_cmd(cmdctl,cmdstr);
    printf("\n#### COMMAND INFO BEFORE START ####\n");
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### STARTING COMMAND ####\n");
    int ret = cmdctl_start_cmd(cmdctl, 0);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### UPDATE FINISH=1 BLOCKING ####\n");
    ret = cmdctl_update_one(cmdctl, 0, 1);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_fail_input_1") {
    // Set up a program with input redirection that fails as the file
    // for input is not present
    char *cmdstr = "cat -n < data/no-such-file.txt";
    char *testdir = set_testdir("test-results/fail_input1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    cmdctl_add_cmd(cmdctl,cmdstr);
    printf("\n#### COMMAND INFO BEFORE START ####\n");
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### STARTING COMMAND ####\n");
    int ret = cmdctl_start_cmd(cmdctl, 0);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### UPDATE FINISH=1 BLOCKING ####\n");
    ret = cmdctl_update_one(cmdctl, 0, 1);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_fail_output_1") {
    // Set up a program that will fail as the output file cannot be
    // written; a bit tricky as on GRACE this requires use of the
    // access control lists used for AFS permissions
    char *cmdstr = "seq 10 20";
    char *testdir = set_testdir("test-results/fail_output1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    cmdctl_add_cmd(cmdctl,cmdstr);
    // create an unwritable file in place of the output file
    char sysbuf[MAX_LINE];
    sprintf(sysbuf,"data/make_unwriteable.sh %s Dont tread on me",
            cmdctl->cmds[0].output_filename);
    system(sysbuf);
    printf("\n#### COMMAND INFO BEFORE START ####\n");
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### STARTING COMMAND ####\n");
    int ret = cmdctl_start_cmd(cmdctl, 0);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### UPDATE FINISH=1 BLOCKING ####\n");
    ret = cmdctl_update_one(cmdctl, 0, 1);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_fail_exec_1") {
    // Set up a child that will fail to exec() because the program is
    // not found. Checks to ensure that this important case is handled
    // properly.
    char *cmdstr = "./data/no-such-program";
    char *testdir = set_testdir("test-results/fail_exec1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    cmdctl_add_cmd(cmdctl,cmdstr);
    printf("\n#### COMMAND INFO BEFORE START ####\n");
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### STARTING COMMAND ####\n");
    int ret = cmdctl_start_cmd(cmdctl, 0);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    printf("\n#### UPDATE FINISH=1 BLOCKING ####\n");
    ret = cmdctl_update_one(cmdctl, 0, 1);
    printf("ret: %d\n",ret);
    cmdctl_print_all(cmdctl);
    cmdctl_print_info(cmdctl, 0);
    cmdctl_show_output(cmdctl, 0);
    cmdctl_free(cmdctl);
  } // ENDTEST

  IF_TEST("cmdctl_update_combo_1") {
    // Checks that calling cmdctl_upate_all() with finish=0 does not
    // block and only the later call with finish=1 blocks. In the
    // interim, the state of the commands is listed as RUNNING.
    char *cmds[] = {
      "data/sleep_print.sh 1.00 Last",
      "data/sleep_print.sh 0.25 Done now",
      "data/table.sh 10 0.35",
      NULL,
    };
    char *testdir = set_testdir("test-results/update_combo1");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    printf("\n##### COMMAND ADD/START ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_add_cmd(cmdctl,cmds[i]);
      cmdctl_start_cmd(cmdctl, i);
    }
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("\n##### UPDATE AFTER 0.5s PAUSE CMD 1,2 SHOULD FINISH ####\n");
    pause_for(0.5);
    cmdctl_update_all(cmdctl, 0); 
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND UPDATE ALL FINISH=1 BLOCK ####\n");
    cmdctl_update_all(cmdctl,1);
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND OUTPUT ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_print_info(cmdctl, i);
      cmdctl_show_output(cmdctl, i);
      printf("\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST


  IF_TEST("cmdctl_update_combo_2") {
    // Checks that calling cmdctl_upate_all() with finish=0 does not
    // block and only the later call with finish=1 blocks. In the
    // interim, the state of the commands is listed as RUNNING.
    char *cmds[] = {
      "data/sleep_print.sh 1.35 Last",
      "data/sleep_print.sh 0.25 First done",
      "data/table.sh 50 0.35",
      "data/table.sh  5 0.60",
      "data/sleep_print.sh 1.25 Later done",
      "data/sleep_print.sh 0.70 Middle done",
      "data/table.sh 15 0.80",
      NULL,
    };
    char *testdir = set_testdir("test-results/update_combo2");
    cmdctl_t *cmdctl = cmdctl_new(testdir, DEFAULT_CMDCAP);
    cmdctl_create_cmddir(cmdctl);
    printf("\n##### COMMAND ADD/START ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_add_cmd(cmdctl,cmds[i]);
      cmdctl_start_cmd(cmdctl, i);
    }
    printf("===PRINT ALL===\n");
    cmdctl_print_all(cmdctl);
    printf("\n##### UPDATE AFTER 0.5s PAUSE  ####\n");
    pause_for(0.5);
    cmdctl_update_all(cmdctl, 0); 
    cmdctl_print_all(cmdctl);
    printf("\n##### UPDATE AFTER 1.10s PAUSE ####\n");
    pause_for(0.6);
    cmdctl_update_all(cmdctl, 0); 
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND UPDATE ALL FINISH=1 BLOCK ####\n");
    cmdctl_update_all(cmdctl,1);
    cmdctl_print_all(cmdctl);
    printf("\n##### COMMAND OUTPUT ####\n");
    for(int i=0; cmds[i]!=NULL; i++){
      cmdctl_print_info(cmdctl, i);
      cmdctl_show_output(cmdctl, i);
      printf("\n");
    }
    cmdctl_free(cmdctl);
  } // ENDTEST


  ///////// END MATTER //////////////////////////////////////////////////////////

  if(nrun == 0){
    printf("No test named '%s' found\n",test_name);
    return 1;
  }
  else if(nrun > 1){
    printf("%d tests run\n",nrun);
  }

  return 0;
}
