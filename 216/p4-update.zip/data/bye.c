#include <stdio.h>
int main(){
  printf("See you, space cowboy\n");
  return 0;
}
