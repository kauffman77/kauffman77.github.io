#!/bin/bash
#
# usage: self_signal.sh <signum> [optional_sleep_first]

signum=$1

if [[ "$2" != "" ]]; then
    sleep $2
fi

printf "Sending self signal %d\n" "$1"

kill -n $signum $$ 
