!prefix=sleep1
!testdir=chester-test-sleep1

# sleepprint 1 Hello world A
Sleep 1 second then print

!program=bash data/sleepprint.sh 1 Hello world A

```output
Hello world A
```

# sleepprint 1 Hello world B
Sleep 1 second then print

!program=bash data/sleepprint.sh 1 Hello world B

```output
Hello world B
```

