!prefix=sleep2
!testdir=chester-test-sleep2

# sleepprint 1 Hello world A
Sleep then print

!program=bash data/sleepprint.sh 1 Hello world A

```output
Hello world A
```

# sleepprint 1 Hello world B
Sleep then print

!program=bash data/sleepprint.sh 1 Hello world B

```output
Hello world B
```

# sleepprint 2 Hello world C
Sleep then print

!program=bash data/sleepprint.sh 2 Hello world C

```output
Hello world C
```

# sleepprint 2 Hello world D
Sleep then print

!program=bash data/sleepprint.sh 2 Hello world D

```output
Hello world D
```

# sleepprint 2 Hello world E
Sleep then print

!program=bash data/sleepprint.sh 2 Hello world E

```output
Hello world E
```

# sleepprint 2 Hello world F
Sleep then print

!program=bash data/sleepprint.sh 2 Hello world F

```output
Hello world F
```

