#!/bin/bash
set -f                          # disable shell globbing

secs=$1
shift
sleep $secs

$*
