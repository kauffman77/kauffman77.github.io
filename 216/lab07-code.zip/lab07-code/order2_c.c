// order2_c.c: demonstrates C code with a function call to order2() in
// it. Translate the main() function to assembly in order2_asm.s.

#include <stdio.h>

void order2(int *a, int *b);

int main(){                     // main function to be translated to assembly
  int r=17, t=12;
  order2(&r, &t);

  printf("r t: %2d %2d\n",r,t);
  return 0;
}

// Ensures that the integers a,b are "sorted": a is the min, b is the
// max.  Changes the integers at these locations to accomplish this.
void order2(int *a, int *b){
  int tmp = 0;
  if(*a > *b){                  // bubble a up
    tmp = *a;
    *a = *b;
    *b = tmp;
  }
  return;
}

