// quote_main.c: debugging problem, calls a function in a binary file
// that requires use of GDB to navigate to find the correct number to
// put in input.txt.

#include <string.h>
#include <stdio.h>

// functions defined in quote_data.o with no source code available
int max_size();
char *get_it(int i);

char *correct = "C++ makes it harder, but when you do, it blows away your whole leg.";

int main(){
  printf("Complete this sentence by C++ creator Bjarne Stroustrup:\n");
  printf("  C makes it easy to shoot yourself in the foot; ...\n");
  printf("\n");
  printf("reading a number from 0 to %d from input.txt...\n",max_size());
  FILE *fin = fopen("input.txt","r");
  if(fin == NULL){
    printf("Couldn't open input.txt, bailing out.\n");
    return 1;
  }
  int index = -1;
  int res = fscanf(fin,"%d",&index);
  if(res != 1 || index < 0){
    printf("No, no: enter a POSITIVE NUMBER\n");
    return 1;
  }
  printf("You selected:\n");
  char *selected = get_it(index);
  printf("  %s\n",selected);
  int diff = strcmp(selected,correct);
  printf("\n");
  if(diff == 0){
    printf("CORRECT!\n");
    return 0;
  }
  else{
    printf("Have a nice tall glass of ... NOPE.\n");
    return 1;
  }
}

