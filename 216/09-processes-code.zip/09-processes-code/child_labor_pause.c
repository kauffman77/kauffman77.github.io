// child_labor_pause.c: like child_labor.c pauses for input right
// before and right after the fork() call to show that one process
// uses fork() and two processes return from it.
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char* argv[]){

  char *child_argv[] = {"./complain",NULL};             // argument array to child, must end with NULL 
  char *child_cmd = "complain";                         // actual command to run, must be on path

  printf("P: I'm %d, and I really don't feel like '%s'ing\n",
         getpid(),child_cmd);                           // use of getpid() to get current PID
  printf("P: I have a solution\n");

  printf("Press enter to continue and fork()\n");
  scanf("%*c");
  pid_t child_pid = fork();                             // clone a child
  printf("Press enter to continue after fork()\n");
  scanf("%*c");

  if(child_pid == 0){                                   // child will have a 0 here
    printf("C: I'm %d My pa '%d' wants me to '%s'. This sucks.\n",
           getpid(), getppid(), child_cmd);             // use of getpid() and getppid()

    execvp(child_cmd, child_argv);                      // replace running image with child_cmd

    printf("C: I don't feel like myself anymore...\n"); // unreachable statement
  }
  else{                                                 // parent will see nonzero in child_pid
    printf("P: Great, junior %d is taking care of that\n",
           child_pid);
  }
  return 0;
}
