// dumb_kid.c: commits several common programming fouls which result
// in abnormal exit.
//
// usage: ./dumb_kid <int>

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <int>\n",argv[0]);
    return 1;
  }
  int mistake = atoi(argv[1]);
  printf("Case %d:\n");
  if(mistake == 1){             // segmentation fault
    int *ptr = NULL;
    printf("Bro, just touch it, I dare you\n");
    printf("I think it'll hurt though...\n");
    printf("Bro, just DO IT! It won't hurt!\n");
    printf("Okay....\n");
    *ptr = 25;
    printf("See, Bro: peer pressure rocks!\n");
  }
  else if(mistake == 2){        // integer division by 0
    int top = 25;
    int bot = 0;
    printf("I've always wondered what %d / %d this is..\n",top,bot);
    int quot = top / bot;
    printf("And now I know: it's %d\n",quot);
  }
  else if(mistake == 3){        // explicit process kill
    printf("I was gonna die young...\n");
    raise(SIGKILL);
    printf("Now I gotta wait for you, honey...\n");
  }
  else {
    printf("That's more dumb things than I know how to do.\n");
  }
  return 0;
}
