// complain_segfault.c: like complain.c but triggers a segmentation
// fault which is a abnormal exit. This can be detected in the parent
// process.
#include <stdio.h>

int main(){
  printf("COMPLAIN: God this sucks. On a scale of 0 to 10 I hate pa ...\n");

  // These lines to generate a segmentaiton fault which is a
  // non-normal exit for a process
  int *p = NULL;
  *p = 5;
  return 13;
}
