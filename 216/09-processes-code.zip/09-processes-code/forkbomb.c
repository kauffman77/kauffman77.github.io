// BE CAREFUL WITH THIS PROGRAM
// 
// forkbomb.c: A standard "fork bomb" which starts spawning processes
// uncontrollably which is VERY hard on the system. This can quickly
// bring any operating system to its knees as all processes spawned
// attempt to consume as much CPU time as possible to spawn more
// processes which only makes the problem worse.  In most cases this
// will make EVERYONE on the system it runs quite mad so please ONLY
// RUN THIS ON PERSONAL MACHINES.
//
// In most cases after running PRESSING CTRL-C will kill the whole
// forkbomb tree and allow recovery. However, for maximum safety, run
// this program with the 'timeout' program which will kill the entire
// process tree after a short time.
// 
// > gcc -o forkbomb forkbomb.c
// > timeout 5s ./forkbomb
//
// After killing all forkbomb processes, it may take a few
// moments/minutes for the OS to recover from the pressure of
// launching thousands of useless processes
#include <stdio.h>
#include <unistd.h>
int main(void) {
  while(1){
    fork();
  }
  return 0;
}
