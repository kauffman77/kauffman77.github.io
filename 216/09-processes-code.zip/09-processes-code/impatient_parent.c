// impatient_parent.c: demonstrate non-blocking waitpid(), 

#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char* argv){
  char *child_argv[] = {"./complain",NULL};
  char *child_cmd = "complain";
  printf("PARENT: Junior is about to '%s', I'll keep an eye on him\n",
         child_cmd);
  pid_t child_pid = fork();

  // CHILD CODE
  if(child_pid == 0){
    printf("CHILD: I'm %d and I'm about to '%s'\n",
           getpid(), child_cmd);
    execvp(child_cmd, child_argv);
  }

  // PARENT CODE
  int status;
  int retcode;
  int count=0;
  while(1){
    count++;
    retcode = waitpid(child_pid, &status, WNOHANG);   // non-blocking wait     
    if(retcode == 0){                                     // 0 means child has not exited/changed status
      printf("Oh, junior's taking so long. Is he among the 50%% of people that are below average?\n");
    }
    else{
      break;
    }
  }
  printf("PARENT: Good job junior. I only checked on you %d times.\n",
         count);

  return 0;
}
  
