// child_labor.c: demonstrate the basics of fork/exec to launch a
// child process to do "labor"; e.g. run a another program via
// exec. Make sure that the the 'complain' program is compiled first.
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char* argv[]){

  char *child_argv[] = {"./complain",NULL};             // argument array to child, must end with NULL 
  char *child_cmd = "complain";                         // actual command to run, must be on path

  // char *child_argv[] = {"ls","-l","-ah",NULL};       // alternative argv/command swap commenting 
  // char *child_cmd = "ls";                            // with above to alter what child does

  // char *child_argv[] = {"seq","5","2","20",NULL};   // alternative
  // char *child_cmd = "seq";                            

  printf("P: I'm %d, and I really don't feel like '%s'ing\n",
         getpid(),child_cmd);                           // use of getpid() to get current PID
  printf("P: I have a solution\n");

  pid_t child_pid = fork();                             // clone a child

  if(child_pid == 0){                                   // child will have a 0 here
    printf("C: I'm %d My pa '%d' wants me to '%s'. This sucks.\n",
           getpid(), getppid(), child_cmd);             // use of getpid() and getppid()

    execvp(child_cmd, child_argv);                      // replace running image with child_cmd

    printf("C: I don't feel like myself anymore...\n"); // unreachable statement
  }
  else{                                                 // parent will see nonzero in child_pid
    printf("P: Great, junior %d is taking care of that\n",
           child_pid);
  }
  return 0;
}
