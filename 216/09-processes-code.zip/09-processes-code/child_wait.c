// child_wait.c: fork/exec plus parent waits for child to
// complete printing befor printing itself.
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char* argv){

  char *child_argv[] = {"./complain",NULL};          // alternative commands
  char *child_cmd = "complain";

  printf("P: I'm %d, and I really don't feel like '%s'ing\n",
         getpid(),child_cmd);
  printf("P: I have a solution\n");

  pid_t child_pid = fork();

  if(child_pid == 0){
    printf("C: I'm %d My pa '%d' wants me to '%s'. This sucks.\n",
           getpid(), getppid(), child_cmd);
    execvp(child_cmd, child_argv);
    printf("C: I don't feel like myself anymore...\n"); // unreachable
  }
  else{
    int status;
    wait(&status);                                      // wait for any child to finish, collect status
    // wait(NULL);                                      // wait for any child, ignore status
    // waitpid(child_pid, &status);                     // wait for specific child
    // waitpid(-1, NULL);                               // wait for any child, collect status
    printf("P: Great, junior %d is done with that '%s'ing\n",
           child_pid, child_cmd);
  }
  return 0;
}
  
