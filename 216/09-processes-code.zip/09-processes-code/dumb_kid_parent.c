// dumb_kid_parent.c: demonstrates a child that exits abnormally and
// how the parent can determine this from the signal it received using
// hte WIFSIGNALLED() and WTERMSIG() macros

#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

// Table of some common signal numbers and rough descriptions of their
// purpose
char *signal_descriptions[] = {
  "",
  " 1 : <SIGHUP> : controlling terminal has closed",
  " 2 : <SIGINT> : interrupted through user interaction",
  " 3 : <SIGQUIT> : user-triggered quit with core dump requested",
  " 4 : <SIGILL> : invalid or illegal instruction executed",
  " 5 : <SIGTRAP> : debugger enabled?",
  " 6 : <SIGABRT> : process self-terminated abnormally through the abort() function",
  " 7 : <SIGBUS> : BUS ERROR while attempting to access a memory address that is ill-formatted",
  " 8 : <SIGFPE> : arithmetic error, usually INTEGER DIVISION BY 0",
  " 9 : <SIGKILL> : killed by explicit request, usually initiated by user possibly due to timeouts / excessive output",
  "10 : <SIGUSR1> : user-defined signal",
  "11 : <SIGSEGV> : SEGMENTATION FAULT, memory problem such as out-of-bounds access",
  "12 : <SIGUSR2> : user-defined signal",
  "13 : <SIGPIPE> : communication through a pipe that was cut off",
  "14 : <SIGALRM> : alarm expired in program",
  "15 : <SIGTERM> : termination explicitly requested, usually initiated by user",
  NULL
};

int main(int argc, char* argv[]){
  char *kidnum = "1";
  if(argc > 1){
    kidnum = argv[1];
  }

  char *child_argv[] = {"./dumb_kid",kidnum,NULL};
  char *child_cmd = "dumb_kid";

  printf("P: What the world needs is more dumb processes so...\n");
  pid_t child_pid = fork();

  // CHILD CODE
  if(child_pid == 0){
    printf("C: becoming '%s %s'\n",child_argv[0],child_argv[1]);
    execvp(child_cmd, child_argv);
  }

  // PARENT CODE
  int status;
  wait(&status);                // wait for child to finish, collect status
  if(WIFEXITED(status)){        // check for normal exit
    int exit_code = WEXITSTATUS(status);                 // decode status to 0-255
    printf("P: Huh, maybe the kid wasn't so dumb after all (exit_code: %d)\n",
           exit_code);
  }
  else if(WIFSIGNALED(status)){
    int signum = WTERMSIG(status);
    printf("P: Yep, the kid did something dumb, got signal %d\n",signum);
    printf("P: That's %s\n",signal_descriptions[signum]);
    printf("P: Dumbass...\n");
  }
  else{
    printf("P: Something really strange happened... \n");
  }

  return 0;
}
  
