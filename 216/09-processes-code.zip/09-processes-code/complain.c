// complain.c Simple program that can be run with the the child-labor
// or child-wait programs. Returns a nonzero exti code.

#include <stdio.h>

int main(){
  printf("COMPLAIN: God this sucks. On a scale of 0 to 10 I hate pa ...\n");
  int *p = NULL;
  *p = 100;
  return 0;
}
