# re_essentials.py: demo several essential python Regex functions

import re

text="""Pellentesque dapibus 7592 suscipit ligula.  Donec
25.6 posuere augue in quam 1.1507?"""

print( re.findall(r"\d+",text) )
# ['7592', '25', '6', '1', '1507']

print( re.split(r"\d+",text) )
# ['Pellentesque dapibus ', ' suscipit ligula.  Donec\n', '.', ' posuere augue in quam ', '.', '?']

print( re.findall(r"\b\w+\b",text) )
# ['Pellentesque', 'dapibus', '7592', 'suscipit', 'ligula', 'Donec', '25', '6', 'posuere', 'augue', 'in', 'quam', '1', '1507']

print( re.split(r"\s+",text) )
# ['Pellentesque', 'dapibus', '7592', 'suscipit', 'ligula.', 'Donec', '25.6', 'posuere', 'augue', 'in', 'quam', '1.1507?']

m = re.search(r"\d+",text)
print(m)
# <re.Match object; span=(21, 25), match='7592'>

print(m.group())
# 7592

print(m[0])
# 7592

print(m.span())
# (21, 25)

it = re.finditer(r"\d+",text)
print(it)
# <callable_iterator object at 0x7faa84fbfa30>

for m in it:
  print(f"found: '{m[0]}' at {m.span()}")
# found: '7592' at (21, 25)
# found: '25' at (50, 52)
# found: '6' at (53, 54)
# found: '1' at (77, 78)
# found: '1507' at (79, 83)

