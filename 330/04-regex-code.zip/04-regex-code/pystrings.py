# pystrings.py: show several forms of writing strings
def show_strings():
  # double and single-quoted strings
  dq_string = "This \"is\"\na string"
  sq_string = 'This "is"\na string'
  
  # triple-quoted strings allow embedded
  # newlines
  d3_string = """This \"is\"
a string"""
  s3_string = '''This "is"
a string'''
  
  # format strings
  fm_string = f'This "is"\na string'
  
  # raw strings suspend "special"
  # sequences like \n
  ra_string = r'This "is"\na string'

  # abusing python's dynamic capabilities
  # to print all local vars and values
  for k,v in locals().items():
    print(f"{k}:\n{v}\n")

show_strings()

# shell>> python pystrings.py 
# dq_string:
# This "is"
# a string

# sq_string:
# This "is"
# a string

# d3_string:
# This "is"
# a string

# s3_string:
# This "is"
# a string

# fm_string:
# This "is"
# a string

# ra_string:
# This "is"\na string
