# re_guessing_game.py: Show matches for a variety of regular
# expressions from a text source. Running and examining this file will
# help to build an understanding of the basic capabilities regexs
# provide.

import re

text="""Pellentesque dapibus 7592 suscipit ligula.  Donec
25.6 posuere augue in quam 1.1507?  Etiam vel
tortor sodales tellus ultricies 59 commodo.
Suspendisse 2538.4 potenti.  Aenean 0.0012 in sem
ac 2 46.8 leo mollis blandit!
"""
def show_result(regexp):
  result=re.findall(regexp,text)
  print(f"REGEXP: {regexp:20} RESULT: {result}")

print("\n* ROUND 1: Fixed Strings, Char Ranges, One-or-more")
print(f"text:\n{text}")
show_result(r"59")
show_result(r"5[0-9]")
show_result(r"[0-9]")
show_result(r"[0-9]+")
show_result(r"[a-z]+")
show_result(r"[A-Za-z]+")

print("\n* ROUND 2: Abbreviations, Boundaries, Spaces, Anychar")
print(f"text:\n{text}")
show_result(r"\d+")
show_result(r"\w+")
show_result(r" \w+us")
show_result(r"\b\w+us")
show_result(r".")
show_result(r" ...")
show_result(r"\s...")
show_result(r"\b...")
show_result(r"\d+\.\d+")

print("\n* ROUND 3: Alternation, Fixed Ranges")
print(f"text:\n{text}")
show_result(r"us|la")
show_result(r"\d+|\w+")
show_result(r"\d{3}")
show_result(r"\d{2,3}")
show_result(r"\d{1,2}\.\d{1,2}")
show_result(r"\d+|\d+\.\d+")

# # slightly awkward regex to match integer OR floating point value
# show_result(r"\d+(?:\.\d+)?")

print("\n* ROUND 4: One-or-more, Zero-or-more")
print(f"text:\n{text}")
show_result(r"\w+ \d+")
show_result(r"\w+ \d{1,}")
show_result(r"\w+ \d\d*")
show_result(r"\w+ \d*")

print("\n* ROUND 5: Beginning and Ending")
print(f"text:\n{text}")
show_result(r"^\w")
show_result(r"^\w+")
show_result(r".$")
show_result(r"\w+.$")

# print("\n* ROUND 6: Grouping")
# print(f"text:\n{text}")
# show_result(r"")
# show_result(r"^\w+")
# show_result(r".$")
# show_result(r"\w+.$")
