# re_search.py: demonstrate the re.search() function which finds the
# first occurrence of a regex and returns a Match object. If no match
# is found, the special value None is returned.
import re

# string to search
text="""Pellentesque dapibus 7592 suscipit ligula.  Donec
25.6 posuere augue in quam 1.1507?"""

m = re.search("\d+",text)       # search for digits
if m != None:                   # if not None ...
  print(f"Found match: {m[0]}")
else:
  print("No match present")

m = re.search("\w+pi\w+",text)  # word with 'pi' in the middle
if m:                           # Match objects are truthy
  print(f"Found match: {m[0]}") # while None is falsey
else:
  print("No match present")

m = re.search("\w+ily",text)    # word ends in 'ily' which
if m:                           # is not present so None
  print(f"Found match: {m[0]}") # triggers the alternative
else:                           # else to execute
  print("No match present")

