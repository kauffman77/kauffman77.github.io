# re_substitution.py: Demonstrates regex groups and their use
# in flexible substitutions.

import re

text="""In Chapter 3 Section 5 we will discuss the merits of dynamically
typed languages. That Section should be studied as later
in Chapter 4 Section 1 we will cover static type systems with the
following Chapter 4 Section 2 providing a summary of the trade-offs
between static and dynamic. Chapter 5 Section 12 begins discusion of
logic programming..."""

print(f"text:\n{text}")

hits = re.findall(r"Chapter \d+ Section \d+ ", text)
print(f"hits: {hits}")
# hits: ['Chapter 3 Section 5', 'Chapter 4 Section 2', 'Chapter 5 Section 12']

print("\nre.findall() groups")
hits_w_groups = re.findall(r"Chapter (\d+) Section (\d+)", text)
print(f"hits_w_groups: {hits_w_groups}")
# hits_w_groups: [('3', '5'), ('4', '2'), ('5', '12')]

print("\nre.finditer()")
hits_iter = re.finditer(r"Chapter (\d+) Section (\d+)", text)
for m in hits_iter:
  print(f"m[0]: {m[0]} \t m[1]: {m[1]} \t m[2]: {m[2]}")
# m[0]: Chapter 3 Section 5 	 m[1]: 3 	 m[2]: 5
# m[0]: Chapter 4 Section 2 	 m[1]: 4 	 m[2]: 2
# m[0]: Chapter 5 Section 12 	 m[1]: 5 	 m[2]: 12


print("\nre.sub()")
sub_text = re.sub(r"Chapter (\d+) Section (\d+)",
                  r"Chapter \1.\2", text)
print(f"sub_text:\n{sub_text}")
# sub_text:
# In Chapter 3.5 we will discuss the merits of dynamically typed
# languages. That Section should be studied as later in Chapter 4
# Section 1 we will cover static type systems with Chapter 4.2
# providing a summary of the trade-offs between static and
# dynamic. Chapter 5.12 begins discusion of logic programming...


print("\nre.sub() limit 3")
sub_text3 = re.sub(r"Chapter (\d+) Section (\d+)",
                   r"Chapter \1.\2", text, 2)
print(f"sub_text3:\n{sub_text3}")
# sub_text3:
# In Chapter 3.5 we will discuss the merits of dynamically
# typed languages. That Section should be studied as later
# in Chapter 4.1 we will cover static type systems with the
# following Chapter 4 Section 2 providing a summary of the trade-offs
# between static and dynamic. Chapter 5 Section 12 begins discusion of
# logic programming...
