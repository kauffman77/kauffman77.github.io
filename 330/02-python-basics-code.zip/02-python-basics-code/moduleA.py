# moduleA.py moduleB.py moduleC.py: Demonstrates automatic module
# conventions based on filenames and need to import modules to
# reference their contents. Demos as well the convention of housing
# "main" operations as a funciton called main() that is checked via
# the special module name variable __name__ as in
# 
#  if __name__ = '__main__':
#
# Run each file as a script and study the control flow.
# 
# >> python moduleA.py
# moduleA executable code found; running moduleA.main()
# In moduleA.main() with __name__ __main__
# ...
# 
# >> python moduleB.py
# ...
# >> python moduleC.py
# ...

import moduleB

def afunc():
  print("In moduleA.afunc() with __name__",__name__)

def main():
  print("In moduleA.main() with __name__",__name__)
  print("Calling afunc()")
  afunc()
  print("Calling moduleB.bfunc()")
  moduleB.bfunc()

if __name__ == '__main__':
  print("moduleA executable code found; running moduleA.main()")
  main()  
