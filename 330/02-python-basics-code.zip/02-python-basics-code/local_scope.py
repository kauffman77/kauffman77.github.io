

avar = 1

def outer_func(outer_arg):
  avar = 5
  
