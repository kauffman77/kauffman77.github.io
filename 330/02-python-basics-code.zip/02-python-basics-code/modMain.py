# modMain.py modLoud.py modSleepy.py: Demostrate that the 'import'
# statement in Python runs code at the top level. This is why Python
# modules typically define a series of functions and little to no
# executable code at the module scope.
#
# >> python modMain.py
# This is why
# I don't leave the house
# You say the coast is clear
# But you won't catch me out
# But I am le tired
# Then, have a nap
# (3 second delay)
# Now fire!
# running modMain.main()
# in modMain.main()

import modLoud                  # produces output
import modSleepy                # creates a delay

def main():
  print("in modMain.main()")

if __name__ == '__main__':
  print("running modMain.main()")
  main()  
