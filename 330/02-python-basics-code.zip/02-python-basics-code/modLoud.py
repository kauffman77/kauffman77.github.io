
print("This is why")
print("I don't leave the house")
print("You say the coast is clear")
print("But you won't catch me out")

def lyrics():
  # maybe something belongs here
  return ""
