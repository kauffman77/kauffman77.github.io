import time

print("But I am le tired")
print("Then, have a nap")
time.sleep(3)
print("Now fire!")
