# see moduleA.py
import moduleA

if __name__ == '__main__':
  print("moduleC executable code found; jump to moduleA.main()")
  moduleA.main()

