# oo_demo.py: demo of classes in python
class MyClass:
    """A simple example class"""
    i = 12345                   # a field

    def __init__(self,first_i):
        self.i = first_i

    def f(self):
        return 'hello world'
