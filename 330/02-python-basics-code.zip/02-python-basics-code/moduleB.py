# see moduleA.py

def bfunc():
  print("In moduleB.bfunc() with __name__",__name__)

def unused():
  print("Somebody please call me!")
