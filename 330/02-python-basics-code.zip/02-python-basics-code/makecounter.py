# A typical implementation of creating counters in python via a Class
# and methods for the class.
class Counter:
  curval = 0
  def __init__(self,initial):
    self.curval = initial
  def inc(self):
    self.curval += 1
    return self.curval

counterO = Counter(0)
print(counterO.inc())
print(counterO.inc())
print(counterO.inc())
print(counterO.curval)
  
counterO2 = Counter(10)
print(counterO2.inc())
print(counterO2.inc())
  
print()

# Below code does not work in Python and will cause a runtime
# error. It will work in languages that support lexical closures like
# OCaml and Racket; lexical closures and objects both involve the
# coupling of a stateful environment (variables) and code that
# modifies it (functions)
def makecounter(initial):
  curval = initial
  def inc():
    curval += 1                 # curval "escapes" the environment because
    return curval               # it is local to makecounter() but used in
  return inc                    # inc() which is returned as a function

counterF = makecounter(0)       # 
print("counterF created:",counterF)
print("calling counterF():")
print(counterF())
