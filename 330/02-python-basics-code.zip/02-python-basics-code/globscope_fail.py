# globscope_fail.py: demonstrates slight wonkiness in scoping for
# python: module-level (global) variables can be referenced in
# functions, but attempts the change them fail without the "global"
# keyword.

theglob = 1                     # global variable

def print_theglob():            # print it
  print("theglob:",theglob)     

def inc_theglob():              # increment it (??)
  # global theglob                # uncomment to fix
  theglob += 1

print_theglob()                 # print
inc_theglob()                   # increment
print_theglob()                 # print

# shell>> python globscope_fail.py 
# theglob: 1
# Traceback (most recent call last):
#   File "globscope_fail.py", line 16, in <module>
#     inc_theglob()                   # increment
#     ^^^^^^^^^^^^^
#   File "globscope_fail.py", line 13, in inc_theglob
#     theglob += 1
#     ^^^^^^^
# UnboundLocalError: cannot access local variable 'theglob'
# where it is not associated with a value
