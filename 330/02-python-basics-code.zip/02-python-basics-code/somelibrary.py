# somelibrary.py: provides a function to call which happens to compute
# the Fibonacci numbers using list conveniences; used in demoing
# import statement sytnax

def fibiter(n):
  series = [0,1]
  for i in range(2,n+1):
    series.append(series[-1]+series[-2])
  return series[n]

