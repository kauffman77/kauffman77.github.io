1+2                      # expressions output in the REPL
"hello" + " world"       # but not in scripts

x=1+2                    # assignment has no output
s="hello" + " world"     # in the REPL or as scripts

print(x)                 # print() producees output in
print(s)                 # REPL and in scripts
