# collatz.py: an introductory Python example demonstrating a variety
# of its features. Run this as a script via
#
# >> python collatz.py 
# Collatz start val:
# 10
#   0:    10
#   1:     5
#   2:    16
#   3:     8
#   4:     4
#   5:     2
#   6:     1
# Converged to 1 after 6 iterations

# a global variable 
verbose = True

# a function definition taking a couple parameters
def collatz(start,maxsteps):
  cur = start
  step = 0
  if verbose:
    print("start:",start,"maxsteps:",maxsteps)
    print("Step  Current")
    print(f"{step:3}: {cur:5}")
  while cur != 1 and step < maxsteps:
    step += 1
    if cur % 2 == 0:
      cur = cur // 2            # // for integer division
    else:
      cur = cur*3 + 1
    if verbose:
      print(f"{step:3}: {cur:5}")
  return (cur,step)

# executable code at the global scope which prompts for input, calls
# the above function, captures its output, and prints output
start_str = input("Collatz start val:\n")
start = int(start_str)

(final,steps) = collatz(start, 500)
print(f"Reached {final} after {steps} iters")
