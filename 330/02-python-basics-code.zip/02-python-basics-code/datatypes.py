# datatypes.py: basic data types present in python with special syntax
# support

####################
# BASIC TYPES
anint = 5                       # integer
afloat = 123.45                 # float
astr1 = "heya"                  # string
astr2 = 'oiya'                  # string
abool = True                    # boolean


####################
# LISTS: indexed, mutable collections
alist1 = ["a","b","c","c"]      # list e.g. Arraylist
alist2 = [4, "five", 6.7]       # dynamic typing

# numerically indexed
print(alist1[0])                # 'a'
print(alist1[2])                # 'c'
print(alist2[-1])               # 6.7, handy!

alist2[0]=3                     # mutable
# alist2 = [3, "five", 6.7]     
alist1.append("d")              # extendable
# alist1=["a","b","c","c","d"]

for item in alist1:             # iterate
  print(item)

####################
# TUPLES: indexed, immutable collections
atup1 = (1,2,3)                 # a tuple
atup2 = (4,"five",6.7)          

# numerically indexed
print(atup2[0])                 # 4

# atup2[0] = 7                    # ERROR: immutable

(x,y,z) = (1,"hi",True)         # destructure bind
# x = 1
# y = "hi"
# z = True
x,y,z = 1,"hi",True             # parens optional

####################
# DICTIONARY: key-value mappings
amap1 = {"a":1, "b":2}          # dictionary
amap2 = {3:"c", 6.7:True}       # e.g. hashmap

print(amap1["b"])               # lookup: 2
amap1["c"] = 3                  # new key/val

del amap2[3]                    # delete key
# amap2 = {6.7:True}
amap2.pop(6.7)                  # delete key
# amap2 = {}
amap2.pop(9.9,None)             # delete key safely

if "a" in amap1:                # check for a key
  print("a is present")

for key in amap1:               # iterate over keys
  print(key,amap1[key])

for key,val in amap1.items():   # iterate over key/vals
  print(key,val)


####################
# SET: unsorted unique items
aset1 = {"a","b","c"}           # set, e.g. hashset

aset1.add("d")                  # add on
# aset1 = {"a","b","c","d"}
aset1.add("b")                  # duplicate element
# aset1 = {"a","b","c","d"}

if "b" in aset1:                # set membership
  print("b is present")

for item in aset1:              # iteration on set
  print(item)

