# oo_collatz.py: A simple class demoing the OO features of python;
# encodes a class to calculate a Collatz sequence

class Collatz:
  """Allows computation of a collatz sequence"""
  
  # optionally intialize fields of class here like...
  # steps = 0
  # start = -1
  # ...

  
  def __init__(self,start):
    """constructor for the class"""
    self.steps = 0
    self.start = start
    self.cur = start
    self.history = [start]

  
  def step(self):
    """method to take one step on the sequence"""
    if self.cur==1:
      return
    self.steps += 1
    if self.cur % 2 == 0:
      self.cur = self.cur // 2
    else:
      self.cur = self.cur*3 + 1
    self.history.append(self.cur)

  def __str__(self):
    """'special' toString() method for printing"""
    return f"start: {self.start} steps: {self.steps} cur: {self.cur}"

  
  def report(self):
    """print out whole history of sequence"""
    print("Step  Current")
    for i in range(len(self.history)):
      print(f"{i:3}: {self.history[i]:5}")

  def converge(self):
    """iterate to convergence"""
    while self.cur != 1:
      self.step()

def main():
  """main entry point when run as a script"""
  c = Collatz(5)
  print(c)
  c.step()
  print(c)
  c.converge()
  c.report()

if __name__ == '__main__':
  main()  
      
