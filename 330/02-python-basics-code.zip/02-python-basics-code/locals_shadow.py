# locals_shadow.py: demonstrate that like most PLs, python local
# variables "shadow" varialbes at outer scopes so they override
# module-level variables BUT the locals are distrinct from the globals
# and do not affect them

avar = 1

def afunc():
  avar = 5
  print("avar local:",avar)
  avar += 1
  print("avar local:",avar)

afunc()
print("avar global:",avar)

# shell>> python locals_shadow.py 
# avar local: 5
# avar local: 6
# avar global: 1
