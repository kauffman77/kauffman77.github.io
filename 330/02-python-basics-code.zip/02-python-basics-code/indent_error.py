# indent_error.py: demonstrate an indentation error for the 2nd if
# statement. This code won't run until the indentation is
# corrected. One way to catch this early is to use the pylint utility
# to check for such errors via
#
# shell>> pylint indent_error.py
#
# which will report fishy syntax it finds

# proper indent
if 5 > 2:
  print("5 is bigger")
  print("that is all")
else:
  print("something is amiss")

# indentation error
if 6 > 2:
  print("6 is bigger")
    print("all is well")
else:
  print("how strange")
