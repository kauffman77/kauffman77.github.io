# globscope_success.py: see

theglob = 1                     # global variable

def print_theglob():            # print it
  print("theglob:",theglob)     

def inc_theglob():              # increment it (!!)
  global theglob
  theglob += 1

print_theglob()                 # print
inc_theglob()                   # increment
print_theglob()                 # print
