(* higher_order.ml: demonstrate higher-order functions on lists,
   arrays, and other stuff *)

open Printf;;

(**********************************************************************************)
(* Uses of filter to create new lists *)

let ilist = [9; 5; 2; 6; 5; 1;];;
let silist = [("a",2); ("b",9); ("d",7)];;
let ref_list = [ref 1.5; ref 3.6; ref 2.4;  ref 7.1];;

let even_ints =
  List.filter (fun i-> i mod 2 = 0) ilist;;

let above_4_list =
  List.filter (fun i-> i > 4) ilist;;

let above_4p_list =
  List.filter (fun (s,i) -> i>4 ) silist;;

let bfirst_list =
  List.filter (fun (s,i)-> s="b") silist;;

let ref_above3_list =
  List.filter (fun r-> !r > 3.0) ref_list;;

(**********************************************************************************)
(* Uses of iter to perform side-effectson each element *)

let ilist = [9; 5; 2; 6; 5; 1;];;
let silist = [("a",2); ("b",9); ("d",7)];;
let ref_list = [ref 1.5; ref 3.6; ref 2.4;  ref 7.1];;

(* Print all elems of an int list *)
List.iter (fun i->printf "%d\n" i) ilist;;

(* Print all string,int pairs *)
List.iter (fun (s,i)->printf "str: %s  int: %d\n" s i) silist;;

(* Double the float referred to by each element *)
List.iter (fun r-> r := !r *. 2.0) ref_list;;

(* Print all floats referred to *)
List.iter (fun r-> printf "%f\n" !r) ref_list;;

(* Sample definition for iter: tail recursive *)
let rec iter thunk list =
  match list with
  | []         -> ()
  | head::tail -> thunk head;
                  iter thunk tail
;;

(**********************************************************************************)
(* Uses of map to create new lists *)

let ilist = [9; 5; 2; 6; 5; 1;];;
let silist = [("a",2); ("b",9); ("d",7)];;
let ref_list = [ref 1.5; ref 3.6; ref 2.4;  ref 7.1];;

(* Create a list of doubled ints *)
let doubled_list =
  List.map (fun n-> 2*n) ilist;;

(* Convert each int to a stringy version *)
let as_strings_list =
  List.map string_of_int ilist;;

(* Swap pair elements in result list *)
let swapped_list =
  List.map (fun (s,i) -> (i,s)) silist;;

(* Extract only the first element of pairs in result list *)
let firstonly_list =
  List.map fst silist;;

(* Dereference all elements in the result list *)
let derefed_list =
  List.map (!) ref_list;;

(* Form pairs of original value and its square *)
let with_square_list =
  List.map (fun r-> (!r, !r *. !r)) ref_list;;

(* Sample implementation of map: not tail recursive *)
let rec map trans list =
  match list with
  | []         -> []
  | head::tail -> (trans head)::(map trans tail)
;;

(**********************************************************************************)
(* Uses of fold to compute a single value (reduction) from all elements of a list *)

let ilist = [9; 5; 2; 6; 5; 1;];;
let silist = [("a",2); ("b",9); ("d",7)];;
let ref_list = [ref 1.5; ref 3.6; ref 2.4;  ref 7.1];;

(* sum ints in the list *)
let sum_oflist =
  List.fold_left (+) 0 ilist;;

(* sum squares in the list *)
let sumsquares_oflist =
  List.fold_left (fun sum n-> sum + n*n) 0 ilist;;

(* concatenate all string in first elem of pairs *)
let firststrings_oflist =
  List.fold_left (fun all (s,i)-> all^s) "" silist;;

(* product of all floats referred to in the list *)
let product_oflist =
  List.fold_left (fun prod r-> prod *. !r) 1.0 ref_list;;

(* sum of truncating float refs to ints *)
let truncsum_oflist =
  List.fold_left (fun sum r-> sum + (truncate !r)) 0 ref_list;;

(* concat repetitions of the first char in the first elem the string;
   # of repetitions is based on the second elem *)
let repeatfirst_oflist =
  List.fold_left (fun all (s,i)-> all^(String.make i s.[0])) "" silist;;

(*
val List.fold_left : ('a -> 'b -> 'a) -> 'a -> 'b list -> 'a 
                      cur  elem  next   init   thelist   result
*)
(* sample implementation of fold_left *)
let fold_left func init list =
  let rec help cur lst =
    match lst with
    | []         -> cur
    | head::tail -> let next = func cur head in
                    help next tail
  in
  help init list
;;


(* Fold can reverse a list via consing *)
let reversed_ilist =
  List.fold_left (fun cur x-> x::cur) [] ilist
;;

(* Fold can generate a list of all reversed sequential sub-lists *)
let rev_seqlists =
  List.fold_left (fun all x-> (x::(List.hd all))::all) [[]] ilist
;;

(**********************************************************************************)
(* fold_left vs fold_right *)

(* summing works the same save for the order of arguments *)
let sum_l = List.fold_left  (+) 0         [1;2;3;4];;
let sum_r = List.fold_right (+) [1;2;3;4] 0;;

(* consing works differently: fold_left reverses, fold_right does not *)

let cons_l = Listf.old_left  (fun l e-> e::l) []        [1;2;3;4];; (* reversed *)
let cons_r = List.fold_right (fun e l-> e::l) [1;2;3;4] [];;        (* in order *)

(* sample implementation of fold_right: not tail recursive *)
let rec fold_right func list init =
  match list with
    | []         -> init
    | head::tail ->
       let rest = fold_right func tail init in
       func head rest
;;
