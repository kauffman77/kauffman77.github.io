(* lambda_expr.ml: demonstrate use of the (fun .. -> ) syntax to
   declare anonymous functions (lambda expressions) in various
   ways. *)

open Printf;;

let add1_stand x =          (* standard function syntax: add1_normal is *)
  let xp1 = x+1 in          (* parameterized on x and remains unevaluated  *)
  xp1                       (* until x is given a concrete value *)
;;                          
                            
let add1_lambda =           (* bind the name add1_lambda to ... *)
  (fun x ->                 (* a function of 1 parameter named x. *)
     let xp1 = x+1 in       (* Above standard syntax is "syntatic sugar" *)
     xp1)                   (* for the "fun" version. *)
;;

let eight = add1_stand 7;;  (* both versions of the function *)
let ate   = add1_lambda 7;; (* behave identically *)

(* Demonstrate use of a local lambda expression *)
let print3 a b c =
  let print =                   (* bind print to a 1-param function *)
    fun x -> printf "%d\n" x
  in                            (* this example is a bit artificial as *)
  print a;                      (* print would more often use standard let *)
  print b;                      (* syntax to define a local function *)
  print c;
;;

(* Create an array of 2-param functions, each taking a string and an int. *)
let funcs = [|               
    (fun s i -> s^(string_of_int i));    (* 0th elem takes a func of string/int *)
    (fun s i -> (string_of_int i)^s);    (* so all other elems must also do this *)
    (fun s i -> "The string is "^s);
    (fun s i -> "The int is "^(string_of_int i));
  |];;
    
(* Call one of the functions in the array *)
let str = funcs.(1) " seven"  7;;

(* Type a record  *)
type func_rec = {
  anint   : int;                (* int *)
  intfunc : int -> int;         (* func taking int, returning int *)
  sifunc  : string -> int -> string; (* func: string and int in, string out  *)
};;

(* Construct a record using lambda experessions *)
let arec = {
  anint = 7;
  intfunc = (fun x -> 2*x);
  sifunc  = (fun s i -> s^(string_of_int i));
};;

(* Call function stored in the record field. *)
let eight = arec.intfunc 4;;

(* Demo function refs *)
let func_ref = ref (fun s -> s^" "^s);;  (* a ref to a function *)
let bambam = !func_ref "bam";;           (* call the ref'd function *)
func_ref := (fun s -> "!!!");;           (* assign to new  function *)
let exclaim = !func_ref "bam";;          (* call the newly ref'd func *)
