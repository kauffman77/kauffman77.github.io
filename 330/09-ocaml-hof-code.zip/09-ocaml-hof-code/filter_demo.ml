(* filter_demo.ml: demonstrate functions that make use of the
   higher-order filter function. This *)

(* Several functions which construct a list of elements satisfying
   various criteria *)

let rec evens list =            (* all even ints in list *)
  match list with
  | []                    -> []
  | h::t when h mod 2 = 0 -> h::(evens t)
  | _::t                  -> evens t
;;

let rec shorter lim list =      (* all strings shortenr than lim *)
  match list with
  | []                              -> []
  | h::t when String.length h < lim -> h::(shorter lim t)
  | _::t                            -> shorter lim t
;;

let rec betwixt min max list =  (* elements between min/max *)
  match list with
  | []                       -> []
  | h::t when min<h && h<max -> h::(betwixt min max t)
  | _::t                     -> betwixt min max t
;;

(* # evens [1;2;1;5;4;8;6];;
 * - : int list = [2; 4; 8; 6]
 * # shorter 3 ["a"; "bb"; "ccc"; "d"; "eeee"];;
 * - : string list = ["a"; "bb"; "d"]
 * # betwixt 1.0 3.5 [0.5; 1.2; 3.6; 2.0];;
 * - : float list = [1.2; 2.] *)

(* val filter : ('a -> bool) -> 'a list -> 'a list
   Higher-order function: pred is a function of a single element that
   returns a true/false value, often referred to as a "predicate".
   filter returns a all elements from list for which pred is true *)
let rec filter pred list =
  match list with
  | []                      -> []
  | h::t when (pred h)=true -> h::(filter pred t)
  | _::t                    -> filter pred t
;;

let evens list =                 (* even numbers *)
  let is_even n = n mod 2 = 0 in (* predicate: true for even ints *)
  filter is_even list            (* call to filter with predicate *)
;;
let shorter lim list =                     (* strings w/ len < lim *)
  let short s = (String.length s) < lim in (* predicate *)
  filter short list                        (* call to filter *)
;;
let betwixt min max list =             (* elements between min/max *)
  let betw e = min < e && e < max in   (* predicate *)
  filter betw list                     (* call to filter w/ predicate *)
;;

(* # evens [1;2;1;5;4;8;6];;
 * - : int list = [2; 4; 8; 6]
 * # shorter 3 ["a"; "bb"; "ccc"; "d"; "eeee"];;
 * - : string list = ["a"; "bb"; "d"]
 * # betwixt 1.0 3.5 [0.5; 1.2; 3.6; 2.0];;
 * - : float list = [1.2; 2.] *)



(* Short specifications of above functions which use lambda
   expressions for the predicates *)
let evens list =                (* even numbers *)
  filter (fun n -> n mod 2 = 0) list
;;
let shorter lim list =          (* strings shortenr than lim *)
  filter (fun s -> (String.length s) < lim) list
;;
let betwixt min max list =      (* elements between min/max *)
  filter (fun e -> min < e && e < max) list
;;


(* More functions that filter elements *)
let rec ordered list =      (* first pair elem < second *)
  match list with
  | []                  -> []
  | (a,b)::t when a < b -> (a,b)::(ordered t)
  | _::t                -> ordered t
;;

let rec is_some list =      (* options that have some *)
  match list with
  | []          -> []
  | (Some a)::t -> (Some a)::(is_some t)
  | _::t        -> is_some t
;;

(* Definitions using filter higher-order function *)
let ordered list =              (* first pair elem < second *)
  let pred (a,b) = a < b in
  filter pred list
;;

let is_some list =              (* options that have some *)
  let pred opt =                (* named predicate with *)
    match opt with              (* formatted source code *)
    | Some a -> true            (* that is boring but easy *)
    | None   -> false           (* on the eyes *)
  in
  filter pred list
;;
let is_some list =              (* magnificent one-liner version... *)
  filter (fun opt -> match opt with Some a->true | None->false) list
;;                    (* ...that will make you cry on later reading *)

