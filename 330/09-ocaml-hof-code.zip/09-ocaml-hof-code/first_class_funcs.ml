(* first_class_funcs.ml: demonstrate basic higher-order functions. *)

(* Higher-order function which
   applies func as a function to
   arg. *)
let apply func arg =
  func arg
;;

(* Simple arithmetic functions. *)
let incr n = n+1;;
let double n = 2*n;;

let a = apply incr 5;;
let b = apply double 5;;
let c = apply List.hd ["p";"q";"r"]

(* Higher-order function taking two
   function paramters f1 and f2.
   Applies them in succession to
   arg. *)
let apply_both f1 f2 arg=
  let res1  = f1 arg in
  let res12 = f2 res1 in
  res12
;;

let x =
  apply_both incr double 10;;
let y =
  apply_both double incr 10;;
let z =
  apply_both List.tl List.hd ["p";
                              "q";
                              "r"];;

(* 
   a = apply incr 5
     = (incr 5)
     = 6
  
   b = apply double 5
     = (double 5)
     = 10
 
   c = apply List.hd ["p";"q";"r"]
     = List.hd ["p";"q";"r"]
     = "p"

   x = apply_both incr double 10
     = (double (incr 10))
     = (double 11)
     = 22

   y = apply_both double incr 10
     = (incr (double 10))
     = (incr 20)
     = 21

   z = apply_both List.tl List.hd ["p";"q";"r"]
     = (List.hd (List.tl ["p";"q";"r"]))
     = (List.hd ["q";"r"])
     = "q"
*)

