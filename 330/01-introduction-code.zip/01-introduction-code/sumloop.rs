// sumloop.rs: Rust version of summing 1 to 10
// 
// compile / run via
// >> rustc sumloop.rs
// >> ./sumloop
// x is 55

fn main() {
  let mut x = 0;
  for i in 1..11 {
    x = x+i;
  }
  print!("x is {}\n",x);
  // // alternatively
  // print!("x is {x}\n");
}
