# sumloop.py: Python version of summing 1 to 10
#
# run via
# >> python sumloop.py
# x is 55
x = 0
for i in range(1,11):
  x = x+i
print("x is {}".format(x))

# alternative printing via "format strings"
# print(f"x is {x}")
