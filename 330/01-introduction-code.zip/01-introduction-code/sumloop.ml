(* sumloop.ml: OCaml loop to sum numbers 1 to 10

   byte compile / run on the fly via
   >> ocaml sumloop.ml
   x is 55

   byte compile ahead of time and / run via
   >> ocamlc sumloop.ml
   >> ./a.out
   x is 55
*)

(* open Printf                     (\* for the printf function *\) *)

let _ = 
  let x = ref 0 in
  for i=1 to 10 do
    x := !x + i;
  done;
  Printf.printf "x is %d\n" !x;

  
