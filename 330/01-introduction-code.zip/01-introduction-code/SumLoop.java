// SumLoop.java: Java version to sum numbers 1 to 10
// 
// byte compile ahead of time and run via
// >> javac SumLoop.java
// >> java SumLoop
// x is 55

public class SumLoop {
  public static void main(String args[]){
    int x = 0;
    for(int i=1; i<=10; i++){
      x = x+i;
    }
    System.out.printf("x is %d\n",x);
  }
}
