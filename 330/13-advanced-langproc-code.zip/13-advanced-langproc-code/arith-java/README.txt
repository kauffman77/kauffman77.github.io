This directory contains a simple ANTLR4 grammar for a simple
arithmetic language. The grammar is in the file Arith.g.  The provided
Makefile allows compilation and creation of arith.jar with

> make

The main class of arith.jar is ArithMain which has a main() method which
prints the abstract syntax tree of the first command line argument so
that the following will work:

> java -cp .:../antlr-4.5.3-complete.jar ArithMain '1+2*3-12/4'
-
  +
    1
    *
      2
      3
  /
    12
    4

This jar contains a the contents of the antlr-4.5.3-complete.jar file
as well, extracted and re-merged so to limit the number of
dependencies required to use ArithMain.
