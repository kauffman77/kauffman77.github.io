// Types of tokens that can appear in arithmetic
public enum TokenType {
  Plus("+"),
  Minus("-"),
  Multiply("*"),
  Divide("/"),
  Number("Number");

  // String representation of the token
  public String typeString;

  TokenType(String s){
    this.typeString=s;
  }
}
