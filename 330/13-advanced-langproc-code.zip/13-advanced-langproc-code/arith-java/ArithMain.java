import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class ArithMain {
  // Main method to test construction. Attempts to parse the
  // expression given as the first command line argument and print out
  // its contents as a parsed tree.
  //
  // Example:
  // > java -cp .:../antlr-4.5.3-complete.jar ArithMain '1+2*3-12/4'
  public static void main(String[] args) throws Exception {
    if(args.length < 1){
      System.out.println("usage:   java -jar arith.jar 'expression to interpret'");
      System.out.println("Example: java -jar arith.jar '10 - 2 - 3*2'");
      return;
    }
    ANode root = parseExpressionString(args[0]);
    String rootString = root.toString();
    System.out.println(rootString);
  }

  // Construct a tree based on the provided expression string. Primary
  // means to construct trees.
  public static ANode parseExpressionString(String formulaStr){
    ANTLRInputStream input = new ANTLRInputStream(formulaStr);
    ArithLexer lexer = new ArithLexer(input);
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    ArithParser parser = new ArithParser(tokens);

    lexer.removeErrorListeners();                      // remove ConsoleErrorListener
    lexer.addErrorListener(new FailOnErrorListener()); // add failure listener

    parser.removeErrorListeners();                      // remove ConsoleErrorListener
    parser.addErrorListener(new FailOnErrorListener()); // add failure listener

    ParseTree tree = parser.input();
    ANode root = (new ArithVisitorImpl()).visit(tree);
    return root;
  }    


  public static class ANode {

    // Type of token at this node. May be one of the following values:
    //   TokenType.Plus
    //   TokenType.Minus
    //   TokenType.Multiply
    //   TokenType.Divide
    //   TokenType.Number
    public TokenType type;

    // Raw data for this node. May be a number, operator, or an id for
    // another cell
    public String data;

    // Left and right branch of the tree. May be null if syntax dictates
    // that either child is null
    public ANode left, right;

    // Constructor a node with the given data
    public ANode(TokenType type, String data, ANode left, ANode right){
      this.type=type;
      this.data=data;
      this.left=left;
      this.right=right;
    }

    // Constructor a node with the given data
    public ANode(TokenType type, ANode left, ANode right){
      this.type=type;
      this.data=type.typeString;
      this.left=left;
      this.right=right;
    }

    // Create a fancy-ish string version of this node. Enters a
    // recursive version of the method
    public String toString(){
      StringBuilder sb = new StringBuilder();
      fancyToString(this, 0, sb);
      return sb.toString();
    }

    // Controls the indentation of the 
    private static int indentOffset = 2;

    // Recursive helper method to traverse the tree and produce a
    // semi-readable string version of the tree.
    private static void fancyToString(ANode node, int indent, StringBuilder sb){
      if(node == null){
        return;
      }
      for(int i=0; i<indent; i++){
        sb.append(' ');
      }
      sb.append(node.data);
      sb.append('\n');
      fancyToString(node.left,  indent+indentOffset, sb);
      fancyToString(node.right, indent+indentOffset, sb);
      return;
    }

  }

  // Class to cause immediate exception percolation on encountering an
  // error in the input of the expression grammar.
  // 
  // Adapted from The Definitive ANTLR 4 Reference, 2nd Edition" section 9.2
  public static class FailOnErrorListener extends BaseErrorListener {
    @Override
    public void syntaxError(Recognizer<?, ?> recognizer,
                            Object offendingSymbol,
                            int line, int charPos,
                            String msg,
                            RecognitionException e)
    {

      String errmsg = "";
      if(recognizer instanceof Parser){
        java.util.List<String> stack = ((Parser)recognizer).getRuleInvocationStack();
        java.util.Collections.reverse(stack);
        errmsg = stack.toString();
      }
      else if(recognizer instanceof Lexer){
        errmsg = ((Lexer)recognizer).getAllTokens().toString();
      }
      else{
        throw new RuntimeException("WTF^M?");
      }
      String errMsg = String.format("Parse Error:\nRule Stack: %s\nLine %d:%d at %s",
                                    errmsg,line,charPos,offendingSymbol,msg);
      throw new RuntimeException(errMsg);
    }

  }


  // Class which visits an ANTLR parse tree for the Arith grammar and
  // builds a tree of ANodes.  Basic usage is as follows such as in a
  // main() method:
  //
  // ANTLRInputStream input = new ANTLRInputStream(formulaStr);
  // ArithLexer lexer = new ArithLexer(input);
  // CommonTokenStream tokens = new CommonTokenStream(lexer);
  // ArithParser parser = new ArithParser(tokens);
  // ParseTree tree = parser.input();
  // ANode root = (new ArithVisitorImpl()).visit(tree);
  //
  public static class ArithVisitorImpl extends ArithBaseVisitor<ANode>{
    @Override
    public ANode visitAll(ArithParser.AllContext ctx) {
      return visit(ctx.plusOrMinus());
    }

    @Override
    public ANode visitPlus(ArithParser.PlusContext ctx) {
      return new ANode(TokenType.Plus,
                       visit(ctx.plusOrMinus()),visit(ctx.multOrDiv()));
    }
    
    @Override
    public ANode visitMinus(ArithParser.MinusContext ctx) {
      return new ANode(TokenType.Minus,
                       visit(ctx.plusOrMinus()),visit(ctx.multOrDiv()));
    }

    @Override
    public ANode visitMultiply(ArithParser.MultiplyContext ctx) {
      return new ANode(TokenType.Multiply,
                       visit(ctx.multOrDiv()),visit(ctx.ident()));
    }

    @Override
    public ANode visitDivide(ArithParser.DivideContext ctx) {
      return new ANode(TokenType.Divide,
                       visit(ctx.multOrDiv()),visit(ctx.ident()));
    }

    @Override
    public ANode visitNumber(ArithParser.NumberContext ctx) {
      return new ANode(TokenType.Number,ctx.NUMBER().getText(),
                       null,null);
    }

    @Override
    public ANode visitParens(ArithParser.ParensContext ctx) {
      return visit(ctx.plusOrMinus()); 
    }
  }

}
