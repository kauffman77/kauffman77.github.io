(* left_right_assoc.ml: Demonstrates a simple parser that can be
   toggled betwee right associativity and left associativity.  The grammar accepted is

   S -> S - S
   S -> N
   N -> number
   N -> ( S )

   By adjusting one function below, the subtraction is treated as
   either right or left associative. That is and expression of the form:

   10 - 3 - 2 - 1

   is grouped as either of

   Right associative: (10 - (3 - (2 - 1))) = 8
   Left  associative: (((10-3) - 2) - 1)   = 4

   Special techniques are needed to achieve left associativity in
   recursive descent parsers: usually a function which wants left
   associativity uses a loop to consume a sequence of left associative
   operators at the same precedence level rather than a recursion to
   the right.  See

   https://www.engr.mun.ca/~theo/Misc/exp_parsing.htm#classic

   which also has a few other possible solutions.
*)

(* algebraic types for tokens: lexing results *)
type token =
  Minus | OParen | CParen | Int of int;;

(* algebraic types for expression tree: parsing results *)
type expr =
  | Sub of expr * expr
  | Const of int
;;

(* returns true if the given character is a digit 0-9 and false
   otherwise *)
let is_digit c =
  let digits = "0123456789" in
  let loc = String.index_opt digits c in
  loc <> None
;;

(* Lexing routine to convert a string of raw chars to a list of tokens *)
let lex_string string =                      (* create a list of tokens  *)
  let len = String.length string in
  let rec lex pos =                          (* recursive helper *)
    if pos >= len then                       (* off end of string ? *)
      []                                     (* end of input *)
    else                                     (* more to lex *)
      match string.[pos] with                (* match a single character *)
      |' ' | '\t' | '\n' -> lex (pos+1)      (* skip whitespace *)
      |'-' -> Minus :: (lex (pos+1))         (* single char ops become operators *)
      |'(' -> OParen :: (lex (pos+1))        (* and open/close parens *)
      |')' -> CParen :: (lex (pos+1))
      | d when is_digit d ->                 (* see a digit *)
         let stop = ref pos in               (* scan through until a non-digit is found *)
         while !stop < len && is_digit string.[!stop] do
           incr stop;
         done;
         let numstr = String.sub string pos (!stop - pos) in (* substring is the int *)
         let num = int_of_string numstr in   (* parse the integer *)
         Int(num) :: (lex !stop)             (* and tack onto the stream of tokens *)
      | _ ->                                 (* any other characters lead to failures *)
         let msg = sprintf "lex error at char %d, char '%c'" pos string.[pos] in
         failwith msg
  in                                         (* end helper *)
  lex 0                                      (* call helper *)
;;

(* Exception type in case of parse error *)
exception ParseError of {
    msg  : string;
    toks : token list;
};;

(* parse a number or a paren expression *)
let rec parse_num toks =
  match toks with
  | [] ->                                  (* out of input *)
     raise (ParseError {msg="expected an expression"; toks=toks})
  | Int n ::  tail ->                      (* ints are self-evaluating *)
     (Const(n),tail)
  | OParen :: tail ->                      (* parenthesized expresion *)
     begin
       let (expr,rest) = parse_top tail in (* start back at lowest precedence *)
       match rest with
       | CParen::tail -> (expr,tail)
       | _ -> raise (ParseError {msg="unclosed parentheses"; toks=rest})
     end
  | _ ->
     raise (ParseError {msg="syntax error"; toks=toks})

(* right associativity via standard recursion *)
and parsesub_right toks =
  let (lexpr, rest) = parse_num toks in         (* try higher prec first           *)
  match rest with                               
  | Minus :: tail ->                            (* - first                         *)
     let (rexpr,rest) = parsesub_right tail in  (* recursively generate right-hand *)
     (Sub(lexpr,rexpr), rest)                   (* subtract left / right           *)
  | _ -> (lexpr, rest)                          (* not a sub                       *)

(* left associativity via iteration *)
and parsesub_left toks =
  let (lexpr, rest) = parse_num toks in         (* try higher prec first        *)
  let rec iter lexpr toks =                     (* loop through adjacent exprs  *)
    match toks with
    | Minus :: rest ->                          (* found -                      *)
       let (rexpr,rest) = parse_num rest in     (* consume a higher-prec expr   *)
       iter (Sub(lexpr,rexpr)) rest             (* create Sub and iterate again *)
    | _ -> (lexpr, toks)
  in
  iter lexpr rest                               (* start iterating              *)

(* Pick one of the two functions as the top-level entry *)
and parse_top toks = parsesub_left toks
(* and parse_top toks = parsesub_right toks *)
;;
