(* arithmain.ml: main routine for lexing/parsing and interpreting an
   arithmetic language. This version directly interprets the language
   rather than building an expression tree.  *)
open Printf;;

let _ =
  try
    (* Lexing is an OCaml standard module for lexer support *)
    let lexbuf = Lexing.from_channel stdin in                (* create a lexing buffer *)
    while true do
      printf "arithmain> %!";
      (* Arithlex.token is a function that produces a token *)
      (* Arithparse.main is function that takes a token producer and a lexing buffer *)
      let result = Arithparse.main Arithlex.token lexbuf in  (* lex/parse an expression *)
      printf "%d\n%!" result;                                (* print integer result *)
    done;
  with Arithlex.Eof ->                                       (* exception thrown to indicate end of file *)
    printf "That's all folks!\n";
;;
