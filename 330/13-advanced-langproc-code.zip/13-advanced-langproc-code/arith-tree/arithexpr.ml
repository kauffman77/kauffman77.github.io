open Printf;;

type expr =                     (* type associated with expression trees *)
 | Const of int
 | Add of expr * expr
 | Sub of expr * expr
 | Mul of expr * expr
 | Div of expr * expr
;;

(* Create a string version of the given parsed expression tree *)
let parsetree_string expr =
  let buf = Buffer.create 256 in                    (* extensibel character buffer *)
  let indent n =
    for i=1 to n do                           
      Buffer.add_string buf "  ";
    done;
  in
  let rec build expr depth =                        (* recursive helper *)
    indent depth;
    match expr with
    | Const(i)  -> Buffer.add_string buf (sprintf "IConst(%d)\n" i);
    | Add(left,right) | Sub(left,right)
    | Mul(left,right) | Div(left,right) ->
       let str = match expr with
         | Add _ -> "Add" | Sub _ -> "Sub"
         | Mul _ -> "Mul" | Div _ -> "Div"
         | _ -> failwith "impossible to reach (right?)"
       in
       Buffer.add_string buf (sprintf "%s\n" str);
       build left  (depth+1);
       build right (depth+1);
  in
  build expr 0;
  Buffer.contents buf                               (* return string from Buffer *)
;;
