open Printf;;

let _ =
  try
    (* Lexing is an OCaml standard module for lexer support *)
    let lexbuf = Lexing.from_channel stdin in                   (* create a lexing buffer *)
    while true do
      printf "arithmain> %!";
      (* Arithlex.token is a function that produces a token *)
      (* Arithparse.main is function that takes a token producer and a lexing buffer *)
      let parsetree = Arithparse.main Arithlex.token lexbuf in  (* lex/parse an expression *)
      let treestr = Arithexpr.parsetree_string parsetree in
      printf "%s\n%!" treestr;                                  (* print tree result *)
    done;
  with Arithlex.Eof ->                                          (* exception thrown to indicate end of file *)
    printf "That's all folks!\n";
;;
