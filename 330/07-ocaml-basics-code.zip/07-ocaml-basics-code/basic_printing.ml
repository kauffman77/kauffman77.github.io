(* basic_printing.ml : printing and unit value *)
let return_val =
  print_endline "hi there!\n";;
(* output: hi there! *)
(* val return_val : unit = () *)

(* built-in printing functions *)
print_string  "hi";;
print_int     5;;
print_float   1.23;;
print_endline "done";;
(* output: 
   hi51.23done 
*)
print_int 7;;      (* unit input     *)    
print_newline ();; (* functions with *)         
print_int 8;;      (* no args like   *)                
print_newline ();; (* print_newline  *) 
(* output: 
   7
   8
*)

(* basic_printing.ml : local scope, print variables *)
let x = "hi" in             (* local scope with x *)
let y = 5 in                (* .. and y *)
print_string  "string: ";   (* single semi-colon for *)
print_string  x;            (* side-effects only statements *)
print_newline ();           (* that continue the local scope *)
print_string  "int: ";      
print_int     y;
print_newline ();
let z = 1.23 in             (* add z to local scope *)
print_string  "float: ";
print_float   z;
print_newline ();
print_endline "done";
;;                          (* end of local scope *)
