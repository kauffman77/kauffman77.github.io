(* printf_demo.ml : demonstrate the printf function
   for succinct output *)

open Printf;;      (* access functions from Printf module *)
(* function printf is now available *)

printf "hi there!\n";;
printf "sub in an int: %d\n" 17;;
(* Output:
   hi there!
   sub in an int: 17
*)

printf "string: %s integer %d float %f done\n"
               "hi"         5      1.23;;
(* output: 
   string: hi integer 5 float 1.230000 done 
*)

let x = "hi" in          (* local scope with x *)
let y = 5 in             (* and y *)
printf "string: %s\n" x;
printf "int: %d\n" y;
let z = 1.23 in          (* bind z *)
printf "float: %f\n" z;
printf "done\n";
;;                       (* end of scope *)
