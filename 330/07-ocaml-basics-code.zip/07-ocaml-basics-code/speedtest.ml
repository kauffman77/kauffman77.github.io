(* Simple loop-increment program to measure speed of
   execution. Compare byte-code versus native code runtimes as
   follows.

   > ocamlc speedtest.ml    # compile to bytecode
   > file a.out             # show file type
   a.out: a /usr/bin/ocamlrun script executable (binary data)

   > time ./a.out           # time execution
   33554432
   
   real  0m0.277s           # about a quarter second passed
   user  0m0.276s
   sys   0m0.000s

   > ocamlopt speedtest.ml  # compile to native code
   > file a.out             # show file type
   a.out: ELF 64-bit LSB pie executable x86-64

   > time ./a.out
   33554432
   
   real  0m0.022s           # about 1/10th the time: faster
   user  0m0.022s
   sys   0m0.000s
*)

let _ = 
  let n = 1 lsl 25 in                   (* left shift an int *)
  let x = ref 0 in                      (* ref starts at 0 *)
  for i=1 to n do
    x := !x + 1;                        (* repeatedly increment *)
  done;
  let str = string_of_int !x in         (* convert final int to string *)
  print_endline str;                    (* and print *)
;;
