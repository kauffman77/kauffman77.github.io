open Printf;;

for i = 0 to 63 do
  let x = 1 lsl i in
  printf "shift %2d: value %d\n" i x;
  if x=0 then
    printf "int's are %d bits wide in OCaml on this system\n" i;
done;;
