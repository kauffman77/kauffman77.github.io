(* collatz_rec.ml: alternative to the iterative version of collatz,
   this version demonstrates several additional features of OCaml
   including nested functions, slightly more complex pattern matching,
   and recursion but is otherwise equivalent.
*)
open Printf;;                                           (* allow printf() calls rather than Printf.printf() *)

let verbose = true;;                                    (* module-level var; will end these with ;; for *)
                                                        (* clarity but can leave this off if desired *)
let collatz start maxsteps =                            (* function to compute *)

  let rec collatz_step cur step =                       (* nested helper func in the scope of collatz *)
    if verbose then                                     (*  that recursively computes one step in the sequence *)
      printf "%3d: %5d\n" step cur;                     (* print if verbose is enabled *)
    let rem = cur mod 2 in                              (* calculate remainder for matching  *)
    match (cur,step=maxsteps,rem) with                  (* MATCH different cases of tuple *)
      (1,_,   _) -> (cur,step)                          (* cur is 1: converged so return  *)
    | (_,true,_) -> (cur,step)                          (* step=maxsteps: return due to iteration exceeded *)
    | (_,_,   0) -> collatz_step (cur/2)   (step+1)     (* rem=0:  even case to recurse *)
    | (_,_,   _) -> collatz_step (cur*3+1) (step+1)     (* rem!=0: odd case to recurse *)
  in                                                    (* end of nested helper *)
  if verbose then                                       (* main body of collatz func *)
    begin                                               (* several statements in an if/then require *)
      printf "start: %d maxsteps %d\n" start maxsteps;  (* a begin/end block like { } in other languages  *)
      printf "Step  Current\n";
    end;                                                (* end of if/then  *)
  collatz_step start 0                                  (* call recursive helper, its return val is returned *)
;;

let _ =                                                 (* equivalent of a "main" block *)
  print_string "Collatz start val:\n";                  (* simple string printing *)
  let start = read_int () in                            (* read an int and convert it *)

  let (final,steps) = collatz start 500 in              (* call function and capture return tuple *)
  printf "Reached %d after %d iters\n" final steps;     (* print result *)
;;
