(* local_is_local_fixed.ml : fixes local binding
   error by making it a top-level binding
*)

let x = "hello";;	  (* top-level binding *)

let a =                   (* top-level binding *)
  let y = " " in          (* local binding *)
  let z = "world" in      (* local binding *)
  x^y^z                   (* result *)
;;                        (* x,y,z go out of scope here *)


print_endline a;;         (* print a, it is well defined *)

print_endline x;;	  (* print x, it is well defined *)
