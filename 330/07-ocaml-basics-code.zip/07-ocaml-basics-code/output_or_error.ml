(* Block 1 *)                  (* OK *)
let a = 7 in                   (* a in local scope *)
print_endline "get started";   (* continue local scope *)
let b = 12 in                  (* b in local scope *)
print_endline "another line";  (* continue local scope *)
print_int (a+b);               (* a and b still in scope, all is well *)
print_newline ();
;;                             (* end local scope, a b undefined *)

(* Block 2 *)                  (* ERROR *)
let c = 2 in                   (* c in local scope *)
let d = a + c in               (* ERROR: no binding for a  *)
print_int d;
print_newline ();
;;

(* Block 3 *)                  (* OK *)
let a = 9                      (* a bound to 9 *)
;;                             (* at the top level *)
print_endline "last one";
print_int a;                   (* a is a top-level binding, still in scope *)
print_newline ();
;;
