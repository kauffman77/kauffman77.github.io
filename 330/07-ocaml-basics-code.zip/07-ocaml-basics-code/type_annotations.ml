(* type_annotations.ml : show type annotation syntax of colon 
   for simple definitions *)

let a : int = 7;;             (* annotate a as int *)
let b = 7;;                   (* b inferred as int *)

print_int a;;
print_endline "";;

print_int b;;
print_endline "";;

(* fully annotated version *)
let c : int =                 (* annotate c as int *)
  let x : string = "hi" in
  let y : string = "bye" in
  let z : string = x^y in     (* concatenate *)
  String.length z             (* return string length : int *)
;;

print_int c;;
print_endline "";;

(* fully inferred version *)
let d =                       (* inferred c as int <-----+  *)
  let x = "hi" in             (* inferred x as string    |  *)
  let y = "bye" in            (* inferred y as string    |  *)
  let z = x^y in              (* inferred z as string    |  *)
  String.length z             (* return string length : int *)
;;

print_int d;;
print_endline "";;
