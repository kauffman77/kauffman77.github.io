let first =                             (* first top level binding *)
  let x = 1 in                          (* local binding *)
  let y = 5 in                          (* local binding *)
  y*2 + x                               (* * + : integer multiply and add *)
;;

(* binds first to 
     y*2 + x 
   = 5*2 + 1
   = 11
*)

let second =                            (* second top-level binding *)
  let s = "TAR" in                      (* local binding *)
  let t = "DIS" in                      (* local binding *)
  s^t                                   (* ^ : string concatenate (^) *)
;;
(* binds second to
     "TAR"^"DIS"  (concatenate strings)
   = "TARDIS"
*)


(* A less clear way of writing the above code *)
let first = let x = 1 in let y = 5 in y*2 + x;;
let second = let s = "TAR" in let t = "DIS" in s^t;;
