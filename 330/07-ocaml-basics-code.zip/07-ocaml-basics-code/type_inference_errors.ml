open Printf;;                   (* type_inference_errors.ml: generates *)
                                (* a type error while compiling *)
let doubler i = 2*i;;

let _ =
  let four = doubler 2 in
  let eight = doubler four in
  let yesyes = doubler "yes" in    (* like in Python, right? *)
  printf "%d %d %d\n" four eight;
  printf "%d\n" yesyes;
;;
