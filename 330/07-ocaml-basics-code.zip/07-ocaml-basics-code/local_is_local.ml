(* local_is_local.ml : demo of local binding error *)

let a =                   (* top-level binding *)
  let x = "hello" in      (* local binding *)
  let y = " " in          (* local binding *)
  let z = "world" in      (* local binding *)
  x^y^z                   (* result *)
;;                        (* x,y,z go out of scope here *)

print_endline a;;         (* print a, it is well defined *)

print_endline x;;         (* x is not defined *)
