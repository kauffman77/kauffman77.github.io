(* collatz.ml: introductory OCaml example demonstrating a variety of
   its features. Compile/Run this via

   >> ocamlc collatz.ml    # byte-compile to a.out
   >> ./a.out              # run the program
   Collatz start val:
   10
     0:    10
     1:     5
     2:    16
     3:     8
     4:     4
     5:     2
     6:     1
   Reached 1 after 6 iterations
   
   Alternatively one can run directly via
   >> ocaml collatz.ml
*)
open Printf;;                                           (* allow printf() calls rather than Printf.printf() *)

let verbose = true;;                                    (* module-level var; will end these with ;; for *)
                                                        (*   clarity but can leave it off if desired *)
let collatz start maxsteps =                            (* functions defined via name followed by parameters *)
  let cur = ref start in                                (* let/in introduce name/value bindings *)
  let step = ref 0 in                                   (* immutable by default, ref allows mutability *)
  if verbose then                                       (* main body of collatz func *)
    begin                                               (* several statements in an if/then require *)
      printf "start: %d maxsteps %d\n"                  (* a begin/end block like { } in other languages  *)
              start maxsteps;                           (* no parens around function calls *)
      printf "Step  Current\n";                         (* Side-effect statements like printing/mutation require ; *)
    end;                                                (* end of if/then  *)

  while !cur != 1 && !step < maxsteps do                (* deref a reference via ! (bang) *)
    if verbose then                                     
      printf "%3d: %5d\n" !step !cur;                   (* print if verbose is enabled *)
    begin match !cur mod 2 with                         (* MATCH different cases given expression: 0 or 1 *)
    | 0 -> cur := !cur/2;                               (* rem=0:  even case *)
    | _ -> cur := !cur*3+1;                             (* rem!=0: odd case *)
    end;                                                (* begin/end for match that is done for side-effects *)
    step := !step + 1;
  done;
  (!cur,!step)                                          (* final expression to appear is return value *)
;;                                                      (* end of collatz function *)

let _ =                                                 (* equivalent of a "main" block *)
  print_string "Collatz start val:\n";                  (* simple string printing *)
  let start = read_int () in                            (* read an int and convert it *)

  let (final,steps) = collatz start 500 in              (* call function and capture return tuple *)
  printf "Reached %d after %d iters\n" final steps;     (* print result *)
;;


(* The below code is an alternative to the "let _ =" expression which
   puts the same code at the module level. Module-level (global)
   statements and bindings behave a little differently, cannot use the
   let/in syntax so won't be used as much as "let _ =" for "main"
   function code. *)

(* 
print_string "Collatz start val:\n";   
let start = read_int ();;              

let (final,steps) = collatz start 500;;
printf "Reached %d after %d iters\n" final steps;;
*)

