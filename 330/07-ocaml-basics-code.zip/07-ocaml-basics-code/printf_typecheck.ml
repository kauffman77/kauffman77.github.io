(* Demonstrate compiler checking substitution 
   types in a printf format string  *)
open Printf;;

let x = 42 in
let y = 1.23 in
printf "x is %f and y is %d" x y;;
