(* approximate_mutability.ml : show how
   successive let bindings can look sort of
   like mutability *)

let x = 5 in	   (* local: bind old x to 5 *)
let x = x+5 in	   (* local: new x is old x+5 *)
print_int x;;      (* prints 10: most recent x  *)
 		   (* top-level: new x out of scope *)
print_endline "";;

let x = 7;;        (* top-level x <-------+ *)
let y =            (* top-level y <---+   | *)
  let z = x+5 in   (* z = 12 = 7+5    |   | *)
  let x = x+2 in   (* x =  9 = 7+2    |   | *)
  let z = z+2 in   (* z = 14 = 12+2   |   | *)
  z+x;;            (* 14+9 = 23 ------+   | *)
                   (* end local scope |   | *)
print_int y;;      (* prints 23 ------+   | *)
print_endline "";; (*                     | *) 
                   (*                     | *)
print_int x;;      (* prints 7 -----------+ *)
print_endline "";; (*                       *)
