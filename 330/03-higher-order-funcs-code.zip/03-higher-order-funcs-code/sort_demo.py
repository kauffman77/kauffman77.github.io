# sort_demo.py: demonstration of using first-class functions to modify
# the sorting order of a list of numbers

nums = [23426, -16781, 9963, 10870, 677, 
        -21218, 22541, 11610, 24488, -24855]

nums.sort()                     # sort the list
print(nums)                     # w/ standard order

nums.sort(key=abs)              # sort by absolute
print(nums)                     # value via abs()

nums.sort(key=lambda x: -x)     # sort in reverse
print(nums)                     # via a lambda
