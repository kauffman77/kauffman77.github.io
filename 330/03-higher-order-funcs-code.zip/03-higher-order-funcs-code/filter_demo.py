# filter_demo.py: shows basic use of filter(), includes items in a
# new, likely shorter list, that return True from the function
# provided as an argument. Uses lambda expressions for the filter
# functions.

words = ["apple","banana","apricot","grape","artichoke"]

awords = list(filter(lambda x: x[0]=="a", words))
print(awords)        # ['apple', 'apricot', 'artichoke']

short_words = list(filter(lambda x: len(x) <= 5, words))
print(short_words)   # ['apple', 'grape']

long_words = list(filter(lambda x: len(x) > 5, words))
print(long_words)    # ['banana', 'apricot', 'artichoke']

all_words = list(filter(lambda x: 5.5, words))
print(all_words)     # entire list due to 5.5 being truthy
