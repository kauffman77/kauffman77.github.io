# function_value.py: demos basic semantics of first-class-functions,
# that they may be assigned as values to variables

def double_it(x):               # define function
  return 2*x
print(double_it)                # show a printed rep of func

a = double_it(5)                # call function
print(a)

di = double_it                  # alias for double_it()
print(di)

b = di(7)                       # call di() -> double_it()
print(b)
