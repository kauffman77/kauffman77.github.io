# map_demo.py: demonstrates use of the map() higher-order function on
# lists. Note the need to convert the resulting iterable "<map
# object>" to a list ot see its explicit results.

def add_one(x):                    # a transform function
  return x+1

nums0  = [10,20,30,40]             # base data
nums1  = map(add_one,nums0)        # transformed data..
nums1l = list(map(add_one,nums0))  # converted to a list

print(f"nums0:  {nums0}")
print(f"nums1:  {nums1}")
print(f"nums1l: {nums1l}")

def upcase(x):                     # a transform function
  return x.upper()

strsm  = ["cat","Dog","pIg"]       # base data
strsu  = map(upcase, strsm)        # transformed data..
strsul = list(map(upcase, strsm))  # converted to a list

print(f"strsm:  {strsm}")
print(f"strsu:  {strsu}")
print(f"strsul: {strsul}")

# shell>> python map_demo.py
# nums0: [10, 20, 30, 40]
# nums1: <map object at 0x7fa0a6167d00>
# strsm: ['cat', 'Dog', 'pIg']
# strsu: <map object at 0x7fa0a6167c10>
# shell>> python map_demo.py
# nums0:  [10, 20, 30, 40]
# nums1:  <map object at 0x7f597bd67d00>
# nums1l: [11, 21, 31, 41]
# strsm:  ['cat', 'Dog', 'pIg']
# strsu:  <map object at 0x7f597bd66620>
# strsul: ['CAT', 'DOG', 'PIG']
