# reduce_demo.py: demonstrates the reduce() higher-order function
# which converts a DS (list) of values to a single value through
# repeated function application

from functools import reduce    # reduce() not in default imports

nums = [10,20,30,40]            # some date to operat on

asum0 = reduce(lambda cur,x: x+cur, nums, 0)   # sum starting at 0
print(asum0)      # 100

asum13 = reduce(lambda cur,x: x+cur, nums, 13) # sum starting at 13
print(asum13)     # 113

asum_def = reduce(lambda cur,x: x+cur, nums)   # default to sum list only
print(asum_def)   # 100

aprod1 = reduce(lambda cur,x: x*cur, nums, 1)  # product of list, init 1
print(aprod1)     # 240000

aprod_def = reduce(lambda cur,x: x*cur, nums)  # product of list only
print(aprod_def)  # 240000

astr = reduce(lambda cur,x: cur+str(x)+" ", nums, "") # string concat
print(astr)       # "10 20 30 40 " 

amax = reduce(lambda cur,x: x if x>cur else cur, nums) # reduce via max
print(amax)       # 40

amax2 = reduce(max, nums)                      # max() func used directly
print(amax)       # 40

print(max(nums))                               # pythonic style
# There should be one-- and preferably only one --obvious way to do it.
# Although that way may not be obvious at first unless you're Dutch.
# PEP-20: The Zen of Python
