# apply_exercise.py: Demo of two higher-order functions for an in-class exercise

def double_it(x):               # series of transform
  return 2*x                    # functions

def halve_it(x):
  return x/2

import math
def log2_it(x):
  return math.log2(x)


def apply2(func1, func2, data):
  data1 = func1(data)
  data2 = func2(data)
  # return (func1(data),func2(data))
  return (data1,data2)

print( apply2(double_it, halve_it, 10) )
# (20, 5.0)

print( apply2(log2_it, double_it, 32) )
# (5.0, 64)


def apply_all(func_list, data):
  data_list = []
  for func in func_list:
    data_list.append(func(data))
  return data_list

flist = [double_it, halve_it, log2_it]
print( apply_all(flist, 10) )
# [20, 5.0, 3.32]



