# function_args.py: Demonstrate a higher-order function 'scale_list()'
# which takes a scaling function and applies it to each element in a
# list. Allows for flexible list transformation.

def scale_list(func, alist):    # higher-order function
  for i in range(len(alist)):
    alist[i] = func(alist[i])   # apply func() to each elem

def double_it(x):               # series of transform
  return 2*x                    # functions

def halve_it(x):
  return x/2

import math
def log2_it(x):
  return math.log2(x)

l1 = [10, 20, 30, 40]           # base list
print(l1)

l2 = l1.copy()                  # copy of list
scale_list(double_it, l2)       # double elements
print(l2)                       

l3 = l1.copy()                  # copy of list
scale_list(halve_it, l3)        # halve elements
scale_list(log2_it,  l3)        # log2() elements
print(l3)


