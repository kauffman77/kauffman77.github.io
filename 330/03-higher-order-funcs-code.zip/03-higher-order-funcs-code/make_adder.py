
# See: https://peps.python.org/pep-0227/

# work-around using "containers" (references) to affect a lexical
# closure
def make_summer_arr():
    cur = [0]
    def summer(x):
        cur[0] += x
        return cur[0]
    return summer
sum0 = make_summer_arr()
print(sum0(6))

# the more natural means to do so does not work
def make_summer():
    cur = 0
    def adder(x):
        cur += x
        return cur
    return adder
sum0 = make_summer()
print(sum0(6))

# a stock example that works due to 'base' not being modified
def make_adder(base):
    def adder(x):
        return base + x
    return adder
add5 = make_adder(5)
print(add5(6))
