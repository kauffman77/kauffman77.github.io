# lambda_demo.py: demonstrates basic syntax of lambda expressions to
# create anonymous one-liner functions in Python.

def double_it1(x):                     # standard func binding
  return 2*x

double_it2 = lambda x: 2*x             # lambda binding
#  NAME      LAMBDA EXPRESSION 

alist = [1,2,3,4,5]

print(list(map(double_it1, alist)))    # call w/ standard func
# [2, 4, 6, 8, 10]

print(list(map(double_it2, alist)))    # call w/ lambda func
# [2, 4, 6, 8, 10]

print(list(map(lambda y: 2*y, alist))) # call w/ lambda directly 
# [2, 4, 6, 8, 10]

print(list(map(lambda x: x+1, alist))) # call w/ different lambda
# [2, 3, 4, 5, 6]

import math                            # call with different lambda
print(list(map(lambda x: math.log2(x), alist)))
# [0.0, 1.0, 1.584962500721156, 2.0, 2.321928094887362]

