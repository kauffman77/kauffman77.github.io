# nested_scope.py: basic demo of python's nested function scopes. This
# allows use of nested "inner" functions as "helpers" for a
# computation which is sometimes convenient. The functions
# 'inner_func1()' and 'inner_func2()' are nested within 'outer_func()'
# and are not accessible outside of the context of running
# 'outer_func()'.  While running, each of the inner functions has
# acces to the local variables within 'outer_func()' such as 'oarg'
# and 'oloc'.

def outer_func(oarg):                      # outer function
  # oloc = "q"

  def inner_func1(iarg):                   # 1st nested inner function
    iloc = "j"                             # nested local variable
    print(f"inner_func1():")
    print(f"  iloc:{iloc} iarg:{iarg}")
    print(f"  oloc:{oloc} oarg:{oarg}")
    return 1

  def inner_func2(iarg):                   # 2nd nested inner function
    iloc = "k"                             # nested local variable
    print(f"inner_func2():")
    print(f"  iloc:{iloc} iarg:{iarg}")
    print(f"  oloc:{oloc} oarg:{oarg}")
    return 2

  oloc = "q"                               # local variable to outer
  r1 = inner_func1("x")                    # call 1st inner func
  oloc = "u"                               # alter outer local var
  r2 = inner_func2("y")                    # call 2nd inner func
  # print(iloc)                            # error: inner scopes not visible from outer
  return r1+r2


r = outer_func("a")                        # from modul cope, call outer func
print(r)

# shell>> python nested_scope.py
# inner_func1():
#   iloc:j iarg:x
#   oloc:q oarg:a
# inner_func2():
#   iloc:k iarg:y
#   oloc:u oarg:a
# 3
