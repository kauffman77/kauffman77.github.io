from more_itertools import *

words = ["apple","banana","apricot","grape","artichoke"]
consume(side_effect(lambda x: print(x),words))

alist=[]
consume(side_effect(lambda x: alist.append(x),words))
print(alist)                    # copy of words
