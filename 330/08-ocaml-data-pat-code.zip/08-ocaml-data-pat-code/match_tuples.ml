(* match_tuples.ml: examples of pattern matching with tuples *)
open Printf;;

let has_meaning pair =
  match pair with
  | (42,42) -> "full of meaning"
  | (42,_)  -> "meaning first"       (* _ : don't care / ignore *)
  | (_,42)  -> "meaning second"
  | _       -> "there is no meaning"
;;
let print_meaning a b c =
  match a,b,c with              (* create tuple for pat-match *)
  | 4,2,_                       (* both patterns use same action *)
  | _,4,2 -> printf "There is meaning\n";
  | x,y,z -> printf "%d %d %d have no meaning\n" x y z;
;;               (* x,y,z wild cards: match anything *)

