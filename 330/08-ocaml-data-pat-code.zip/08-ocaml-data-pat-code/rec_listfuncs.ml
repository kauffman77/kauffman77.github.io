(* rec_listfuncs.ml : recursive functions on lists *)

(* Count the number of elements in a linked list *)
let rec list_length list =
  if list = [] then                     (* base case: empty list *)
    0                                   (* has length 0 *)
  else                                  (* recursive case *)
    let rest = List.tl list in          (* peel of tail *)
    let len_rest = list_length rest in  (* recursive call *)
    let ans = 1 + len_rest in           (* add on for current elem *)
    ans                                 (* return as answer *)
;;

(* terse version of the above *)
let rec list_length list =
  if list = [] then                     (* base case *)
    0
  else
    1 + (list_length (List.tl list))    (* recursive case *)
;;

(* Count how many times elem appears in lst *)
let rec count_occur elem lst =
  if lst = [] then
    0
  else
    let first = List.hd lst in
    let rest  = List.tl lst in
    let rest_count = count_occur elem rest in
    if elem = first then
      1 + rest_count
    else
      rest_count
;;

(* commented version of the above *)
let rec count_occur elem lst =
  if lst = [] then                            (* base case: empty list *)
    0                                         (* 0 occurrences *)
  else                                        (* recursive case *)
    let first = List.hd lst in                (* peel of head *)
    let rest  = List.tl lst in                (* and tail of list *)
    let rest_count = count_occur elem rest in (* count occurences in rest *)
    if elem = first then                      (* if current elem matches *)
      1 + rest_count                          (* add 1 and return *)
    else                                      (* otherwise *)
      rest_count                              (* count in rest of lsit *)
;;


(* Create a new list which has list1 followed by list2; the builtin @
   operator does this via list1 @ list2; it functions similarly to the
   below version *)
let rec append_lists list1 list2 =
  if list1 = [] then                    (* base case: nothing in list1 *)
    list2                               (* just list2 *)
  else                                  (* recursive case *)
    let first = List.hd list1 in        (* get first and rest of list1 *)
    let rest  = List.tl list1 in        
    let app_rest =                      (* answer for rest of list *)
            append_lists rest list2 in  (* recursive call *)
    let app_all = first :: app_rest in  (* cons on first elem to rest *)
    app_all
;;

(* terse version of the above *)
let rec append_lists list1 list2 =
  if list1 = [] then
    list2
  else
    (List.hd list1)  ::  (append_lists (List.tl list1) list2)
(*   |---first---| |Cons|               |---rest----|         *)
(*                        |--------recursive call----------|  *)
;;

(* Print the number the index and element for a string list. Uses a
   nested recursive helper function. *)
let print_elems_idx strlist =
  let rec helper i lst =                (* recursive helper: 2 params *)
    if lst != [] then                   (* if any list left *)
      let first = List.hd lst in        (* grab first element *)
      let rest =  List.tl lst in        (* and rest of list *)
      Printf.printf "index %d : %s\n" i first;    (* print  *)
      helper (i+1) rest                 (* recurse on remaining list *)
  in                                    (* end helper definition *)
  helper 0 strlist;                     (* call helper starting at 0 *)
;;

(* Create a list of the elements between the indices start/stop in the
   given list. Uses a nested helper function for most of the work. *)
let elems_between start stop list =
  let rec helper i lst =
    if i > stop then
      []
    else if i < start then
      helper (i+1) (List.tl lst)
    else
      let first = List.hd lst in
      let rest =  List.tl lst in
      let sublst = helper (i+1) rest in
      first :: sublst
  in
  helper 0 list
;;

(* Commented version of the above *)

let elems_between start stop list =      (* int -> int -> 'a list            *)
  let rec helper i lst =                 (* int -> 'a list -> 'a list        *)
    if i > stop then                     (* case for after stop index        *)
      []                                 (* end of possible elems between    *)
    else if i < start then               (* before the start index           *)
      helper (i+1) (List.tl lst)         (* recurse further along lst        *)
    else                                 (* case of start <= i <= stop       *)
      let first = List.hd lst in         (* get head and tail                *)
      let rest =  List.tl lst in                                             
      let sublst = helper (i+1) rest in  (* recurse further to get sublst    *)
      first :: sublst                    (* cons first onto sublst, return   *)
  in                                     (* end helper definition            *)
  helper 0 list                          (* call helper at beginning of list *)
;;
