(* match_execise.ml: several in-class exercises for match/with to
   practice techniques and expand. *)

(* return true if a and be are not the same booleans  *)
let xor a b =
  match a,b with
  | true,false
  | false,true -> true
  | _ -> false
;;

(* recursive fibonacci using match, will stack overflow on negative
   args *)
let rec fib n =
  match n with
  | 0 -> 0
  | 1 -> 1
  | n -> (fib (n-1)) + (fib (n-2))
;;


(* fib using match, checks for negaive arguments in general case via
   if/then *)
let rec fib_safe n =
  match n with
  | 0 -> 0
  | 1 -> 1
  | n ->
     if n > 1 then
       (fib (n-1)) + (fib (n-2))
     else
       failwith "Negative argumet to fib"
;;

(* failwith "string" : raises a general exception with the given
   message that halts execution of the function; if the exception is
   uncaught it terminates the program *)

(* fib using a guard to check for negative args *)
let rec fib_guard n =
  match n with
  | 0 -> 0
  | 1 -> 1
  | n when n>1 -> (fib (n-1)) + (fib (n-2))
  | _ -> failwith "Negative argumet to fib"
;;
