(* rec_funcs.ml : example recursive functions *)

(* sum the numbers 1 to n using recursion *)
let rec sum_1_to_n n =
  if n=1 then                            (* base case, reached 1 *)
    1                                    (* return 1 *)
  else                                   (* recursive case *)
    let below = n-1 in                   (* start point for nums below *)
    let sum_below = sum_1_to_n below in  (* recurse on nums below *)
    let ans = n+sum_below in             (* add on current n  *)
    ans                                  (* return as answer *)
;;

(* terse version of the same function *)
let rec sum_1_to_n n =
  if n=1 then
    1                                    (* base case *)
  else
    n + (sum_1_to_n (n-1))               (* recursive case *)
;;

(* print numbers in a given range *)
let rec print_range start stop =
  if start <= stop then
    begin
      Printf.printf "%d\n" start;
      print_range (start+1) stop
    end;
;;
