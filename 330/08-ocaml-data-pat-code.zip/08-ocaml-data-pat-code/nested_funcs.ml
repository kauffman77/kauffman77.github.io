(* nested_funcs.ml : demonstrate nested functions *)

(* Return the sum of two factorials. Uses an internal function
   definition to compute factorials of parameters. *)
let sum_factorials n m =

  (* compute factorial recursively *)
  let rec fact i =              (* local recursive function *)
    if i<=1 then
      1                         (* base case *)
    else
      i * (fact (i-1))          (* recursive case *)
  in                            (* end local function definition *)

  let nfact = fact n in         (* call fact on n*)
  let mfact = fact m in         (* call fact on m *)
  nfact+mfact                   (* return sum of factorials *)
;;                              
(* end of function scope: fact no longer available *)
(* sum_factorials IS available, top-level binding *)

(* Calculates the nth Fibonacci number. Uses a recursive helper
   function for efficiency *)
let fibonacci n =
  let rec fib_helper i n1 n2 =      (* mocks iteration with i *)
    if i=n then                     (* found answer *)
      n1+n2                         (* return sum of last two *)
    else                            (* otherwise *)
      fib_helper (i+1) (n1+n2) n1   (* move ahead an iter updating locals *)
  in
  if n=0 then                       (* check for initial cases *)
    0
  else if n=1 then
    1
  else                              (* start helper otherwise *)
    fib_helper 2 1 0
;;
