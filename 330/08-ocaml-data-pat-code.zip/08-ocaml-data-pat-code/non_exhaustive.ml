(* non_exhuastive.ml: Omitting the last case means there are data
   patterns which have no associated case. OCaml compiler can detec
   these ane complains loudly about them. *)
open Printf;;

let print_meaning a b c =
  match a,b,c with
  | 4,2,_
  | _,4,2 -> printf "There is meaning\n";
  (* | x,y,z -> printf "%d %d %d have no meaning\n" x y z; *)
;;

print_meaning 4 2 0;;
print_meaning 1 2 3;;
print_meaning 9 4 2;;

(*

>> ocamlc non_exhaustive.ml
File "non_exhaustive.ml", lines 8-10, characters 2-41:
 8 | ..match a,b,c with
 9 |   | 4,2,_
10 |   | _,4,2 -> printf "There is meaning\n";
Warning 8 [partial-match]: this pattern-matching is not exhaustive.
Here is an example of a case that is not matched:
(4, 4, 0)

>> ./a.out
There is meaning
Fatal error: exception Match_failure("non_exhaustive.ml", 8, 2)

*)
