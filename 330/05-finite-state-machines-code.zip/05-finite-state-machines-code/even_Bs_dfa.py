# even_Bs_dfa.py: demonstrates encoding the Even-Bs DFA as a small
# data structure in python and shows a primitive dfa matching routine
# which can use such a data structure to detect matches.

# Even-Bs DFA #1 as a data structure
even_Bs_dfa = {
  "alphabet":{"a","b"},
  "nstates":4,                  # no need for "names"
  "start":1,
  "accept":{3},
  "trans":[{},                  # transitions array, leave 0 blank
           {"a":1,"b":2},       # each element is a dictionary
           {"a":2,"b":3},       # of input to new state 
           {"a":3,"b":4},       # with one list entry per state
           {"a":4,"b":3}],      # ex: trans[4]["b"] is 3
}

# Simple matching routine for data encoded like the above DFA.
def dfa_match(dfa,instr):        
  state = dfa["start"]           # get start state
  trans = dfa["trans"]           # alias for transition table
  for i in instr:                # iterate over input characters
    if not i in dfa["alphabet"]: # check if char is in alphabet
      return "Error"             # error if not
    state = trans[state][i]      # set new state via transition table
  if state in dfa["accept"]:
    return "Accept!"
  else:
    return "Reject"
  


instr = input("Enter a string of a's and b's to check:\n")
print(f"Entered: {instr}")
result = dfa_match(even_Bs_dfa,instr)
print(result)
