// even_Bs_dfa.c: Shows a relatively efficient DFA code realization
// that accepts the "Even-Bs" set of strings.  The use of Labels and
// Gotos along with switch/case constructs in DFA code is not strictly
// needed BUT compiles to extremely efficient execution and is usually
// what automated tools such as Lex/Yacc generate.

// function that returns 1 for strings in Even-Bs, 0 for a,b strings
// NOT in Even-Bs, and -1 if strings are not in the accepted alphabet
// (e.g. not comprised of solely a,b characters).
int even_Bs_dfa(char *input){
  int pos=-1;
 S1:
  pos++;
  switch(input[pos]){
    case 'a':  goto S1;
    case 'b':  goto S2;
    case '\0': goto REJECT;
    default:   goto ERROR;
  }
 S2:
  pos++;
  switch(input[pos]){
    case 'a':  goto S2;
    case 'b':  goto S3;
    case '\0': goto REJECT;
    default:   goto ERROR;
  }
 S3:
  pos++;
  switch(input[pos]){
    case 'a':  goto S3;
    case 'b':  goto S4;
    case '\0': goto ACCEPT;
    default:   goto ERROR;
  }
 S4:
  pos++;
  switch(input[pos]){
    case 'a':  goto S4;
    case 'b':  goto S3;
    case '\0': goto REJECT;
    default:   goto ERROR;
  }
 REJECT:
  return 0;
 ACCEPT:
  return 1;
 ERROR:
  return -1;
}
    
#include <stdio.h>

// Main function to prompt for a string and check if it is in Even-Bs
// or not.
int main(int argc, char *argv[]){
  printf("Enter a string of a's and b's to check:\n");
  char input[256];
  scanf("%s",input);
  printf("Entered: %s\n",input);
  int result = even_as_dfa(input);
  if(result == 1){
    printf("Accept!\n");
  }
  else if(result == 0){
    printf("Reject\n");
  }
  else if(result == -1){
    printf("Error: are all characters a's or b's?\n");
  }
  else{
    printf("Something unexpected happened...\n");
  }
  return 0;
}
