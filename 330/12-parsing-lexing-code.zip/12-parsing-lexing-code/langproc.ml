(* langproc.ml: covers basic processing of arithmetic expressions with
   numbers, + and *, and parentheses *)

open Printf;;

(* algebraic types for tokens: lexing results *)
type token =
  Plus | Times | OParen | CParen | Int of int;;

(* algebraic types for expression tree: parsing results *)
type expr =
  | Add of expr * expr
  | Mul of expr * expr
  | Const of int
;;


(* rote examples of input with expected output *)

let input = "5 + 10*4 + 7*(3+2)";;           (* Lexing: convert this string..  *)
let lexed = [Int 5; Plus; Int 10;            (* Into this stream of tokens *)
             Times; Int 4; Plus;
             Int 7; Times;
             OParen; Int 3; Plus;
             Int 2; CParen];;
let parsed =                                 (* Parsing: convert lexed tokens.. *)
  Add(Const(5),                              (* Into a data semantic structure *)
      Add(Mul(Const(10),                     (* in this case a tree reflecting the *)
              Const(4)),                     (* order in which expressions should  *)
          Mul(Const(7),                      (* be evaluated *)
              Add(Const(3),
                  Const(1)))))
;;

let evaluated = 76;;


(* returns true if the given character is a digit 0-9 and false
   otherwise *)
let is_digit c =
  let digits = "0123456789" in
  let loc = String.index_opt digits c in
  loc <> None
;;


let lex_string string =                      (* create a list of tokens  *)
  let len = String.length string in
  let rec lex pos =                          (* recursive helper *)
    if pos >= len then                       (* off end of string ? *)
      []                                     (* end of input *)
    else                                     (* more to lex *)
      match string.[pos] with                (* match a single character *)
      |' ' | '\t' | '\n' -> lex (pos+1)      (* skip whitespace *)
      |'+' -> Plus :: (lex (pos+1))          (* single char ops become operators *)
      |'*' -> Times :: (lex (pos+1))         (* like add and multiply *)
      |'(' -> OParen :: (lex (pos+1))        (* and open/close parens *)
      |')' -> CParen :: (lex (pos+1))
      | d when is_digit d ->                 (* see a digit *)
         let stop = ref pos in               (* scan through until a non-digit is found *)
         while !stop < len && is_digit string.[!stop] do
           incr stop;
         done;
         let numstr = String.sub string pos (!stop - pos) in (* substring is the int *)
         let num = int_of_string numstr in   (* parse the integer *)
         Int(num) :: (lex !stop)             (* and tack onto the stream of tokens *)
      | _ ->                                 (* any other characters lead to failures *)
         let msg = sprintf "lex error at char %d, char '%c'" pos string.[pos] in
         failwith msg
  in                                         (* end helper *)
  lex 0                                      (* call helper *)
;;

let lexed2 = lex_string input;;

(* Exception type in case of parse error *)
exception ParseError of {
    msg  : string;
    toks : token list;
};;

(* A parsing routine for lexed expressions like "5 + 10*4 +
   7*(3+2)". It parses the following CFG into an Abstract Syntax Tree:

   A -> A + A 
   A -> M
   M -> M * M 
   M -> N 
   N -> number
   N -> (A)

*)
let parse_tokens tokens =

  (* prec2: addition only *)
  let rec prec2 toks =
    let (lexpr, rest) = prec1 toks in   (* try higher prec first *)
    match rest with
    | Plus :: tail ->                   (* + is first *)
       let (rexpr,rest) = prec2 tail in (* recurse to get right-hand expr *)
       (Add(lexpr,rexpr), rest)         (* add left/right expr *)
    | _ -> (lexpr, rest)                (* not an addition *)

  (* prec1: multiplication *)
  and prec1 toks =
    let (lexpr, rest) = prec0 toks in   (* try higher prec first *)
    match rest with
    | Times :: tail ->                  (* * is first *)
       let (rexpr,rest) = prec1 tail in (* recurse to get right-hand expr *)
       (Mul(lexpr,rexpr), rest)         (* multiplyt left/right expr *)
    | _ -> (lexpr, rest)                (* not a multiply *)

  (* prec0: self-evaluating tokens like Int and parenthesized expressions *)
  and prec0 toks =
    match toks with
    | [] ->                                  (* out of input *)
       raise (ParseError {msg="expected an expression"; toks=toks})
    | Int n ::  tail ->                      (* ints are self-evaluating *)
       (Const(n),tail)
    | OParen :: tail ->                      (* parenthesized expresion *)
       begin
         let (expr,rest) = prec2 tail in     (* start back at lowest precedence *)
         match rest with
         | CParen::tail -> (expr,tail)
         | _ -> raise (ParseError {msg="unclosed parentheses"; toks=rest})
       end
    | _ ->
       raise (ParseError {msg="syntax error"; toks=toks})
  in

  (* end helpers, main code for parse_tokens *)
  let (expr, rest) = prec2 tokens in
  match rest with
  | [] -> expr
  | _  -> raise (ParseError{msg="tokens remain in stream";toks=rest})
;;

let lexed2 = [Int 5; Plus; Int 10; Times; Int 4; Plus; Int 7; Times;
              OParen; Int 3; Plus; Int 2; CParen];;

let parsed2 = parse_tokens lexed2;;

(* Evaluate AST of expressions to produce an integer result *)
let rec evaluate expr =
  match expr with
  | Const i -> i
  | Add(lexpr,rexpr) ->
     let lans = evaluate lexpr in
     let rans = evaluate rexpr in
     lans + rans
  | Mul(lexpr,rexpr) ->
     let lans = evaluate lexpr in
     let rans = evaluate rexpr in
     lans * rans
;;

(* full cycle of lex, parse, evaluate *)
let result = evaluate (parse_tokens (lex_string input));;

(* with use of '|>' threading operator (a.k.a reverse application) *)
let result = input |> lex_string |> parse_tokens |> evaluate;;
