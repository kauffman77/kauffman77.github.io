(* langproc_trace.ml: Identical functionality to langproc.ml but has
   parsing functions declared at the top level to enable tracing.  Try
   the following in a REPL:

   #use "langproc_trace.ml";;
   # #trace prec2;;
   # #trace prec1;;
   # #trace prec0;;
   # parse_tokens (lex_string "7*(3+2)");;

*)

open Printf;;

(**********************************************************************************)
(* LEXER *)

(* algebraic types for tokens: lexing results *)
type token =
  Plus | Times | OParen | CParen | Int of int;;

(* returns true if the given character is a digit 0-9 and false
   otherwise *)
let is_digit c =
  let digits = "0123456789" in
  let loc = String.index_opt digits c in
  loc <> None
;;

let lex_string string =                      (* create a list of tokens  *)
  let len = String.length string in
  let rec lex pos =                          (* recursive helper *)
    if pos >= len then                       (* off end of string ? *)
      []                                     (* end of input *)
    else                                     (* more to lex *)
      match string.[pos] with                (* match a single character *)
      |' ' | '\t' | '\n' -> lex (pos+1)      (* skip whitespace *)
      |'+' -> Plus :: (lex (pos+1))          (* single char ops become operators *)
      |'*' -> Times :: (lex (pos+1))         (* like add and multiply *)
      |'(' -> OParen :: (lex (pos+1))        (* and open/close parens *)
      |')' -> CParen :: (lex (pos+1))
      | d when is_digit d ->                 (* see a digit *)
         let stop = ref pos in               (* scan through until a non-digit is found *)
         while !stop < len && is_digit string.[!stop] do
           incr stop;
         done;
         let numstr = String.sub string pos (!stop - pos) in (* substring is the int *)
         let num = int_of_string numstr in   (* parse the integer *)
         Int(num) :: (lex !stop)             (* and tack onto the stream of tokens *)
      | _ ->                                 (* any other characters lead to failures *)
         let msg = sprintf "lex error at char %d, char '%c'" pos string.[pos] in
         failwith msg
  in                                         (* end helper *)
  lex 0                                      (* call helper *)
;;

(**********************************************************************************)
(* PARSER *)

(* algebraic types for expression tree: parsing results *)
type expr =
  | Add of expr * expr
  | Mul of expr * expr
  | Const of int
;;

(* Exception type in case of parse error *)
exception ParseError of {
    msg  : string;
    toks : token list;
};;

(* Define the functions for the recursive descent parser at the top
   level so they can be accessed in a #trace directive in the repl. *)

(* Begin mutually recursive function definitions which use let/rec/and
   syntax. NO TOP-LEVEL PARSE which shortens function call
   traces. Original order of return values as (expr, toklist) is
   reversed to be (toklist,expr) so it is easier to line up token
   lists in call/return traces. *)
let rec parse_tokens tokens =
  let (rest, expr) = prec2 tokens in
  match rest with
  | [] -> expr
  | _  -> raise (ParseError{msg="tokens remain in stream";toks=rest})

(* prec2: addition only *)
and prec2 toks =
  let (rest, lexpr) = prec1 toks in   (* try higher prec first *)
  match rest with
  | Plus :: tail ->                   (* + is first *)
     let (rest,rexpr) = prec2 tail in (* recurse to get right-hand expr *)
     (rest, Add(lexpr,rexpr))         (* add left/right expr *)
  | _ -> (rest, lexpr)                (* not an addition *)


(* prec1: multiplication *)
and prec1 toks =
  let (rest, lexpr) = prec0 toks in   (* try higher prec first *)
  match rest with
  | Times :: tail ->                  (* * is first *)
     let (rest,rexpr) = prec1 tail in (* recurse to get right-hand expr *)
     (rest, Mul(lexpr,rexpr))         (* multiplyt left/right expr *)
  | _ -> (rest, lexpr)                (* not a multiply *)

(* prec0: self-evaluating tokens like Int and parenthesized expressions *)
and prec0 toks =
  match toks with
  | [] ->                                  (* out of input *)
     raise (ParseError {msg="expected an expression"; toks=toks})
  | Int n ::  tail ->                      (* ints are self-evaluating *)
     (tail,Const(n))
  | OParen :: tail ->                      (* parenthesized expresion *)
     begin
       let (rest,expr) = prec2 tail in (* start back at lowest precedence *)
       match rest with
       | CParen::tail -> (tail,expr)
       | _ -> raise (ParseError {msg="unclosed parentheses"; toks=rest})
     end
  | _ ->
     raise (ParseError {msg="syntax error"; toks=toks})
;;
(* end of mutually recursive parsing function definitions *)

(**********************************************************************************)
(* EVALUATOR *)

(* Evaluate AST of expressions to produce an integer result *)
let rec evaluate expr =
  match expr with
  | Const i -> i
  | Add(lexpr,rexpr) ->
     let lans = evaluate lexpr in
     let rans = evaluate rexpr in
     lans + rans
  | Mul(lexpr,rexpr) ->
     let lans = evaluate lexpr in
     let rans = evaluate rexpr in
     lans * rans
;;

(* Sample input string *)
let input = "5 + 10*4 + 7*(3+2)";;

(* full cycle of lex, parse, evaluate *)
let result = evaluate (parse_tokens (lex_string input));;
