// show_it.rs: implement a generic function which accepts data with a
// certain Trait and operates on it.

#![allow(dead_code)]                      // annotation to silence warning on unused function
use std::fmt::{Display,Formatter,Result};  // import some standard types / traits

fn show_it<T:Display>(thing: T){ // accept any type with Display trait
  println!("The thing is {}",thing);
}

struct Omelet {                 // new datatype Omelet
  cook_time: f32, is_cooked: bool, ingredients: String,
}
impl Display for Omelet{        // (B) existing Trait Display, new datatype Omelet
  fn fmt(&self, f: &mut Formatter<'_>) -> Result {
    return write!(f,"Omelet{{ cook_time: {:.2}, is_cooked: {}, ingredients: {}}}",
                  self.cook_time, self.is_cooked, self.ingredients);
  }
}                               // allows Omelet to be println!()'d

fn main(){                      // show use of generic function
  show_it("Hello");
  show_it(1.234);
  show_it(Omelet{cook_time:1.0, is_cooked: false,
                 ingredients: "ham cheese".to_string()});
}

// Alternative syntaxes for constraining types
fn show_it2(thing: impl Display){
  println!("The thing is {}",thing);
}

fn show_it3<T>(thing: T)
where T: Display
{
  println!("The thing is {}",thing);
}
