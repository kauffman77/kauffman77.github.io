// rust_pointers.rs: demonstrate the basic syntax of rust
// references. In some select cases references must be derefed via *
// while in most cases derferencing is done automatically.

// refs to primitive types like i32 must be explicitly dereferenced
fn update_int(x: &mut i32){
  *x = *x+5;
}


// refs to struct types like String may be explicitly dereferenced but
// it is not conventional to do so; rather the * operator binds weekly
// so must be parenthesized. As well, the rust compiler supports
// automatic dereferencing on method invocation.
fn update_str(s: &mut String){
  (*s).push_str("All work and no play makes Jack a dull boy.\n");
  s.push_str("All work and no play makes Jack a dull boy.\n");
  // both of the above have the same effect
}

fn main() {
  let mut a = 0;
  for i in 0..3 {
    update_int(&mut a);
    println!("iter {i}: a is {a}");
  }  

  println!();

  let mut z = String::new();
  for i in 0..3 {
    update_str(&mut z);
    println!("iter {i}:\n{z}");
  }  
  
}  
