// vec_demo.rs: Demonstrate basic features of Vectors, Rust's
// most-used data structure. For folks accustomed to ArrayList's from
// Java, there is little new except the slicing features which allow
// borrowing contiguous portions of the vector.
fn main(){
  let mut v : Vec<i32> = Vec::new();   // required type annotation for new()
  v.push(10); v.push(20); v.push(30);  // extend vector
  let mut v2 = vec![10,20,30];         // vec! macro is commonly used
  
  v2[1] = 40;                          // standard [] indexing
  println!("v2[1]: {}", v2[1]);

  // Oh so many ways to iterate
  for x in &v2 {                       // implicit slice
    print!("{x} ");
  }
  println!();

  for x in &v2[..] {                   // explicit slice
    print!("{x} ");
  }
  println!();

  for x in v2.iter() {                 // explicit iterator
    print!("{x} ");
  }
  println!();

  for i in 0..v2.len(){                // traditional via range
    print!("v2[{i}]: {}  ",v2[i]);
  }    
  println!();
  for (i,x) in v2.iter().enumerate() { // iterator + index
    print!("v2[{i}]: {x}  ");
  }
  println!();

  // Vectors are Generic / Polymorphic; type annotation below is optional
  let vs1 : Vec<&str> = vec!["katz:","all","your","bass","..."];
  let vs2             = vec!["are:","belong","to","us"];
  for x in &vs1 {
    print!("{x} ");
  }
  for x in &vs2 {
    print!("{x} ");
  }
  println!();

  // SLICES: borrowed portions of vectors
  let v100: Vec<i32> = (0..100).collect(); // range to vector 
  println!("v100[50]: {}",v100[50]);

  let v20_40: &[i32] = &v100[20..40];  // slice of vector w/ explicit
  for x in v20_40 {                    // type annotation
    print!("{x} ");
  }
  println!();
  let v50_70 = &v100[50..70];          // slice omitting type annotation
  for x in v50_70 {
    print!("{x} ");
  }
  println!();

  let vs =                             // vector of primitive str
    vec!["katz:","all","your","bass","are","belong","to","us"];
  let sl_vs : &[&str] = &vs[1..4];     // slice of vector, type annotation optional
  for x in sl_vs {                     // iterate over slice
    print!("{x} ");
  }
  println!();
}
