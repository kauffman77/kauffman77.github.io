// impl_demo.rs: demonstrate Rust's impl construct to add "methods" to
// a struct. 
struct Omelet {                 // a new data type with fields
  cook_time: f32,               // floating point field
  is_cooked: bool,              // boolean field
  ingredients: String,          // string field
}

impl Omelet {                          // "methods" for Omelet struct

  fn new(ingr: &str) -> Omelet {       // construct an Omelet
    return Omelet{cook_time: 0.0,
                  is_cooked: false,
                  ingredients: String::from(ingr)};
  }

  fn cook(&mut self, time: f32){       // cook an omelet
    self.cook_time += time;            // note the first param: &mut self
    if self.cook_time >= 5.0 {         // which is assigned by the compiler
      self.is_cooked = true;           // to &mut Omelet based on the context
    }
  }
  // Above function could use the following prototype instead which
  // makes explicit the type of the first parameter; this style is not
  // used in favor of the compiler inference shown above
  // 
  // fn cook(self: &mut Omelet, time: f32){       // cook an omelet
}

impl Omelet{                                 // MORE functions for Omelet
  fn add_ingredient(&mut self, ingr: &str){  // add an ingredient
    self.ingredients.push_str(ingr);
  }
  fn is_overcooked(&self) -> bool {          // check for overcooked
    return self.cook_time > 8.0;             // no mutation so &mut not needed
  }
  fn denver_ingredients() -> &'static str {  // function that does not need
    return "ham cheese peppers";             // an Omelet instance to operate
  }                                          // akin to Java 'static' function
}                                            // &'static indicates str is constant

fn main(){
  let ingr = Omelet::denver_ingredients(); // invoke function in Omelet namespace
  let mut denver = Omelet::new(ingr);      // typical "constructor" invocation

  Omelet::cook(&mut denver, 0.25);     // direct invocation of cook() function
  denver.cook(0.25);                   // "dot" invocation of cook() function
  denver.add_ingredient(" mushrooms"); // "dot" invocation of function

  while !denver.is_overcooked() {      // literally overdo it
    denver.cook(0.5);
  }
  println!("cook_time: {}",denver.cook_time);
  println!("is_cooked: {}",denver.is_cooked);
  println!("ingredients: {}",denver.ingredients);
}
