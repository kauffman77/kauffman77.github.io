fn last_or_push<'a>(vec: &'a mut Vec<String>) -> &'a String {
    if let Some(s) = vec.last() { // borrows vec
        // returning s here forces vec to be borrowed
        // for the rest of the function, even though it
        // shouldn't have to be
        return s; 
    }
    
    // Because vec is borrowed, this call to vec.push gives
    // an error!
    vec.push("".to_string()); // ERROR
    vec.last().unwrap()
}

fn main(){


  let mut x = String::from("hello");
  let y = &mut x;
  println!("{}",y);
  x.push_str(" world");

  // let mut x = String::from("hello");
  // let y = &mut x;
  // x = String::from("goodbye");
  // y.push_str(" world");
  // println!("{}",y);
  // println!("{}",x);



  // let mut yipee = String::from("yipyipp");
  // let x = &mut yipee;
  // // let y = &mut yipee;

  // x.pop();
  // x.push_str(" hooray");
  // // y.push_str(" hooray");

  // print!("x = {}", x); 
  // // print!("x = {}, y = {}", x , y); 

  // // let x = String::from("hello");
  // // let y = &mut x;
  // // let mut y = 7;
  // // y += 2;
  // // println!("{}",y);
}
