// collatz.rs: an introductory rust example demonstrating a variety
// of its features. Compile/Run this via
// 
// >> rustc collatz.rs
// 
// >> ./collatz
// Collatz start val: 
// 10
// start: 10
// Step  Current
//   0    10
//   1     5
//   2    16
//   3     8
//   4     4
//   5     2
//   6     1
// Reached 1 after 6 iters
// 
// >> ./collatz
// Collatz start val: 
// apple
// thread 'main' panicked at collatz.rs:66:17:
// Bad int 'apple': invalid digit found in string
// note: run with `RUST_BACKTRACE=1` environment 
// variable to display a backtrace

use std::io;
// imports another "crate" (package) which is used to handle input

use std::str::FromStr;
// used to get at the i32::from_str() method to convert a string to
// int, one of two paths shown below the other being the obtuse
// instr.parse::<i32>()

const VERBOSE : bool = true;    
// module level variables, all caps to avoid compiler warnings

// collatz function: notice parameter and return types are
// required. i32 is a 32-bit signed integer (e.g. positive or
// negative).
fn collatz (start: i32, maxsteps: i32) -> (i32,i32) {
  let mut cur = start;                  // by default vars are immutable but 
  let mut step = 0;                     // 'mut' keyword adjusts this
  if VERBOSE {                          // no ( ) around conditions 
    println!("start: {start}");         // format substituion in prinln!() mcaro, most of the time...
    println!("Step  Current");
    println!("{step:3} {cur:5}");
  }
  while cur != 1 && step < maxsteps {
    step += 1;
    if cur % 2 == 0{
      cur = cur / 2;
    }
    else{
      cur = cur*3 + 1;
    }
    if VERBOSE {                        // using 'if(VERBOSE)' will cause the compiler to complain
      println!("{step:3} {cur:5}");
    }
  }
  (cur,step)                            // last value sans as semicolon (;) is the function return value
  // return (cur,step);                 // alternative explicit return
}
      
fn main() {                                                 // entry point for programs is main.rs
  println!("Collatz start val: ");
  let mut instr = String::new();                            // buffer to read into
  match io::stdin().read_line(&mut instr) {                 // attempt to read typed input
    Err(why) => panic!("Input failed: {}",why),             // fail on errors
    Ok(_) => {}                                             // proceed on an Ok()
  };
  instr.pop();                                              // removes trailing newline from instr[]
  let start = match i32::from_str(instr.as_str()) {         // attempt to convert string to int
    Err(why) => panic!("Bad int '{instr}': {}",why),        // fail on problems
    Ok(anint) => anint                                      // otherwise return the int
  };
  let (last,steps) = collatz(start, 500);                   // call collatz() func
  println!("Reached {last} after {steps} iters");           // print results
}

#[allow(dead_code)]                                         // annotation to silence warning on unused function
fn main2() {                                                // alternative style for "handling" errors
  println!("Collatz start val: ");                          // use of the .expect() method panics! on Err
  let mut instr = String::new();                            // buffer to read into
  io::stdin().read_line(&mut instr).expect("Input failed"); // read a typed input line into instr[]
  instr.pop();                                              // removes trailing newline from instr[]
  let start = instr.parse::<i32>().expect("Bad int");       // convert to an integer

  let (last,steps) = collatz(start, 500);                   // call collatz() func
  println!("Reached {last} after {steps} iters");           // print results
}
