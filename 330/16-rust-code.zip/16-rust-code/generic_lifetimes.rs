// generic_lifetimes.rs: 
// 
// from: https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html

fn main() {
  let string1 = String::from("abcd");
  let string2 = "xyz";

  let result = longest(string1.as_str(), string2);
  println!("The longest string is {}", result);

  different_lifetimes();
}

// // This version of longest fails to compile as the borrow checker is
// // concerned about the lifetimes of the refs going in and out
// 
// fn longest(x: &str, y: &str) -> &str {
//   if x.len() > y.len() {
//     x
//   } else {
//     y
//   }
// }

// This version of longest uses the notation 'a to denote a specific
// lifetimes for each of the refs. The 'a is assigned to the paramters
// x / y indicating that they have minimum lifetimes that are
// equal. It is also assigned to the return type so that it is known
// that what goes out will have an an equal minium lifetime to what
// goes in.
// 
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
  if x.len() > y.len() {
    x
  } else {
    y
  }
}

// a static string
static STAT_STRING : &'static str = "Who wants to live forever?";

// Simple reasoning about the meanaing of the 'a constraint falls down
// quickly. The longest() function indicates all parameters coming in
// have the "equal" lifetimes. However, in the example below:
// 
// - string1's lifetime is the duration of the function
// - STAT_STRING's lifetime is the entirety of the program (static lifetime)
// 
// These two lifetimes are NOT equal yet the code compiles and runs
// properly. The constraint 'a is best thought of as a specific
// lifetime and any vars with the 'a annotation have a minimum
// lifetime equal to or greater than 'a.
fn different_lifetimes() {
  let string1 = String::from("abcd");
  let result = longest(string1.as_str(), STAT_STRING);
  println!("The longest string is {}", result);
}
