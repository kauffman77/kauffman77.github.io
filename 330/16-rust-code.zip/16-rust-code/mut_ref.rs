// mut_ref.rs: When mutating a referenced value, the reference must be
// made mutable via &mu

fn add_some(vec: &mut Vec<i32>){
  for i in 1..=3 {
    vec.push(i);                // alters param vector
  }
}

fn main(){
  let mut v = vec![10,11];
  add_some(&mut v);             // pass with ability to mutate
  add_some(&mut v);             // and again
  println!("{:?}",v);           // use hand debug print formating
}
