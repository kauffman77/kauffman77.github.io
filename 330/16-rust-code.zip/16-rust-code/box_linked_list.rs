// box_linked_list.rs: Demos several new features of Rust required to
// get linking structures to work. These are Box: heap pointer type
// and the mem::replace() function for stealing ownership by supplying
// a replacement value.

#![allow(dead_code)]                          // silence unused function warnings

use std::mem;                                 // for the replace() function

enum Node {                                   // type for nodes in list
  Cons(i32, Box<Node>),
  Nil,
}
use Node::*;                                  // bare names Cons / Nil

struct List {                                 // type for list
  head: Node,
  len:  u32,
}

impl List {
  fn print_node(node: &Node){                 // recursive function to chase
    match node {                              // node links and print all elems
      Nil => {                                // match end of list
        println!();
      }
      Cons(data, box_tail) => {               // match data and recurse
        println!("{} ",data);
        Self::print_node(box_tail);           // annoying need to Self-reference
      }                                       // impl namespace
    }
  }

  fn print(&self){
    Self::print_node(&self.head);             // Self-reference required
  }

  // fn push(&mut self, data: i32){              // ERROR: ownership problems
  //   self.head =                               // assigning head BUT
  //     Cons(data, Box::new(self.head));        // assignment requires moving head first
  // }                                           // which fails borrow checker

  fn push(&mut self, data: i32){              // add element at head of list
    let stolen =                              // adjust ownership of head to stolen, 
      mem::replace(&mut self.head, Nil);      // head becomes Nil momentarily
    self.head = Cons(data, Box::new(stolen)); // assign head to newly allocated node
    self.len += 1;                            // update length
  }


  fn pop(&mut self) -> Option<i32> {          // remove head element and return it or None
    let stolen =                              // steal the head making it Nil for a moment
      mem::replace(&mut self.head, Nil);      // so that it can be owned in match
    match stolen  {                           // match head node
      Nil => return None,                     // head was Nil so remains so
      Cons(data, box_next) => {               // head was Cons
        self.head = *box_next;                // set head to next node, deref needed
        self.len -= 1;                        // decrement length
        return Some(data);                    // return stolen data
      }
    }
  }
}

fn main() {
  let mut list = List {                       // create initial list with raw construciton
    head: Cons(3, Box::new(Cons(2, Box::new(Cons(1, Box::new(Nil)))))),
    len:  3,
  };
  list.print();                               // print list
  list.push(4);                               // push additional elements
  list.push(5);
  list.print();
  for _ in 0..3 {                             // loop and...
    let x = list.pop();                       // pop elements
    println!("popped {}",x.unwrap());
  }
  list.print();
}
