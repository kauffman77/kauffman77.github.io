// string_init.rs: various ways to intialize String data from
// primitive str data. There does not appear to be widely agreed upon
// canonical means to do this but all of the below are reasonable
// options.

fn main(){
  // let a : Vec<String> =
  //   vec!["hi",            // unsupported: &str requires conversion to String
  //        "bye",
  //        "aloha"]; 

  let b : Vec<String> =
    vec!["hi".to_string(),      // convert &str to String
         "bye".to_string(),
         "aloha".to_string()];

  let c : Vec<String> =
    vec!["hi".into(),           // convert &str to String
         "bye".into(),
         "aloha".into()];

  let d : Vec<String> =
    vec![String::from("hi"),    // init String from &str
         String::from("bye"),
         String::from("aloha")];

  // let e : Vec<String> =
  //   vec![String::new("hi"),     // new doesn't support an arg
  //        String::new("bye"),
  //        String::new("aloha")];


  let all : Vec<Vec<String>> = vec![b,c,d];
  for v in all {
    for s in v {
      println!("{s} ");
    }
    println!();
  }
}
