// c_mem_problems.c: illustrate a common problem in C which is to
// inadvertently free() a block of memory but continue to use it. This
// kind of problem is prevented in memory safe langauges like Java /
// OCaml by their use of a Garbage collector to de-allocate and in
// Rust by preventing ownership of memory block from transferring back
// and forth between locations (functions).

#include <stdio.h>
#include <stdlib.h>

void use_arr(int *arr, int len){ 
  printf("arr: [");
  for(int i=0; i<len; i++){     // print the array
    printf("%d ",arr[i]);
  }
  printf("]\n");
}

void use_up_arr(int *arr, int len){
  printf("arr: [");
  for(int i=0; i<len; i++){     // print the array
    printf("%d ",arr[i]);
  }
  printf("]\n");
  free(arr);                    // and free the array
}

int main(int argc, char *argv[]){
  int len = 5;
  int *a = malloc(sizeof(int) * len);
  for(int i=0; i<len; i++){
    a[i] = (i+1)*10;
  }

  use_arr(a,len);
  use_up_arr(a,len);
  use_arr(a,len);

  return 0;
}
