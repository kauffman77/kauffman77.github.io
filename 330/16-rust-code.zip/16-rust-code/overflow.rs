// overflow.rs: demonstrate Rusts emphasis on safety by intentionally
// overflowing and integer which will cause a panic.  This can be
// disabled via compile flags which are often used when building
// projects for "release" as checking for oveflows slows programs
// down. Compare against times for overflow.c compiled with/without
// such checks.

fn main() {
  let mut i : i32 = 1;
  while i > 0 {
    i += 1;
  } // loop ends when i overflows to become negative
  println!("i is {i}");
}

// # default is to check for overflow and panic
// >> rustc overflow.rs
// >> time ./overflow
// thread 'main' panicked at overflow.rs:6:5:
// attempt to add with overflow
// note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
//
// real 0m6.144s          # checks cost some time
// user 0m6.139s
// sys  0m0.000s
//
// # Compile with overflow checks disabled
// >> rustc -C overflow-checks=off overflow.rs
// >> time ./overflow
// i is -2147483648
//
// real 0m3.608s          # safety has its costs
// user 0m3.606s
// sys  0m0.001s
//
// There are are alternatives to blanket disabling of overflow checks
// such as using "wrap" types that are intended to overflow which
// won't be subject to these checks.
//
// Other languages like C take the opposite approach: overflow is
// "normal" but checks for it can be inserted by the compiler via
// options like:
//
// >> gcc -ftrapv overflow.c
