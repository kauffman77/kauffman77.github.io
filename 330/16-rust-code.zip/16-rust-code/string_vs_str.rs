// string_vs_str.rs: shows some of the overlap and differences between
// a primitive str which is a fixed length array of characters and the
// String struct which is meant to grow/shrink much like a Java
// StringBuffer.
// 
// str    methods: https://doc.rust-lang.org/std/primitive.str.html
// String methods: https://doc.rust-lang.org/std/string/struct.String.html

fn main(){
  let a = "hello world";                  // primitive str not meant to grow in size
  let b = String::from("hello world");    // standard String buffer of characters
  println!("a: {a}\nb: {b}");

  let mut c = "goodbye mut";              // both can be made mutable
  let mut d = String::from("goobye mut");
  println!("c: {c}\nd: {d}");

  c = "another string";                   // mutable allows altering
  d = String::from("Another string");     // binding associated with c/d
  println!("c: {c}\nd: {d}");

  // c[0] = 'A';                          // no raw indexing allowed as unicode chars are used which have 
  // d[0] = 'A';                          // varying widths and make raw indexing intractable 

  for (i,ch) in c.chars().enumerate() {   // iterate over characters in a str
    println!("c[{i}]: {ch}");             // .iter() pops of chars while
  }                                       // .enumerate() gives index,char pairs
  for (i,ch) in d.chars().enumerate() {   // likewise for characters in a String
    println!("d[{i}]: {ch}");
  }

  let cs1 : &str = &d[2..11];             // string slices work for both
  let cs2 : &str = &d[8..];               // str and String
  println!("cs1: {cs1}  cs2: {cs2}");     // Slices allow a "view" of part of the data
  let ds1 : &str = &d[2..11];
  let ds2 : &str = &d[8..];
  println!("ds1: {ds1}  ds2: {ds2}");

  let clen = c.len();                     // length methods for both str and String
  let dlen = d.len();
  println!("clen: {clen}  dlen: {dlen}");

  // c.push_str(" again");      // no ability to grow a str
  d.push_str(" again");         // methods for String
  println!("c: {c}\nd: {d}");

  // c.replace_range(0..1,"And ");  // no supported method as str isn't meant to grow
  d.replace_range(0..0,"And ");     // grow


  with_a_str(&c);                         // types match
  with_a_str(&d);                         // automatic conversion from Str->str via .as_str()
  
  //with_a_string(&c);                    // no automatic conversion: compiler error
  with_a_string(&d);                      // types match

}

fn with_a_str(v: &str){                   // accept a str
  println!("v: {v}");
}

fn with_a_string(v: &String){             // accept a String
  println!("v: {v}");
}
