// vec_ownership.rs: Examples of ownership with container types like
// vectors.  Demos how data added to a vec become owned by it so
// previous bindings lose ownership. Also demos common mistakes such
// as following how following compiler hints doesn't always fix
// problems.

fn main(){
  //////// A ////////
  let s = String::from("abc");  // string is born
  let mut v = vec![];           // vec is born
  v.push(&s);                   // string ref from vec
  println!("s: {s}");           // okay as a ref is passed
  println!("v[0]: {}",v[0]);    // okay as s is in scope

  //////// B ////////
  let s = String::from("abc");  // string is born
  let mut v = vec![];           // vec is born
  v.push(s);                    // vec now owns string
  // println!("s: {s}");        // ERROR: s lost ownership
  println!("v[0]: {}",v[0]);    // okay as v owns string

  use_make_vec();
  use_vec_ref();
}

//////// C ////////
fn make_vec() -> Vec<String>{   // CORRECT: return vec of String
  let s = String::from("abc");  // string is born
  let mut v = vec![];           // vec is born
  v.push(s);                    // string moves into vec, vec owns it
  return v;                     // safe to return
}
fn use_make_vec() {
  let v = make_vec();
  println!("v[0]: {}",v[0]);
}

// //////// D ////////
// fn make_vec() -> Vec<&String>{  // ERROR: unable to resolve types
//   let s = String::from("abc");  // string is born within function
//   let mut v = vec![];           // vec is born
//   v.push(&s);                   // ref to string from vec, string still owned by s
//   return v;                     // ERROR: returning from func would de-allocate s
// }                               // but refs remain to it in v
// fn use_make_vec() {
//   let v = make_vec();
//   println!("v[0]: {}",v[0]);
// }

// //////// E ////////
// fn make_vec() -> Vec<&'static String>{  
//   let s = String::from("abc");  // for (D), compiler suggests adding &'static
//   let mut v = vec![];           // which is a "lifetime" for the string. This 
//   v.push(&s);                   // does not help in this case as the fundamental
//   return v;                     // error is that s's String needs to be owned by 
// }                               // the escaping vector
// fn use_make_vec() {
//   let v = make_vec();
//   println!("v[0]: {}",v[0]);
// }

//////// F ////////
fn vec_ref(s: &String) -> Vec<&String>{ // string owned from elsewhere
  let mut v = vec![];                   // vec is born
  v.push(s);                            // vec refers to string, doesn't own it
  return v;                             // safe to return as string isn't owned by v
}  
fn use_vec_ref(){
  let s = String::from("abc");  // string is born
  let v = vec_ref(&s);
  println!("v[0]: {}",v[0]);
}
