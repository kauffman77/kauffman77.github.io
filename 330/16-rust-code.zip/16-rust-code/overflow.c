#include <stdio.h>
int main() {
  int i = 1;
  while(i > 0) {
    i += 1;
  } // loop ends when i overflows to become negative
  printf("i is %d",i);
}
