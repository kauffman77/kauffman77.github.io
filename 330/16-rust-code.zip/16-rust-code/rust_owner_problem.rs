// rust_owner_problems.rs: illustrate how rust prevents the problems
// that C has: the vector a when passed to a function, is then owned
// by the function and cannot come back from it.

fn use_arr(arr: Vec<i32>){      // arr is owned
  print!("arr: [");
  for x in arr{
    print!("{x} ");
  }
  println!("]");
}                               // arr is dropped

fn use_up_arr(arr: Vec<i32>){   // arr is owned
  print!("arr: [");
  for x in arr{
    print!("{x} ");
  }
  println!("]");
}                               // arr is dropped

fn main(){
  let len = 5;
  let mut a = vec![];
  for i in 0..len {
    a.push((i+1)*10);
  }
  use_arr(a);                   // ownership lost
  use_up_arr(a);                // compiler error
  use_arr(a);
}
