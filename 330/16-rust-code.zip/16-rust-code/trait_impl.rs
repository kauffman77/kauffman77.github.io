// trait_impl.rs: Demonstrate implementatin of a simple Trait for
// existing types. This allows existing types to have their
// functionality expanded.  There is a major restriction to this
// extension.
//
// Syntax is covered and examples are given for each of the following
// cases (including (D) which does not compile
// 
// |---+--------+--------+-----+-----------------------------------|
// |   | Trait  | Type   | Ok? | Notes                             |
// |---+--------+--------+-----+-----------------------------------|
// | A | New    | New    | Yes | Can implement MyTrait for MyData  |
// | B | Exists | New    | Yes | Can implement Iterator for MyData |
// | C | New    | Exists | Yes | Can implement MyTrait for i32     |
// | D | Exists | Exists | No  | Cannot implement Iterator for i32 |
// |---+--------+--------+-----+-----------------------------------|

struct Omelet {                 // new datatype Omelet
  cook_time: f32,
  is_cooked: bool,
  ingredients: String,
}

impl Omelet {                    // "methods" for Omelet
  fn new(ingr: &str) -> Omelet {    
    return Omelet{cook_time: 0.0,
                  is_cooked: false,
                  ingredients: String::from(ingr)};
  }

  fn cook(&mut self, time: f32){
    self.cook_time += time;
    if self.cook_time >= 5.0 {
      self.is_cooked = true;
    }
  }
}

trait Updateable {              // a new trait Updateable
  fn update(&mut self);
}

impl Updateable for Omelet {    // (A) new Trait Updateable, new type Omelet
  fn update(&mut self){
    self.cook(0.25);            // update an Omelet by cooking it a bit
  }
}
    
impl Iterator for Omelet{       // (B) existing Trait Iterator, new datatype Omelet
  type Item = ();               // iterator returns unit, denoted ()
  fn next(&mut self) -> Option<Self::Item> { // required "method" for Iterator
    if self.is_cooked {                      // when cooked, stop iterating
      return None;
    }
    else {
      self.cook(0.5);           // iterate by cooking a little and returning
      return Some(());          // some of unit
    }
  }
}

use std::fmt::{Display,Formatter,Result};  // import some standard types / traits

impl Display for Omelet{        // (B) existing Trait Display, new datatype Omelet
  fn fmt(&self, f: &mut Formatter<'_>) -> Result {
    return write!(f,"Omelet{{ cook_time: {:.2}, is_cooked: {}, ingredients: {}}}",
                  self.cook_time, self.is_cooked, self.ingredients);
  }
}                               // allows Omelet to be println!()'d

impl Updateable for i32 {       // (C) new Trait Updateable, existing type i32
  fn update(&mut self){
    *self = *self + 1;
  }
}

impl Updateable for String {    // (C) new Trait Updateable, existing type String
  fn update(&mut self){
    self.push('_');
  }
}

// impl Iterator for String {      // (D) exiting Trait Iterator, existing type String
//   type Item = char;             // ERROR: this case is not allowed by rust
//   fn next(&mut self) -> Option<Self::Item> {
//     return self.pop();          // return Some(last_char) or None
//   }
// }

// impl Iterator for i32 {         // (D) exiting Trait Iterator, existing type i32
//   type Item = i32;              // ERROR: this case is not allowed by rust
//   fn next(&mut self) -> Option<Self::Item> {
//     if self > 0 {
//       let cur: i32 = *self;
//       self -= 1;
//       return Some(cur);
//     }
//     else{
//       return None;
//     }
//   }
// }

fn main(){                         // demo some usage
  let mut omelet = Omelet::new("feta tomato");
  for _ in 1..5 {               
    omelet.update();               // update an omelet repeatedly
    println!("omelet: {}",omelet); // print the omelet via Display
  }

  let mut count = 0;
  for _ in 1..10{
    count.update();                // repeatedly update an integer
    println!("count: {count}");
  }

  let mut string = String::new();
  for _ in 1..10{
    string.update();               // repeteadly update a String
    println!("string: {string}");
  }

  for _ in &mut omelet {           // iterate on omelet
    println!("Iterating on omelet");
    // println!("omelet: {}",&omelet);   // ERROR: mut ref to omelet already owned above
  }
  println!("Finished omelet: {}",omelet);

  // // Following code seems plausible but due to Rust's need to know all
  // // sizes at compile time, it will not work. It demonstrates that
  // // simple uses of Traits to try to do dynamic dispatch are not
  // // possible in Rust and instead one must jump through additional
  // // hoops.
  // let vec : Vec<dyn Updateable> = vec![count,string];
  // for _ in 1..10{
  //   for x in vec.iter(){
  //     x.update();
  //   }
  // }
  // println!("vec[0]: {}",vec[0]);
  // println!("vec[1]: {}",vec[1]);
}
  
