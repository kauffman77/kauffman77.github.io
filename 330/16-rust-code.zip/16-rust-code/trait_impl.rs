// trait_imple.s: Demonstrate implementatin of a simple Trait for
// existing types. This allows existing types to have their
// functionality expanded.  There is a major restriction to this
// extension.
//
// |--------+--------+-----+-----------------------------------|
// | Trait  | Type   | ??  | Notes                             |
// |--------+--------+-----+-----------------------------------|
// | New    | New    | Yes | Can implement MyTrait for MyData  |
// | Exists | New    | Yes | Can implement Iterator for MyData |
// | New    | Exists | Yes | Can implement MyTrait for i32     |
// | Exists | Exists | No  | Cannot implement Iterator for i32 |
// |--------+--------+-----+-----------------------------------|


// A. Implement a New Trait for an Existing Type
// B. Implement an Existing Type for a New

trait Updateable {
  fn update(&mut self);
}

impl Updateable for i32 {
  fn update(&mut self){
    *self = *self + 1;
  }
}

impl Updateable for String {
  fn update(&mut self){
    self.push('_');
  }
}


fn main(){
  let mut count = 0;
  for _ in 1..10{
    count.update();
    println!("count: {count}");
  }

  let mut string = String::new();
  for _ in 1..10{
    string.update();
    println!("string: {string}");
  }

  // // Following code seems plausible but due to Rust's need to know
  // // all sizes at compile time, it will not work
  // 
  // let vec : Vec<dyn Updateable> = vec![count,string];
  // for _ in 1..10{
  //   for x in vec.iter(){
  //     x.update();
  //   }
  // }
  // println!("vec[0]: {}",vec[0]);
  // println!("vec[1]: {}",vec[1]);
  
}
  
