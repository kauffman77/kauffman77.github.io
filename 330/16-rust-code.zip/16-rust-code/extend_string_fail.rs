// extend_string_fail.rs: demonstrates a failed attempt to extend the
// String data type with a new operation, forbidden by Rust.

impl String {
  // return true if unicode (wide) characters appear in the String
  fn has_unicode(&self) -> bool {
    return self.len() != self.chars().count();
  }
}

fn main(){
  let ascii = String::from("hello world");
  let utf8  = String::from("😃 Have nice Day!");

  println!("ascii has_unicode(): {}",ascii.has_unicode());
  println!("utf8  has_unicode(): {}",utf8.has_unicode());
}
// COMPILER ERRORS:
// >> rustc extend_string_fail.rs 
// error[E0116]: cannot define inherent `impl` for a type outside of the crate where the type is defined
//  --> extend_string_fail.rs:4:1
//   |
// 4 | impl String {
//   | ^^^^^^^^^^^ impl for type defined outside of crate.
//   |
//   = note: define and implement a trait or new type instead

// error: aborting due to previous error

// For more information about this error, try `rustc --explain E0116`.
