// two_mut.rs: Illustrate the rule of 1 mutable reference at a time
// for any memory cell. This code won't compile without commenting out
// the ERROR lines near the end.

fn update_ints(x: &mut i32, y: &mut i32){
  *x = *x+5;
  *y = *y+5;
}

fn add_ints(x: & i32, y: & i32) -> i32{
  let z = *x + *y;
  return z;
}

fn main(){
  let mut a = 10;
  let mut b = 20;
  update_ints(&mut a, &mut b);  // mutable refs to a and b
  println!("a: {a}  b: {b}");   // with ownership is retained in main()

  update_ints(&mut a, &mut b);  // again shared refs which allow
  println!("a: {a}  b: {b}");   // mutation

  let sum = add_ints(&a, &a);   // multiple immutable refs can exist
  println!("sum: {sum}");       // for a given memory cell

  // comment this line to allow compilation
  update_ints(&mut a, &mut a);  // ERROR: only 1 mutable ref for a can
  println!("a: {a}");           // exist at a time; this makes reasoning
}                               // about ownership and concurrency easier
