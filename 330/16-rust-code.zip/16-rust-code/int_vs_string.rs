fn main(){
  let x = 1;                    // original 1
  let y = x;                    // copied 1
  println!("x: {x}  y: {y}");   // x and y distinct 1's

  let s = String::from("hi");   // original "hi"
  let t = s;                    // "hi" stolen from s

  println!("s: {s}  t: {t}");   // s cannot be used here
}                               // ^^COMPILE ERROR
