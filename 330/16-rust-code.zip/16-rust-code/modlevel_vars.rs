// Demonstrats some module level variable syntax

const VERBOSE : bool = true;    
// module level variables, all caps to avoid compiler warnings

static SINT : i32 = 5;
const  CINT : i32 = 5;
// module level variables may be static or constant. Static keeps an
// actual memory location for the variable while Const may inline the
// specified value at various locations.

static FNAME : &'static str = "gettysburg.txt";
// str must be declared with a "lifetime" to indicate that, as a
// module-level variable, it will exist throghout the duration of the
// program. This is needed to satisfy the compiler which, without the
// lifetime declaration, would refuse this declaration indicating that
// the size of the str is not known. This is perplexing as C compilers
// have determining the sizes of fixed strings for about 40 years but
// perhaps rust will learn such skills as it grows up.
