// sorted_print.rs: failed attempt to implment a function which
// accepts any type of colletion and prints a sorted version. Type
// problems, wonky syntax, and lifetime issues abound here.  There is
// an analogous StackOverflow post from here 2020:
//   https://stackoverflow.com/questions/60678342/trying-to-write-a-generic-function-that-takes-and-uses-an-intoiterator-as-a-para
// BUT it is unanswered. Alas...

#![allow(dead_code)]            // annotation to silence warning on unused function

// sample code with where syntax for IntoIterator
fn find_min<'a, I>(vals: I) -> Option<&'a u32>
where
    I: IntoIterator<Item = &'a u32>,
{
    vals.into_iter().min()
}

// alternative code with constraint in angle brackets
// https://users.rust-lang.org/t/generic-iterator-with-specific-item-as-function-parameter/74731
fn analyze_items<'a, 'b: 'a>(collection: impl IntoIterator<Item = &'a &'b str>) {
  for item in collection {
    println!("{}", item);
  }
}

// compile errors
fn analyze_items2<'a, C, I>(coll: &'a C)
where
  C: IntoIterator<Item = &'a I>,
  I: Display + 'a
{  
  for item in coll.into_iter() {
    println!("{}", item);
  }
}


fn sorted_print<'a, T, I>(vals: T)
where
    T: IntoIterator<Item = &'a I>,
    I: Ord + Display + 'a
{
  for x in vals.into_iter(){
    println!("{}",x);
  }
}

// // Same problem
// // https://stackoverflow.com/questions/60678342/trying-to-write-a-generic-function-that-takes-and-uses-an-intoiterator-as-a-para
// // No answer
// fn sorted_print<'a, T, I>(vals: &T)
// where
//     T: IntoIterator<Item = &'a I>,
//     I: Ord + Display + 'a
// {
//   for x in vals.into_iter(){
//     println!("{}",x);
//   }
// }

fn sorted_print2<'a, T, I>(vals: T)
where
    T: IntoIterator,
    T::Item: Ord + Display + 'a
{
  for x in vals.into_iter(){
    println!("{}",x);
  }
}

// fn sorted_print<'a,T>(col: &'a T)
// where
//   T: IntoIterator + Clone,
//   T::Item: &'a Ord + Display
// {
//   let mut vec = vec![];
//   let iter = col.clone().into_iter();
//   for x in iter {
//     vec.push(&x);
//   }
//   vec.sort();
//   for x in vec {
//     println!("{x}");
//   }
// }

fn demo_sorted_print(){
  let jenny = vec![8,6,7,5,3,0,9];
  sorted_print(&mut jenny.iter());
}
  

fn main(){
  demo_show_it();
  demo_sorted_print();
}
