// struct_enum_demo.rs: demonstrate basic syntax of structs and enums,
// Rust's mechanism for adding new types

#![allow(dead_code)]            // don't warn about unused functions

struct Omelet {                 // a new data type with fields
  cook_time: f32,               // floating point field
  is_cooked: bool,              // boolean field
  ingredients: String,          // string field
}

fn use_omelet(){                // demonstrates use of Omelet type
  println!("===USE OMELET====");
  let om = Omelet {             // create an immutable Omelet
    cook_time: 2.5,
    is_cooked: false,
    ingredients: String::from("bacon cheddar")
  };                            // print out a field
  println!("om.ingredients: {}",om.ingredients);
  
  let mut mom = Omelet {        // create a fully mutable Omelet
    cook_time: 0.0,
    is_cooked: false,
    ingredients: String::from("spinach swiss")
  };
  mom.cook_time += 4.999;       // alter fields 
  mom.is_cooked = true;
  mom.ingredients.push_str(" mushroom");
  println!("mom.ingredients: {}",mom.ingredients);
  println!("mom.cook_time: {:.2}",mom.cook_time);
}

enum Breakfast {                // like OCaml's algebraic types, 4 variants of type
  None,                         // Variant with no additional data
  Meager(String),               // Variant with String data
  Hearty(Omelet),               // Variant with Omelet data
  Misc(u32,String)              // Variant with pair of u32 and String
}

use Breakfast::*;               // to use bare name of variants, bring them into namespace

// function that operates on Breakfast types
fn breakfast_count(br: &Breakfast) -> u32 {
  return match br {             // match on the variants of Breakfast
    None           => 0,                  
    Misc (count,_) => *count,   // read about * on your own time
    _              => 1         // all other variants 
  };
}

// demonstrate syntax / usage of Breakfast type
fn use_breakfast(){
  println!("===USE BREAKFAST====");
  // construct several variants
  let dog_br = Meager(String::from("kibble"));
  let md_br  = Misc(4,String::from("cups oatmeal"));
  let ck_br  =
    Hearty(Omelet{cook_time: 5.00,
                  is_cooked: true,
                  ingredients: String::from("ham swiss")});
  // Breakfast data can go into the same array
  let br_vec = vec![dog_br, md_br, ck_br, None ];
  for (i,x) in br_vec.iter().enumerate() {
    let desc = match x {        // iterate over array handling
      None      => "none",      // each variant and producing outpu
      Meager(_) => "meager",
      Hearty(_) => "hearty",
      Misc(_,_) => "misc",
    };
    let count = breakfast_count(&x);
    println!("{i}: {desc}, count: {count}");
  }
}
  

fn main(){
  use_omelet();
  use_breakfast();
}

// // Version with interesting ownership problem
// fn use_breakfast(){
//   let dog_br = Meager(String::from("kibble"));
//   let ck_br  = Hearty(Omelet{cook_time: 5.00,
//                              is_cooked: true,
//                              ingredients: String::from("ham swiss")});
//   let md_br  = Misc(4,String::from("cups oatmeal"));
//   let br_vec = vec![dog_br, ck_br, md_br];
//   for (i,x) in br_vec.iter().enumerate() {
//     let desc = match x {
//       None      => "none",
//       Meager(_) => "meager",
//       Hearty(_) => "hearty",
//       Misc(count,_)   => format!("{} misc",count),
//       // Above attempt to use format!() macro to create a string is a
//       // fascinating example of minor friction in Rust. The above
//       // branches of the match all result in a &str while format!()
//       // produces a String so the arms don't type-check.  Since
//       // format!() creates the String, it cannot be coerced to via
//       // as_str() since the String itself will go out of scope and
//       // borrowed &str would be de-allocated. The best I can tell, the
//       // only way to "fix" this is to change all other branches to
//       // String::from(..) calls.

//     };
//     println!("{i}: {desc}");
//   }
// }
