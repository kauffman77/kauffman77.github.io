// rust_owner_borrow.rs: fix the owner_problem via a borrow: pass a
// ref instead.

fn use_arr(arr: &Vec<i32>){ 
  print!("arr: [");             // arr borrowed
  for x in arr{
    print!("{x} ");
  }
  println!("]");
}                               // arr not dropped

fn use_up_arr(arr: &Vec<i32>){ 
  print!("arr: [");             // arr borrowed
  for x in arr{
    print!("{x} ");
  }
  println!("]");
}                               // arr not dropped

fn main(){
  let len = 5;
  let mut a = vec![];
  for i in 0..len {
    a.push((i+1)*10);
  }
  use_arr(&a);                  // ownership retained
  use_up_arr(&a);               // ownership retained
  use_arr(&a);                  // ownership retained
}                               // a is now dropped
