// ownership_basics: Shows 3 examples of ownership by passing values
// to a function several times. An integer example is given first
// followed by 3 variations on a string version which 

#[allow(dead_code)]

fn main(){
  show_add();
  show_append();
}

////////////////////////////////////////////////////////////////////////////////
// int add: works fine as int values are copied on passing them as
// values to a function. 
fn show_add() {                 // ALWAYS WORKS
  let a = 2;                    // allocate ints
  let b = 3;
  let ab = add2(a,b);           // pass ints as params
  let ba = add2(b,a);           // due to copying, retain ownership
  println!("{a} plus {b} is {ab}");
  println!("{b} plus {a} is {ba}");
}
fn add2(x: i32, y: i32) -> i32{
  let z = x+y;
  return z;
}

// ////////////////////////////////////////////////////////////////////////////////
// // string append Version 1: this version is fundamentally broken due
// // to the memory ownershp rules that rust imposes. The compiler will
// // reject it due to ownership problems.
// fn show_append() {              
//   let s = String::from("two");  // allocate strings
//   let t = String::from("three");
//   let st = append2(s,t);        // append2() assumes ownership of s and t
//   let ts = append2(t,s);        // ownership lost and compiler forbids re-use
//   println!("{s} plus {t} is {st}");
//   println!("{s} plus {t} is {ts}");
// }
// // accepting a String means that ownership of the string now belows to
// // this function. The memory associated with x,y is de-allocated at
// // the end of the function as these variables go out of scope.
// fn append2(x: String, y: String) -> String {
//   let mut z = String::new();
//   z.push_str(&x);
//   z.push_str(&y);
//   return z;
// }

////////////////////////////////////////////////////////////////////////////////
// string append Version 2: this version works by passing clones of
// the original string so that it is distinct
fn show_append() {              
  let s = String::from("two");  // allocate strings
  let t = String::from("three");
  let st = append2(s.clone(),t.clone()); // append2() gets its own copies
  let ts = append2(t.clone(),s.clone()); // of s and t
  println!("{s} plus {t} is {st}");
  println!("{s} plus {t} is {ts}");
}
fn append2(x: String, y: String) -> String {
  let mut z = String::new();
  z.push_str(&x);
  z.push_str("_");
  z.push_str(&y);
  return z;
}


// ////////////////////////////////////////////////////////////////////////////////
// // string append Version 3: this version uses the "reference"
// // designation in rust which allows sharing of information according
// // to controlled rules.
// fn show_append() {              
//   let s = String::from("two");  // allocate strings
//   let t = String::from("three");
//   let st = append2(&s,&t);        // append2() gets references to s/t
//   let ts = append2(&t,&s);        // show_append() retains ownership
//   println!("{s} plus {t} is {st}");
//   println!("{s} plus {t} is {ts}");
// }
// fn append2(x: &String, y: &String) -> String {
//   let mut z = String::new();    // params x,y are refs to String
//   z.push_str(&x);
//   z.push_str("_");
//   z.push_str(&y);
//   return z;
// }
