// move_errors.rs: A few simple data types in Rust implement the Copy
// trait or some equivalent.  This means the raw bits of the data are
// copied from one place to the next on binding a new name. Most other
// data in rust are copied via pointers to the stack/heap data
// associated with the type. A common example is String. These data
// "move" to the new binding so old names from them are lose ownership
// and are no longer valid. When copies of these are needed, the Clone
// trait with its .clone() method allow a distin, deep copy of the
// data to be made.

fn main(){
  let s : i32 = 5;              // s is a primitive i32 int
  println!("s: {s}");
  let t = s;                    // okay because i32 implements Copy trait
  println!("t: {t}");           // so bits of s are copied to t
  println!("s: {s}");           // okay as s is preserved

  let s : &str = "hello";       // s is a primitive str ref
  println!("s: {s}");
  let t = s;                    // okay because str refs are okay to share (?)
  println!("t: {t}");           // source unavailable as to why this one works alright
  println!("s: {s}");           // okay

  let s : String = String::from("hello");
  println!("s: {s}");           // s is a String: heap allocated which does NOT copy bits
  let t = s;                    // data has "moved" to t so s has lost ownership, uses of s are invalid
  println!("t: {t}");           // okay
  // println!("s: {s}");        // ERROR due to previous borrowing

  let s : String = String::from("hello");
  println!("s: {s}");
  let t = s.clone();            // create a deep copy of s associated with t
  println!("t: {t}");           // okay
  println!("s: {s}");           // okay
}    
