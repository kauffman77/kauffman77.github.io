// add_front.rs: demos a generic function

// generic on datatype T: constrains v / z to have a type relation
fn add_front<T>(v: &mut Vec<T>, z: T){
  v.push(z);
  v.rotate_right(1);
}
// The type constraint T indicates that this funciton works for any
// datatype so long as the input Vector and element match types


fn main() {
  let mut ivec = vec![3,4,5];
  add_front(&mut ivec, 2);      // call generic func with i32 vec
  add_front(&mut ivec, 1);
  println!("ivec: {:?}",ivec);

  let mut svec = vec!["c","d"];
  add_front(&mut svec, "b");    // call generic func with &str
  add_front(&mut svec, "a");
  println!("svec: {:?}",svec);
}
