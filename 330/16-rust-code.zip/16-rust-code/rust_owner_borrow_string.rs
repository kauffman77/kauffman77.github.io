// rust_owner_borrow_string.rs: variant of the owner borrow example
// but with strings.

fn use_arr(arr: &Vec<String>){ 
  print!("arr: [");             // arr borrowed
  for x in arr{
    print!("{x} ");
  }
  println!("]");
}                               // arr not dropped

fn use_up_arr(arr: &Vec<String>){ 
  print!("arr: [");             // arr borrowed
  for x in arr{
    print!("{x} ");
  }
  println!("]");
}                               // arr not dropped

fn main(){
  let a : Vec<String> =
    vec![String::from("hi"),    // init String from &str
         String::from("bye"),
         String::from("aloha")];

  use_arr(&a);                  // ownership retained
  use_up_arr(&a);               // ownership retained
  use_arr(&a);                  // ownership retained
}                               // a is now dropped
