"""A module that provides a spell checking routine for text files with
several ways to interact with it"""

import re                       # for regex
import sys                      # for command line args
import os                       # for getenv

debug = 0
debug = os.environ.get("DEBUG")

"""Set to nonzero to enable debugging messages in this module"""

def load_word_set(fname):
  """Load a dictionary of words from the given file into a set"""
  word_set = set()
  with open(fname) as file:
    for line in file:
      word_set.add(line[:-1])   # trim the newlines from words
  return word_set


def check_marking(word,thelocs):
  """Mark incorrect words with asterisks"""
  word_set = thelocs["word_set"]
  if word.lower() in word_set:
    return word
  else:
    return f"**{word}**" 
    
def check_interactive(word,thelocs):
  """Prompt for a replacement for a misspelled word and return it"""
  word_set = thelocs["word_set"]
  if word.lower() in word_set:
    return word
  corrected = input(f"correction for '{word}': ")
  return corrected

def check_ismart(word,thelocs):
  """Prompt for a replacement for a misspelled word and return it;
  giving empty strings will default to the original word"""
  word_set = thelocs["word_set"]
  if word.lower() in word_set:
    return word
  corrected = input(f"correction for '{word}' (empty accepts): ")
  if corrected=="":
    corrected = word
  return corrected

def check_icontext(word,thelocs):
  """Print a context for the misspelled word to make it easier to
  recognize it's intent; prompt for a replacement"""
  word_set = thelocs["word_set"]
  if word.lower() in word_set:
    return word
  contents = thelocs["contents"]
  wmatch = thelocs["wmatch"]
  width = 20
  before_word = contents[max(wmatch.start()-20,0):wmatch.start()]
  after_word = contents[wmatch.end():min(wmatch.end()+20,len(contents))]
  print(f"...{before_word}**{word}**{after_word}...")
  corrected = input(f"correction for '{word}' (empty accepts): ")
  if corrected=="":
    corrected = word
  return corrected


def spellcheck_file(fname, word_set, check_fun):
  """Spell check the named file creating a new copy of it with the
  .checked extension. word_set is a set of words that are correctly
  spelled which check_fun() is a function to call with each word to
  check it.
  """
  contents = ""
  with open(fname) as file:     # oft referred to as a "slurp", reads entire 
    contents = file.read()      # contents of file into a string
  if debug:
    print(f"The whole file:\n{contents}")
    
  # Iterate through the contents matching a regex for a word. Each
  # word is passed to the check_fun() with with local variables which
  # returns the "corrected" version of the word (original or not). The
  # new document is construted by creating a list with contents that
  # are chunks of the original doc between word matches interspersed
  # with the (possibly) corrected words.

  word_pattern = r"[A-z']+"     # regex to match words in the text, letters + quote
  modlist = []                  # list of modified tokens
  last_end = 0                  # where did the last regex end its match

  for wmatch in re.finditer(word_pattern, contents):    # iterate over the word matches
    modlist.append(contents[last_end:wmatch.start()])   # append content between last match and this one
    last_end = wmatch.end()                             # set the current end of match for the nex iter
    checked_word = check_fun(wmatch[0],locals())        # call check_fun() to get a replacement word
    modlist.append(checked_word)                        # append the new word to the growing doc
  modlist.append(contents[last_end:len(contents)])      # add chunk of data after the last match

  if debug:
    print("MODIFIED CONTENTS:")
    for mod in modlist:
      print(mod)
    modstr = "".join(modlist)
    print(f"MODIFIED STRING\n{modstr}")
    
  fname_checked = f"{fname}.checked"                 # name of new file for checked text
  with open(fname_checked,"w") as file:              # iterate over the list of modified text
    for x in modlist:                                # writing out each bit of text to the 
      file.write(x)                                  # file
  print(f"Spell check results in {fname_checked}")

  return None
                  
check_funcs = {
  "mark"        : check_marking,
  "interactive" : check_interactive,
  "ismart"      : check_ismart,
  "icontext"    : check_icontext,
}
"""Options for the checking function accepted on the command line"""

usage =f"""\
python spellcheck.py <file> <dict> <checkfun>
- file: a text file to spell check
- dict: a text file containing correctly spelled words
- checkfun: how are words checked, one of: {', '.join(check_funcs.keys())}
"""

def main():
  """main function to be run from command line invocation. Accepts
  input file, dictionary file and which function to use while
  checking. 

  """
  if len(sys.argv) < 3:
    print(usage)
    exit(1)
  fname = sys.argv[1]
  word_set_fname = sys.argv[2]
  check_fun_str = sys.argv[3]

  if debug:
    print(f"command line args: fname '{fname}' word_set_fname '{word_set_fname}' check_fun_str '{check_fun_str}'")

  word_set = load_word_set(word_set_fname)
  check_fun = check_funcs[check_fun_str]
  spellcheck_file(fname, word_set, check_fun)
    
if __name__ == "__main__":
  main()
