(* Returns min/max of a list as a pair. *)
let rec minmax list =
  match list with
  | [] -> failwith "empty list"      (* empty list fail *)
  | last :: [] -> (last,last)        (* base case: 1 element *)
  | head :: tail ->                  (* recursive case *)
     let (min,max) = minmax tail in  (* recurse, then match results *)
     match (head < min),(head > max) with
     | false,false -> (min,max)      (* head in the middle *)
     | true,false  -> (head,max)     (* head is smaller *)
     | false,true  -> (min,head)     (* head is bigger *)
     | true,true   -> (head,head)    (* both? stranger things... *)
;;
(* Same as above with tail recursiv helper function *)
let rec minmax list =
  match list with
  | [] -> failwith "empty list";     (* empty list fail *)
  | first :: rest ->                 (* peel off first element *)
     let rec help (min,max) lst =    (* define TR helper *)
       match lst with
       | [] -> (min,max)             (* end of list *)
       | head :: tail ->             (* keep going *)
          match (head < min),(head > max) with
          | false,false -> help (min,max)   tail
          | true,false  -> help (head,max)  tail
          | false,true  -> help (min,head)  tail
          | true,true   -> help (head,head) tail
     in
     help (first,first) rest;;       (* call helper *)
;;
