(* fruits.ml: demonstration of a simple algebraic type in OCaml *)

type fruit =                         (* create a new type *)
    Apple | Orange | Grapes of int;; (* 3 value kinds possible *)

let a = Apple;;                       (* bind a to Apple *)
let g = Grapes(7);;                   (* bind g to Grapes *)

let count_fruit f =                   (* function of fruit *)
    match f with                        (* pattern match f *)
    | Apple ->  1                       (* case of Apple *)
    | Orange -> 1                       (* case of Orange *)
    | Grapes(n) -> n                    (* case of Grapes *)
;;
