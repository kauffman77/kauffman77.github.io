(* myref.ml: shows example code of how the ref, !, and := operators
   are created via a record with a mutable field. *)

(* Type for a mutable ref *)
type 'a myref = {mutable contents : 'a};;

(* Create a myref, same as the ref function *)
let make_ref x =
  {contents = x};;

(* Dereference a reference *)
let deref myref =
  myref.contents;;

(* Define symbol to be the same function as above; prefix operator as above *)
let (!) myref =
  myref.contents;;

(* Define an assignment function *)
let assign myref x =
  myref.contents <- x;;

(* Define symbol to be same as above; infix op same as default *)
let (:=) myref x =
  myref.contents <- x;;

open Printf;;

(* a 'main' bit of code which demonstrates use of myref *)
let _ =
  let a = make_ref 5 in
  printf "a has contents %d\n" !a;
  a := 7;
  printf "a has contents %d\n" !a;
  a := (!a) * 2;
  printf "a has contents %d\n" !a;
  let b = make_ref "hi" in
  printf "b has contents '%s'\n" !b;
  b := (!b) ^ " and bye";
  printf "b has contents '%s'\n" !b;
;;
