(* alg_trees.ml: Show basic definitions for trees *)

(* BINARY TREES: Trees are not built into OCaml but they are easily
   defined using Algebraic data types *)

type strtree =
  | Bottom                              (* no more tree *)
  | Node of string * strtree * strtree  (* data with left/right tree *)
;;
let empty  = Bottom;;
let single = Node ("alone",Bottom,Bottom);;
let small  = Node ("Mario",
                   Node("Bowser",
                        Bottom,
                        Node("Luigi",Bottom,Bottom)),
                   Node("Princess",Bottom,Bottom));;
                 



let left_right = Node ("root",
                       Node("lefty",Bottom,Bottom),
                       Node("righty",Bottom,Bottom));;

let bigger =
  Node("a",
       Node("b",
            Bottom,
            Node("c",
                 Node("d",
                      Bottom,
                      Bottom),
                 Node("e",
                      Bottom,
                      Bottom))),
         Node("f",
              Node("g",
                   Bottom,
                   Bottom),
              Bottom))
;;

let rec count_nodes tree =
  match tree with
  | Bottom -> 0
  | Node (_,left,right) ->
     1 + (count_nodes left) + (count_nodes right)
;;

let counts =
  [("empty",       (count_nodes empty));
   ("single",      (count_nodes single));
   ("small",       (count_nodes small));
   ("left_right",  (count_nodes left_right));
   ("bigger",      (count_nodes bigger));
  ];;


(************************************************************************)
(* Revamp the tree to use an anonymous record that allows fields to be
   given names like `left` and `data` to improve readability *)
type fieldtree =
  | Bot                            (* no fields *)
  | Nod of {data : string;         (* anonymous record with data *)
            left : fieldtree;      (* left and *)
            right : fieldtree}     (* right fields *)
;;

let field_small =                  (* establish a small tree using the above type *)
  Nod {data="Mario";
       left= Nod{data ="Bowser";
                 left =Bot;
                 right=Nod{data="Luigi"; left=Bot; right=Bot}};
       right=Nod{data="Princess"; left=Bot; right=Bot}}
;;

let rec count_nodes_f ftree =
  match ftree with
  | Bot -> 0
  | Nod n ->
     let lcount = count_nodes_f n.left in
     let rcount = count_nodes_f n.right in
     1 + lcount + rcount
;;


let rootdata =                     (* assign data from root node *)
  match field_small with
  | Bot -> ""
  | Nod(n) -> n.data
;;


(************************************************************************)
(* LEXING/PARSING *)

(* Types associated with lexed/parsed input *)
type tokens =
  Plus | Times | OParen | CParen | Int of int;;
type expr =
  | Add of expr * expr
  | Mul of expr * expr
  | Const of int
;;


let input = "5 + 9*4 + 7*(3+1)";;  (* Lexing: convert this string..  *)
let lexed = [Int 5; Plus; Int 9;   (* Into this stream of tokens *)
             Times; Int 4; Plus;
             Int 7; Times;
             OParen; Int 3; Plus;
             Int 1; CParen];;
let parsed =                       (* Parsing: convert lexed tokens.. *)
  Add(Const(5),                    (* Into a data semantic structure *)
      Add(Mul(Const(9),            (* in this case a tree reflecting the *)
              Const(4)),           (* order in which expressions should  *)
          Mul(Const(7),            (* be evaluated *)
              Add(Const(3),
                  Const(1)))))
;;
