(* records_demo.ml: show basic syntax associated with records *)

type hobbit = {name : string; age : int};;
let sam = {name="Samwise Gamgee"; age=21};;
let bilbo = {name="Bilbo Baggins"; age=111};;


(* a list of hobbits *)
let hobs = [
    {name="Frodo";  age=23};
    {name="Merry";  age=22};
    {name="Pippin"; age=25};
];;




type ring = {
    number : int; 
    power  : float;
    owner  : string;
};;

let nenya = {number=2; power=5000.2; owner="Galadriel"};;
let one = {number=1; power=infinity; owner="Sauron"};;


(* demo "with" syntax for field replacement *)
let old_sam = {sam with age=100};;
let lost_one = {one with owner="Bilbo"; power=1575.1};;

(* new type with changeable name but fixed age *)
type mut_hob = {mutable m_name : string;
                age  : int};;

(* example mutable hobbits *)
let h = {m_name="Smeagol"; age=25};;

(* mutate a field *)
h.m_name <- "Gollum";;

(* a list of mutable hobbits *)
let hobs = [
    {m_name="Frodo";  age=23};
    {m_name="Merry";  age=22};
    {m_name="Pippin"; age=25};
];;

(* DEFINE: creates a new list of mut_hob with all ages incremented by 1 *)
let rec hobbit_bdays (list : mut_hob list) =
  match list with
  | [] -> []
  | hob :: tail ->
     {hob with age=hob.age+1} :: (hobbit_bdays tail)
;;

(* DEFINE: name of each hobbit has the string "Fellow" prepended to it so 
   that "Frodo" becomes "Fellow Frodo" *)
let rec hobbit_fellowship (list : mut_hob list) =
  match list with
  | [] -> ()
  | hob :: tail ->
     hob.m_name <- "Fellow "^hob.m_name;
     hobbit_fellowship tail;
;;
       
(* a list of older hobbits gotten by applying the hobbit_bdays to the above list *)
let older_hobs = hobbit_bdays hobs;;

(* modified older_hobs list so that names all have "Fellow" prepended *)
hobbit_fellowship older_hobs;;
