(* Return the longest string and its
   length from the list given. If the
   list is empty return ("",0) *)
let longest_string strlist =
  let rec help (max_str,max_len) list =
    match list with
    | [] -> (max_str,max_len)
    | str :: tail ->
       let len = String.length str in
       if len > max_len then
         help (str,len) tail
       else
         help (max_str,max_len) tail
  in
  help ("",0) strlist
;;

(* Use of when guards to further analyze cases; requires repeated
   String.length calls which are constante time by annoying. *)
let longest_string strlist =
  let rec help (max_str,max_len) list =
    match list with
    | [] -> (max_str,max_len)
    | str :: tail when (String.length str) > max_len ->
       help (str,(String.length str)) tail
    | str :: tail ->
       help (max_str,max_len) tail
  in
  help ("",0) strlist
;;

(* Use of "as" keyword: decompose 1st argument into pair
   max_str,max_len AND ALSO refer to whole pair as "max". This avoids
   re-allocating / re-constructing the argument pair on each iteration
   which will increase execution efficiency if a concern. *)
let longest_string strlist =
  let rec help ((max_str,max_len) as max) list =
    match list with
    | [] -> max                 (* pass in current pair *)
    | str :: tail ->
       let len = String.length str in
       if len > max_len then
         help (str,len) tail
       else
         help max tail
  in
  help ("",0) strlist
;;



