(* thisthat.ml: demonstration of an algebraic type with 2 type
   parameters. Examples here start to show how flexible and
   sophisticated the type system is in ML. *)

type ('a, 'b) thisthat = This of 'a | That of 'b;;
(* Two type parameter are associated with thisthats, the type of the
   first and the type of the second. While the type parameters are
   paired, actual values are singular, one of the two types associated
   with the thisthat. *)

let ttlist = [This 5; That "str"; This 2; That "flurbo"];;
(* val ttlist : (int, string) thisthat list =
 *   [This 5; That "str"; This 2; That "flurbo"] *)


let x = This 5;;
(* val x : (int, 'a) thisthat = This 5 *)
(* Since there is no associated That, the second type parameter is
   free and can be used in any context that the first parameter is
   bound to int *)

let y = That "string";;
(* val y : ('a, string) thisthat = That "string" *)
(* Similar to the above except that the first type parameter is free *)

let xylist = [x;y];;
(* val xylist : (int, string) thisthat list = [This 5; That "string"] *)
(* Putting these two into a list makes the list fills in both type
   params for the list *)

let z = That true;;
(* val z : ('a, bool) thisthat = That true *)
(* Like y, the first type parameter is free *)

let xzlist = [x;z];;
(* val xzlist : (int, bool) thisthat list = [This 5; That true] *)
(* x is still polymorphic so can be put in a list with z with the
   resulting list having (int, bool) combinations while the previous
   xylsit had (int, string) combinations *)
