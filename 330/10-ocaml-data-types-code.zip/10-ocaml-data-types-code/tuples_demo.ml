(* tuples_demo.ml: demonstrate basic tuple usage *)

let int_pair = (1,2);;

let mixed_triple = (1,"two",3.0);;

let mixed_pair = ("a",5);;

let a = fst mixed_pair;;
let five = snd mixed_pair;;

let one =
  match mixed_triple with
  | (a,b,c) -> a
;;

let three_pt_0 =
  match mixed_triple with
  | (a,b,c) -> c;;

(* Pattern match a pair of booleans,
   return a relevant string *)
let boolpair_str bpair =
  match bpair with
  | true,true   -> "all true"
  | false,false -> "all false"
  | true,false
  | false,true  -> "mixed bag"
;;

(* Pattern match a pair of lists to
   determine which is longer *)
let rec longer_list lista listb =
  match lista,listb with
  | [],[] -> "same length"
  | _,[]  -> "a is longer"
  | [],_  -> "b is longer"
  | (a::atail),(b::btail) ->
     longer_list atail btail
;;
