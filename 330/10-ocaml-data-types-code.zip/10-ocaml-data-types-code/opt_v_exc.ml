(* opt_v_exc.ml: compare use of options vs exceptions in a main loop
   which searches association lists. Searching for something not in in
   the assocition list is handled by the option list but causes crash
   for the exception version.  Will cover exception handling later. *)
open Printf;;

let h = "herbivore";;
let c = "carnivore";;
let o = "omnivore";;
let alist = ["aardvark",h; "dingo",o; "bear",o; "lion",c; "deer",h];;
let continue = ref true;;

let _ =

  continue := true;

  printf "Using options\n";
  while !continue = true do
    printf "Enter animal name or 'next loop': ";
    let line = read_line () in
    if line="next loop" then
      continue := false
    else
      let result = List.assoc_opt line alist in          (* assoc_opt: *)
      match result with
      | Some k -> printf "'%s' is a '%s'\n" line k       (* found *)
      | None   -> printf "Don't know about '%s'\n" line  (* not found *)
  done;

  continue := true;

  printf "\n";
  printf "Using options\n";
  while !continue = true do
    printf "Enter animal name or 'next loop': ";
    let line = read_line () in
    if line="next loop" then
      continue := false
    else
      let result = List.assoc line alist in              (* assoc: *)
      printf "'%s' is a '%s'\n" line result              (* found *)
  done;                                                  (* not found raises an exception *)
;;

(* Sample session:
  > ocaml ocamlc opt_v_exc.ml 
  > a.out
  Using options
  Enter animal name or 'next loop': aardvark
  'aardvark' is a 'herbivore'
  Enter animal name or 'next loop': bear
  'bear' is a 'omnivore'
  Enter animal name or 'next loop': human
  Don't know about 'human'
  Enter animal name or 'next loop': hawk
  Don't know about 'hawk'
  Enter animal name or 'next loop': dingo
  'dingo' is a 'omnivore'

  Using Exceptions
  Enter animal name or 'next loop': next loop
  Enter animal name or 'next loop': aardvark
  'aardvark' is a 'herbivore'
  Enter animal name or 'next loop': bear
  'bear' is a 'omnivore'
  Enter animal name or 'next loop': human
  Fatal error: exception Not_found
*)
