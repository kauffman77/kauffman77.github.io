(* algebraic_types.ml: demonstration of algebraic types in OCaml *)

type fruit =                         (* create a new type *)
    Apple | Orange | Grapes of int;; (* 3 value kinds possible *)

let a = Apple;;                       (* bind a to Apple *)
let g = Grapes(7);;                   (* bind g to Grapes *)

let count_fruit f =                   (* function of fruit *)
    match f with                        (* pattern match f *)
    | Apple ->  1                       (* case of Apple *)
    | Orange -> 1                       (* case of Orange *)
    | Grapes(n) -> n                    (* case of Grapes *)
;;

(* Establish a type that is either an int or string *)
type age_name =
  | Age  of int                 (* Age constructor takes an int *)
  | Name of string              (* Name constructor takes a string  *)
;;

(* Construction of individual age_name values   *)
let i = Age 21;;                 (* construct an Age with data 21 *)
let s = Name "Sam";;             (* construct a Name with data "Sam" *)
let j = Age 15;;

(* age_name list to demonstrate how they are the same type and can
   therefore be in a list together. *)
let mixed_list = [
    Age 1;
    Name "Two";
    Age 3;
    Name "Four";
];;

(* Sum all the Age data in the given age_name list *)
let rec sum_ages list =
  match list with
  | [] -> 0                     (* base case *)
  | (Age i)::tail ->            (* have an age with data i *)
     i + (sum_ages tail)        (* add i onto recursive call *)
  | _ :: tail ->                (* must be a Name *)
     sum_ages tail              (* don't add anything *)
;;

(* call the above function *)
let sum = sum_ages mixed_list;;

(* Sum the "lengths" of Ages and Names. Length of an Age is 1; Length
   of a Name is the string length of the associated data.  *)
let rec sum_lengths list =
  match list with
  | [] -> 0
  | (Age _)::tail ->                          (* don't need data for age *)
     1 + (sum_lengths tail)                   (* add 1 onto total *)
  | (Name n) :: tail ->                       (* do need data for name *)
     (String.length n) + (sum_lengths tail)   (* add on length of name *)
;;
  
(* call the above function *)
let totlen = sum_lengths mixed_list;;


(* Returns a pair of integers; first element is how many times an Age
   occurs; the second is how many times a Name occurs *)
let rec age_name_count list =
  match list with
  | [] -> (0,0)
  | head::tail ->
    let (ages,names) = age_name_count tail in
    match head with
    | Age _ -> (1+ages, names)
    | Name _-> (ages, 1+names)
;;

(* call above function *)
let counts = age_name_count [Age 1; Age 3; Name "x"; Age 4];;
