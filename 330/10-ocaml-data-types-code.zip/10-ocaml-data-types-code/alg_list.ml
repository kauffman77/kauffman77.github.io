(* alg_lists.ml: Re-create standard lists with algebraic types. *) 

(************************************************************************)
(* INT LISTS ONLY: no type parameter so the only works for ints *)

type intlist =
  | Emptyi                      (* end of the int list *)
  | Consi of (int * intlist)    (* an int with more list *)
;;

(* construct an integer list *)
let ilist1 = Consi (1, Consi(2, Consi(3, Emptyi)));;

(* construct another integer list *)
let ilist2 = Consi (5, Consi(6, Consi(7, Consi(8, Emptyi))));;

(* function that sums all elements of an my_intlist *)
let rec sum_il list =
  match list with
  | Emptyi -> 0
  | Consi (head,tail) -> head + (sum_il tail)
;;

(* function that calculates the length of my_intlist *)
let rec length_il list =
  match list with
  | Emptyi -> 0
  | Consi (_,tail) -> 1 + (length_il tail)
;;


(************************************************************************)
(* GENERAL POLYMORPHIC LIST: has a type parameter so works with any
   type of data *)

type 'a mylist =                (* type parameter *)
  | Empty                       (* end of the list *)
  | Cons of ('a * 'a mylist)    (* an element with more list *)
;;

(* construct a string list *)
let list1 = Cons ("a", Cons("b", Cons("c", Empty)));;

(* construct a boolean list *)
let list2 = Cons (true, Cons(false, Cons(true, Cons(true, Empty))));;

(* function that calculates the length of a mylist *)
let rec length_ml list =
  match list with
  | Empty -> 0
  | Cons (_,tail) -> 1 + (length_ml tail)
;;
