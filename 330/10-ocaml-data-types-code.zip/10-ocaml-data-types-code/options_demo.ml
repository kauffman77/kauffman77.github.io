(* options_demo.ml: Demonstrate use of the option type in OCaml which
   is a polymorphic Algebraic type. *)

let iopt = Some 5;;             (* integer option *)
let bopt = Some false;;         (* boolean option *)

let stropt_list = [             (* string option list *)
    None; 
    Some "dude";
    Some "sweet"
];;

(* An association list *)
let alist = [("a",5);
             ("b",10)];;

(* Return the value associated with query key in association
   list alist.  Raises a Not_found exception if there is no
   association *)
let rec assoc query alist =
  match alist with
  | [] -> raise Not_found                     (* not found *)
  | (k,v)::tail when query=k -> v             (* found *)
  | _::tail -> assoc query tail               (* recurse deeper *)
;;

(* Find association of query key in given association
   list. Return (Some value) if found or None if not found. *)
let rec assoc_opt query alist =
  match alist with
  | [] -> None                                (* not found *)
  | (k,v)::tail when query=k -> Some v        (* found *)
  | _::tail -> assoc_opt query tail           (* recurse deeper *)
;;

(* Count how many times a (Some _) appears in a list of options *)
let rec count_some opt_list =
  match opt_list with
  | [] -> 0
  | None::tail -> count_some tail
  | (Some _)::tail -> 1 + (count_some tail)
;;


(* Sum all (Some i) options that appear in the list *)
let rec sum_some_ints opt_list =
  match opt_list with
  | [] -> 0
  | None::tail -> sum_some_ints tail
  | (Some i)::tail -> i + (sum_some_ints tail)
;;
