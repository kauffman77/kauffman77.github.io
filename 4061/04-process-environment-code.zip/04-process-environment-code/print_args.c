// Print all the arguments in the argv array. Prints a special message
// if option is --verbose.

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]){
  printf("%d args received\n",argc);
  for(int i=0; i<argc; i++){
    printf("%d: %s\n",i,argv[i]);
    if( strcmp(argv[i],"--verbose") == 0){
      printf("Turning on VERBOSE output\n");
    }
  }
  return 0;
}
