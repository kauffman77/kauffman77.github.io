#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){

  char *rock = getenv( "ROCK" );
  if( rock != NULL ){
    printf("ROCK is %s\n",rock);
    printf("Turning volume to 11\n");
    setenv("VOLUME", "11", 1);
  }
  else{
    printf("ROCK is not set\n");
  }

  char *volume = getenv("VOLUME");
  if(volume != NULL){
    printf("Volume is %s\n",volume);
  }
  else{
    printf("Volume is not set\n");
  }
  return 0;
}
