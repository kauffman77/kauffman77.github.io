<?php
if(array_key_exists("quote_num",$_POST)){
  $quote_num = $_POST["quote_num"];
  $start  = ($quote_num-1)*3+1;
  echo shell_exec(sprintf("sed -n '%d,%dp' quotes.txt",$start,$start+1)); 
}
else{
  echo "Looks like someone forgot to POST a quote_num";
}
echo "\n"
?>
