// hello.c: demonstrate I/O using a low-level system call, write().
// Note that there is no printf() and no #include <stdio.h> in this
// file. The standard C library is not used for output. Rather a
// system call is employed directly.

#include <unistd.h>             // header for write()

int main(){
  char *message = "Hello system call!\n";
  int length = 19;              // \n is one character
  int ret = write(STDOUT_FILENO, message, length);
  // Arguments to write() are
  // - STDOUT_FILENO: usually 1, file descriptor for standard output
  // - message: location of the bytes to write
  // - 19: number of bytes to write
  return ret;                   // will be 19 if all goes well
}
