// append_loop_oappend.c: Repeatedly append to the end of a
// file. Uses the O_APPEND flag to open() to guarnatee all write()'s
// append to a file. Precludes the need to coordinate multiple
// processes.
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  if(argc < 4){
    printf("usage: %s <filename> <count> <key>\n",
           argv[0]);
    return 1;
  }

  char *filename = argv[1];     // file to append
  int count = atoi(argv[2]);    // number of times to append
  int key = atoi(argv[3]);      // number "key" to append    

  int fd = open(filename,
                O_CREAT | O_RDWR    | O_APPEND, 
                S_IRUSR | S_IWUSR);// ^^^^^^^^ All writes append, no coordination required

  char line[128];               // create the line to be write()'n to the file
  sprintf(line,"%04d\n",key);
  int len = strlen(line);

  for(int i=0; i<count; i++){   // Loop to repeatedly append
    // lseek(fd, 0, SEEK_END);  // no need to lseek() due to O_APPEND flag
    write(fd, line, len);       // write a line; due to O_APPEND flag, always appends
  }

  close(fd);

  return 0;
}
