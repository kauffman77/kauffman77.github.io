// append_lockf_loop.c: uses a mandatory POSIX file lock to coorindate
// access to append to the file.
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  if(argc < 4){
    printf("usage: %s <filename> <count> <key>\n",
           argv[0]);
    return 1;
  }

  char *filename = argv[1];     // file to append
  int count = atoi(argv[2]);    // number of times to append
  int key = atoi(argv[3]);      // number "key" to append    

  int fd = open(filename, O_CREAT | O_RDWR , S_IRUSR | S_IWUSR);

  char line[128];               // create the line to be write()'n to the file
  sprintf(line,"%04d\n",key);
  int len = strlen(line);

  for(int i=0; i<count; i++){   // Loop to repeatedly append
    // begin critical region
    lockf(fd, F_LOCK, 0);       // lock whole file

    lseek(fd, 0, SEEK_END);     // seek to end of file
    write(fd, line, len);       // write a line

    lockf(fd, F_ULOCK, 0);      // unlock whole file
    // end critical region
  }

  close(fd);

  return 0;
}
