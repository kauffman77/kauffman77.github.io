// append_loop_sem.c: Repeatedly write to the end of a file but uses a
// semaphore to lock while doing a lseek()/write(). This ensures
// appends are atomic preventing data loss.
// 
// # COMPILE
// > gcc -g -o append_loop_sem append_loop_sem.c -lpthread   # link PThreads library
// 
// # RUN IN A LOOP
// > append_loop_sem -init 1 1
// > rm thefile.txt
// > for i in $(seq 10); do append_loop thefile.txt 100 $i & done 

#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  if(argc < 4){
    printf("usage: %s <filename> <count> <key>\n",
           argv[0]);
    return 1;
  }

  char *filename = argv[1];     // file to append
  int count = atoi(argv[2]);    // number of times to append
  int key = atoi(argv[3]);      // number "key" to append    

  char *sem_name = "/the_semaphore";   // global name for semaphore

  if(strcmp(filename, "-unlink")==0){  // allow deletion of semaphore
    printf("unlinking\n");             // when no longer needed
    sem_unlink(sem_name);
    return 0;
  }

  sem_t *sem =                         // abstract type for semaphore
    sem_open(sem_name, O_CREAT, S_IRUSR | S_IWUSR);
  // Note file-like semantics with sem_open(): name, flags, permissions;

  if(strcmp(filename, "-init")==0){ // must first initialize the semaphore 
    printf("initializing\n");       // before it can be used
    sem_init(sem, 1, 1);
    sem_close(sem);
    return 0;
  }


  int fd = open(filename, O_CREAT | O_RDWR , S_IRUSR | S_IWUSR);

  char line[128];               // create the line to be write()'n to the file
  sprintf(line,"%04d\n",key);
  int len = strlen(line);

  for(int i=0; i<count; i++){   // Loop to repeatedly append
    // begin critical region
    sem_wait(sem);              // Acquire semaphore
    lseek(fd, 0, SEEK_END);     // seek to end of file
    write(fd, line, len);       // write a line
    sem_post(sem);              // Release semaphore
    // end critical region
  }

  close(fd);
  sem_close(sem);               // close semaphore

  return 0;
}

// Semaphore may appear on the file system somewhere though this is
// not a POSIX requriement; on Linux /dev/shm/ exposes semaphores and
// shared memory segements.
