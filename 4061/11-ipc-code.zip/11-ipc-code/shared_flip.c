// shared_flip.c: demonstrates coordinating changes to a shared memory
// block using semaphores and dangers of what can happen if it is not
// done.  Run as follows.
// 
// > gcc -o shared_flip shared_flip.c -lrt -lpthread
// > ./shared_flip -init
// filling '/something_shared' with 64 chars of '0'
// > ./shared_flip -flip
// flipping bits
// > ./shared_flip -show
// segment contains: '111111111111111111111111111111111111111111111111111111111111111'
// > ./shared_flip -flip
// flipping bits
// > ./shared_flip -show
// segment contains: '000000000000000000000000000000000000000000000000000000000000000'
// 
// # RUN A LARGE NUMBER OF COMPETING PROCESSES, MAY TAKE SEVERAL TRIES
// > for i in $(seq 100); do ./shared_flip -flip & done
// ...
// # SHOW BROKEN OUTPUT
// > ./shared_flip -show
// segment contains: '100000000000000000000000000000000000000000000000000000001000000'
//
// > ./shared_flip -init
// # NEVER BREAKS OUTPUT DUE TO LOCKING
// > for i in $(seq 100); do ./shared_flip -lockflip & done
// > for i in $(seq 100); do ./shared_flip -innerlockflip & done
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <string.h>

#define SHM_SIZE 64                                     // byte size of shared memory

int main(int argc, char *argv[]) {
  if (argc < 2) {
    printf("usage: %s -init\n",argv[0]);
    printf("  initialize shared memory segment and semaphore\n");
    printf("usage: %s -show\n",argv[0]);
    printf("  print contents of shared memory segment\n");
    printf("usage: %s -flip\n",argv[0]);
    printf("  flip all 0's to 1's, 1's to 0's, no locking\n");
    printf("usage: %s -lockflip\n",argv[0]);
    printf("  flip all 0's to 1's, 1's to 0's, lock shared memory first\n");
    printf("usage: %s -innerlockflip\n",argv[0]);
    printf("  flip all 0's to 1's, 1's to 0's, lock shared memory first\n");
    printf("usage: %s -unlink\n",argv[0]);
    printf("  remove shared memory segment\n");
    exit(1);
  }

  char *shared_name = "/something_shared";
  char *sem_name = "/the_lock";
  if (argc == 2 && strcmp(argv[1],"-unlink")==0 ) {
    printf("removing shared memory\n");
    shm_unlink(shared_name);                              // unlink and remove the segment
    return 0;
  }

  int shared_fd =                                         // retrieve a file descriptor for shared memory
    shm_open(shared_name, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
  ftruncate(shared_fd, SHM_SIZE);                         // set the size of the shared memory area

  char *shared_bytes =                                    // map into process address space
    mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shared_fd, 0);
  close(shared_fd);

  if(0){}
  else if(strcmp(argv[1], "-show")==0){                       // -show : show current contents
    printf("segment contains: '%s'\n", shared_bytes);
  }
  else if (argc == 2 && strcmp(argv[1],"-init")==0) { // -init
    printf("filling '%s' with %d chars of '0'\n",
           shared_name, SHM_SIZE);
    for(int i=0; i<SHM_SIZE-1; i++){
      shared_bytes[i] = '0';
    }
    shared_bytes[SHM_SIZE-1] = '\0';

    sem_t *sem = sem_open(sem_name, O_CREAT, S_IRUSR | S_IWUSR);
    sem_init(sem, 1, 1);
    sem_close(sem);
  }
  else if (argc == 2 && strcmp(argv[1],"-flip")==0) { // -flip (unsafe, no locking)
    printf("flipping bits\n");
    // START1 critical region
    for(int i=0; i<SHM_SIZE-1; i++){
      // START2 critical region
      if(shared_bytes[i] == '0'){
        shared_bytes[i] = '1';
      }
      else if(shared_bytes[i] == '1'){
        shared_bytes[i] = '0';
      }
      // STOP2 critical region
    }
    // STOP1 critical region
  }
  else if (argc == 2 && strcmp(argv[1],"-lockflip")==0) { // -lockflip (safe via locking)
    sem_t *sem = sem_open(sem_name, 0, S_IRUSR | S_IWUSR);
    sem_wait(sem);                // lock semaphore
    printf("flipping bits\n");
    for(int i=0; i<SHM_SIZE-1; i++){
      if(shared_bytes[i] == '0'){
        shared_bytes[i] = '1';
      }
      else if(shared_bytes[i] == '1'){
        shared_bytes[i] = '0';
      }
    }
    sem_post(sem);                // unlock semaphore
    sem_close(sem);
  }
  else if (argc == 2 && strcmp(argv[1],"-innerlockflip")==0) {
    sem_t *sem = sem_open(sem_name, 0, S_IRUSR | S_IWUSR);
    printf("flipping bits\n");
    for(int i=0; i<SHM_SIZE-1; i++){
      sem_wait(sem);                // lock semaphore
      if(shared_bytes[i] == '0'){
        shared_bytes[i] = '1';
      }
      else if(shared_bytes[i] == '1'){
        shared_bytes[i] = '0';
      }
      sem_post(sem);            // unlock semaphore
    }
    sem_close(sem);
  }
  munmap(shared_bytes, SHM_SIZE);                         // unmap the shared meory

  return 0;
}
