#!/bin/bash
# Compares several approaches to atomically appending to files using
# various approaches to coordinate (or not)


echo Compiling

gcc -g -o append_loop          append_loop.c
gcc -g -o append_loop_sem      append_loop_sem.c  -lpthread
gcc -g -o append_loop_lockf    append_loop_lockf.c
gcc -g -o append_loop_oappend  append_loop_oappend.c

cmds=("append_loop" "append_loop_sem"     # bash array of commands to run
      "append_loop_lockf"   "append_loop_oappend")

append_loop_sem -init                     # initialize for the semaphore

nprocs=100                                # number of subprocesses 
nwrite=100                                # number of writes per process
file=thefile.txt

echo Timing each command with $nwrites children
echo

for cmd in "${cmds[@]}"; do               # loop over each command
    echo $cmd
    rm -f $file
    time  ( for i in $(seq $nprocs); do $cmd $file $nwrite $i & done )
    wc -l $file
    echo
    echo
done

