// shmdemo_posix.c: demonstrate posix shared memory segments, very
// similar to memory mapped files. Program creates a segement of
// shared memory called '/something_shared' and either reports its
// current contents or writes new contents to it.  On Linux, this
// shared segment looks like a regular file in
// 
// /dev/shm/something_shared
// 
// > gcc -o shmdemo shmdemo_posix.c -lrt

#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <string.h>

#define SHM_SIZE 64                                     // byte size of shared memory

int main(int argc, char *argv[]) {
  if (argc < 2) {
    printf("usage: %s -init\n",argv[0]);
    printf("  fill contents of shared memory\n");
    printf("usage: %s -show\n",argv[0]);
    printf("  print contents of shared memory segment\n");
    printf("usage: %s -watch\n",argv[0]);
    printf("  report shared memory contents every second\n");
    printf("usage: %s -delete\n",argv[0]);
    printf("  delete shared memory segment\n");
    printf("usage: %s <data> <pos>\n",argv[0]);
    printf("  write new contents of to shared memory segment to given position\n");
    exit(1);
  }

  char *cmd = argv[1];

  char *shared_name = "/something_shared";
  if (strcmp(cmd,"-delete")==0 ) {
    printf("removing shared memory\n");
    shm_unlink(shared_name);                              // unlink and remove the segment
    return 0;
  }

  int shared_fd =                                         // retrieve a file descriptor for shared memory
    shm_open(shared_name, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
  ftruncate(shared_fd, SHM_SIZE);                         // set the size of the shared memory area

  char *shared_bytes =                                    // map into process address space
    mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shared_fd, 0);
  close(shared_fd);

  if(0){}
  else if (strcmp(cmd,"-init")==0) {                      // -init : fill with dashes
    printf("filling '%s' with %d chars\n", shared_name, SHM_SIZE);
    for(int i=0; i<SHM_SIZE-1; i++){
      shared_bytes[i] = '-';
    }
    shared_bytes[SHM_SIZE-1] = '\0';
  }
  else if(strcmp(cmd, "-show")==0){                       // -show : show current contents
    printf("segment contains: '%s'\n", shared_bytes);
  }
  else if (strcmp(cmd,"-watch")==0 ) {                    // -watch memory, report every second
    while(1){
      printf("segment contains: '%s'\n", shared_bytes);   
      sleep(1);
    }
  }
  else if (argc == 3) {                                   // set memory
    int len = strlen(cmd);                                // cmd is string to set 
    int pos = atoi(argv[2]);                              // place cmd at argv[2] position
    printf("writing arg (len=%d) to position %d\n", len,pos);
    for(int i=0; i<len; i++){                             // modify the segment based on the command line
      shared_bytes[i+pos] = cmd[i];                       // copy characters into the shared memeory
    }
  }
  munmap(shared_bytes, SHM_SIZE);                         // unmap the shared meory

  return 0;
}
