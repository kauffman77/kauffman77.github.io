// ordered_fork.c: uses wait() to ensure parents finish after children
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
  printf("START:: pid: %d  parent_pid: %d\n", getpid(), getppid());
  for(int i=0; i<4; i++){
    pid_t pid = fork();
    if(pid != 0){
      wait(NULL);
    }
  }
  printf("FINISH: pid: %d  parent_pid: %d\n", getpid(), getppid());
  return 0;
}
