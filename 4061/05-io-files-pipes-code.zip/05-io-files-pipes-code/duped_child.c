// duped_chld.c: solution to in-class activity on redirecting output
// in child process.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char *argv[]){
  system("echo '' > write.txt");       // ensure file exists, is empty
  printf("BEGIN: Process %d\n",getpid());
  int fd = open("write.txt",O_WRONLY); // open a file
  int backup;
  pid_t child = fork();                // fork a child, inherits open file
  if(child == 0){                      // child only redirects stdout
    backup = dup(STDOUT_FILENO);       // make backup of stdout
    dup2(fd,STDOUT_FILENO);            // dup2() alters stdout so child printf() goes into file
  }
  printf("MIDDLE: Process %d\n",getpid());
  if(child == 0){
    dup2(backup,STDOUT_FILENO);        // restore stdout
  }
  printf("END: Process %d All done\n",getpid()); 
  close(fd);
  return 0;
}


