// write_read_ints.c: Demonstration of writing binary integer data to
// a file the reading it back.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>

#define COUNT 16

int main(int argc, char *argv[]){
  printf("0. Recreating empty integers.dat\n");
  system("echo '' > integers.dat");                     // ensures integers.dat present, empty initially
  char *outfile = "integers.dat";                       // make sure this file exists

  printf("1. Opening file %s\n",outfile);
  int out_fd = open(outfile,O_WRONLY);                  // open for writing, must exist 
  if(out_fd == -1){                                     // check result and fail if not opened
    perror("Couldn't open output file");
    exit(1);
  }

  printf("2. Filling output buffer\n");
  int out_ints[COUNT];
  for(int i=0; i<COUNT; i++){
    out_ints[i] = i;
  }

  int bufsize = sizeof(int)*COUNT;                      // calculate size of output

  printf("3. Writing up to %d bytes to file %s\n",
         bufsize,outfile);
  int bytes_written = write(out_fd, out_ints, bufsize); // do th write
  if(bytes_written == -1){                              // check for errors
    perror("Failed to read from file");
    exit(1);
  }
  printf("4. Wrote %d bytes to %s\n",bytes_written,outfile);

  if(close(out_fd) == -1){                              // check for errors on close
    perror("Couldn't close file");
  }
  
  printf("5. Opening %s for reading\n",outfile);
  int in_fd = open(outfile,O_RDONLY);                   // open file for reading
  if(in_fd == -1){                                      // check result and fail if not opened
    perror("Couldn't open file");
    exit(1);
  }

  printf("6. Reading up to %d bytes from %s\n",bufsize,outfile);
  int in_ints[COUNT];
  int bytes_read = read(in_fd, in_ints, bufsize);       // read from file, max BUFSIZE
  if(bytes_read == -1){                                 // check for errors
    perror("Failed to read from file");
    exit(1);
  }

  printf("7. Read %d bytes, as numbers\n",bytes_read);    // print bytes read
  printf("8. printf()'ing individual numbers:\n");
  for(int i=0; i<COUNT; i++){
    printf("%d ",in_ints[i]);
  }
  printf("\n");

  printf("9. write()'ing %d bytes of integers to screen\n",bytes_read);
  write(STDOUT_FILENO, in_ints, bytes_read);


  int result = close(in_fd);
  if(result == -1){
    perror("Failed to close file");
    exit(1);
  }

  printf("\n\n");
  return 0;
}
