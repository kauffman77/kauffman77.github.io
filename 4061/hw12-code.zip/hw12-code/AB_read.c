// AB_read.c: Start two child processes which run sleep_print with
// differing delays and messages. Their output is put into pipes
// readable by the parent.  The main loop alternates reading from each
// child in turn which means that some data builds up in the "fast"
// pipe while the main processs waits for a read() to complete on the
// "slow" pipe.

#include "ab.h"
int main() {
  int pipeA[2], pipeB[2];                                            // pipes for children to speak to parent
  int pidA = make_child(pipeA, 1, "AAAA");                           // create two children with different
  int pidB = make_child(pipeB, 3, "BBBB");                           // messages and delays between prints

  printf("AB_read: listening for children\n");                         

  int childA_done=0, childB_done=0;
  while(!childA_done || !childB_done){                               // loop to listen until signaled or children finish
    char buf[1024]; int nread;                                       // read buffer 

    if(!childA_done){                                                // check childA if not done
      nread = read(pipeA[PREAD], buf, 1024);                         // read from pipeA
      if(nread == 0){
        printf("Child A closed pipe\n");
        childA_done = 1;
      }
      else{
        buf[nread] = '\0';
        printf("A had: |%s|\n",buf);
      }
    }

    if(!childB_done){                                                // check childB if not done
      nread = read(pipeB[PREAD], buf, 1024);                         // read from pipeB
      if(nread == 0){
        printf("Child B closed pipe\n");
        childB_done = 1;
      }
      else{
        buf[nread] = '\0';
        printf("B had: |%s|\n",buf);
      }
    }
  }

  waitpid(pidA, NULL, 0);
  waitpid(pidB, NULL, 0);
  printf("AB_read: finishing\n");
  return 0;
}
