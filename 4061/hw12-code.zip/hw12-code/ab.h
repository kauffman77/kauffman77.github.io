#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <errno.h>
#include <poll.h>
#include <sys/wait.h>

#define PREAD  0                                                     // read and write ends of pipes
#define PWRITE 1

int make_child(int pip[], int delay, char *msg);
