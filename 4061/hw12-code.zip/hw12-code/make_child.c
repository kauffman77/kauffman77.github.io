#include "ab.h"

#define CHILD_ITERS 10

// Creates a child process that sleeps then prints 'msg' into the pipe
// 'pip[]' repeatedly. Each sleep lasts for 'delay' seconds. The
// parent process is returned the child pid and the child never
// exits on completing the printing.
int make_child(int pip[], int delay, char *msg){    // Create a child which sleeps then prints
  pipe(pip);
  int pid = fork();
  if(pid != 0){                                     // PARENT
    close(pip[PWRITE]);                             // Parent doesn't use the write ends
    return pid;                                     // Return child pid to parent
  }
                                                    // CHILD CODE
  close(pip[PREAD]);                                // CHILD: doesn't use read end
  int len = strlen(msg);                                             
  for(int i=0; i<CHILD_ITERS; i++){
    sleep(delay);
    write(pip[PWRITE], msg, len);
  }
  close(pip[PWRITE]);
  exit(0);                                          // exit CHILD process
  return 0;                                         // make the compiler happy
}
