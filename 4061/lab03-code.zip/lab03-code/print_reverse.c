#include <stdio.h>
#include <stdlib.h>

int main(){
  int max_size = 1, cur_pos = 0;                   // initial max and position
  char *buf = malloc(max_size*sizeof(char));       // allocate 1 byte of intial space
  while(1){                                        // loop until breaking on end of input
    int ret = scanf("%c", &buf[cur_pos]);          // read a single character to the current position
    if(ret == EOF){                                // break if end of input is reached
      break;                                       // 
    }                                              // 
    cur_pos++;                                     // update current input
    if(cur_pos == max_size){                       // check if more space is needed
      max_size *= 2;                               // double size of buffer
      char *new_buf =                              // pointer to either new or old location
        realloc(buf, max_size*sizeof(char));       // re-allocate, copies characters to new space if needed
      if(new_buf == NULL){                         // check that re-allocation succeeded
        printf("ERROR: reallocation failed\n");    // if not...
        free(buf);                                 // de-allocate current buffer
        exit(1);                                   // bail out
      }
      buf = new_buf;                               // assigns either existin or new location of expanded space
    }                                              // may be a size change in place or a new location
  }                                                // end of input reading loop
  for(int i=cur_pos-1; i>=0; i--){                 // loop over characters printing them in reverse
    printf("%c",buf[i]);                           // 
  }                                                // 
  printf("\n");                                    // 
  free(buf);                                       // free the dynamically allocated buf
  return 0;
}
// DEMO:
// > gcc make print_reverse
// > printf "0123456789" | ./print_reverse
// 9876543210
// > printf "here is everything I have" | ./print_reverse
// evah I gnihtyreve si ereh
