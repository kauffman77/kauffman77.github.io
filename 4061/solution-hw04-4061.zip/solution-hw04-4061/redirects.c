// Used for HW Quiz, 3 ways to redirect output in a child to a pipe

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

#define PREAD 0                            // index of read end of pipe
#define PWRITE 1                           // index of write end of pipe

int main(){
  int my_pipe[2];
  int stdout_bak = dup(STDOUT_FILENO);     // Duplicate stdout so it can be restored later

  // BLOCK 1
  pipe(my_pipe);
  dup2(my_pipe[PWRITE], STDOUT_FILENO);
  pid_t pid = fork();
  if(pid == 0){
    printf("I'm the child!\n");
    return 0;
  }
  
  // BLOCK 2
  pipe(my_pipe);
  pid_t pid = fork();
  if(pid == 0){
    dup2(my_pipe[PWRITE], STDOUT_FILENO);
    printf("I'm the child!\n");
    return 0;
  }

  // BLOCK 3
  pipe(my_pipe);
  pid_t pid = fork();
  if(pid == 0){
    dup2(my_pipe[PWRITE], STDOUT_FILENO);
    execlp("ls", "-l");
    return 0;
  }

  dup2(stdout_bak, STDOUT_FILENO);         // Restore stdout: redirect to backed up fd
  wait(NULL);
  close(my_pipe[PWRITE]);

  char buf[2048];
  printf("Parent printing pipe:\n");
  while(1){
    int nbytes=read(my_pipe[PREAD], buf, 2048);
    printf("Read %d bytes\n",nbytes);
    if(nbytes == 0){
      break;
    }
    write(stdout_bak, buf, nbytes);
  }
  return 0;
  
}
