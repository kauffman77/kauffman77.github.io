#!/bin/bash

# test runner program over many runs to see concurrency problems /
# repeated runs of jobs. Each iteration starts several runners on
# jobs.txt.2 and shows any prints any duplicated jobs after the
# iteration number.
# 
# EXAMPLE:
# > ./test_runner.sh runner_nosem
# ITER 1
# ITER 2
# ...
# ITER 9
# ITER 10
# 001: 81527 RUN 'seq 100000'
# 001: 81528 RUN 'seq 100000'
# ITER 11
# ...
# ITER 18
# ITER 19
# 004: 83533 RUN 'ls'
# 004: 83537 RUN 'ls'
# ITER 20
# 003: 83759 RUN 'du . -h'
# 003: 83761 RUN 'du . -h'
# ...


if [[ "$1" == "" ]]; then
    printf "usage: ./test_runner {runner}\n"
    exit 1
fi

runner=$1                                  # 1st arg is name of runner program to run
runner_count=10                            # number of runners to start for each iteration
test_iters=25

jobsfile=test_jobs.2.txt                   # base jobs file, doesn't have any sleep() jobs to make iterations faster
tmpfile=test_jobs.tmp
./$runner -init                            # initialize semaphores if needed

for r in $(seq $test_iters); do            # perform "experiment" a bunch of times
    cp $jobsfile $tmpfile                  # copy the jobs file to the one that will be used by the runners
    for i in $(seq $runner_count); do      # start several runners to cooperate
        ./$runner $tmpfile &
    done | cat > out.tmp
    unique_pids=$(gawk '{print $2}' out.tmp | sort | uniq |wc -l)
    printf "ITER %2d: %d unique pids did jobs\n" "$r" "$unique_pids";
    duplicates=$(sort out.tmp | uniq -w 3 -D) # sort output and look for duplicate job runs
    if [[ "$duplicates" != "" ]]; then
        printf "Duplicate Job Detected:\n%s\n" "$duplicates"
    fi
done

