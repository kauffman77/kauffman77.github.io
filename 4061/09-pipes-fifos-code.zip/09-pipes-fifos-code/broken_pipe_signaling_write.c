// broken_pipe_signaling_write.c: like related funcion but uses
// write() instead of printf() to show that write() will fail with
// errno==EPIPE when writing to a broken pipe. This means that the
// write() completes and the global `count` variable continues to
// rise.

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

int count = 0;

void bp_handler(int sig_num) {
  fprintf(stderr,"Received SIGPIPE! count: %d\n",count);
  fflush(stderr);
  if(getenv("EXIT_ON_BROKEN_PIPE")){      // exit if environment variable indicates as much
    printf("Exiting, final count: %d\n",count);
    fprintf(stderr,"exit(1)\n");
    exit(1);
  }
}

int main () {
  if(getenv("HANDLE_BROKEN_PIPE")){       // turn on/off exiting from broken pipe signal
    struct sigaction my_sa = {};          // portable signal handling setup with sigaction()
    my_sa.sa_handler = bp_handler;        // set handler function
    my_sa.sa_flags = SA_RESTART;          // always restart system calls on signals possible 
    sigaction(SIGPIPE, &my_sa, NULL);     // register SIGPIPE with given action
  } 
  char *str = "X\n";
  for(int i=0; 1; i++){
    int ret = write(STDOUT_FILENO, str, 2);
    if(ret < 0){
      perror("write() failed");
    }
    count++;
  }
  return 0;
}
