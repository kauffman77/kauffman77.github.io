// Attempt to 'wrap' the wc utility with a main() that has signal
// handling; will take some more work to get right as standard
// terminal discipline sends signals to whole process group rather
// than just the parent process to allow for easy killing
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <sys/wait.h>

int KEEP_GOING = 1;
void handler(int sig_num) {
  KEEP_GOING = 0;
}

int main(int argc, char *argv[]) {
  struct sigaction my_sa =      // set up signal handling
    { .sa_handler = handler };
  sigaction(SIGINT, &my_sa, NULL);

  FILE    *fpout;
  if ((fpout = popen("wc", "w")) == NULL){
    perror("popen error");
    exit(1);
  }

  // copy argv[1] to pager
  while (KEEP_GOING){
    int c = fgetc(stdin);
    if(c == EOF){             // end of input, bail out
      KEEP_GOING = 0;
    }
    else{
      fputc(c,fpout);
    }
  }
  if (pclose(fpout) == -1){
    perror("pclose error");
    exit(1);
  }

  return 0;
}
