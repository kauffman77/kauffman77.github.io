// broken_pipe_signaling.c: demonstrates interactions between signals
// and pipes. When writing to a pipe that has its Read end closed, a
// process will receive SIGPIPE. By default this signal causes the
// process to terminate. This program demonstrates this and
// variants. Environment variables are used to adjust its behavior and
// should try the following examples on the command line and be able
// to explain the resulting output/behavior:
//
// 
// > gcc broken_pipe_signaling.c           # compile
// > ./a.out | head                        # run default, handler and exit enabled
// ...
// > HANDLE_BROKEN_PIPE=0 ./a.out | head   # disable handler, signals not caught
// ...
// > EXIT_ON_BROKEN_PIPE=0 ./a.out | head  # handler enabled, don't exit on signal
// ...                                     # be prepared with Ctl-c


#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

int handle_broken_pipe  = 1;              // 1 to enable a handler for SIGPIPE
int exit_on_broken_pipe = 1;              // 1 to exit in signal handler on broken pipe

void bp_handler(int sig_num) {
  fprintf(stderr,"Received SIGPIPE: broken pipe!\n");
  fflush(stderr);
  if(exit_on_broken_pipe==1){             // exit if global variable indicates as much
    fprintf(stderr,"exit(1) from bp_handler()\n");
    exit(1);
  }
  return;
}

int main () {
  char *envval;                           // check environment variables to change behavior
  envval = getenv("HANDLE_BROKEN_PIPE");
  if(envval != NULL){
    handle_broken_pipe = atoi(envval);    // turn on/off handler of broken pipe signal
  }
  envval = getenv("EXIT_ON_BROKEN_PIPE"); 
  if(envval != NULL){
    exit_on_broken_pipe = atoi(envval);   // turn on/off exiting from broken pipe signal
  }


  if( handle_broken_pipe==1 ){            // set handling functions for programs
    struct sigaction my_sa = {};          // portable signal handling setup with sigaction()
    my_sa.sa_handler = bp_handler;        // set handler function
    my_sa.sa_flags = SA_RESTART;          // always restart system calls on signals possible 
    sigaction(SIGPIPE, &my_sa, NULL);     // register SIGPIPE with given action
  } 

  for(int i=0; 1; i++){                   // loop forever producing output
    printf("%d\n",i);
    i++;
  }
  return 0;
}
