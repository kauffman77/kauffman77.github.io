// reads only 5 characters from an input file then closes it; used to
// partially read from a FIFO so not all data is consumed

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]){
  char *fname = argv[1];
  int fd = open(fname, O_RDONLY);
  char buf[6];
  read(fd, buf, 5);
  buf[5] = '\0';
  printf("%s\n",buf);
  close(fd);
  return 0;
}
