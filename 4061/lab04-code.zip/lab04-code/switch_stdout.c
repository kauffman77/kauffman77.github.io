// switch_stdout.c: demonstrates use of dup2() and dup() to redirect
// standard output to a new location temporarily and then restore it. 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main(){
  int stdout_bak = dup(STDOUT_FILENO); // make a backup of stdout

  int out_fd = open("mystery.txt",     // open file mystery.txt
                    O_WRONLY|O_CREAT,  // for writing, create if needed
                    S_IRUSR|S_IWUSR);  // give user read/write permission

  if(out_fd == -1){                    // check for errors opening file
    perror("Couldn't open file 'mystery.txt'");
    exit(1);                           // bail out if open fails
  }

  printf("1. Now you see me.\n");      // print to the screen

  dup2(out_fd, STDOUT_FILENO);         // change stdout to go to mystery.txt

  printf("2. Now you don't!\n");       // print goes to mystery.txt

  close(out_fd);                       // close mystery.txt

  dup2(stdout_bak, STDOUT_FILENO);     // restore stdout to screen

  printf("3. How mysterious...\n");    // print goes to screen

  return 0;
}
