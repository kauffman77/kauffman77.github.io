// SOLUTION
// 
// file_reverse.c: prints a file in reverse by first reading the whole
// file into an expanding buffer then printing the characters in in
// last to first.

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
  if(argc < 2){
    printf("usage: file_reverse <file>\n");
    return 1;
  }

  char *filename = argv[1];
  FILE *fin = fopen(filename, "r");
  int max_size = 1, cur_pos = 0;
  char *buf = malloc(max_size*sizeof(char));
  while(1){
    int ret = fscanf(fin,"%c", &buf[cur_pos]);
    if(ret == EOF){
      break;
    }
    cur_pos++;
    if(cur_pos == max_size){
      max_size *= 2;
      buf = realloc(buf, max_size*sizeof(char));
      if(buf == NULL){
        printf("ERROR: reallocation failed\n");
        exit(1);
      }
    }
  }

  fclose(fin);

  for(int i=cur_pos-1; i>=0; i--){
    printf("%c",buf[i]);
  }

  printf("\n");
  free(buf);
  return 0;
}
