// em_client.c: client code to look up an email based on name. 
#include "em.h"
int main(int argc, char *argv[]){
  setvbuf(stdout, NULL, _IONBF, 0);                              // disable IO buffering

  if(argc < 3){
    printf("usage: %s GET <name>\n",argv[0]);
    printf("       %s PUT <name> <new_email>\n",argv[0]);
    exit(1);
  }

  char *command = argv[1];                                     // GET or PUT
  char *name = argv[2];                                        // name like 'Chris Kauffman'
  request_t request = {};                                      // {} initializes to all 0's

  sprintf(request.client_fifo, "%d.fifo", getpid());           // fifo named after pid (mildly unsafe naming)
  strncpy(request.command, command, BUFSIZE);                  // copy in the command
  strncpy(request.name, name, BUFSIZE);

  // TODO: Fill in new_email for GET vs PUT
  if( strcmp(command, "GET")==0 ){                             // for GET command
    strcpy(request.new_email, "");                             // blank new_email field
  }
  else if( strcmp(command, "PUT")==0 ){                        // for PUT command
    strcpy(request.new_email, argv[3]);                        // 3rd command line argument is new_email
  }
  else{
    printf("Command '%s' not known; exiting\n",
           request.command);
    return 1;
  }
  
  // TODO: create the client's fifo to receive a response
  mkfifo(request.client_fifo, S_IRUSR | S_IWUSR);              // create the client FIFO for a response

  // REMAINING CODE IS COMPLETE

  printf("CLIENT #%d: sending request {client_fifo='%s' command='%s' name='%s' new_email='%s'}\n",
         getpid(), request.client_fifo, request.command, request.name, request.new_email);

  int requests_fd = open("requests.fifo", O_RDWR);             // open FIFO read/write in case server hasn't started  
  write(requests_fd, &request, sizeof(request_t));             // send request to server

  printf("CLIENT #%d: opening '%s'\n", getpid(), request.client_fifo);
  char response[256];
  int client_fifo_fd = open(request.client_fifo, O_RDWR);      // open client FIFO to receive response
  printf("CLIENT #%d: fifo opened, awaiting server response\n",getpid());

  int nread = read(client_fifo_fd, response, 255);             // read response from server
  response[nread] = '\0';                                      // null terminate the string
  printf("CLIENT #%d: response for '%s %s' is: %s\n",         // report response
         getpid(), request.command, request.name, response);

  close(client_fifo_fd);                                       // clean up and exit
  close(requests_fd);
  remove(request.client_fifo);
  return 0;
}
