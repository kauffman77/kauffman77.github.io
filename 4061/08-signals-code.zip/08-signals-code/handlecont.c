// no_interruptions_sigaction.c: A C program that is not killed from
// interrupt or terminate signals by establishing handlers that ignore
// signals. sigaction() is used to set up the signal handlers.
//
// To stop this program from running, open another terminal and try
//  > pkill -9 a.out
// assuming you named the output program a.out
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

// Function run when a SIGINT is sent to the program
void handle_SIGCONT(int sig_num) {
  // ignored
}
 
int main () {
  // Set handling functions for programs
  struct sigaction my_sa = {};               // portable signal handling setup with sigaction()

  my_sa.sa_handler = handle_SIGCONT;
  sigaction(SIGCONT, &my_sa, NULL);
  
  pause();

  printf("Program complete\n");

  return 0;
}
