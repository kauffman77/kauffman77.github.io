// signal_catch.c: demonstrates use of sigaction() / SA_SIGINFO option
// to use a slightly more complex signal handler function. Notably
// this allows the PID of the process that sent the signal to be
// determined allowing a process to "signal back".
//
// The code has a "catcher" that pause()'s for signals and signals
// back to a "pitcher" signal.

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

pid_t partner_pid = -1;

void complex_handler(int signum, siginfo_t *siginfo, void *thread_context){
  partner_pid = siginfo->si_pid; // set partner_pid to the PID that sent the signal
}

int main (int argc, char *argv[]) {
  if(argc < 2){
    printf("usage: %s catcher\n",argv[0]);
    printf("usage: %s pitcher <catcher_pid>\n",argv[0]);
    exit(1);
  }

  struct sigaction my_sa = {               
    .sa_flags = SA_RESTART | SA_SIGINFO, // 2nd flag uses more complex handler
    .sa_sigaction = complex_handler,     // functions which take more options
  };
  sigaction(SIGUSR1, &my_sa, NULL);      // set the signal handler for SIGUSR1


  char *mode = argv[1];
  if(0){}
  else if( strcmp(mode,"catcher")==0 ){ // catcher that loops waiting for
    while(1){                           // signals and signals back
      printf("Catcher %d waiting for signal\n", getpid());
      pause();
      printf("Catcher caught signal from pid %d\n", partner_pid);
      printf("Catcher Signalling back to %d\n", partner_pid);
      int ret = kill(partner_pid, SIGUSR1);
      if(ret == -1){
        perror("Catcher could not signal back");
      }
    }
  }
  else if( strcmp(mode,"pitcher")==0 ){ // pitcher that sends one signal then
    pid_t catcher_pid = atol(argv[2]);  // gets a response before ending
    printf("Pitcher %d sending signal to %d\n", getpid(), catcher_pid);
    int ret = kill(catcher_pid, SIGUSR1);
    if(ret == -1){
      perror("Catcher could not signal back");
    }
    pause();
    printf("Pitcher got signal back from %d\n", partner_pid);
  }    
  else{
    printf("Unknown mode '%s'\n",mode);
  }
  return 0;
}
