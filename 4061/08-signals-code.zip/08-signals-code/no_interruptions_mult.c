// no_interruptions_mult.c: like no_interruptions_sigaction.c but uses
// a single signal handler for multiple signals. Shows how the handler
// can distinguish between signals sent to it via its sole integer
// argument.
// 
// To stop this program from running, open another terminal and try
//  > pkill -9 a.out
// assuming you named the output program a.out
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

// Function run when a SIGINT is sent to the program
void handle_all(int sig_num) {
  if(sig_num == SIGINT){
    printf("\nNo SIGINT-erruptions allowed.\n");
    fflush(stdout);
  }
  else if(sig_num == SIGTERM){
    printf("\nTry to SIGTERM me? Piss off!\n");
    fflush(stdout);
  }
}

int main () {
  // Set handling functions for programs
  struct sigaction my_sa = {};               // portable signal handling setup with sigaction()

  my_sa.sa_handler = handle_all;
  sigaction(SIGTERM, &my_sa, NULL);
  sigaction(SIGINT, &my_sa, NULL);
  
  // Infinite loop 
  while(1) {        
    sleep(1);
    printf("Ma-na na-na!\n");
    fflush(stdout);
  }
  return 0;
}
