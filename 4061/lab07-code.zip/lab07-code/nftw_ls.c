// nftw_ls.c: Demonstrates use of the nftw() library call to
// recursively travere directory. Each file visited has
// print_file_info() called on it.

#include "headers.h"

#define MAX_FDS  20             // maximum file descriptors to be used by nftw()

int total_files = 0;            // tracks total files visited during directory walk

// Prints info on a single file indicated by argument
// 'filename'. Argument 'sb' is a pointer to a 'struct stat' that has
// already been filled with information for the file via a stat()-like
// call. The 'unused1' and 'unused2' arguments are for compatibilty
// with the library function 'nftw()'.
int print_file_info(const char *filename, const struct stat *sb,
                    const int unused1,    struct FTW *unused2)
{
  // check file type type using S_xxx macros. These are associated
  // with stat() family of calls and use the bits in field sb.st_mode
  // to report the kind of file found.
  char type = '?';                                // char to set for type
       if( S_ISDIR (sb->st_mode) ){ type = 'D'; } // Directory
  else if( S_ISREG (sb->st_mode) ){ type = 'F'; } // Regular File
  else if( S_ISLNK (sb->st_mode) ){ type = 'L'; } // Symbolic Link
  else if( S_ISBLK (sb->st_mode) ){ type = 'B'; } // Block special device (hard drive)
  else if( S_ISCHR (sb->st_mode) ){ type = 'C'; } // Character special device (terminal)
  else if( S_ISFIFO(sb->st_mode) ){ type = 'P'; } // Pipe / FIFO (via mkfifo)
  else if( S_ISSOCK(sb->st_mode) ){ type = 'S'; } // Socket (network device)
         
  // // alternate version which uses switch() control structure and
  // // masking to extract format bits
  // switch (sb->st_mode & S_IFMT) {
  //   case S_IFDIR:  type = 'D';      break;
  //   case S_IFREG:  type = 'F';      break;
  //   case S_IFLNK:  type = 'L';      break;
  //   case S_IFBLK:  type = 'B';      break;
  //   case S_IFCHR:  type = 'C';      break;
  //   case S_IFIFO:  type = 'P';      break;
  //   case S_IFSOCK: type = 'S';      break;
  //   default: printf("Unknown file type?\n"); break;
  // }

  char *time_str = ctime(&(sb->st_mtime));        // format modification time as a string
  time_str[strlen(time_str)-1] = '\0';            // eliminate trailing newline in formatted time
  printf("%c %24s %8lu %s\n",                     // print type of file and filename to it
         type, time_str, sb->st_size, filename);  

  total_files++;
  return 0;
}

int main(int argc, char *argv[]) {
  char *filename = ".";                           // default to traversing current directory
  if(argc > 1){                                   // or take command line argument as dir to list
    filename = argv[1];
  }
  printf("%c %-24s %-8s %s\n",                    // print a header for information columns
         'T', "MTIME","BYTES","FILENAME");
  printf("%c %-24s %-8s %s\n",                    
         '=', "========================", "========", "================");
  int len = strlen(filename);
  if(filename[len-1] == '/'){                     // chop trailing slash if present
    filename[len-1] = '\0';
  }

  nftw(filename, print_file_info,                 // library call to recursively traverse and
       MAX_FDS, FTW_PHYS);                        // call print_file_info() on each entry

  printf("========================================\n");
  printf("%d total files visited\n",total_files);
  return 0;
}
