#define _XOPEN_SOURCE 700       // causes some functions like nftw() to become defined in headers
#include <ftw.h>                // includes nftw() function and associated structs
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>

#define MAX_FDS  20          // maximum file descriptors to be used by nftw()

typedef int (*cmp_t) (const void *, const void *); // convenience type to cast comparison functions when passed to qsort()

