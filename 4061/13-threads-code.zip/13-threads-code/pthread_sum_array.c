// pthread_sum_array: demonstrates a common pattern of dividing a
// shared data structure like an array among threads to work on the
// data in parallel.  Shows how to use a parameter to the thread
// function, a workdata_t in this case, to pass a unique integer ID
// like 0,1,2,... to each thread which is then used to determine which
// part of the data the thrad will use for its portion of the
// computation.

#include <stdio.h>
#include <stdlib.h> 
#include <pthread.h>

// global variables to allow all threads to work on the same shared array
int *array = NULL;                               // shared array among all threads
int array_len = -1;                              // length of the array set on command line
int num_threads = -1;                            // number of threads that will cooperate

typedef struct {                                 // struct giving info to each thread
  int thread_id;                                 // thread's logical id numbered 0,1,2,...
  int thread_sum;                                // spot to fill in a sum for the thread, used back in main()
} workdata_t;


void *workfunc(void *wd){                        // thread worker function
  workdata_t *workdata = (workdata_t*) wd;       // caste parameter to workdata
  int my_id = workdata->thread_id;               // extract logical thread id for this thread
  int count = (array_len / num_threads);         // how many elements each thread should sum up
  int start = my_id*count;                       // where this thread start in the array, based on its ID
  int stop  = (my_id+1)*count;                   // where this thread should stop
  if(my_id == num_threads-1){                    // last thread goes to end of array in case 
    stop = array_len;                            // the array length is not evenly divisible by num_threads
  }
  printf("Thread %d summing elements %d to %d\n",
         my_id,start,stop);

  int my_sum = 0;                                // local sum for this thread's portion of the array
  for(int i=start; i<stop; i++){
    my_sum += array[i];
  }
  printf("Thread %d sum is %d\n", my_id, my_sum);
  workdata->thread_sum = my_sum;                 // set the struct field to personal sum so main() can use it
  return NULL;
}

int main(int argc, char **argv) { 
  if(argc < 3){
    printf("usage: %s <array_len> <num_threads>\n",argv[0]);
    printf("  array_len:   int, length of the array to sum\n");
    printf("  num_threads: int, number of threads to use for the computation\n");
    return -1;
  }

  array_len = atoi(argv[1]);                     // set globals from command line
  num_threads = atoi(argv[2]);

  array = malloc(sizeof(int)*array_len);         // initialize array with 0,1,2,3,...
  for(int i=0; i<array_len; i++){
    array[i] = i;
  }

  pthread_t threads[num_threads];                // structs for tracking each thread and
  workdata_t workdata[num_threads];              // passing each thread its own parameters

  for(int i=0; i<num_threads; i++){              // launch each thread
    workdata[i].thread_id = i;
    pthread_create(&threads[i],NULL,
                   workfunc, &workdata[i]);
  }

  int total_sum = 0;
  for(int i=0; i<num_threads; i++){              // wait for each thread to finish
    pthread_join(threads[i], (void **) NULL);
    total_sum += workdata[i].thread_sum;         // after thread finishes, add its local sum to the total
  }

  printf("total_sum: %d\n",total_sum);
  free(array);
  return 0;
}
