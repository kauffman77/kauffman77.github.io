// em_server.c: server code which contains a name/email pairs and will
// fulfill requests from a client through FIFOs.
#include "em.h"

// data the server has and clients want: pairings of name and email
char data[][2][128] = {
  {"Chris Kauffman"       ,"kauffman@umn.edu"},
  {"Christopher Jonathan" ,"jonat003@umn.edu"},
  {"Amy Larson"           ,"larson@cs.umn.edu"},
  {"Chris Dovolis"        ,"dovolis@cs.umn.edu"},
  {"Dan Knights"          ,"knights@cs.umn.edu"},
  {"George Karypis"       ,"karypis@cs.umn.edu"},
  {"Steven Jensen"        ,"sjensen@cs.umn.edu"},
  {"Daniel Keefe"         ,"dfk@umn.edu"},
  {"Michael W. Whalen"    ,"whalen@cs.umn.edu"},
  {"Catherine Qi Zhao"    ,"qzhao@umn.edu"},
  {"Dan Challou"          ,"challou@cs.umn.edu"},
  {"Steven Wu"            ,"zsw@umn.edu"},
  {"Michael Steinbach"    ,"steinbac@cs.umn.edu"},
  {"Jon Weissman"         ,"jon@cs.umn.edu"},
  {"Victoria Interrante"  ,"interran@cs.umn.edu"},
  {"Shana Watters"        ,"watt0087@umn.edu"},
  {"James Parker"         ,"jparker@cs.umn.edu"},
  {"James Moen"           ,"moen0017@cs.umn.edu"},
  {"Daniel Giesel"        ,"giese138@umn.edu"},
  {"Jon Read"             ,"readx028@umn.edu"},
  {"Sara Stokowski"       ,"stoko004@umn.edu"},
  {""                     , ""},
};

// TODO: Createa global variable and signal handler function to
// track when SIGINT or SIGTERM has been received
???;
???;

int main(int argc, char *argv[]) {
  setvbuf(stdout, NULL, _IONBF, 0);                              // disable IO buffering

  // TODO: Create a sigaction struct with handler set to the above
  // handler function
  // 
  //NOTE: do NOT use the SA_RESTART flag as the read() below
  // should be interruptible by a signal to shut down.
  struct ??? ??? = {
    ???
  };

  // TODO: Set the signal handler for SIGTERM and SIGINT
  ???;
  ???;
  
  printf("SERVER #%5d: starting up\n", getpid());

  remove("requests.fifo");                                       // remove old requests FIFO, ensures starting in a good state
  mkfifo("requests.fifo", S_IRUSR | S_IWUSR);                    // create requests FIFO for client requests

  printf("SERVER #%5d: created new requests.fifo, now opening it\n", getpid());
  int requests_fd = open("requests.fifo", O_RDWR);               // open FIFO read/write to avoid blocking

  printf("SERVER #%5d: opened requests.fifo, listening for requests\n", getpid());

  while(1){                                                      // loop forever awaiting client requests
    request_t request;
    int nread = read(requests_fd, &request, sizeof(request_t));  // read a single request from the requests FIFO

    // TODO: read() may return a -1 due to being interrupted by a
    // signal.  Check the global variable set by the signal handler to
    // determine if the server has been signalled to shut down.
    if( ??? && ??? ){                         // check for signal to exit
      printf("SERVER #%5d: Signalled to shut down\n", getpid());
      break;
    }
    else if(nread != sizeof(request_t)){                         // check for other errors in read()
      printf("SERVER #%5d: read %d bytes from requests.fifo, smaller than a request_t; bailing out\n",
             getpid(), nread);
      break;
    }

    printf("SERVER #%5d: received request {client_fifo='%s' command='%s' name='%s' new_email='%s'}\n",
           getpid(), request.client_fifo, request.command, request.name, request.new_email);
    

    int index = -1;                                              // search for name matching request 
    for(int i=0; data[i][0][0] != '\0'; i++){
      if( strcmp(request.name, data[i][0])==0 ){
        index = i;                                               // found matching record
        break;
      }
    }

    char response[BUFSIZE]={};                                   // formulate response to client 

    if(index == -1){                                             // matching name not found
      snprintf(response, BUFSIZE,
               "name '%s' not found", request.name);
    }
    else if( strcmp(request.command,"GET")==0 ){                 // GET command response
      // TODO: respond to a GET request by coping data into the
      // response[] buffer with the name at the `index` that was
      // found. Note that data[][] is arranged as
      // 
      // - data[index][0]: name of person
      // - data[index][1]: email of person
      ??? (???, ???, "%s", ???);
    }

    else if( strcmp(request.command,"PUT")==0 ){                 // PUT command response
      // TODO: respond to a PUT request by copying the new_email into
      // the data array to overwrite the old email address. Then
      // construct the response using the format specified
      ???;  // alter data in array with new email address
      snprintf(???, ???,
               "email for '%s' updated to '%s'",
               ???);
    }

    else{                                                        // neither of GET/PUT
      snprintf(response, BUFSIZE,
               "unknown command '%s'",
               request.command);
    }
      
    printf("SERVER #%5d: opening client FIFO '%s'\n",
           getpid(), request.client_fifo);
    int client_fifo_fd = open(request.client_fifo, O_WRONLY);

    printf("SERVER #%5d: for name '%s' writing response '%s'\n",
           getpid(), request.name, response);

    // TODO: Write the response into the client's fifo
    ???;                 // reply with results to client

    printf("SERVER #%5d: closing connection to fifo '%s'\n",
           getpid(), request.client_fifo);
    close(client_fifo_fd);
  }

  printf("SERVER #%5d: main loop complete, cleaning up\n", getpid());
  close(requests_fd);                                            // server is done, clean up
  remove("requests.fifo");

  exit(0);
}
