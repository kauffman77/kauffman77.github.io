#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <signal.h>
#include <errno.h>

#define BUFSIZE 128

typedef struct {
  char client_fifo[BUFSIZE];        // filename of FIFO on which to respond
  char command[BUFSIZE];            // GET or PUT
  char name[BUFSIZE];               // name of person for GET / PUT command
  char new_email[BUFSIZE];          // new email address for PUT
} request_t;

