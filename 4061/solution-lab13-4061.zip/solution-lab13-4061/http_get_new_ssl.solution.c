// http_post_ssl.c: Demosntrates the HTTP POST functionality which
// allows a page to be accessed and some parameters passed to
// it. Compile this program via
// 
// > gcc -Wall -g -o http_post_ssl http_post_ssl.c -lssl -lcrypto
//
// Experiment with running it without and with an integer parameter
// between 1 and 101:
//
// > ./http_post_ssl 
// 
// > ./http_post_ssl 31
// 
// > ./http_post_ssl 85
//
// A web form to execute similar code is here:
// https://www-users.cs.umn.edu/~kauffman/quotes_submit.html

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <assert.h>
#include <arpa/inet.h>

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define PORT "443"                                  // the port client will be connecting to 
#define MAXDATASIZE 1024                            // max number of bytes we can get at once 

void get_address_string(struct addrinfo *addr, char buffer[]);

int main(int argc, char *argv[]) {
  if(argc < 2){
    printf("usage: %s <NUM>\n",argv[0]);
    return 0;
  }

  char *hostname = "www-users.cs.umn.edu";
  char *hostfile = "/~kauffman/quotes.php";
  // char *hostname = "httpbin.org";   ///
  // char *hostfile = "/post";         ///

  printf("Host: %s\nFile: %s\n",hostname, hostfile);

  // TODO: Use code similar to that in http_get_ssl.c to create a
  // socket, connect it to a server, and create an encrypted version
  // of the socket. Later code will use the variables 'sockfd' and
  // 'ssl_connection' for these as was done in http_get_ssl.c
  int ret;
  struct addrinfo *serv_addr;   // filled by getaddrinfo
  int sockfd;                   // created via socket()
  SSL_CTX *ctx;                 // created via SSL functions
  SSL *ssl_connection;          // created via SSL functions

  ret = getaddrinfo(hostname, PORT, NULL, &serv_addr);  /// 
  assert(ret == 0);                                     /// 
  sockfd = socket(serv_addr->ai_family,                 /// 
                  serv_addr->ai_socktype,               /// 
                  serv_addr->ai_protocol);              /// 
  assert(ret != -1);                                    /// 
  ret = connect(sockfd,                                 /// 
                serv_addr->ai_addr,                     /// 
                serv_addr->ai_addrlen);                 /// 
  assert(ret != -1);                                    /// 
  OpenSSL_add_all_algorithms();                         /// 
  SSL_library_init();                                   /// 
  const SSL_METHOD *method = SSLv23_client_method();    /// 
  ctx = SSL_CTX_new(method);                            /// 
  ssl_connection = SSL_new(ctx);                        /// 
  assert(ssl_connection != NULL);                       /// 
  SSL_set_fd(ssl_connection, sockfd);                   /// 
  SSL_connect(ssl_connection);                          /// 


  // char address_str[INET6_ADDRSTRLEN];               // fill in a string version of the addrss which was resolved
  // get_address_string(serv_addr, address_str);       // defined below, fills in buffer with printable address
  // printf("connected to %s\n", address_str);         // 
  // freeaddrinfo(serv_addr);                          // all done with this structure


  // TODO: Format the string `post_data[]` as
  //   quote_num=<NUM>
  // where <NUM> is the 1st command line argument; keep in mind that
  // argv[] elements are strings and that you do not need to do any error checking.
  char post_data[MAXDATASIZE];
  sprintf(post_data,"quote_num=%s",argv[1]); ///


  // // This block forms a HTTP POST request which starts with some
  // // header information and ends with key/value data. In this case the
  // // only key/val needed is
  // char request[MAXDATASIZE] = {}; // string that will hold the data for the POST request
  // int len = 0;
  // len += snprintf(request+len, MAXDATASIZE, "POST %s HTTP/1.1\r\n", hostfile);
  // len += snprintf(request+len, MAXDATASIZE, "Host: %s\r\n", hostname);
  // len += snprintf(request+len, MAXDATASIZE, "Content-Type: application/x-www-form-urlencoded\r\n");
  // len += snprintf(request+len, MAXDATASIZE, "Connection: close\r\n");
  // len += snprintf(request+len, MAXDATASIZE, "Content-Length: %lu\r\n\r\n",strlen(post_data));
  // len += snprintf(request+len, MAXDATASIZE, "%s\r\n\r\n",post_data);

  char *request_format = 
    "POST %s HTTP/1.1\r\n"
    "Host: %s\r\n"
    "Content-Type: application/x-www-form-urlencoded\r\n"
    "Connection: close\r\n"
    "Content-Length: %lu\r\n\r\n"
    "%s\r\n\r\n";
  char request[MAXDATASIZE] = {}; // string that will hold the data for the POST request
  snprintf(request, MAXDATASIZE, request_format,
           hostfile, hostname, strlen(post_data), post_data);
  int len = strlen(request);

  printf("REQUEST\n");
  printf("-------\n");
  printf("%s",request);
  printf("-------\n");

  int nbytes;
  nbytes = SSL_write(ssl_connection, request, len);
  assert(nbytes == len);

  printf("RESPONSE\n");
  printf("-------\n");

  char response[MAXDATASIZE];
  while(1){
    int nbytes =                                     // receive data data from the server
      SSL_read(ssl_connection, response, MAXDATASIZE); 
    assert(nbytes != -1);
    if(nbytes == 0){
      break;
    }
    write(STDOUT_FILENO, response, nbytes);
  }
  printf("-------\n");

  SSL_free(ssl_connection);
  SSL_CTX_free(ctx);

  close(sockfd);

  return 0;
}

// // Fill in the given buffer with a string version of the address from
// // the given addrinfo.  This involves some nasty casting.  addrinfo
// // structs have the member.
// // 
// //  struct sockaddr *ai_addr;	/* Socket address for socket.  */
// // 
// // which may be either a sockaddr_in (IPv4) or sockaddr_in6 (IPv6).
// // The exact type is defined in the sin_family which is supposed be
// // identical to the ai_family field of the addrinfo.
// //
// // The main workhorse is inet_ntop() which does the actual fill-in of
// // the buffer with the translated address.
// void get_address_string(struct addrinfo *addr, char buffer[]){
//   void *ip_address = NULL;
//   if(addr->ai_family == AF_INET){                   // ipv4 address
//     ip_address = (void *) &((struct sockaddr_in*)addr->ai_addr)->sin_addr;
//   }
//   else if(addr->ai_family == AF_INET6){             // ipv6 address
//     ip_address = (void *) &((struct sockaddr_in6*)addr->ai_addr)->sin6_addr;
//   }
//   inet_ntop(addr->ai_family, ip_address, buffer, INET6_ADDRSTRLEN);
// }
