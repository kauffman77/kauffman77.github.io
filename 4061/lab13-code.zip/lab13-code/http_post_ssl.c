// http_post_ssl.c: Demosntrates the HTTP POST functionality which
// allows a page to be accessed and some parameters passed to
// it. Compile this program via
// 
// > gcc -Wall -g -o http_post_ssl http_post_ssl.c -lssl -lcrypto
//
// Experiment with running it without and with an integer parameter
// between 1 and 101:
//
// > ./http_post_ssl 31
// 
// > ./http_post_ssl 85
//
// A web form to execute similar code is here:
// https://www-users.cs.umn.edu/~kauffman/quotes_submit.html

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <assert.h>
#include <arpa/inet.h>

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define PORT "443"                                  // the port client will be connecting to 
#define MAXDATASIZE 1024                            // max number of bytes we can get at once 

void get_address_string(struct addrinfo *addr, char buffer[]);

int main(int argc, char *argv[]) {
  if(argc < 2){
    printf("usage: %s <NUM>\n",argv[0]);
    return 0;
  }

  char *hostname = "www-users.cs.umn.edu";
  char *hostfile = "/~kauffman/quotes.php";

  printf("Host: %s\nFile: %s\n",hostname, hostfile);

  // TODO: Use code similar to that in http_get_ssl.c to create a
  // socket, connect it to a server, and create an encrypted version
  // of the socket. Later code will use the variables 'sockfd' and
  // 'ssl_connection' for these as was done in http_get_ssl.c
  int ret;
  struct addrinfo *serv_addr;   // filled by getaddrinfo
  int sockfd;                   // created via socket()
  SSL_CTX *ctx;                 // created via SSL functions
  SSL *ssl_connection;          // created via SSL functions

  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;


  // TODO: Format the string `post_data[]` as
  //   quote_num=<NUM>
  // where <NUM> is the 1st command line argument; keep in mind that
  // argv[] elements are strings and that you do not need to do any error checking.
  char post_data[MAXDATASIZE];
  ???;


  // The basic format of a POST request is below and ends with data in
  // the key/val form like "quote_num=15".  This format string is used
  // to create the message by filling in parameters shown elsewhere.
  char *request_format = 
    "POST %s HTTP/1.1\r\n"        // hostfile
    "Host: %s\r\n"                // hostname
    "Content-Type: application/x-www-form-urlencoded\r\n"
    "Connection: close\r\n"       // close after answering
    "Content-Length: %lu\r\n\r\n" // length of following key/val pairs
    "%s\r\n\r\n";                 // key/vale data from variable 'post_data'

  char request[MAXDATASIZE];      // print/format the request data
  snprintf(request, MAXDATASIZE, request_format,
           hostfile, hostname, strlen(post_data), post_data);

  printf("REQUEST\n");
  printf("-------\n");
  printf("%s",request);
  printf("-------\n");

  // TODO: Write the request[] to the `ssl_connection`.  Use the
  // SSL_write() function which has identical arguments to the
  // standard write() system call.  Use strlen() to calculate the
  // length of the request. 
  ???;
  ???;
  ???;
  ???;



  // TODO: Receive response data and write() it to the screen. Use the
  // `response[]` buffer below.  Use the SSL_read() function which has
  // identical semantics to read().  Note that responses can be
  // arbitrarily long so it is typical to use a loop to read()
  // data. However, for this simple example, responses are short and
  // can likely be read with a single pass.
  char response[MAXDATASIZE];
  printf("RESPONSE\n");
  printf("-------\n");

  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;
  ???;


  printf("-------\n");            // End of response

  SSL_free(ssl_connection);       // cleans up SSL variables
  SSL_CTX_free(ctx);
  close(sockfd);                  // closes/de-allocates socket

  return 0;
}
