// fork_shape.c: predict the shape of this set of fork() calls
#include <stdio.h>
#include <unistd.h>
#include <wait.h>
int main(void) {
  pid_t pid = -1;
  for(int i=0; i<4; i++){
    pid = fork();
    if(pid != 0){
      break;
    }
  }
  waitpid(pid, NULL, 0);
  printf("pid = %d, parent pid = %d\n", getpid(), getppid());
  return 0;
}
