// my_cat.c: print all bytes of a file to the screen using low-level
// system calls; makes sure to call read() requesting more than 1 byte
// at a time for mild efficiency gains
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define BUFSIZE 32

int main(int argc, char *argv[]){
  char *infile = argv[1];                       
  int in_fd = open(infile,O_RDONLY);
  char buf[BUFSIZE];
  int nread, total=0;
  while(1){
    nread = read(in_fd,buf,BUFSIZE);
    if(nread == 0){
      break;
    }
    write(STDOUT_FILENO, buf, nread);
    total += nread;
  }
  nread = snprintf(buf, BUFSIZE, "%d bytes total\n",total);
  write(STDOUT_FILENO, buf, nread);
  close(in_fd);
  return 0;
}
