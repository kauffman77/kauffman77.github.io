// AB_threads.c: Starts two child processes which sleep/print into a
// pipe with differing delays and messages. To avoid blocking the main
// process and ensure that output is obtained from the different pipes
// as soon as possible, two threads are started by the main process to
// read from the two child processes.  Since these threads block
// independently until their read() call returns, the process appears
// to respond as soon as data becomes available in either pipe.

#include "ab.h"                                                      // include headers

int pipeA[2], pipeB[2];                                              // pipes for children to speak to parent

void *threadA_func(void *x){
  char buf[1024]; int nread;
  while(1){
    nread = read(pipeA[PREAD], buf, 1024);                           // read from pipeA
    if(nread == 0){
      break;
    }
    buf[nread] = '\0';
    printf("A had: |%s|\n",buf);
  }
  printf("Child A closed pipe\n");
  return NULL;
}

void *threadB_func(void *x){
  char buf[1024]; int nread;
  while(1){
    nread = read(pipeB[PREAD], buf, 1024);                           // read from pipeB
    if(nread == 0){
      break;
    }
    printf("B had: |%s|\n",buf);
  }
    buf[nread] = '\0';
  printf("Child B closed pipe\n");
  return NULL;
}

int main() {
  int pidA = make_child(pipeA, 1, "AAAA");                           // create two children with different
  int pidB = make_child(pipeB, 3, "BBBB");                           // messages and delays between prints

  printf("AB_threads: starting threadA / threadB\n");                         
  pthread_t threadA, threadB;
  pthread_create(&threadA, NULL, threadA_func, NULL);
  pthread_create(&threadB, NULL, threadB_func, NULL);

  pthread_join(threadA, NULL);
  printf("Thread A completed\n");
  pthread_join(threadB, NULL);
  printf("Thread B completed\n");

  waitpid(pidA, NULL, 0);
  waitpid(pidB, NULL, 0);
  printf("AB_threads: finishing\n");

  return 0;
}
