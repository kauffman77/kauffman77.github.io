// AB_poll.c: Starts two child processes which sleep/print into a pipe
// with differing delays and messages.  The main loop employs the
// poll() system call which indicates which input sources are ready
// allowing the parent to read data from child processes as soon as it
// becomes available.

#include "ab.h"

int main() {
  int pipeA[2], pipeB[2];                                            // pipes for children to speak to parent
  int pidA = make_child(pipeA, 1, "AAAA");                           // create two children with different
  int pidB = make_child(pipeB, 3, "BBBB");                           // messages and delays between prints

  printf("poll_AB: listening for children\n");                         

  struct pollfd pfds[2];                                             // array of structures for poll, 1 per fd to be monitored
  pfds[0].fd     = pipeA[PREAD];                                     // populate first entry with pipeA fd
  pfds[0].events = POLLIN;                                           // check for ready to read() without blocking
  pfds[1].fd     = pipeB[PREAD];                                     // same as above for pipeB fd
  pfds[1].events = POLLIN;

  int childA_done=0, childB_done=0;
  while(!childA_done || !childB_done){                               // loop to listen until signaled or children finish
    char buf[1024]; int nread;                                       // read buffer 

    int ret = poll(pfds, 2, -1);                                     // block until OS notifies input is ready

    if( pfds[0].revents & POLLIN ){                                  // Child A had input as indicated by 'revents'
      nread = read(pipeA[PREAD], buf, 1024);                         // read from pipeA
      buf[nread] = '\0';
      printf("A had: |%s|\n",buf);
    }
    else if( pfds[0].revents & POLLHUP ){                            // Child A "hung up" : closed other end of pipe
      printf("Child A closed pipe\n");
      pfds[0].fd = -1;                                               // mark pollfd struct to ignore this file descriptor
      childA_done = 1;
    }      

    if( pfds[1].revents & POLLIN ){                                  // Child B had input as indicated by 'revents'
      nread = read(pipeB[PREAD], buf, 1024);                         // read from pipeB
      buf[nread] = '\0';
      printf("B had: |%s|\n",buf);
    }
    else if( pfds[1].revents & POLLHUP ){                            // Child B "hung up" : closed other end of pipe
      printf("Child B closed pipe\n");
      pfds[1].fd = -1;                                               // mark pollfd struct to ignore this file descriptor
      childB_done = 1;
    }      

  }

  waitpid(pidA, NULL, 0);
  waitpid(pidB, NULL, 0);
  printf("AB_poll: finishing\n");
  return 0;
}
