#!/bin/bash
rm -rf subdir-small

for i in $(seq 5); do
    mkdir -p subdir-small/dir_${i};
done
for i in $(seq 7); do
    seq $i > subdir-small/file_${i}.txt;
done
echo More input than the others >> subdir-small/file_3.txt
for i in $(seq 3); do
    seq $((i+10)) > subdir-small/dir_1/file_1${i}.txt;
done
for i in $(seq 5); do
    seq $((i+20)) > subdir-small/dir_3/file_3${i}.txt;
done
for i in $(seq 4); do
    seq $((i+30)) > subdir-small/dir_4/file_4${i}.txt;
done
echo A bit more >> subdir-small/dir_3/file_35.txt
echo Way more than I imagenined there woudl be here >> subdir-small/dir_1/file_12.txt
seq 2000 >> subdir-small/file_5.txt
