// SOLUTION
// wc_signal.c: Counts lines/words/chars like wc BUT with graceful
// shutdown/reporting of results if sent the interrupt signal sent via
// Ctrl-c in a terminal.
//
// Complete TODO items to fill in a signal handler
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>                    // provides isspace() and other char type funcs

int KEEP_GOING = 1;                   // control variable to continue loop

// TODO: Add a signal handling function which turns "off" the loop
void handler(int sig_num) {
  KEEP_GOING = 0;
}
 
int main (int argc, char *argv[]) {

  // TODO: add struct/calls to sigaction() to handle SIGINT and shut
  // down "gracefully". Use sigaction() and associated structs. Ensure
  // that the flag SA_RESTART is set as well to ensure system calls
  // are automatically restarted.
  struct sigaction my_sa = {
    .sa_handler = handler,            // function handler
    .sa_flags = SA_RESTART,           // option to restart system calls
  };
  sigaction(SIGINT, &my_sa, NULL);
  
  int nwords=0, nlines=0, nchars=0;   // counts for various entities
  int last = ' ';                     // pretend last char is initially space

  while(KEEP_GOING) {                 // Loop while not end of input and not signalled
    int cur = fgetc(stdin);           // get the next character

    if(cur == EOF){                   // end of input, bail out
      KEEP_GOING = 0;
      if(last != '\n'){               // ending without a newline
        nlines++;                     // increment nlines
      }
    }
    else{
      nchars++;                       // one more character
      nlines += (cur == '\n');        // check for new line
      nwords +=                       // check for transition of space to nonspace
        !isspace(cur) && isspace(last); 
      last = cur;
    }
  }
  printf("\n");                       // extra newline in case of keyboard signal
  printf("%d lines %d words %d chars\n",
         nlines, nwords, nchars);
  return 0;
}
