// Sample program to estimate PI = 3.14159... by randomly generating
// points in the positive quadrant and testing whether they are
// distance <= 1.0 from the origin.  The ratio of "hits" to tries is
// an approximation for the area of the quarter circle with radius 1
// so multiplying the ratio by 4 estimates pi.
// 
// usage: omp_picalc <num_samples> [threads]
//   num_samples: int, how many sample points to try, higher gets closer to pi

#include <stdio.h>
#include <omp.h>
#include <stdlib.h> 

int main(int argc, char **argv) { 
  if(argc < 2){
    printf("usage: omp_picalc <num_samples> \n");
    printf("  num_samples: int, how many sample points to try, higher gets closer to pi\n");
    return -1;
  }

  int npoints = atoi(argv[1]);
  int total_hits=0;

  unsigned int seed = 123456789;
  int i;
  for (i = 0; i < npoints; i++) { 
    double x = ((double) rand_r(&seed)) / ((double) RAND_MAX);
    double y = ((double) rand_r(&seed)) / ((double) RAND_MAX);
    if (x*x + y*y <= 1.0){
      total_hits++;
    }
  } 

  double pi_est = ((double)total_hits) / npoints * 4.0;
  printf("npoints: %8d\n",npoints);
  printf("hits:    %8d\n",total_hits);
  printf("pi_est:  %f\n",pi_est);
}
