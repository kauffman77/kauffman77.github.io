// Demonstrates several variants of picalc using reduction, atomic,
// and critical OpenMP clauses
//
// Uncommant sections marked A, B, C, D while commenting out other
// sections to see the effects. It is useful to time the results for
// comparison with
//
// > gcc omp_picalc_alt.c -fopenmp
// > time -p a.out 100000000

#include <stdio.h>
#include <omp.h>
#include <stdlib.h> 

int main(int argc, char **argv) { 
  if(argc < 2){
    printf("usage: omp_picalc <num_samples> [threads]\n");
    printf("  num_samples: int, how many sample points to try, higher gets closer to pi\n");
    printf("  threads: how many threads to use, to a limit more gets better performance\n");
    return -1;
  }

  if(argc > 2){
    omp_set_num_threads(atoi(argv[2]));
  }

  int npoints = atoi(argv[1]);
  int total_hits=0;

  // A
  // #pragma omp parallel reduction(+: total_hits)  
  // B and C
  #pragma omp parallel 
  { 
    int num_threads = omp_get_num_threads(); 
    int thread_id = omp_get_thread_num();
    int points_per_thread = npoints / num_threads; 
    unsigned int seed = 123456789 * thread_id;
    int private_total_hits = 0;
    int i;
    for (i = 0; i < points_per_thread; i++) { 
      double x = ((double) rand_r(&seed)) / ((double) RAND_MAX);
      double y = ((double) rand_r(&seed)) / ((double) RAND_MAX);
      if (x*x + y*y <= 1.0){
        // total_hits++; // A

        // B
        // #pragma omp atomic
        // total_hits++;

        // C
        // #pragma omp critical
        // {
        //   total_hits++;
        // }

        // D
        private_total_hits++;
      }
    }
    // D
    #pragma omp critical
    {
      total_hits += private_total_hits;
    }
  } 

  double pi_est = ((double)total_hits) / npoints * 4.0;
  printf("npoints: %8d\n",npoints);
  printf("hits:    %8d\n",total_hits);
  printf("pi_est:  %f\n",pi_est);
}
