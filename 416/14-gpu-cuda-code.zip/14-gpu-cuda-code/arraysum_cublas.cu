// arraysum_cublas.c: Demonstrates summing an array via the cuBLAS
// library.  Uses the sdot() functon which is intended for dot
// products but can be shoe-horned int summing an array.
//
// >> nvcc arraysum_cublas.cu -lcublas
// >> ./a.out 10000000 
// cudablasSdot sum:   10000000.0 gpu_millis:     0.2590 

#include <stdio.h>
#include <stdlib.h>

#include <cublas_v2.h>

int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <length> <nthreads> <kernelnum>\n",argv[0]);
    printf("  length:    length of array to sum\n");
    return 1;
  }
  
  int length   = atoi(argv[1]);

  cublasStatus_t status;
  cublasHandle_t handle;

  status = cublasCreate(&handle);

  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "!!!! CUBLAS initialization error\n");
    return EXIT_FAILURE;
  }

  // allocate array of 1.0's to reduce
  float host_sum = 0.0;
  float *host_x = (float *) malloc(sizeof(float) * length);

  for(int i=0; i<length; i++){
    host_x[i] = 1.0;
  }

  // allocate device (GPU) memory
  float *dev_x;                 // array of data
  cudaMalloc((void**) &dev_x,   length*sizeof(float));
  cudaMemcpy(dev_x, host_x, length*sizeof(float), cudaMemcpyHostToDevice);

  // 1 sum for each block to improve efficiency; some kernel variants
  // use only the 0th element, others use whole array
  float *dev_sum;
  cudaMalloc((void**) &dev_sum, sizeof(float));
  cudaMemset(dev_sum, 0, sizeof(float));

  float *dev_one, host_one=1.0;
  cudaMalloc((void**) &dev_one, sizeof(float));
  cudaMemcpy(dev_one, &host_one, sizeof(float), cudaMemcpyHostToDevice);
  
  cudaEvent_t beg, end;         // timers provided by CUDA
  cudaEventCreate(&beg);
  cudaEventCreate(&end);

  cudaEventRecord(beg);         // start time
  
  // sdot() computes the dot product of two vectors. To get the sum of
  // dev_x[], use 'vector' of a single 1.0 and an increment of 0 so
  // that the 1.0 is repeatedly used summing the first array.
  status = cublasSdot(handle, length, dev_x, 1, dev_one, 0, dev_sum);

  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "!!!! kernel execution error.\n");
    return EXIT_FAILURE;
  }

  cudaEventRecord(end);         // finish time
  cudaEventSynchronize(end);    // ensure device / cpu in sync
  float gpu_millis = 0;         // calculate elapsed time
  cudaEventElapsedTime(&gpu_millis, beg, end);  

  cudaDeviceSynchronize();

  // copy host memory to device
  cudaMemcpy(&host_sum, dev_sum, sizeof(float), cudaMemcpyDeviceToHost);
  
  printf("cudablasSdot ");
  printf("sum: %12.1f ", host_sum);
  printf("gpu_millis: %10.4f ", gpu_millis);
  printf("\n");

  free(host_x); 
  cudaFree(dev_x);
  cudaFree(dev_sum); 
  cudaFree(dev_one); 

  return 0;
}
