// matadd_cuda.cu: demonstration of a 2D kernel to add two
// matrices. Illustrates handling kernel launch as well as the `pitch`
// in CUDAs 2D array allocation/handling routines.
#include <stdio.h>
#include <stdlib.h>

// KERNEL: each thread performs one pair-wise addition. pitch is the
// width in bytes of rows.
__global__ void matrix_add(long pitch, long rows, long cols,
                           float* a, float* b, float* c)
{
  long row = threadIdx.x + blockDim.x * blockIdx.x; // x : vertical position (row)
  long col = threadIdx.y + blockDim.y * blockIdx.y; // y : horizontal position (col)
  long fpitch = pitch / sizeof(float);              // padded floats per row
  long idx = row * fpitch + col;                    // linear index into matrix
  if(row < rows && col < cols){
    c[idx] = a[idx] + b[idx];
    // // DEBUGGING
    // printf("mat[%3ld][%3ld] idx %4ld by block[%3d][%3d] thread[%3d][%3d] = %e %e\n",
    //        row, col, idx, 
    //        blockIdx.x, blockIdx.y, threadIdx.x, threadIdx.y,
    //        a[idx], b[idx]);
  }
}

int main(int argc, char *argv[]){
  if(argc < 5){
    printf("usage: %s <rows> <cols> <threadx> <thready>\n",argv[0]);
    return 1;
  }

  // command line parameters
  long rows = atol(argv[1]);
  long cols = atol(argv[2]);
  int threadx = atoi(argv[3]);
  int thready = atoi(argv[4]);

  // allocate / initialize vectors on host
  long bytes = sizeof(float)*rows*cols;
  float *host_a = (float *) malloc( bytes );
  float *host_b = (float *) malloc( bytes );
  float *host_c = (float *) malloc( bytes );

  // Initialize so that x[i][j] + y[i][j] = cols
  for(int i=0; i<rows; i++){
    for(int j=0; j<cols; j++){
      long idx = i*cols + j;
      host_a[idx] = (float) j+1;
      host_b[idx] = (float) cols-j-1;
      host_c[idx] = 0.0;
    }
  }

  // actual size of each row after cuda pads them
  size_t pitch_a, pitch_b, pitch_c;
  size_t width = sizeof(float)*cols;

  // allocate device (GPU) memory
  float *dev_a, *dev_b, *dev_c;
  cudaMallocPitch((void**) &dev_a, &pitch_a, width, rows);
  cudaMallocPitch((void**) &dev_b, &pitch_b, width, rows);
  cudaMallocPitch((void**) &dev_c, &pitch_c, width, rows);

  // copy host memory to device
  cudaMemcpy2D(dev_a, pitch_a, host_a, sizeof(float)*cols,
               width, rows, cudaMemcpyHostToDevice);
  cudaMemcpy2D(dev_b, pitch_b, host_b, sizeof(float)*cols,
               width, rows, cudaMemcpyHostToDevice);
  
  // calculate params for kernel execution
  int blockx = (rows + threadx - 1) / threadx;
  int blocky = (cols + thready - 1) / thready;
  dim3 blocks(blockx, blocky);
  dim3 threads(threadx, thready);

  printf("Running %3d x %3d Blocks w/ %3d x %3d threads each\n",
         blocks.x,blocks.y,threads.x,threads.y);

  // execute the GPU kernel
  matrix_add<<<blocks, threads>>>(pitch_a, rows, cols, dev_a, dev_b, dev_c);

  // copy device memory to host
  cudaMemcpy2D(host_c, sizeof(float)*cols, dev_c, pitch_c,
               width, rows, cudaMemcpyDeviceToHost);
  
  // verify results
  float fcols = (float) cols;
  int okay = 1;
  for(int i=0; i<rows; i++){
    for(int j=0; j<cols; j++){
      int idx = i*cols + j;
      float diff = host_c[idx] - fcols;
      if( diff > 1e-4 || diff < -1e-4 ){
        printf("[%2d][%2d] %.6e vs %.6e, diff %.6e\n",
               i, j, host_c[idx], fcols, diff);
        okay = 0;
      }
    }
  }
  if(okay){
    printf("all element sums verified\n");
  }

  // free host memory
  free(host_a); free(host_b); free(host_c);

  // free device memory
  cudaFree(dev_a); cudaFree(dev_b); cudaFree(dev_c);

  return 0;
}
