
#include <stdio.h>
#include <stdlib.h>

__global__ void odd_even_round(float *data, int length)
{
  int idx = 2 * (threadIdx.x + blockDim.x * blockIdx.x);
  if(idx < length-1){
    float x = data[idx+0];
    float y = data[idx+1];
    float newx = min(x,y);
    float newy = max(x,y);
    data[idx+0] = newx;
    data[idx+1] = newy;
  }
}


// convenience type to enable casting of typed comparisong functions
// to the void-ish functions expected by qsort()
typedef int (*cmp_t) (const void *, const void *);

// compare two floats pointed to
int floatcmp(const float *xp, const float *yp) { 
  float diff = *xp - *yp;
  if(diff < 0){
    return -1;
  }
  else if(diff > 0){
    return +1;
  }
  else{
    return 0;
  }
}


int main(int argc, char *argv[]){
  if(argc < 3){
    printf("usage: %s <length> <nthreads>\n",argv[0]);
    printf("  length:    length of array to sum\n");
    printf("  nthreads:  threads per block\n");
    // printf("  kernelnum: which reduction kernel to try\n");
    return 1;
  }
  
  int length   = atoi(argv[1]);
  int nthreads = atoi(argv[2]);
  int nblocks = (length/2 + nthreads -1) / nthreads;
  // use total_threads = length / 2;

  // allocate array of 1.0's to reduce
  float *host_x = (float *) malloc(sizeof(float) * length);
  float *host_y = (float *) malloc(sizeof(float) * length);

  srand(1234567890);            // Generate random numbers on the host
  for(int i=0; i<length; i++){
    float r = ((float) random()) / RAND_MAX;
    r = r*2.0 - 1.0;
    host_x[i] = r;
    host_y[i] = r;
  }
  if(getenv("DEBUG")){
    printf("INITIAL:\n");
    for(int i=0; i<length; i++){
      printf("[%3d] %.4f\n",i,host_x[i]);
    }
  }

  // allocate device (GPU) memory and copy over host data
  float *dev_x;                 // array of data
  cudaMalloc((void**) &dev_x,   length*sizeof(float));
  cudaMemcpy(dev_x, host_x, length*sizeof(float), cudaMemcpyHostToDevice);

  cudaEvent_t beg, end;         // timers provided by CUDA
  cudaEventCreate(&beg);
  cudaEventCreate(&end);

  cudaEventRecord(beg);         // start time
  

  for(int i=0; i<length; i++){
    if(i % 2 == 0){
      odd_even_round<<<nblocks, nthreads>>>(dev_x, length);
    }
    else{
      odd_even_round<<<nblocks, nthreads>>>(dev_x+1, length-1);
    }
  }

  cudaEventRecord(end);         // finish time
  cudaEventSynchronize(end);    // ensure device / cpu in sync
  float gpu_millis = 0;         // calculate elapsed time
  cudaEventElapsedTime(&gpu_millis, beg, end);  


  cudaDeviceSynchronize();

  // copy host memory to device
  cudaMemcpy(host_x, dev_x, length*sizeof(float), cudaMemcpyDeviceToHost);
  
  // verify using a cpu sort on identical data
  clock_t cpu_beg = clock();
  qsort((void*) host_y, length, sizeof(float), (cmp_t) floatcmp);
  clock_t cpu_end = clock();
  float cpu_millis = ((float) (cpu_end - cpu_beg)) / CLOCKS_PER_SEC;
  cpu_millis *= 1000;

  if(getenv("DEBUG")){
    printf("FINAL:\n");
    for(int i=0; i<length; i++){
      printf("[%3d] %.4f\n",i,host_x[i]);
    }
  }

  for(int i=0; i<length; i++){
    if(host_x[i] != host_y[i]){
      printf("UNORDERED: xy[%3d] = %.4f VS %.4f\n",
             i,  host_x[i], host_y[i]);
    }
  }

  // for(int i=0; i<length-1; i++){
  //   if(host_x[i] > host_x[i+1]){
  //     printf("UNORDERED: x[%d] = %.4f VS x[%d] = %.4f\n",
  //            i,  host_x[i],
  //            i+1,host_x[i+1]);
  //   }
  // }

  


  // int kernel = 0;
  // printf("Kernel %d ",kernelnum);
  printf("length %10d ",length);
  printf("nblocks %6d ",nblocks);
  printf("nthreads %4d ",nthreads);
  printf("gpu_millis: %10.4f ", gpu_millis);
  printf("cpu_millis: %10.4f ", cpu_millis);
  printf("\n");

  free(host_x); 
  cudaFree(dev_x);

  return 0;
}

  
  
