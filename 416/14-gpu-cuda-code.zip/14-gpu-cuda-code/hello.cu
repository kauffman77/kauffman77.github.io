// hello.cu: C code demonstrating basics of cuda
// 
// >> ssh csel-broccoli.cselabs.umn.edu
// >> module load soft/cuda        # load module associated with cuda
// >> nvcc hello.cu                # compile cuda code with NVidia compiler driver
// >> ls
// a.out  hello.cu
// >> file a.out                   # show file type of a.out
// a.out: ELF 64-bit LSB shared object, x86-64, version 1 (SYSV), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, BuildID[sha1]=dcbf0af1b6abfec1c461ccdc03e44b6146edd8e9, for GNU/Linux 3.2.0, not stripped
// >> ./a.out                      # run executable
// Thread 00: Hello World
// Thread 01: Hello World
// ...
// Thread 15: Hello World

#include <stdio.h>

__global__ void hello_gpu() {   // __global__ => called from CPU/GPU, runs on GPU
  printf("Block %02d Thread %02d: Hello World\n",
         blockIdx.x,            // ever-present structs which gives
         threadIdx.x);          // each GPU thread indexing info
}

int main (int argc, char *argv[]){
  printf("CPU: Running 1 block w/ 16 threads\n");
  hello_gpu<<<1,16>>>();        // executes in 1 block, 16 threads per block
  cudaDeviceSynchronize();      // ensures GPU completes operations

  printf("\n");

  int nblocks  = argc < 2 ? 3 : atoi(argv[1]); // default 3 blocks
  int nthreads = argc < 3 ? 4 : atoi(argv[2]); // default 4 threads/block
  printf("CPU: Running %d blocks w/ %d threads\n",
         nblocks, nthreads);

  hello_gpu<<<nblocks, nthreads>>>();
  cudaDeviceSynchronize();
  return 0;
}
