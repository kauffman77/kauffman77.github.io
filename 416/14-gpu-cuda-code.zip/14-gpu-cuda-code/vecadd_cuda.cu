// vecadd_cuda.cu: example of performing a vector addition using
// CUDA. Demonstrates a simple kernel along with the memory allocation
// scheme between host/device.

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

// macro to check that cuda operations succeed and bail if not
#define CHECK(EXPR) (assert(cudaSuccess == (EXPR)))

// KERNEL: each thread performs one pair-wise addition
__global__ void vector_add(long length,
                           float* x, float* y, float* z)
{
  long idx = threadIdx.x + blockDim.x * blockIdx.x;
  if(idx < length){
    z[idx] = x[idx] + y[idx];
  }
}

int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <veclength>\n",argv[0]);
    return 1;
  }
  
  long length = atol(argv[1]);

  // allocate / initialize vectors on host; due to CUDA being
  // C++ oriented, the (float *) caste is required.
  float *host_x = (float *) malloc(sizeof(float) * length);
  float *host_y = (float *) malloc(sizeof(float) * length);
  float *host_z = (float *) malloc(sizeof(float) * length);

  // Initialize so that x[i] + y[i] = length
  for(int i=0; i<length; i++){
    host_x[i] = (float) i;
    host_y[i] = (float) length-i;
    host_z[i] = 0.0;
  }

  // allocate device (GPU) memory
  float *dev_x, *dev_y, *dev_z;
  cudaError err;
  err = cudaMalloc((void**) &dev_x, length * sizeof(float));
  assert(err == cudaSuccess);
  err = cudaMalloc((void**) &dev_y, length * sizeof(float));
  assert(err == cudaSuccess);
  err = cudaMalloc((void**) &dev_z, length * sizeof(float));
  assert(err == cudaSuccess);

  // copy host memory to device
  CHECK( cudaMemcpy(dev_x, host_x, length*sizeof(float), cudaMemcpyHostToDevice) );
  CHECK( cudaMemcpy(dev_y, host_y, length*sizeof(float), cudaMemcpyHostToDevice) );
  
  // calculate params for kernel execution
  long nthreads = 256;
  long nblocks  = (length+255) / nthreads;

  printf("Running %ld Blocks w/ %ld threads each\n",
         nblocks, nthreads);

  // execute the GPU kernel
  vector_add<<<nblocks, nthreads>>>(length, dev_x, dev_y, dev_z);

  // cudaDeviceSynchronize();
  // 
  // sync is not strictly necessary because next op is to copy back to
  // host which blocks until GPU kernels finished before copying
  // memory to the host. Copying to the host always blocks host until
  // launched kernels complete and data transfer completes.

  // copy device memory to host
  CHECK( cudaMemcpy(host_z, dev_z, length*sizeof(float), cudaMemcpyDeviceToHost) );
  
  for(int i=0; i<length; i++){  // print results of addition
    if(i % 10 == 0){
      printf("\n%4d: ",i);
    }
    printf("%6.1f ", host_z[i]);
  }
  printf("\n");

  // free host memory
  free(host_x); free(host_y); free(host_z);

  // free device memory
  cudaFree(dev_x); cudaFree(dev_y); cudaFree(dev_z);

  return 0;
}

  
  
