// arraysum_cuda.cu: Array summing benchmark. Explores several
// variants of algorithms to sum the contents of an array.
//
// usage: ./a.out <length> <nthreads> <kernelnum>
//   length:    length of array to sum
//   nthreads:  threads per block
//   kernelnum: which reduction kernel to try
// 
// EXAMPLES
// >> ./a.out 10000000 64 4
// Kernel 4 nblocks   156250 nthreads   64 sum:   10000000.0 gpu_millis:     0.9232 
//
// >> ./a.out 10000000 128 3
// Kernel 3 nblocks    78125 nthreads  128 sum:   10000000.0 gpu_millis:     0.7149 
//
// >> for nthreads in 32 64 128 256 512; do ./a.out 10000000 $nthreads 4; done
// Kernel 4 nblocks   312500 nthreads   32 sum:   10000000.0 gpu_millis:     1.8330 
// Kernel 4 nblocks   156250 nthreads   64 sum:   10000000.0 gpu_millis:     0.9232 
// Kernel 4 nblocks    78125 nthreads  128 sum:   10000000.0 gpu_millis:     0.8895 
// Kernel 4 nblocks    39063 nthreads  256 sum:   10000000.0 gpu_millis:     0.9898 
// Kernel 4 nblocks    19532 nthreads  512 sum:   10000000.0 gpu_millis:     1.1520 

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

// all threads hit the same global sum; no syncronization on global
// memory so results are not computed correctly
__global__ void array_sum_1(int length, float* data, float *sum)
{
  int i = threadIdx.x + blockDim.x * blockIdx.x;
  if(i < length){
    float myelem = data[i];
    *sum += myelem;
  }
}

// all threads hit the same global sum with atomic operations
__global__ void array_sum_2(int length, float* data, float *sum)
{
  int i = threadIdx.x + blockDim.x * blockIdx.x;
  if(i < length){
    float myelem = data[i];
    atomicAdd(sum, myelem);
  }
}

// let lead thread perform a loop to sum all data elements
__global__ void array_sum_3(int length, float* data, float *sum)
{
  if(threadIdx.x == 0){         // thread 0 iterates over shared array summing
    float blocksum = 0.0;
    int idx = threadIdx.x + blockDim.x * blockIdx.x;
    for(int i=0; i < blockDim.x; i++){
      if(idx+i >= length){
        break;
      }
      blocksum += data[i+idx];
    }
    atomicAdd(sum, blocksum);
    // printf("Block %04d from %d to %d adding on %.lf\n",
    //        blockIdx.x, idx, idx+blockDim.x, blocksum);
  }
}

// all threads transfer data to shared cache memory; thread 0 sums the
// array and atomically updates the global
__global__ void array_sum_4(int length, float* data, float *sum)
{
  extern __shared__ float blockvals[];
  blockvals[threadIdx.x] = 0.0;

  int idx = threadIdx.x + blockDim.x * blockIdx.x;
  if(idx < length){
    blockvals[threadIdx.x] = data[idx];
  }

  __syncthreads();              // ensure all threads have completed copying

  if(threadIdx.x == 0){         // thread 0 iterates over shared array summing
    float blocksum = 0.0;
    for(int i=0; i < blockDim.x; i++){
      blocksum += blockvals[i];
    }
    atomicAdd(sum, blocksum);
  }
}

// Perform a true multi-thread reduction using shared memory
__global__ void array_sum_5(int length, float* data, float *sum)
{
  extern __shared__ float blockvals[];
  blockvals[threadIdx.x] = 0.0;

  int idx = threadIdx.x + blockDim.x * blockIdx.x;
  if(idx < length){
    blockvals[threadIdx.x] = data[idx];
  }

  __syncthreads();

  for(int i=blockDim.x/2; i > 0; i /= 2){
    int partner = threadIdx.x + i;
    if(threadIdx.x < i){
      blockvals[threadIdx.x] += blockvals[partner];
    }
    __syncthreads();
  }

  if(threadIdx.x == 0){
    // printf("Block %04d adding on %.lf\n",
    //        blockIdx.x,blockvals[0]);
    atomicAdd(sum, blockvals[0]);
  }
}


// Attempt to statically code the loop - not any better than other
// versions
__global__ void array_sum_6(int length, float* data, float *sum)
{
  __shared__ float blockvals[256];
  int tid = threadIdx.x;

  blockvals[tid] = 0.0;

  int idx = threadIdx.x + blockDim.x * blockIdx.x;
  if(idx < length){
    blockvals[tid] = data[idx];
  }

  __syncthreads();

  if(tid < 128){ blockvals[tid] += blockvals[tid+128]; }
  __syncthreads();
  if(tid <  64){ blockvals[tid] += blockvals[tid+ 64]; }
  __syncthreads();
  if(tid <  32){ blockvals[tid] += blockvals[tid+ 32]; }
  __syncthreads();
  if(tid <  16){ blockvals[tid] += blockvals[tid+ 16]; }
  __syncthreads();
  if(tid <   8){ blockvals[tid] += blockvals[tid+  8]; }
  __syncthreads();
  if(tid <   4){ blockvals[tid] += blockvals[tid+  4]; }
  __syncthreads();
  if(tid <   2){ blockvals[tid] += blockvals[tid+  2]; }
  __syncthreads();
  if(tid <   1){ blockvals[tid] += blockvals[tid+  1]; }
  __syncthreads();


  if(tid == 0){
    atomicAdd(sum, blockvals[0]);
  }
}


// // BROKEN CODE: for demoing style only, does not produce correct results.
// // threads hit a block-specific sum - requires 2 passes.
// __global__ void array_sum_broken(int length, float* data, float *sums)
// {
//   int i = threadIdx.x + blockDim.x * blockIdx.x;
//   if(i < length){
//     float myelem = data[i];
//     atomicAdd(&sums[blockIdx.x], myelem);
//   }
// }


typedef enum {
  NONE        = 0,
  ARRAY_SUM_1 = 1,
  ARRAY_SUM_2 = 2,
  ARRAY_SUM_3 = 3,
  ARRAY_SUM_4 = 4,
  ARRAY_SUM_5 = 5,
  ARRAY_SUM_6 = 6,
} KERNELS;

int main(int argc, char *argv[]){
  if(argc < 4){
    printf("usage: %s <length> <nthreads> <kernelnum>\n",argv[0]);
    printf("  length:    length of array to sum\n");
    printf("  nthreads:  threads per block\n");
    printf("  kernelnum: which reduction kernel to try\n");
    return 1;
  }
  
  int length   = atoi(argv[1]);
  int nthreads = atoi(argv[2]);
  int nblocks = (length + nthreads -1) / nthreads; // calculate number of blocks
  int kernelnum = atoi(argv[3]);

  // allocate array of 1.0's to reduce
  float host_sum = 0.0;
  float *host_x = (float *) malloc(sizeof(float) * length);

  for(int i=0; i<length; i++){
    host_x[i] = 1.0;
  }

  // allocate device (GPU) memory
  float *dev_x;                 // array of data
  cudaMalloc((void**) &dev_x,   length*sizeof(float));
  cudaMemcpy(dev_x, host_x, length*sizeof(float), cudaMemcpyHostToDevice);


  // 1 sum for each block to improve efficiency; some kernel variants
  // use only the 0th element, others use whole array
  float *dev_sums;               
  cudaMalloc((void**) &dev_sums, nblocks*sizeof(float));
  cudaMemset(dev_sums, 0, nblocks*sizeof(float));
  
  size_t shared_size = sizeof(float)*nthreads; // used only in some kernels

  cudaEvent_t beg, end;         // timers provided by CUDA
  cudaEventCreate(&beg);
  cudaEventCreate(&end);

  cudaEventRecord(beg);         // start time
  

  // execute one of the GPU kernels
  switch(kernelnum){
    case ARRAY_SUM_1:
      array_sum_1<<<nblocks, nthreads>>>(length, dev_x, dev_sums);
      break;
  
    case ARRAY_SUM_2:
      array_sum_2<<<nblocks, nthreads>>>(length, dev_x, dev_sums);
      break;
  
    case ARRAY_SUM_3:           // no space needed as only locals used
      array_sum_3<<<nblocks, nthreads>>>(length, dev_x, dev_sums);
      break;

    case ARRAY_SUM_4:
      array_sum_4<<<nblocks, nthreads, shared_size>>>(length, dev_x, dev_sums);
      break;

    case ARRAY_SUM_5:
      array_sum_5<<<nblocks, nthreads, shared_size>>>(length, dev_x, dev_sums);
      break;

    case ARRAY_SUM_6:           // no space needed as size is static
      array_sum_6<<<nblocks, nthreads>>>(length, dev_x, dev_sums);
      break;

    default:
      printf("Error: no such kernel %d\n",kernelnum);
      exit(1);
    }
    

  cudaEventRecord(end);         // finish time
  cudaEventSynchronize(end);    // ensure device / cpu in sync
  float gpu_millis = 0;         // calculate elapsed time
  cudaEventElapsedTime(&gpu_millis, beg, end);  


  cudaDeviceSynchronize();

  // copy host memory to device
  cudaMemcpy(&host_sum, &dev_sums[0], sizeof(float), cudaMemcpyDeviceToHost);
  
  printf("Kernel %d ",kernelnum);
  printf("nblocks %8d ",nblocks);
  printf("nthreads %4d ",nthreads);
  printf("sum: %12.1f ", host_sum);
  printf("gpu_millis: %10.4f ", gpu_millis);
  printf("\n");

  free(host_x); 
  cudaFree(dev_x);
  cudaFree(dev_sums); 

  return 0;
}

  
  
