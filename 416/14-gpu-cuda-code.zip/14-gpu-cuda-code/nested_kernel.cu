// nested_kernel.cu: Code demoing nested kernels
// 
// compile:
// >> nvcc nested_kernel.cu -gencode arch=compute_70,code=sm_70 -rdc=true
//
// Original source:
// https://developer.download.nvidia.com/assets/cuda/files/CUDADownloads/TechBrief_Dynamic_Parallelism_in_CUDA.pdf
// 
// Kauffman: Modified to make it minimally executable example and remove bugs in that source

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

__global__ void ChildKernel(int par_bx, int par_tx, void* data){
  printf("Child thread par_bx: %d par_tx: %d blockIdx.x: %d threadIdx.x: %d\n",
         par_bx, par_tx, blockIdx.x, threadIdx.x);
  // NOTE: child has no way to know what parent created it unless
  // parent passes parameters reflecting this as is done here
}
__global__ void ParentKernel(void *data){
  if (threadIdx.x == 0) {
    printf("Parent thread blockIdx.x: %d threadIdx.x: %d\n",
           blockIdx.x, threadIdx.x);
    ChildKernel<<<2, 16>>>(blockIdx.x, threadIdx.x, data);
  }
  __syncthreads();
  // Potentially new operations on data
}

// Host Code
int main(int argc, char *argv[]){
  printf("Launching parent kernel\n");
  void *data = NULL;
  ParentKernel<<<4, 8>>>(data);
  cudaDeviceSynchronize();
  return 0;
}
