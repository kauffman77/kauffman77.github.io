// vecloop_cuda.cu: repeatedly performing vector addition using CUDA.
//
// Launch this program with large parameters such as
// 
// broccoli>> ./a.out 20000 1000000000 device > /dev/null
//
// Then in a separate terminal use "top" or the following invocation
// to observe the GPU monitoring utility nvidia-smi
//
// broccoli>> watch -n 0.1 nvidia-smi

#include <stdio.h>
#include <stdlib.h>

// (A) KERNEL: each thread performs one pair-wise addition
__global__ void vector_add(long length,
                           float* x, float* y, float* z)
{
  long idx = threadIdx.x + blockDim.x * blockIdx.x;
  if(idx < length){
    z[idx] = x[idx] + y[idx];
  }
}

// (B) KERNEL: each thread performs a loop of additions
__global__ void vector_loopadd(long iterations, long length,
                               float* x, float* y, float* z)
{
  int idx = threadIdx.x + blockDim.x * blockIdx.x;
  if(idx < length){
    for(long i=0; i<iterations; i++){
      z[idx] = x[idx] + y[idx];
    }
  }
}


int main(int argc, char *argv[]){
  if(argc < 4){
    printf("usage: %s <veclength> <iterations> {host,device}\n",argv[0]);
    return 1;
  }
  
  long length = atol(argv[1]);
  long iterations = atol(argv[2]);
  char *style = argv[3];

  // allocate / initialize vectors on host; due to CUDA being
  // C++ oriented, the (float *) caste is required.
  float *host_x = (float *) malloc(sizeof(float) * length);
  float *host_y = (float *) malloc(sizeof(float) * length);
  float *host_z = (float *) malloc(sizeof(float) * length);
  for(int i=0; i<length; i++){
    host_x[i] = (float) i;
    host_y[i] = (float) length-i-1;
    host_z[i] = 0.0;
  }

  // allocate device (GPU) memory
  float *dev_x, *dev_y, *dev_z;
  cudaMalloc((void**) &dev_x, length * sizeof(float));
  cudaMalloc((void**) &dev_y, length * sizeof(float));
  cudaMalloc((void**) &dev_z, length * sizeof(float));

  // copy host memory to device
  cudaMemcpy(dev_x, host_x, length*sizeof(float), cudaMemcpyHostToDevice);
  cudaMemcpy(dev_y, host_y, length*sizeof(float), cudaMemcpyHostToDevice);
  
  // calculate params for kernel execution
  int nthreads = 256;
  int nblocks  = (length+255) / nthreads;

  printf("Running %d Blocks w/ %d threads each\n",
         nblocks, nthreads);

  // execute the GPU kernel
  if(0){}

  else if( strcmp(style,"host") == 0){ // loop on CPU repeatedly lauchning kernels
    // (A) Repeated Kernel invocation from host
    for(long i=0; i<iterations; i++){
      vector_add<<<nblocks, nthreads>>>(length, dev_x, dev_y, dev_z);
    }
  }

  else if( strcmp(style,"device") == 0){ // perform loop in GPU kernel
    // (B) Single kernel invocation with device loop
    vector_loopadd<<<nblocks, nthreads>>>(iterations, length, dev_x, dev_y, dev_z);
  }

  else{
    printf("Unknown style '%s'; computing nothing\n",style);
  }

  // cudaDeviceSynchronize();
  // sync is not strictly necessary because next op is tocopy back to
  // host which blocks until GPU kernels finished before copying
  // memory to the host. Copying to the host always blocks host until
  // transfer completes.

  // copy host memory to device
  cudaMemcpy(host_z, dev_z, length*sizeof(float), cudaMemcpyDeviceToHost);
  
  for(int i=0; i<length; i++){
    if(i % 10 == 0){
      printf("%4d: ",i);
    }
    printf("%6.1f ", host_z[i]);
    if((i + 1) % 10 == 0){
      printf("\n");
    }
  }
  printf("\n");

  free(host_x); free(host_y); free(host_z);
  cudaFree(dev_x); cudaFree(dev_y); cudaFree(dev_z);

  return 0;
}

  
  
