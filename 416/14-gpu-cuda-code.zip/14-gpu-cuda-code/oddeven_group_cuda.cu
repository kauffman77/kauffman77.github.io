// oddeven_group_cuda.cu: Demonstrates use of cooperative groups to
// coordinate across multiple blocks. Allows the odd_even sort to be
// reworked to avoid repeated kernel launches.

#include <stdio.h>
#include <stdlib.h>
#include <cooperative_groups.h> // brings in types / functions for coopeartive groups

namespace cg = cooperative_groups; // C++ syntax to shorten namespace reference

// perform odd-even sort on the GPU using cooperative group sync'ing
// across iterations
__global__ void odd_even_gridsync(float *data, int length)
{
  cg::grid_group grid = cg::this_grid(); // retrieve grid for this thread
  int idx = 2 * (threadIdx.x + blockDim.x * blockIdx.x);

  for(int i=0; i < length/2+1; i++){
    float x,y,newx,newy;
    if(idx < length-1){         // even iteration
      x = data[idx+0];
      y = data[idx+1];
      newx = min(x,y);
      newy = max(x,y);
      data[idx+0] = newx;
      data[idx+1] = newy;
      // printf("DEBUG: e %4d : %+f %+f\n",idx,newx,newy);
    }
    grid.sync();                // sync entire grid at this point
    if(idx < length-2){         // odd iteration
      x = data[idx+1];
      y = data[idx+2];
      newx = min(x,y);
      newy = max(x,y);
      data[idx+1] = newx;
      data[idx+2] = newy;
      // printf("DEBUG: o %4d : %+f %+f\n",idx,newx,newy);
    }
    grid.sync();
  }
}
// same code as above sans the sync which will lead to incorrect
// results. Not currently active in main() but useful for
// experimentation.
__global__ void odd_even_nosync(float *data, int length) {
  int idx = 2 * (threadIdx.x + blockDim.x * blockIdx.x);
  for(int i=0; i < length/2+1; i++){
    float x,y,newx,newy;
    if(idx < length-1){         // even iteration
      x = data[idx+0];
      y = data[idx+1];
      newx = min(x,y);
      newy = max(x,y);
      data[idx+0] = newx;
      data[idx+1] = newy;
    }
    // grid.sync();             // missing sync leads to incorrect results
    if(idx < length-2){         // odd iteration
      x = data[idx+1];
      y = data[idx+2];
      newx = min(x,y);
      newy = max(x,y);
      data[idx+1] = newx;
      data[idx+2] = newy;
    }
    // grid.sync();             // missing sync leads to incorrect results
  }
}

// convenience type to enable casting of typed comparisong functions
// to the void-ish functions expected by qsort()
typedef int (*cmp_t) (const void *, const void *);

// compare two floats pointed to
int floatcmp(const float *xp, const float *yp) { 
  float diff = *xp - *yp;
  if(diff < 0){
    return -1;
  }
  else if(diff > 0){
    return +1;
  }
  else{
    return 0;
  }
}

int main(int argc, char *argv[]){
  if(argc < 3){
    printf("usage: %s <length> <nthreads>\n",argv[0]);
    printf("  length:    length of array to sum\n");
    printf("  nthreads:  threads per block\n");
    return 1;
  }
  
  int length   = atoi(argv[1]);
  int nthreads = atoi(argv[2]);
  int nblocks = (length/2 + nthreads -1) / nthreads;

  // check that threads can be sync'd in a grid - must all be on the
  // GPU at once
  int max_threads, max_blocks;
  cudaOccupancyMaxPotentialBlockSize(&max_blocks, &max_threads, odd_even_gridsync, 0, 0);
  if(nthreads * nblocks > max_threads * max_blocks){
    printf("WARNING: Exceeding max total threads that can be sync'd in cooperative groups\n");
    printf("WARNING: This may cause deadlock\n");
    printf("MAX: %4d threads * %4d blocks = %8d grid threads\n",
           max_threads,max_blocks,max_threads*max_blocks);
    printf("REQ: %4d threads * %4d blocks = %8d grid threads\n",
           nthreads, nblocks,nthreads*nblocks);
  }

  // allocate array of 1.0's to reduce
  float *host_x = (float *) malloc(sizeof(float) * length);
  float *host_y = (float *) malloc(sizeof(float) * length);

  srand(1234567890);            // Generate random numbers on the host
  for(int i=0; i<length; i++){
    float r = ((float) random()) / RAND_MAX;
    r = r*2.0 - 1.0;
    host_x[i] = r;
    host_y[i] = r;
  }
  if(getenv("DEBUG")){
    printf("INITIAL:\n");
    for(int i=0; i<length; i++){
      printf("[%4d] %+.4f\n",i,host_x[i]);
    }
  }

  // allocate device (GPU) memory and copy over host data
  float *dev_x;                 // array of data
  cudaMalloc((void**) &dev_x,   length*sizeof(float));
  cudaMemcpy(dev_x, host_x, length*sizeof(float), cudaMemcpyHostToDevice);

  cudaEvent_t beg, end;         // timers provided by CUDA
  cudaEventCreate(&beg);
  cudaEventCreate(&end);

  cudaEventRecord(beg);         // start time
  

  // // To use cooperative groups and sync across blocks, cannot use standard
  // // Kernel launch - this will silently fail. Instead, use the code below: the
  // // cudaLaunchCooperativeKernel() function
  // odd_even<<<nblocks, nthreads>>>(dev_x, length);


  // form an argument array for the cooperative kernel launch; all
  // types void, all arguments are pointes to host variables that will
  // be sent to to the kernel.
  void *arguments[] = {(void *)&dev_x, (void *)&length};

  // launch the cooperative kernel
  cudaLaunchCooperativeKernel((void*) odd_even_gridsync,
                              nblocks, nthreads, arguments);

  cudaEventRecord(end);         // finish time
  cudaEventSynchronize(end);    // ensure device / cpu in sync
  float gpu_millis = 0;         // calculate elapsed time
  cudaEventElapsedTime(&gpu_millis, beg, end);  


  cudaDeviceSynchronize();

  // copy dev mem to host
  cudaMemcpy(host_x, dev_x, length*sizeof(float), cudaMemcpyDeviceToHost);
  
  // verify using a cpu sort on identical data
  clock_t cpu_beg = clock();
  qsort((void*) host_y, length, sizeof(float), (cmp_t) floatcmp);
  clock_t cpu_end = clock();
  float cpu_millis = ((float) (cpu_end - cpu_beg)) / CLOCKS_PER_SEC;
  cpu_millis *= 1000;

  if(getenv("DEBUG")){
    printf("FINAL:\n");
    for(int i=0; i<length; i++){
      printf("[%4d] %+.4f\n",i,host_x[i]);
    }
  }

  for(int i=0; i<length; i++){
    if(host_x[i] != host_y[i]){
      printf("UNORDERED: xy[%5d] = %+.4f VS %+.4f\n",
             i,  host_x[i], host_y[i]);
    }
  }

  // for(int i=0; i<length-1; i++){
  //   if(host_x[i] > host_x[i+1]){
  //     printf("UNORDERED: x[%d] = %.4f VS x[%d] = %.4f\n",
  //            i,  host_x[i],
  //            i+1,host_x[i+1]);
  //   }
  // }

  


  // int kernel = 0;
  // printf("Kernel %d ",kernelnum);
  printf("length %10d ",length);
  printf("nblocks %6d ",nblocks);
  printf("nthreads %4d ",nthreads);
  printf("gpu_millis: %10.4f ", gpu_millis);
  printf("cpu_millis: %10.4f ", cpu_millis);
  printf("\n");

  free(host_x); 
  cudaFree(dev_x);

  return 0;
}

  
  
