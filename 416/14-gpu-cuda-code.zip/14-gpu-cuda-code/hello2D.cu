// hello2D.cu: demonstration of dim3 data type and launch of 2D
// blocks and threads

#include <stdio.h>

__global__ void hello_gpu2D() {
  printf("Block[%02d,%02d] Thread[%02d,%02d]: Hello World\n",
         blockIdx.x,  blockIdx.y,
         threadIdx.x, threadIdx.y);
}

int main (int argc, char *argv[]){
  int thread_x=4, thread_y=2;
  int block_x=3, block_y=5;

  if(argc >= 5){
    thread_x = atoi(argv[1]);
    thread_y = atoi(argv[2]);
    block_x  = atoi(argv[3]);
    block_y  = atoi(argv[4]);
  }

  dim3 threadsPerBlock(thread_x, thread_y);
  dim3 blocksPerGrid(block_x, block_y);

  printf("CPU: Running %d x %d blocks w/ %d x %d threads\n",
         blocksPerGrid.x, blocksPerGrid.y,
         threadsPerBlock.x, threadsPerBlock.y);

  hello_gpu2D<<<blocksPerGrid, threadsPerBlock>>>();
  cudaDeviceSynchronize();

  int tot_threads = thread_x * thread_y * block_x * block_y;
  printf("%d threads complete\n",tot_threads);
  return 0;
}
