The Hostfiles that are given here *may* work on various CSE Labs
clusters. They were tested with some success in Fall 2021 but due to
the clusters being re-arranged with some frequency, they won't always
work.  Running MPI codes across different hosts requires SSH key
access to them (e.g. no password prompt).
