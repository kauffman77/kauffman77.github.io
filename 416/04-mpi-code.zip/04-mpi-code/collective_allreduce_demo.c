// collective_allreduce_demo.c: Demonstration of the MPI_Allreduce
// function; sums/products/maxes/mins distinct data from individual
// procs onto a single proc
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char **argv){
  MPI_Init (&argc, &argv);

  int procid, total_procs, i, *send_buf, *recv_buf;
  int root_proc = 0;

  MPI_Comm_size(MPI_COMM_WORLD, &total_procs); 
  MPI_Comm_rank(MPI_COMM_WORLD, &procid); 

  int total_elements = 8;

  // Everyone allocates for their share of data including root
  send_buf = malloc(sizeof(int) * total_elements);

  /* Each proc fills send_buf[] with unique values */
  int x = 1;
  for(i=0; i<total_elements; i++){
    send_buf[i] = x;
    x *= (procid+2);
  }
  // send_buf[] now filled with unique values on each proc

  // Each proc reports its contents
  printf("proc %d elements: ",procid);
  for(i=0; i<total_elements; i++){
    printf("%6d ",send_buf[i]);
  }
  printf("\n");

  // Everyon allocates reduced_data to be filled with reduced data
  recv_buf = malloc(sizeof(int) * total_elements);

  // Everyone calls reduce, everyone sends and receives
  MPI_Allreduce(send_buf, recv_buf, total_elements, MPI_INT,
                MPI_SUM, // operation to perform on each element
                MPI_COMM_WORLD); 
  // recv_buf[] now contains each procs send_buf[] summed up on ALL procs

  // Each proc reports its reduced data
  printf("proc %d SUM     : ",procid);
  for(i=0; i<total_elements; i++){
    printf("%6d ",recv_buf[i]);
  }
  printf("\n");

  MPI_Barrier(MPI_COMM_WORLD);  // barrier to make printing saner

  // Reduce again but this time find the MIN and do it in place with
  // option MPI_IN_PLACE 
  MPI_Allreduce(MPI_IN_PLACE, send_buf, total_elements, MPI_INT,
                MPI_MIN, // operation to perform on each element
                MPI_COMM_WORLD); 
  // send_buf[] now contains min elements on all procs

  // Each proc reports its reduced data
  printf("proc %d MIN     : ",procid);
  for(i=0; i<total_elements; i++){
    printf("%4d ",send_buf[i]);
  }
  printf("\n");

  // Everyone frees data
  free(send_buf);
  free(recv_buf);

  MPI_Finalize();
  return 0;
}
