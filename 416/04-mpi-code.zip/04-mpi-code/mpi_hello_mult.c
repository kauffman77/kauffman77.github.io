// mpi_hello_mult.c: like mpi_hello.c but all procs print multiple
// messages to show interleaving and arbitrary ordering of output

#include <stdio.h>
#include <mpi.h>

int main (int argc, char *argv[]){
  int rank;                     // the id of this processor
  int size;                     // the number of processors being used

  MPI_Init (&argc, &argv);               // starts MPI
  MPI_Comm_rank (MPI_COMM_WORLD, &rank); // get current process id
  MPI_Comm_size (MPI_COMM_WORLD, &size); // get number of processes
  // Say hello multiple times on each processor
  for(int i=0; i<8; i++){
    printf( "Hello world #%d from process %d of %d\n", i, rank, size );
  }
  MPI_Finalize();
  return 0;
}
