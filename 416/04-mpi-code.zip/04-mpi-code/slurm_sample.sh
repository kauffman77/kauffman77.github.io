#!/bin/bash -l

# This is a sample Slurm job script to compile and run a sample code
# on Zaratan. The SBATCH options that govern how it will run are
# documented with more information available among Zaratan's docs such
# as
# - https://hpcc.umd.edu/kb/submitting-jobs/ (overview)
# - https://hpcc.umd.edu/kb/job-examples/ (specific examples of MPI / etc)
# 
# Relevant commands to know are
# - sbatch slurmjob.sh    # submit the job 
# - squeue -j 12345       # show status of specific job running
# - squeue -p partition   # show jobs running on the given partition

################################################################################
# SAMPLE SUBMISSION SESSION
# Below is a sample session that submits the job, checks the relevant
# partition for the running job, and lists the job output file when it
# completes running.
#
# # Runnin on Zaratan
# >> cd 416/04-mpi-code
# 
# >> ls testslurm.sh mpi_hello_plus.c
# testslurm.sh   mpi_hello_plus.c
# 
# >> sbatch testslurm.sh
# Submitted batch job 17693717
# 
# >> squeue -j 17693717
#              JOBID PARTITION     NAME     USER ST       TIME  NODES NODELIST(REASON)
#           17693717     debug testslur    profk  R       0:01      1 compute-b8-57
# 
# >> squeue -p debug
#              JOBID PARTITION     NAME     USER ST       TIME  NODES NODELIST(REASON)
#           176936234    debug tensflow  turtle6  R       1:34      1 compute-b8-57
#           17693717     debug testslur    profk  R       0:01      1 compute-b8-57   <<<
#
# ## A short time later ...
# >> squeue -j 17693717
#              JOBID PARTITION     NAME     USER ST       TIME  NODES NODELIST(REASON)
# 
# >> squeue -p debug
#              JOBID PARTITION     NAME     USER ST       TIME  NODES NODELIST(REASON)
#           176936234    debug tensflow  turtle6  R       1:34      1 compute-b8-57
#
# >> ls slurm-17693717.out
# slurm-17693717.out

################################################################################
# SLURM BATCH OPTIONS

# Comment below that start with #SBATCH set options for the resources
# and runtime granted this when submitted

#SBATCH --account=cmsc416-class
### Charge to class group time; shorthand `-a cmsc416`

#SBATCH --partition=debug
### Partition (queue) to submit to, "debug" for short runs, "standard" for longer
### shorthand `-p debug`

#SBATCH --time=0:01:00
### Max runtime, shorthand -t 0:01:00

#SBATCH --ntasks=32
### Number of MPI processors requested, change to 1 if doing pure multithreadng
### shorthand `-n 32`

#SBATCH --cpus-per-task=1
### Number of cores per MPI task, raise above 1 if combining with multithreading
### shorthand `-c 1`

#SBATCH --mem-per-cpu=250m
### Memory allocated per MPI Task
### Alternatively `--mem=4g` dictates a total for all procs but
### doesn't scale as the number of MPI tasks is used

### Which events to mail about and which email address to use 
#SBATCH --mail-type=ALL
#SBATCH --mail-user=profk@umn.edu

################################################################################
# JOB ACTIONS
# Below are the actual commands that will be run with output captured
# in a file like `slurm-17693654.out` based on the job number. These
# are regular shell commands / bash script actions for those familiar.
date
hostname
printf '\n'
cd ~/416/04-mpi-code
printf 'Compiling mpi_hello_plus.c\n'
mpicc -o mpi_hello_plus mpi_hello_plus.c
printf 'Running mpi_hello_plus with 32 procs\n'
printf '===============================\n'
mpirun -np 32 ./mpi_hello_plus
printf '===============================\n'
date
