// send_recv_immediate.c: demonstrates non-blocking "immediate" send
// and receive which allows for finer control and more overlapping of
// communication/computation than blocking versions at the cost of
// more code complexity and explicit syncronization calls

#include <stdio.h>
#include <mpi.h>

#define NAME_LEN 255

int main (int argc, char *argv[]){
  MPI_Init (&argc, &argv);	// starts MPI

  // Basic info
  int npes, myrank, name_len;   
  char processor_name[NAME_LEN];
  MPI_Comm_size(MPI_COMM_WORLD, &npes); 
  MPI_Comm_rank(MPI_COMM_WORLD, &myrank); 
  MPI_Get_processor_name(processor_name, &name_len);

  // Fill a with powers of proc rank
  int count=5;
  int a[count], b[count];
  
  int partner=-1, tag=1;

  if (myrank%2 == 0) {          // evens isend() to higher
    partner = (myrank+1)%npes;
    for(int i=0; i<count; i++){ // compute data to send
      a[i] = i + 10*myrank;
    }
    MPI_Request request;        // non-blocking send
    MPI_Isend(a, count, MPI_INT, partner, tag, MPI_COMM_WORLD, &request);
    for(int i=0; i<count; i++){ // work while send completes
      b[i] = i + 10*(myrank + 1);
    }                           // ensure send has completed
    MPI_Wait(&request, MPI_STATUS_IGNORE);
  }
  else{                         // odds irecv() from lower
    partner = (myrank-1+npes)%npes;
    MPI_Request request;        // initiate irecv()
    MPI_Irecv(a, count, MPI_INT, partner, tag, MPI_COMM_WORLD, &request);
    for(int i=0; i<count; i++){ // work while receiving
      b[i] = i + 10*myrank;
    }                           // ensure receive has completed
    MPI_Wait(&request, MPI_STATUS_IGNORE);

  }

  for(int i=0; i<count; i++){   // both procs alter a[] which is safe
    a[i] += b[i];               // due to the wait() calls above
  }

  int total = 0;
  for(int i=0; i<count; i++){
    total += a[i];
  }
  printf("Proc %d (%s) with %d: Total = %d\n",
         myrank,processor_name,partner,total);

  MPI_Finalize();
  return 0;
}


