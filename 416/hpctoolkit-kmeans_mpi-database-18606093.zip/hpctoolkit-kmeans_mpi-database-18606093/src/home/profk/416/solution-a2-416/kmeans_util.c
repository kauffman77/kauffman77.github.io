#include "kmeans.h"

// allocates a new data struct with enough space for the clustering
// computation.
kmdata_t *kmdata_new(uint_t ndata, uint_t dim){
  kmdata_t *kmdata = calloc(sizeof(kmdata_t),1);
  kmdata->ndata = ndata;
  kmdata->dim = dim;
  kmdata->all_feats = calloc(dim*ndata,sizeof(real_t));
  kmdata->features = calloc(ndata,sizeof(real_t*));
  // set up 2D indexing for individual features
  for(uint_t i=0; i<ndata; i++){ 
    kmdata->features[i] = &kmdata->all_feats[i*dim];
  }
  kmdata->assigns = calloc(ndata,sizeof(uint_t));
  kmdata->labels = calloc(ndata,sizeof(uint_t));
  return kmdata;
}

// allocates a new cluster struct with enough space for the clustering
// computation.
kmclust_t *kmclust_new(uint_t nclust, uint_t dim){
  kmclust_t *kmclust = calloc(sizeof(kmclust_t),1);
  kmclust->nclust = nclust;
  kmclust->dim = dim;
  kmclust->all_feats = calloc(dim*nclust,sizeof(real_t));
  kmclust->features = calloc(nclust,sizeof(real_t*));
  // set up 2D indexing for individual features
  for(uint_t i=0; i<nclust; i++){ 
    kmclust->features[i] = &kmclust->all_feats[i*dim];
  }
  kmclust->counts = calloc(nclust,sizeof(uint_t));
  return kmclust;
}

// deallocate dataset struct
void kmdata_free(kmdata_t *data){
  free(data->features);
  free(data->all_feats);
  free(data->assigns);
  free(data->labels);
  free(data);
}

// deallocate cluster struct
void kmclust_free(kmclust_t *clust){
  free(clust->features);
  free(clust->all_feats);
  free(clust->counts);
  free(clust);
}

// Sets number of lines and total number of whitespace separated
// tokens in the file. Returns -1 if file can't be opened, 0 on
// success.
//
// EXAMPLE: int ret = filestats("digits_all_1e1.txt", &toks, &lines);
// toks  is now 7860 : 10 lines with 786 tokens per line, label + ":" + 28x28 pixels
// lines is now 10   : there are 10 lines in the file
int filestats(char *filename, ssize_t *tot_tokens, ssize_t *tot_lines){
  FILE *fin = fopen(filename,"r");
  if(fin == NULL){
    printf("Failed to open file '%s'\n",filename);
    return -1;
  }

  ssize_t ntokens=0, nlines=0, column=0;
  int intoken=0, token;
  while((token = fgetc(fin)) != EOF){
    if(token == '\n'){          // reached end of line
      column = 0;
      nlines++;
    }
    else{
      column++;
    }
    if(isspace(token) && intoken==1){ // token to whitespace
      intoken = 0;
    }
    else if(!isspace(token) && intoken==0){ // whitespace to token
      intoken = 1;
      ntokens++;
    }
  }
  if(column != 0){              // didn't end with a newline
    nlines++;                   // add a line on to the count
  }
  *tot_tokens = ntokens;
  *tot_lines = nlines;
  fclose(fin);
  // printf("DBG: tokens: %lu\n",ntokens);
  // printf("DBG: lines: %lu\n",nlines);
  return 0;
}

// Load a data set from the named file. Employs filestats() to count
// lines / tokens. Data should be formatted as a text file as:
// 
// 7 :  84 185 159 151  60  36   0   0   0   0   0   0
// 2 :   0  77 251 210  25   0   0   0 122 248 253  65
// 1 :   0   0   0   0   0   0   0   0   0  45 244 150
// 0 :   0   0   0   0 110 190 251 251 251 253 169 109
// 4 :   0   0   0   4 195 231   0   0   0   0   0   0
// 1 :   0   0   0   0   0   0   0   0   0  81 254 254
// 4 :   0  20 189 253 147   0   0   0   0   0   0   0
// 9 :   0   0   0   0  91 224 253 253  19   0   0   0
// 5 :   0   0   0   0   0   0  63 253 253 253 253 253
// 9 :   0   0   0   0   0   0   0  36  56 137 201 199
//
// with the lead number being an optional correct label for the data
// and remaining numbers being floating point values that are space
// separated which are the feature vector for each data. The abve
// example does not have any fractional values for features but it
// could.
kmdata_t *kmdata_load(char *filename){
  ssize_t ntokens, nlines;      // count tokens in first line to determine dimensionality
  if( filestats(filename, &ntokens, &nlines) != 0){
    return NULL;                // couldn't open, bail out
  }

  uint_t ndata = nlines;                      // one datum per line
  uint_t dim = (ntokens - 2*nlines) / nlines; // discount ':' and label on each line

  if((ntokens - 2*nlines) % nlines != 0){
    printf("ERROR: data file appears corrupted\n");
    printf("ERROR: tokens: %lu lines: %lu  dim would be: %u\n",
           ntokens, nlines, dim);
    return NULL;
  }

  kmdata_t *data = kmdata_new(ndata, dim);    // allocate space for data set

  FILE *fin = fopen(filename,"r");
  uint_t maxlabel = 0;                        // track the max label for ease later
  for(uint_t i=0; i<ndata; i++){              // iterate over each line
    fscanf(fin, "%d : ", &data->labels[i]);   
    if(data->labels[i] > maxlabel){
      maxlabel = data->labels[i];
    }
    for(uint_t d=0; d<dim; d++){              // read each feature dimension
      fscanf(fin, "%f", &data->features[i][d]);     // for floats
      // fscanf(fin, "%lf", &data->features[i][d]); // for doubles
    }
  }
  fclose(fin);
  data->nlabels = maxlabel+1;
  return data;
}

// Save clusters as PGM files (portable gray map), a text-based image
// file. Saves only if the dimension looks like a perfect square (can
// be a square image) such as what is present in the MNIST database
// (dim = 28*28 = 784)
void save_pgm_files(kmclust_t *clust, char *savedir){
  uint_t dim_root = sqrt(clust->dim);
  if(clust->dim % dim_root == 0){              // check if this looks like a square image
    printf("Saving cluster centers to %s/cent_0000.pgm ...\n",
           savedir);
    real_t maxfeat = -INFINITY;
    for(uint_t c=0; c<clust->nclust; c++){
      for(uint_t d=0; d<clust->dim; d++){
        if(maxfeat < clust->features[c][d]){
          maxfeat = clust->features[c][d];
        }
      }
    }
    
    for(uint_t c=0; c<clust->nclust; c++){    // save each cluster file as a PGM file
      char outfile[512];
      sprintf(outfile,"%s/cent_%04u.pgm",savedir,c);
      FILE *fout = fopen(outfile,"w");
      if(fout == NULL){
        printf("ERROR: could not open output file '%s'\n",outfile);
        return;
      }
      fprintf(fout, "P2\n");
      fprintf(fout, "%u %u\n",dim_root,dim_root);
      fprintf(fout, "%.0f\n",maxfeat);
      for(uint_t d=0; d<clust->dim; d++){
        if(d > 0 && d%28==0){
          fprintf(fout,"\n");
        }
        fprintf(fout, "%3.0f ", clust->features[c][d]);
      }
      fprintf(fout,"\n");
      fclose(fout);
    }
  }


}
