#include "kmeans.h"
#include <mpi.h>

// #define MPI_REALNUM MPI_FLOAT

// Prints out a message if the environment variable DEBUG is set;
// includes processor information.
// Try running as `DEBUG=1 mpirun -np 4 ./mpi_hello`
void dpprintf(const char* format, ...) {
  if(getenv("DEBUG") != NULL){
    int total_procs, proc_id, host_len;
    char host[256];
    MPI_Comm_rank (MPI_COMM_WORLD, &proc_id);     // get current process id
    MPI_Comm_size (MPI_COMM_WORLD, &total_procs); // get number of processes
    MPI_Get_processor_name(host, &host_len);      // get the symbolic host name
    pid_t pid = getpid();

    va_list args;
    va_start (args, format);
    char fmt_buf[2048];
    snprintf(fmt_buf, 2048, "|DEBUG Proc %03d / %d PID %d Host %s| %s",
             proc_id, total_procs, pid, host, format);
    vfprintf(stderr, fmt_buf, args);
    va_end(args);
  }
}

int main(int argc, char *argv[]){             // MAIN PROGRAM
  int total_procs, procid;

  MPI_Init (&argc, &argv);	// starts MPI and get basic info
  MPI_Comm_size(MPI_COMM_WORLD, &total_procs);
  MPI_Comm_rank(MPI_COMM_WORLD, &procid);

  if(argc < 3){
    if(procid == 0){
      printf("usage: %s <datafile> <nclust> [savedir] [MAXITER]\n",argv[0]);
      return 1;
    }
    MPI_Finalize();
    return 0;
  }

  char *datafile = argv[1];
  uint_t nclust = atoi(argv[2]);
  uint_t MAXITER = 100;                       // default values 
  char *savedir = ".";

  if(argc > 3){                               // create save directory if needed
    savedir = argv[3];
    char cmd[1024];
    sprintf(cmd, "mkdir -p %s", savedir);
    if(procid == 0){
      system(cmd);
    }
  }
  if(argc > 4){                               // adjust MAXITER if needed
    MAXITER = atoi(argv[4]);
  }

  if(procid == 0){
    printf("datafile: %s\n",datafile);
    printf("nclust: %u\n",nclust);
    printf("savedir: %s\n",savedir);
  }

  kmdata_t *alldata = NULL;
  uint_t ndata_all, dim;          // for broadcast of ndata and dim

  if(procid == 0){              // only root loads data from disk
    alldata = kmdata_load(datafile);
    if(alldata == NULL){
      printf("ERROR: failed to load datafile '%s', bailing out\n",
             datafile);
      return 2;
    }

    printf("ndata: %u\n", alldata->ndata);
    printf("dim: %u\n", alldata->dim);
    printf("\n");

    ndata_all = alldata->ndata;
    dim = alldata->dim;
  }

  MPI_Bcast( &ndata_all, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
  MPI_Bcast( &dim,       1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

  dpprintf("ndata_all: %d\n",ndata_all);
  dpprintf("dim: %d\n",dim);

  // Set up scatterv / gatherv data
  // Determine how many elements each proc will have and their
  // displacements. Not strictly necessary in a scatterv for all procs
  // to know how many elements will be on all other procs, but for any
  // subsequent all-gatherv operation it is needed so for simplicity
  // just have everyone calculate it here.
  int data_counts[total_procs];
  int data_displs[total_procs];

  // Divide total_elements as evenly as possible: lower numbered
  // processors get one extra element each.
  int ndata_per_proc = ndata_all / total_procs;
  int surplus        = ndata_all % total_procs;
  for(int i=0; i<total_procs; i++){
    data_counts[i] = (i < surplus) ? ndata_per_proc+1 : ndata_per_proc;
    data_displs[i] = (i == 0) ? 0 : data_displs[i-1] + data_counts[i-1];
  }
  // counts[] and displs[] now contain counts of data points BUT must
  // scale these by the dimesion
  int feat_counts[total_procs];
  int feat_displs[total_procs];
  for(int i=0; i<total_procs; i++){
    feat_counts[i] = data_counts[i] * dim;
    feat_displs[i] = data_displs[i] * dim;
  }

  int my_data_count = data_counts[procid];    // number of data on this proc
  int my_feat_count = feat_counts[procid];    // number of data*dim on this proc

  // allocate data for personal slice of data
  kmdata_t *mydata = kmdata_new(my_data_count, dim); 

  // scatter data from root to all procs
  real_t *root_all_feats = (procid==0) ? alldata->all_feats : NULL;
  dpprintf("%p\n",root_all_feats);
  dpprintf("%p\n",feat_counts);
  dpprintf("%p\n",feat_displs);
  dpprintf("%p\n",mydata->all_feats);
  dpprintf("%d\n",my_feat_count);
  MPI_Scatterv(root_all_feats,    feat_counts, feat_displs, MPI_FLOAT,
               mydata->all_feats, my_feat_count, MPI_FLOAT,
               0, MPI_COMM_WORLD);

  // MPI_Scatter(root_all_feats,    my_feat_count, MPI_FLOAT,
  //             mydata->all_feats, my_feat_count, MPI_FLOAT,
  //             0, MPI_COMM_WORLD);


  kmclust_t *clust = kmclust_new(nclust, dim);

  // ASSIGN CLUSTER TO ALL DATA - do so linearly so each proc needs to
  // know its "starting point" in the linear ordering; calculate this
  // from the the counts[] array
  int mystart = 0;                            // starting point for this proc in
  for(int i=0; i<procid; i++){                //  a linear ordering of all data
    mystart += data_counts[i];
  }

  for(uint_t i=0; i<mydata->ndata; i++){      // randomly assign initial clusters
    uint_t c = (mystart + i) % clust->nclust; // as data index mod nclust
    mydata->assigns[i] = c;
  }

  for(uint_t c=0; c<clust->nclust; c++){            // calculate initial cluster counts 
    uint_t icount = ndata_all / clust->nclust;      // which are regular
    uint_t extra = c < (ndata_all % clust->nclust); // extras in earlier clusters
    clust->counts[c] = icount + extra;
  }

  ////////////////////////////////////////////////////////////////////////////////
  // THE MAIN ALGORITHM
  uint_t nchange = ndata_all;
  uint_t curiter = 1;
  if(procid==0){
    printf("==CLUSTERING: MAXITER %u==\n",MAXITER);
    printf("ITER NCHANGE CLUST_COUNTS\n");
  }

  while(nchange > 0 && curiter <= MAXITER ){

    // DETERMINE NEW CLUSTER CENTERS
    for(uint_t i=0; i<clust->nclust; i++){     // reset cluster centers
      for(uint_t d=0; d<clust->dim; d++){
        clust->features[i][d] = 0.0;
      }
    }

    for(uint_t i=0; i<mydata->ndata; i++){     // sum up data in each cluster
      uint_t c = mydata->assigns[i];
      for(uint_t d=0; d<mydata->dim; d++){
        clust->features[c][d] += mydata->features[i][d];
      }
    }

    dpprintf("nclust: %d dim: %d\n", clust->nclust, dim);

    // all reduce cluster features to enable parallel computation of
    // new cluster centers
    MPI_Allreduce(MPI_IN_PLACE, clust->all_feats, clust->nclust*dim,
                  MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
    
    for(uint_t c=0; c<clust->nclust; c++){     // divide by count to get mean value
      if(clust->counts[c] > 0){
        for(uint_t d=0; d<clust->dim; d++){
          // dpprintf("clust->features[c][d]: %d %d %f\n",
          //          c,d,clust->features[c][d]);
          clust->features[c][d] /= clust->counts[c];
        }
      }
    }
      
    // DETERMINE NEW CLUSTER MEMBERSHIP FOR EACH DATA
    nchange = 0;
    for(uint_t i=0; i<clust->nclust; i++){     // reset cluster counts
      clust->counts[i] = 0;                    // use memset
    }
    for(uint_t i=0; i<mydata->ndata; i++){
      uint_t best_clust = 0;
      real_t best_distsq = INFINITY;
      for(uint_t c=0; c<clust->nclust; c++){
        real_t distsq = 0.0;
        for(uint_t d=0; d<mydata->dim; d++){
          real_t diff = mydata->features[i][d] - clust->features[c][d];
          distsq += diff*diff;
          // printf("DBG: curiter %u i %u c %u d %u diff %f\n",curiter,i,c,d,diff);
        }
        if(distsq < best_distsq){
          best_clust = c;
          best_distsq = distsq;
        }
      }
      clust->counts[best_clust]++;              // assigned to best clust
      if(best_clust != mydata->assigns[i]){
        // printf("DBG: data %u changing clusters: %u to %u\n",
        //        i, data->assigns[i], best_clust);
        nchange++;
        mydata->assigns[i] = best_clust;
      }
    }


    dpprintf("mydata->ndata %u nchange %u\n",mydata->ndata, nchange);


    // reduce cluster counts so that all procs have the counts at the
    // top of the next iteration
    MPI_Allreduce(MPI_IN_PLACE, clust->counts, clust->nclust,
                  MPI_UNSIGNED, MPI_SUM, MPI_COMM_WORLD);

    // reduce number of data that changed assignments so procs can
    // coordinate terminatation
    MPI_Allreduce(MPI_IN_PLACE, &nchange, 1,
                  MPI_UNSIGNED, MPI_SUM, MPI_COMM_WORLD);

    if(procid==0){
      printf("%3u: %5u |", curiter, nchange);
      for(uint_t c=0; c<clust->nclust; c++){
        printf(" %4u",clust->counts[c]);
      }
      printf("\n");
    }
    curiter++;
  }

  // gather of cluster assigments to root
  uint_t *all_assigns = (procid==0) ? alldata->assigns : NULL;
  MPI_Gatherv(mydata->assigns, my_data_count, MPI_UNSIGNED,
              all_assigns, data_counts, data_displs, MPI_UNSIGNED,
              0, MPI_COMM_WORLD);
  // MPI_Gather(mydata->assigns, ndata_perproc, MPI_UNSIGNED,
  //            all_assigns,     ndata_perproc, MPI_UNSIGNED,
  //            0, MPI_COMM_WORLD);

  kmdata_free(mydata);

  if(procid != 0){              // non-root done at this point
    kmclust_free(clust);
    MPI_Finalize();
    return 0;                   // non-root returns
  }

  ////////////////////////////////////////////////////////////////////////////////
  // CLEANUP + OUTPUT : root processor only
  kmdata_t *data = alldata;

  if(curiter > MAXITER){
    printf("WARNING: maximum iteration %u exceeded, may not have conveged\n",
           MAXITER);
  }
  else{
    printf("CONVERGED: after %u iterations\n", curiter);
  }
  printf("\n");

  uint_t confusion[data->nlabels][clust->nclust];
  memset(confusion, 0, sizeof(uint_t)*alldata->nlabels*clust->nclust);

  for(uint_t i=0; i<data->ndata; i++){                        // calculate confusion matrix
    confusion[data->labels[i]][data->assigns[i]]++;
  }

  printf("==CONFUSION MATRIX + COUNTS==\n");
  printf("LABEL \\ CLUST\n");
  printf("%2s ","");
  for(uint_t j=0; j<clust->nclust; j++){
    printf(" %4u",j);
  }
  printf("  TOT\n");
  for(uint_t i=0; i<data->nlabels; i++){
    printf("%2u:",i);
    uint_t tot = 0;
    for(uint_t j=0; j<clust->nclust; j++){
      printf(" %4u",confusion[i][j]);
      tot += confusion[i][j];
    }
    printf(" %4u\n",tot);
  }
  {
    printf("TOT");
    uint_t tot = 0;
    for(uint_t c=0; c<clust->nclust; c++){
      printf(" %4u",clust->counts[c]);
      tot += clust->counts[c];
    }
    printf(" %4u\n",tot);
  }
  printf("\n");

  // LABEL FILE OUTPUT
  char outfile[512];
  sprintf(outfile,"%s/labels.txt",savedir);
  printf("Saving cluster labels to file %s\n",
         outfile);

  FILE *fout = fopen(outfile, "w");
  if(fout == NULL){
    printf("ERROR: could not open output file '%s'\n",outfile);
    return 3;
  }
  for(uint_t i=0; i<data->ndata; i++){
    fprintf(fout,"%2u %2u\n", data->labels[i],data->assigns[i]);
  }
  fclose(fout);

  // PGM FILE OUTPUT for cluster center display
  save_pgm_files(clust, savedir);

  kmdata_free(alldata);
  kmclust_free(clust);
  MPI_Finalize();                              // root finalizes
  return 0;
}
