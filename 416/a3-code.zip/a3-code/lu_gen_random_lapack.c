// lu_gen_random_lapack.c: Like lu_gen_random.c but uses BLAS to speed
// up the matrix multiply to produce the final A matrix. WAY faster
// than the non-blas version.

#include <stdio.h>
#include <stdlib.h>
#include <cblas.h>              // for cblas_dgemm() - general matrix multiply

// Coefficients entries placed in the L and U matrices; these are
// randomly selected but choosing a limited set of values keeps the
// matrix from becoming too ill-conditioned and means that the crummy
// LU factorization code that these are to be used with will still be
// able to compute reasonable answers without pivoting.
float coefs[4] = {-1.0, -0.5, +0.5, +1.0};


// state of the random number generator for phase09 
unsigned long rand_kr_state = 1234567;

// generate a random integer in range 0 to 32768; stolen from
// Kernighan and Ritchie's C text
unsigned int rand_kr() {
  rand_kr_state = rand_kr_state * 1103515245 + 12345;
  return (unsigned int)(rand_kr_state/65536) % 32768;
}

// set seed for rand_kr()
void srand_kr(unsigned long seed){
  rand_kr_state = seed;
}

// generate a random float in the range of lo to hi
float rand_float_kr(float lo, float hi){
  float rand = rand_kr() / 32768.0; // in range 0 to 1
  return (rand*(hi-lo))+lo;
}


int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <outprefix> <dim> [seed]\n",argv[0]);
    printf("  <outprefix>: required prefix for matrix names, 'mat' would generate 'mat_A.dat' and 'mat_LU.dat'\n");
    printf("  <dim>:       required size of the square matrix\n");
    printf("  [seed]:      optional seed for random number generation\n");
    return 1;
  }
  char *outprefix = argv[1];
  long dim = atol(argv[2]);     // set matrix dimension

  if(argc > 3){                 // check for a seed and set it
    srand_kr(atol(argv[3]));    // if present
  }

  float lo=-1.0;                // range of values in L and U
  float hi=+1.0;

  printf("Generating L\n");
  // compute L (lower triangle with ones on diagonal)
  float *L = calloc(sizeof(float), dim*dim); // initialize to 0's to get upper triangle as 0's
  for(int i=0; i<dim; i++){
    float *row = L+i*dim;
    for(int j=0; j<i; j++){
      row[j] = coefs[rand_kr() % 4];
      // printf("L[%d][%d] = %+f\n",i,j,row[j]);
    }
    row[i] = 1.0;               // diagonal entries in L are 1.0
  }
      
  printf("Generating U\n");
  // compute U (upper triangle)
  float *U = calloc(sizeof(float), dim*dim); // initialize to 0's to get lower triangle as 0's
  for(int i=0; i<dim; i++){
    float *row = U+i*dim;
    for(int j=i; j<dim; j++){
      row[j] = coefs[rand_kr() % 4];
      // printf("U[%d][%d] = %+f\n",i,j,row[j]);
    }
  }

  printf("Multiplying L*U\n");
  // multiply L*U to get A
  float *A = calloc(sizeof(float), dim*dim); // initialize to 0's in case of switching to a cache friendly approach
  double alpha=1.0, beta=1.0;
  cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
              dim, dim, dim,
              alpha,
              L, dim, U, dim,
              beta, A, dim);
  printf("Done\n");

  char outname[256];            // to construct output filenames

  printf("Writing A matrix\n");
  // Write A matrix, binary format is
  // dim : 8-byte long
  // data : dim*dim 4-byte floats
  sprintf(outname,"%s_A.dat",outprefix);
  FILE *fileA = fopen(outname,"w");
  if(fileA==NULL){
    fprintf(stderr,"Problems opening file '%s' ",outname);
    perror("");
    exit(1);
  }
  fwrite(&dim, sizeof(long),        1, fileA);
  fwrite(   A, sizeof(float), dim*dim, fileA);
  fclose(fileA);
  
  // copy upper diagonal elements from U to L to prepare for output
  for(int i=0; i<dim; i++){
    float *rowL = L+i*dim;
    float *rowU = U+i*dim;
    for(int j=i; j<dim; j++){
      rowL[j] = rowU[j];
    }
  }

  printf("Writing LU matrix\n");
  // Write the L/U matrix, binary format is 
  // dim : 8-byte long
  // data : dim*dim 4-byte floats
  sprintf(outname,"%s_LU.dat",outprefix);
  FILE *fileLU = fopen(outname,"w");
  if(fileA==NULL){
    fprintf(stderr,"Problems opening file '%s' ",outname);
    perror("");
    exit(1);
  }
  fwrite(&dim, sizeof(long),        1, fileLU);
  fwrite(   L, sizeof(float), dim*dim, fileLU);
  fclose(fileLU);

  free(L);
  free(U);
  free(A);
  return 0;
}
