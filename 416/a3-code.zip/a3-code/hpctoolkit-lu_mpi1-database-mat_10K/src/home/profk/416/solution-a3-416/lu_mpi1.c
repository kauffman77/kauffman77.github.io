// lu_mpi1.c: a parallelization of lu_serial.c
#define SOLUTION
// SOLUTION: This variant does
// - Block Row decomposition of matrix
// - Each proc loads the matrix in parallel by seeking to the
//   appropriate location in the file and loading data

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <mpi.h>
#include <fcntl.h>
#include <unistd.h>

#define TOL 5e-3                // tolerance for numerical comparisons

int lu_load_mpi1(char *fname, float **A, size_t *dim);
int lu_factorize_mpi1(float *A, size_t dim);
int lu_verify_mpi1(float *A, size_t dim, char *expectfile, int verbose);

int proc_rank, proc_count;      // global for convenience; available for all functions

int main(int argc, char *argv[]){

  MPI_Init (&argc, &argv);	// starts MPI and get basic info
  MPI_Comm_size(MPI_COMM_WORLD, &proc_count); 
  MPI_Comm_rank(MPI_COMM_WORLD, &proc_rank); 

  if(argc < 2){
    if(proc_rank == 0){
      printf("usage: %s <inA_file> [checkLU_file] [verbose]\n",argv[0]);
      printf("  <inA_file>:     required file containing the binary A matrix to factor\n");
      printf("  [checkLU_file]: optional file to check for correct LU factorization\n");
      printf("  [verbose]:      optional, if present prints computed / answer elements\n");
      printf("Note: This is NOT a viable factorization code as it lacks pivoting.\n");
      printf("Note: Expect correctness checks to fail for most larger matrices.\n");
    }
    return 1;
  }

  int verbose = argc > 3;
  int ret;

  // load A matrix from file
  char *fname = argv[1];
  size_t dim;
  float *A;
  ret = lu_load_mpi1(fname, &A, &dim);
  assert(ret == 0);
  if(proc_rank==0){
    printf("matrix dimension: %lu\n",dim);
  }

  if(verbose){
    size_t idx = 0;
    size_t row_count = dim / proc_count;
    for(size_t i=0; i<row_count; i++){
      size_t iglobal = proc_rank*row_count + i;
      for(size_t j=0; j<dim; j++, idx++){
        printf("[%lu][%lu] A: %+e  (idx: %ld)\n", iglobal,j,A[idx],idx);
      }
    }
  }

  // call LU factorization for in-place factorization
  ret = lu_factorize_mpi1(A, dim);
  assert(ret == 0);

  // optionally load LU answer and check results
  if(argc > 2){
    char *expectfile = argv[2];
    lu_verify_mpi1(A, dim, expectfile, verbose);
  }
  free(A);
  MPI_Finalize();
  return 0;
}

// Loads a matrix in binary format oriented as
//   dim  : first 8 bytes indicating dim by dim matrix
//   data : dim by dim by sizeof(float) bytes with matrix elements in it
// Sets `Ap` to point at the array of mtrix elements and `dimp` to be
// the dimension.
//
// PARALLEL IMPLEMENTATION: assumes equal number of rows per
// processor; if the matrix size i
int lu_load_mpi1(char *fname, float **Ap, size_t *dimp){
  FILE *infile = fopen(fname,"r");
  if(infile == NULL){
    fprintf(stderr,"Problems opening file '%s' ",fname);
    perror("");
    return 1;
  }    
  size_t dim = 0, elems_read;   // all procs read dimension so they know it
  elems_read = fread(&dim, sizeof(size_t), 1, infile);
  if(elems_read != 1){
    fprintf(stderr,"dim: Expected %lu elements, read %lu elements\n",
            elems_read, sizeof(size_t));
  }
  if(dim % proc_count != 0){
    fprintf(stderr,"dim %lu not divisible by proc_count %d, bailing out\n",
            dim, proc_count);
    MPI_Abort(MPI_COMM_WORLD, 1);
  }
  size_t row_count = dim / proc_count;
  size_t row_start = proc_rank * row_count*dim*sizeof(float);
  fseek(infile, row_start, SEEK_CUR); // all procs seek to their data in the file
  float *A = malloc(sizeof(float)*row_count*dim);
  elems_read = fread(A, sizeof(float), row_count*dim, infile);
  if(elems_read != row_count*dim){
    fprintf(stderr,"data: Expected %lu elems, read %lu elems\n",
            elems_read, row_count*dim);
  }
  fclose(infile);
  *Ap = A;
  *dimp = dim;
  return elems_read != row_count*dim;
}

// int lu_load_mpi1(char *fname, float **Ap, size_t *dimp){
//   int infile = open(fname,O_RDONLY);
//   if(infile==-1){
//     fprintf(stderr,"Problems opening file '%s' ",fname);
//     perror("");
//     return 1;
//   }    
//   size_t dim = 0, bytes_read;
//   bytes_read = read(infile, &dim, sizeof(size_t));
//   if(bytes_read != sizeof(size_t)){
//     fprintf(stderr,"dim: Expected %lu bytes, read %lu bytes\n",
//             bytes_read, sizeof(size_t));
//   }
//   if(dim % proc_count != 0){
//     fprintf(stderr,"dim %lu not divisible by proc_count %d, bailing out\n",
//             dim, proc_count);
//     MPI_Abort(MPI_COMM_WORLD, 1);
//   }
//   size_t row_count = dim / proc_count;
//   size_t row_start = proc_rank * row_count * sizeof(float);
//   lseek(infile, row_start, SEEK_CUR);

//   float *A = malloc(sizeof(float)*row_count*dim);
//   bytes_read = read(infile, A, sizeof(float)*row_count*dim);
//   if(bytes_read != row_count*dim*sizeof(float)){
//     fprintf(stderr,"data: Expected %lu bytes, read %lu bytes\n",
//             bytes_read, row_count*dim*sizeof(float));
//   }
//   close(infile);
//   *Ap = A;
//   *dimp = dim;
//   return bytes_read != row_count*dim*sizeof(float);
// }

// Compute an in-place LU factorization for A which is a dim*dim
// matrix stored as a single array. Does not perform any pivoting so
// is subject to numerical instability for some matrices (though
// hopefully not the provided test matrices).
//
// SOLUTION NOTES: Assumes block row distribution, 
int lu_factorize_mpi1(float *A, size_t dim){
  size_t row_count = dim / proc_count;
  size_t row_beg = proc_rank * row_count;       // begin/end indices in global indexing for local rows
  size_t row_end = (proc_rank+1) * row_count;
  float *row_buf = malloc(dim * sizeof(float)); // receive broadcast if not the root
  
  for(size_t d=0; d<dim; d++){                  // outer computation loop over entire matrix
    int lead_rank = d / row_count;              // proc which has the leading row, source for broadcast
    float *Arow_d = row_buf;                    // default to the buf...
    if(proc_rank == lead_rank){                 // except for proc with the lead row
      Arow_d = A+(d % row_count)*dim;
    }
    MPI_Bcast(Arow_d, dim, MPI_FLOAT, lead_rank, MPI_COMM_WORLD);
    size_t ibeg = (d<row_beg) ? 0 : d-row_beg;  // adjust local begin row; as d gets higher...
    size_t iend = (d<row_end) ? row_count : 0;  // low rank procs don't have relevant rows, don't iterate
    if(proc_rank == lead_rank){                 // lead proc skips the first row it is broadcasting...
      ibeg++;                                   // which is not altered
    }
    for(size_t i=ibeg; i<iend; i++){
      float *Arow_i = A+i*dim;
      float scale = Arow_i[d] / Arow_d[d];      // scale row by this amount to eliminate lead element
      Arow_i[d] = scale;                        // store scale in the lower triangle of the matrix
      for(size_t j=d+1; j<dim; j++){            // subtract scaled lead row from this row
        Arow_i[j] -= scale*Arow_d[j];
      }
    }
  }
  free(row_buf);
  return 0;   
}
 
// Check that matrix `A` matches the data in `expectfile`. Loads the
// matrix in `expectfile` and checks all elements in A are within
// tolerance of the expected values
int lu_verify_mpi1(float *A, size_t dim, char *expectfile, int verbose){
  size_t dim_B;
  float *B;
  int ret;
  ret = lu_load_mpi1(expectfile, &B, &dim_B);
  assert(ret == 0);

  size_t row_count = dim / proc_count;
  // check that computed two matrices are close
  size_t idx = 0;                // linear index in 2D matrix
  size_t above_tol = 0;
  for(size_t i=0; i<row_count; i++){
    size_t iglobal = i+proc_rank*row_count;
    for(size_t j=0; j<dim; j++, idx++){
      float diff = fabsf((A[idx] - B[idx])/B[idx]);
      if(verbose){
        printf("[%ld][%ld] A: %+e  LU: %+e  diff: %+e  (idx: %ld)\n",
               iglobal,j,A[idx],B[idx],diff,idx);
      }
      if(diff > TOL){
        printf("ABOVE TOL: [%ld][%ld] A: %+e  LU: %+e  diff: %+e  (idx: %ld)\n",
               iglobal,j,A[idx],B[idx],diff,idx);
        above_tol++;
      }
    }
  }
  size_t above_tol_total;
  MPI_Reduce(&above_tol, &above_tol_total, 1, MPI_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
  if(proc_rank==0){
    printf("%lu entries above tolerance %+e\n", above_tol_total, TOL);
  }
  free(B);
  return 0;
}
