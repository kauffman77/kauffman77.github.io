// lu_serial.c: a crummy serial implemenation of LU matrix
// factorization. This version is for demonstration purposes only and
// is badly numerically unstable due to lacking row/column pivoting.

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#define TOL 5e-3                // tolerance for numerical comparisons

int lu_load_serial(char *fname, float **A, size_t *dim);
int lu_factorize_serial(float *A, size_t dim);
int lu_verify_serial(float *A, size_t dim, char *expectfile, int verbose);

int main(int argc, char *argv[]){
  if(argc < 2){
    printf("usage: %s <inA_file> [checkLU_file] [verbose]\n",argv[0]);
    printf("  <inA_file>:     required file containing the binary A matrix to factor\n");
    printf("  [checkLU_file]: optional file to check for correct LU factorization\n");
    printf("  [verbose]:      optional, if present prints computed / answer elements\n");
    printf("Note: This is NOT a viable factorization code as it lacks pivoting.\n");
    printf("Note: Expect correctness checks to fail for most larger matrices.\n");
    return 1;
  }

  int verbose = argc > 3;
  int ret;

  // load A matrix from file
  char *fname = argv[1];
  size_t dim;
  float *A;
  ret = lu_load_serial(fname, &A, &dim);
  assert(ret == 0);
  printf("matrix dimension: %lu\n",dim);

  if(verbose){
    size_t idx = 0;
    for(size_t i=0; i<dim; i++){
      for(size_t j=0; j<dim; j++, idx++){
        printf("[%lu][%lu] A: %+e  (idx: %ld)\n", i,j,A[idx],idx);
      }
    }
  }

  // call LU factorization for in-place factorization
  ret = lu_factorize_serial(A, dim);
  assert(ret == 0);

  // optionally load LU answer and check results
  if(argc > 2){
    char *expectfile = argv[2];
    lu_verify_serial(A, dim, expectfile, verbose);
  }
  free(A);
  return 0;
}

// Loads a matrix in binary format oriented as
//   dim  : first 8 bytes indicating dim by dim matrix
//   data : dim by dim by sizeof(float) bytes with matrix elements in it
// Sets `Ap` to point at the array of mtrix elements and `dimp` to be
// the dimension
int lu_load_serial(char *fname, float **Ap, size_t *dimp){
  FILE *infile = fopen(fname,"r");
  if(infile == NULL){
    fprintf(stderr,"Problems opening file '%s' ",fname);
    perror("");
    return 1;
  }    
  size_t dim = 0, elems_read;
  elems_read = fread(&dim, sizeof(size_t), 1, infile);
  if(elems_read != 1){
    fprintf(stderr,"dim: Expected %lu elements, read %lu elements\n",
            elems_read, sizeof(size_t));
  }
  float *A = malloc(sizeof(float)*dim*dim);
  elems_read = fread(A, sizeof(float), dim*dim, infile);
  if(elems_read != dim*dim){
    fprintf(stderr,"data: Expected %lu elems, read %lu elems\n",
            elems_read, dim*dim);
  }
  fclose(infile);
  *Ap = A;
  *dimp = dim;
  return elems_read != dim*dim;
}


// Compute an in-place LU factorization for A which is a dim*dim
// matrix stored as a single array. Does not perform any pivoting so
// is subject to numerical instability for some matrices (though
// hopefully not the provided test matrices).
int lu_factorize_serial(float *A, size_t dim){
  for(size_t d=0; d<dim; d++){
    float *Arow_d = A+d*dim;
    for(size_t i=d+1; i<dim; i++){
      float *Arow_i = A+i*dim;
      float scale = Arow_i[d] / Arow_d[d]; // scale row by this amount to eliminate lead element
      Arow_i[d] = scale;                   // store scale in the lower triangle of the matrix
      for(size_t j=d+1; j<dim; j++){         // subtract scaled lead row from this row
        Arow_i[j] -= scale*Arow_d[j];
      }
    }
  }
  return 0;   
}
 
// Check that matrix `A` matches the data in `expectfile`. Loads the
// matrix in `expectfile` and checks all elements in A are within
// tolerance of the expected values
int lu_verify_serial(float *A, size_t dim, char *expectfile, int verbose){
  size_t dim_B;
  float *B;
  int ret;
  ret = lu_load_serial(expectfile, &B, &dim_B);
  assert(ret == 0);

  // check that computed two matrices are close
  size_t idx = 0;                // linear index in 2D matrix
  size_t above_tol = 0;
  for(size_t i=0; i<dim; i++){
    for(size_t j=0; j<dim; j++, idx++){
      float diff = fabsf((A[idx] - B[idx])/B[idx]);
      if(verbose){
        printf("[%ld][%ld] A: %+e  LU: %+e  diff: %+e  (idx: %ld)\n",
               i,j,A[idx],B[idx],diff,idx);
      }
      if(diff > TOL){
        printf("ABOVE TOL: [%ld][%ld] A: %+e  LU: %+e  diff: %+e  (idx: %ld)\n",
               i,j,A[idx],B[idx],diff,idx);
        above_tol++;
      }
    }
  }
  printf("%lu entries above tolerance %+e\n", above_tol, TOL);
  free(B);
  return 0;
}
