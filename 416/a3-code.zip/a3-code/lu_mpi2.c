// lu_mpi2.c: a parallelization of lu_serial.c
#define SOLUTION 0

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <mpi.h>
#include <fcntl.h>
#include <unistd.h>

#define TOL 5e-3                // tolerance for numerical comparisons

int lu_load_mpi2(char *fname, float **A, size_t *dim);
int lu_factorize_mpi2(float *A, size_t dim);
int lu_verify_mpi2(float *A, size_t dim, char *expectfile, int verbose);

int proc_rank, proc_count;      // global for convenience; available for all functions

int main(int argc, char *argv[]){

  MPI_Init (&argc, &argv);	// starts MPI and get basic info
  MPI_Comm_size(MPI_COMM_WORLD, &proc_count); 
  MPI_Comm_rank(MPI_COMM_WORLD, &proc_rank); 

  if(argc < 2){
    if(proc_rank == 0){
      printf("usage: %s <inA_file> [checkLU_file] [verbose]\n",argv[0]);
      printf("  <inA_file>:     required file containing the binary A matrix to factor\n");
      printf("  [checkLU_file]: optional file to check for correct LU factorization\n");
      printf("  [verbose]:      optional, if present prints computed / answer elements\n");
      printf("Note: This is NOT a viable factorization code as it lacks pivoting.\n");
      printf("Note: Expect correctness checks to fail for most larger matrices.\n");
    }
    return 1;
  }

  int verbose = argc > 3;
  int ret;

  // load A matrix from file
  char *fname = argv[1];
  size_t dim;
  float *A;
  ret = lu_load_mpi2(fname, &A, &dim);
  assert(ret == 0);
  if(proc_rank==0){
    printf("matrix dimension: %lu\n",dim);
  }

  // output the loaded matrix if requested
  if(verbose){
    size_t idx = 0;
    size_t row_count = dim / proc_count;
    for(size_t i=0; i<row_count; i++){
      size_t iglobal = proc_rank+i*proc_count;
      for(size_t j=0; j<dim; j++, idx++){
        printf("[%lu][%lu] A: %+e  (idx: %ld)\n", iglobal,j,A[idx],idx);
      }
    }
  }

  // call LU factorization for in-place factorization
  ret = lu_factorize_mpi2(A, dim);
  assert(ret == 0);

  // optionally load LU answer and check results
  if(argc > 2){
    char *expectfile = argv[2];
    lu_verify_mpi2(A, dim, expectfile, verbose);
  }
  free(A);
  MPI_Finalize();
  return 0;
}

// Loads a matrix in binary format oriented as
//   dim  : first 8 bytes indicating dim by dim matrix
//   data : dim by dim by sizeof(float) bytes with matrix elements in it
// Sets `Ap` to point at the array of mtrix elements and `dimp` to be
// the dimension.
//
// PARALLEL IMPLEMENTATION: assumes equal number of rows per
// processor and bails out if not so.
int lu_load_mpi2(char *fname, float **Ap, size_t *dimp){
  FILE *infile = fopen(fname,"r");
  if(infile == NULL){
    fprintf(stderr,"Problems opening file '%s' ",fname);
    perror("");
    return 1;
  }    
  size_t dim=0, elems_read;     // read matrix dim first, all procs read so they kno the dimension
  elems_read = fread(&dim, sizeof(size_t), 1, infile);
  if(elems_read != 1){
    fprintf(stderr,"dim: Expected %lu elements, read %lu elements\n",
            elems_read, sizeof(size_t));
  }
  if(dim % proc_count != 0){    // bail on incompatible sizes
    fprintf(stderr,"dim %lu not divisible by proc_count %d, bailing out\n",
            dim, proc_count);
    MPI_Abort(MPI_COMM_WORLD, 1);
  }
  size_t row_count = dim / proc_count;

  float *Aall = NULL;           // root builds matrix for scatter
  if(proc_rank == 0){           // root reads 
    Aall = malloc(sizeof(float)*dim*dim);
    size_t rowbytes = sizeof(float)*dim;

    // For 4 procs and a 16x16 matrix, this will read
    // - A rows 0,4,8,12 into Aall at 0,1,2,3
    // - A rows 1,5,9,13 into Aall at 4,5,6,7
    // - A rows 2,6,10,14 into Aall at 8,9,10,11
    // - A rows 3,7,11,15 into Aall at 12,13,14,15
    // which is set up for the scatter
    for(int p=0; p<proc_count; p++){ 
      size_t file_offset = sizeof(size_t) + p*rowbytes;
      size_t matr_offset = p*dim*row_count;
      for(size_t r=0; r<row_count; r++){
        fseek(infile, file_offset+rowbytes*proc_count*r, SEEK_SET);
        fread(Aall+matr_offset+r*dim, sizeof(float), dim, infile);
      }
    }
    // // DEBUG PRINTING
    // size_t idx = 0;
    // for(size_t i=0; i<dim; i++){
    //   for(size_t j=0; j<dim; j++, idx++){
    //     printf("[%lu][%lu] Aall: %+e  (idx: %ld)\n", i,j,Aall[idx],idx);
    //   }
    // }
  }
  float *A = malloc(sizeof(float)*row_count*dim); // all procs receive in scatter
  MPI_Scatter(Aall, row_count*dim, MPI_FLOAT,
              A,    row_count*dim, MPI_FLOAT,
              0, MPI_COMM_WORLD);
  fclose(infile);
  if(proc_rank == 0){
    free(Aall);
  }
  *Ap = A;
  *dimp = dim;
  return 0;
}

// Compute an in-place LU factorization for A which is a dim*dim
// matrix stored as a single array. Does not perform any pivoting so
// is subject to numerical instability for some matrices (though
// hopefully not the provided test matrices).
//
// PARALLEL IMPLEMENTATION
int lu_factorize_mpi2(float *A, size_t dim){
  size_t row_count = dim / proc_count;
  float *row_buf = malloc(dim * sizeof(float)); // receive broadcast if not the root
  for(size_t d=0; d<dim; d++){                  // outer computation loop over entire matrix
    int lead_rank = d % proc_count;             // proc which has the leading row, source for broadcast
    float *Arow_d = row_buf;                    // default to the buf...
    if(proc_rank == lead_rank){                 // except for proc with the lead row
      Arow_d = A+(d/proc_count)*dim;
    }
    MPI_Bcast(Arow_d, dim, MPI_FLOAT, lead_rank, MPI_COMM_WORLD);
    size_t ibeg = (d/proc_count);               // local row to begin in
    size_t iend = row_count;                    // local row to end in
    if(proc_rank <= lead_rank){                 // low-rank procs skip ahead a bit
      ibeg++;
    }
    for(size_t i=ibeg; i<iend; i++){            // iterate over each row to be adjusted
      float *Arow_i = A+i*dim;                  // find start of row to be adjusted
      float scale = Arow_i[d] / Arow_d[d];      // scale row by this amount to eliminate lead element
      Arow_i[d] = scale;                        // store scale in the lower triangle of the matrix
      for(size_t j=d+1; j<dim; j++){            // subtract scaled lead row from this row
        Arow_i[j] -= scale*Arow_d[j];
      }
    }
  }
  free(row_buf);
  return 0;   
}
 
// Check that matrix `A` matches the data in `expectfile`. Loads the
// matrix in `expectfile` and checks all elements in A are within
// tolerance of the expected values
int lu_verify_mpi2(float *A, size_t dim, char *expectfile, int verbose){
  size_t dim_B;
  float *B;
  int ret;
  ret = lu_load_mpi2(expectfile, &B, &dim_B); // load verifcation matrix in the same way as original matrix
  assert(ret == 0);
  size_t row_count = dim / proc_count;
  // check that computed two matrices are close
  size_t idx = 0;                // linear index in 2D matrix
  size_t above_tol = 0;
  for(size_t i=0; i<row_count; i++){
    size_t iglobal = i+proc_rank*row_count;
    for(size_t j=0; j<dim; j++, idx++){
      float diff = fabsf((A[idx] - B[idx])/B[idx]);
      if(verbose){
        printf("[%ld][%ld] A: %+e  LU: %+e  diff: %+e  (idx: %ld)\n",
               iglobal,j,A[idx],B[idx],diff,idx);
      }
      if(diff > TOL){
        printf("ABOVE TOL: [%ld][%ld] A: %+e  LU: %+e  diff: %+e  (idx: %ld)\n",
               iglobal,j,A[idx],B[idx],diff,idx);
        above_tol++;
      }
    }
  }
  size_t above_tol_total;
  MPI_Reduce(&above_tol, &above_tol_total, 1, MPI_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
  if(proc_rank==0){
    printf("%lu entries above tolerance %+e\n", above_tol_total, TOL);
  }
  free(B);
  return 0;
}
