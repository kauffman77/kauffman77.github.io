// pthread_sum_array.c: demonstrates a common pattern of dividing a
// shared data structure like an array among threads to work on the
// data in parallel.  Shows how to use a parameter to the thread
// function, a work_context_t in this case, to pass a unique integer ID
// like 0,1,2,... to each thread which is then used to determine which
// part of the data the thrad will use for its portion of the
// computation. Also passes shared data and a lock to protect it.

#include <stdio.h>
#include <stdlib.h> 
#include <pthread.h>
#include <sys/time.h>

// Look mah, no globals!

// "Context" struct to carry needed data to a worker thread
typedef struct {                                 // struct giving info to each thread
  int thread_id;                                 // thread's logical id numbered 0,1,2,...
  int num_threads;                               // number of threads that will cooperate
  double *array;                                 // shared array among all threads
  long array_len;                                // length of the array set on command line
  pthread_mutex_t *lock;                         // lock to control access to total_sum
  double *total_sum;                             // pointer to overall sum, shared var
} work_context_t;


void *workfunc(void *arg){                        // thread worker function
  work_context_t *context =
    (work_context_t*) arg;                        // caste parameter to context
  work_context_t ctx = *context;
  long start = ctx.thread_id;                     // where this thread start in the array, based on its ID
  long stride = ctx.num_threads;                  // step by number of threads

  double my_sum = 0.0;                            // local sum for this thread's portion of the array
  for(long i=start; i<ctx.array_len; i+=stride){
    my_sum += ctx.array[i];
  }
  printf("Thread %d sum is %.1f\n", ctx.thread_id, my_sum);

  // CRITICAL REGION
  pthread_mutex_lock(ctx.lock);                   // lock the shared data
  *ctx.total_sum += my_sum;                       // update it
  pthread_mutex_unlock(ctx.lock);                 // unlock
  return NULL;
}

void *workfunc_alt(void *arg){                    // ALTERANATE thread worker function, 
  work_context_t *context =
    (work_context_t*) arg;                        // caste parameter to context
  work_context_t ctx = *context;                  // alternate method of dividing array among threads
  long count = (ctx.array_len / ctx.num_threads); // how many elements each thread should sum up
  long start = ctx.thread_id*count;               // where this thread start in the array, based on its ID
  long stop  = (ctx.thread_id+1)*count;           // where this thread should stop
  if(ctx.thread_id == ctx.num_threads-1){         // last thread goes to end of array in case 
    stop = ctx.array_len;                         // the array length is not evenly divisible by num_threads
  }
  printf("Thread %d summing elements %d to %d\n",
         ctx.thread_id,start,stop);

  double my_sum = 0.0;                           // local sum for this thread's portion of the array
  for(long i=start; i<stop; i++){
    my_sum += ctx.array[i];
  }
  printf("Thread %d sum is %.1f\n", ctx.thread_id, my_sum);

  // CRITICAL REGION
  pthread_mutex_lock(ctx.lock);             // lock the shared data
  *ctx.total_sum += my_sum;                 // update it
  pthread_mutex_unlock(ctx.lock);           // unlock
  return NULL;
}

// For collecting timing
struct timeval beg_time, end_time;

void timing_start(){
  gettimeofday(&beg_time, NULL);
}

double timing_stop(){
  gettimeofday(&end_time, NULL);
  double wall_time = 
    ((end_time.tv_sec-beg_time.tv_sec)) + 
    ((end_time.tv_usec-beg_time.tv_usec) / 1000000.0);
  return wall_time;             // real-world time
}

int main(int argc, char *argv[]) { 
  if(argc < 3){
    printf("usage: %s <array_len> <num_threads>\n",argv[0]);
    printf("  array_len:   int, length of the array to sum\n");
    printf("  num_threads: int, number of threads to use for the computation\n");
    return -1;
  }

  int array_len = atoi(argv[1]);                 // set globals from command line
  int num_threads = atoi(argv[2]);

  double *array = malloc(sizeof(double)*array_len);
  for(int i=0; i<array_len; i++){
    array[i] = 1.0;                              // all 1.0 to make it easy to determine correctness
  }

  timing_start();

  pthread_mutex_t lock;                          // lock to control access to shared total_sum
  pthread_mutex_init(&lock,NULL);                
  double total_sum = 0.0;                         // overall sum for all threads, control access with lock

  pthread_t threads[num_threads];                // structs for tracking each thread and
  work_context_t context[num_threads];           // passing each thread its own parameters

  for(int i=0; i<num_threads; i++){              
    context[i].thread_id = i;                    // give a unique ID
    context[i].num_threads = num_threads;
    context[i].array = array;
    context[i].array_len = array_len;
    context[i].lock = &lock;                     // pointers to lock and 
    context[i].total_sum = &total_sum;           // shared data it protects

    pthread_create(&threads[i],NULL,             // launch each thread
                   workfunc, &context[i]);
  }

  for(int i=0; i<num_threads; i++){              // wait for each thread to finish
    pthread_join(threads[i], (void **) NULL);
  }
  double wall_time = timing_stop();

  printf("total_sum: %.1f\n",total_sum);
  printf("wall_time: %10.3f\n",wall_time);

  free(array);
  pthread_mutex_destroy(&lock);

  return 0;
}
