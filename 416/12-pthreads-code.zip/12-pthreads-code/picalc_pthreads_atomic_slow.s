	.file	"picalc_pthreads_atomic_slow.c"
	.text
	.globl	compute_pi
	.type	compute_pi, @function
compute_pi:
.LFB23:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$40, %rsp
	.cfi_def_cfa_offset 64
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	imull	$123456789, %edi, %edi
	movl	%edi, 20(%rsp)
	movl	$0, %ebx
	jmp	.L2
.L3:
	addl	$1, %ebx
.L2:
	cmpl	%ebx, points_per_thread(%rip)
	jle	.L9
	leaq	20(%rsp), %rbp
	movq	%rbp, %rdi
	call	rand_r@PLT
	pxor	%xmm0, %xmm0
	cvtsi2sdl	%eax, %xmm0
	divsd	.LC0(%rip), %xmm0
	movsd	%xmm0, 8(%rsp)
	movq	%rbp, %rdi
	call	rand_r@PLT
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%eax, %xmm1
	divsd	.LC0(%rip), %xmm1
	movsd	8(%rsp), %xmm0
	mulsd	%xmm0, %xmm0
	mulsd	%xmm1, %xmm1
	addsd	%xmm1, %xmm0
	movsd	.LC1(%rip), %xmm1
	comisd	%xmm0, %xmm1
	jb	.L3
	lock addl	$1, total_hits(%rip)
	jmp	.L3
.L9:
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L10
	movl	$0, %eax
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L10:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE23:
	.size	compute_pi, .-compute_pi
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC2:
	.string	"usage: %s <num_samples> [num_threads]\n"
	.align 8
.LC3:
	.string	"  num_samples: int, how many sample points to try, higher gets closer to pi"
	.align 8
.LC4:
	.string	"  num_threads: int, number of threads to use for the computation, default 4"
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC6:
	.string	"npoints: %8d\n"
.LC7:
	.string	"hits:    %8d\n"
.LC8:
	.string	"pi_est:  %f\n"
	.text
	.globl	main
	.type	main, @function
main:
.LFB24:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rsi, %r12
	movq	%fs:40, %rax
	movq	%rax, -56(%rbp)
	xorl	%eax, %eax
	movq	%rsp, %r15
	cmpl	$1, %edi
	jle	.L22
	movl	%edi, %ebx
	movq	8(%rsi), %rdi
	movl	$10, %edx
	movl	$0, %esi
	call	__isoc23_strtol@PLT
	movq	%rax, -72(%rbp)
	movl	%eax, %r14d
	cmpl	$2, %ebx
	jg	.L23
	movl	$4, %r12d
.L14:
	movl	%r14d, %eax
	cltd
	idivl	%r12d
	movl	%eax, points_per_thread(%rip)
	movslq	%r12d, %rax
	leaq	15(,%rax,8), %rax
	andq	$-16, %rax
	subq	%rax, %rsp
	movq	%rsp, %r13
	movl	$0, %eax
.L15:
	movslq	%r12d, %rdx
	cmpq	%rax, %rdx
	jle	.L24
	leaq	1(%rax), %rbx
	leaq	0(%r13,%rax,8), %rdi
	movq	%rbx, %rcx
	leaq	compute_pi(%rip), %rdx
	movl	$0, %esi
	call	pthread_create@PLT
	movq	%rbx, %rax
	jmp	.L15
.L22:
	movq	(%rsi), %rsi
	leaq	.LC2(%rip), %rdi
	call	printf@PLT
	leaq	.LC3(%rip), %rdi
	call	puts@PLT
	leaq	.LC4(%rip), %rdi
	call	puts@PLT
	movl	$-1, %eax
	jmp	.L11
.L23:
	movq	16(%r12), %rdi
	movl	$10, %edx
	movl	$0, %esi
	call	__isoc23_strtol@PLT
	movl	%eax, %r12d
	jmp	.L14
.L24:
	movl	$0, %ebx
.L17:
	cmpl	%ebx, %r12d
	jle	.L25
	movslq	%ebx, %rax
	movq	0(%r13,%rax,8), %rdi
	movl	$0, %esi
	call	pthread_join@PLT
	addl	$1, %ebx
	jmp	.L17
.L25:
	movl	total_hits(%rip), %eax
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%eax, %xmm1
	pxor	%xmm0, %xmm0
	cvtsi2sdl	-72(%rbp), %xmm0
	divsd	%xmm0, %xmm1
	mulsd	.LC5(%rip), %xmm1
	movq	%xmm1, %rbx
	movl	%r14d, %esi
	leaq	.LC6(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movl	total_hits(%rip), %esi
	leaq	.LC7(%rip), %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	%rbx, %xmm0
	leaq	.LC8(%rip), %rdi
	movl	$1, %eax
	call	printf@PLT
	movq	%r15, %rsp
	movl	$0, %eax
.L11:
	movq	-56(%rbp), %rdx
	subq	%fs:40, %rdx
	jne	.L26
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_remember_state
	.cfi_def_cfa 7, 8
	ret
.L26:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE24:
	.size	main, .-main
	.globl	points_per_thread
	.data
	.align 4
	.type	points_per_thread, @object
	.size	points_per_thread, 4
points_per_thread:
	.long	-1
	.globl	total_hits
	.bss
	.align 4
	.type	total_hits, @object
	.size	total_hits, 4
total_hits:
	.zero	4
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC0:
	.long	-4194304
	.long	1105199103
	.align 8
.LC1:
	.long	0
	.long	1072693248
	.align 8
.LC5:
	.long	0
	.long	1074790400
	.ident	"GCC: (GNU) 15.2.1 20260209"
	.section	.note.GNU-stack,"",@progbits
