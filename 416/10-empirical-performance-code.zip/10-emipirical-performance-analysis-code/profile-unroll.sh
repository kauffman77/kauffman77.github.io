#!/bin/bash

# remove old files
rm -f gmon.out unroll

# Compile
# -pg : instrument code for profiling
# -Og : debug level optimization
# -g  : include debug symbols
gcc -pg -g -Og -o unroll unroll.c

# May need to add the following depending on compiler version
# -no-pie : bug fix for new-ish gcc's

# show source and executable
ls

# run program
./unroll 1000000000

# show that gmon.out has been produced
ls

# show type of file for gmon.out
file gmon.out

# examine profile for unroll
gprof -b unroll
